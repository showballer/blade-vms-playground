// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#include <IO/DeviceCommunication/AllCommunication.h>
#include <IO/DeviceCommunication/Detail/StringConverter.h>
#include <IO/DeviceCommunication/Utils/CommandList.h>
#include <IO/DeviceCommunication/Utils/DeviceList.h>
#include <IO/DeviceCommunication/Utils/ItemList.h>

#include <iostream>
#include <numeric>
#include <thread>

using namespace Polytec::IO;
using namespace std::chrono_literals;

namespace
{
	struct InvalidArgsUsage : public std::exception {};

	DeviceCommunication OpenCommunication(int argc, char** argv);
	void SelectVelocityRange(DeviceCommunication& communication);
	std::wstring QueryRangeFromUser();
	void AutofocusIfAvailable(DeviceCommunication& communication);
	bool HasSensorHead(const DeviceCommunication& communication);
	bool HasAutofocus(const DeviceCommunication& communication);
	void WaitUntillAutofocusStopped(const DeviceCommunication& communication);
	std::wstring ToCommaSeparatedList(const std::vector<std::wstring>& items);
}

/// [main]
int main(int argc, char** argv)
{
	try
	{
		// Create a serial communication with the device based on command line arguments provided
		auto communication = OpenCommunication(argc, argv);
		
		// Let the user pick a velocity range
		SelectVelocityRange(communication);
		
		// Send command to turn on the laser
		if (HasSensorHead(communication))
			communication.SendSet<int16_t>(PTCDeviceType_SensorHead, PTCDeviceCommand_LaserOn, 1);
		else
			std::wcout << L"Sensor head not connected." << std::endl;
		
		// Autofocus the laser (if supported by the connected device)
		AutofocusIfAvailable(communication);
	}
	catch (const InvalidArgsUsage&)
	{
		std::wcout << L"Usage:\n";
		std::wcout << argv[0] << L" Serial COM-port baud_rate\n";
		std::wcout << argv[0] << L" Network device_ip\n";
		std::wcout << std::flush;
	}
	catch (const std::exception& e)
	{
		std::wcout << "Error: " << e.what() << std::endl;
	}
}
/// [main]

namespace
{
	/// <summary>Opens a serial or network communication based on the command line arguments.</summary>
	/// <param name="argc">The command line argument count.</param>
	/// <param name="argv">[in] The command line argument vector.</param>
	/// <returns>A communication handle, 0 if invalid.</returns>
	/// [OpenCommunication]
	DeviceCommunication OpenCommunication(int argc, char** argv)
	{
		if (argc == 4 && std::string(argv[1]) == "Serial")
		{
			const auto comPort = ToWString(argv[2]);
			const int baudRate = std::stoi(argv[3]);
			return CreateSerialCommunication(comPort, baudRate, 1s);
		}
		else if (argc == 3 && std::string(argv[1]) == "Network")
		{
			const auto deviceAddress = ToWString(argv[2]);
			return CreateUdpEthernetCommunication(deviceAddress, 1s);
		}
		else
		{
			throw InvalidArgsUsage();
		}
	}
	/// [OpenCommunication]

	/// <summary>
	/// This function prints a list of available velocity ranges to stdout and lets the user choose
	/// one range by index.
	/// </summary>
	/// <param name="communication">The device communication instance.</param>
	/// [SelectVelocityRange]
	void SelectVelocityRange(DeviceCommunication& communication)
	{
		ItemList range(communication, PTCDeviceType_VelocityDecoderDigital, PTCDeviceCommand_Range);
		
		// Print all velocity ranges from device
		std::wcout << L"Available items: " << ToCommaSeparatedList(range.GetAvailableItems()) << std::endl;

		// Get current velocity range setting from device
		std::wcout << L"Current range: " << range.GetCurrentItem() << std::endl;

		// Get range selection from user
		const auto selectedRange = QueryRangeFromUser();

		// Set new setting on device
		if (!range.IsItemAvailable(selectedRange))
		{
			throw std::runtime_error(
				ToString(L"\"" + selectedRange + L"\" is not an available range on the connected device."));
		}
		range.SetCurrentItem(selectedRange);
	}

	/// <summary>Queries a range to be set from the user.</summary>
	std::wstring QueryRangeFromUser()
	{
		std::wstring result;
		std::wcout << L"Select velocity range: " << std::flush;
		std::getline(std::wcin, result);
		return result;
	}
	/// [SelectVelocityRange]

	/// <summary>
	/// This function performs an autofocus and waits until the autofocus has finished.
	/// </summary>
	/// <param name="communication">The device communication instance.</param>
	void AutofocusIfAvailable(DeviceCommunication& communication)
	{
		if (!HasSensorHead(communication) || !HasAutofocus(communication))
		{
			std::wcout << L"Device has no autofocus." << std::endl;
			return;
		}

		// Send autofocus command to device
		std::wcout << L"Autofocus running..." << std::flush;
		communication.SendSet<int16_t>(PTCDeviceType_SensorHead, PTCDeviceCommand_Autofocus, 1);

		WaitUntillAutofocusStopped(communication);
		std::wcout << "\rAutofocus finished. " << std::endl;
	}

	/// <summary>Waits untill the autofocus has stopped.</summary>
	/// <param name="communication">The device communication instance.</param>
	void WaitUntillAutofocusStopped(const DeviceCommunication& communication)
	{
		while (communication.SendGet<int16_t>(PTCDeviceType_SensorHead, PTCDeviceCommand_Autofocus))
			std::this_thread::sleep_for(250ms);
	}

	/// <summary>Query if the device has a sensor head.</summary>
	/// <param name="communication">The device communication.</param>
	/// <returns>True if sensor head available.</returns>
	/// [HasDeviceAndCommand]
	bool HasSensorHead(const DeviceCommunication& communication)
	{
		return DeviceList(communication).HasDevice(PTCDeviceType_SensorHead);
	}

	/// <summary>Query if the sensor head has autofocus capabilities.</summary>
	/// <param name="communication">The communication.</param>
	/// <returns>True if autofocus, false if not.</returns>
	bool HasAutofocus(const DeviceCommunication& communication)
	{
		return CommandList(communication, PTCDeviceType_SensorHead).HasCommand(PTCDeviceCommand_Autofocus);
	}
	/// [HasDeviceAndCommand]

	std::wstring ToCommaSeparatedList(const std::vector<std::wstring>& items)
	{
		return std::accumulate(items.cbegin(), items.cend(), std::wstring(),
			[](const std::wstring& sum, const std::wstring& item)
		{
			return sum.empty() ? item : sum + L"," + item;
		});
	}
}
