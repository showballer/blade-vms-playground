// Copyright (c) 2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#include <IO/DeviceCommunication/DeviceCommunication.h>

void InteractiveConfiguration(Polytec::IO::DeviceCommunication& communication);
void PrintConfiguration(Polytec::IO::DeviceCommunication& communication);
