﻿// Copyright (c) 2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#include "GetConfig.h"

#include "Utils.h"

#include <IO/DeviceCommunication/Detail/StringConverter.h>
#include <IO/DeviceCommunication/Utils/ChannelActivation.h>
#include <IO/DeviceCommunication/Utils/CommandList.h>
#include <IO/DeviceCommunication/Utils/DeviceList.h>
#include <IO/DeviceCommunication/Utils/ItemList.h>

#include <iostream>
#include <regex>
#include <string>

using namespace Polytec::IO;

namespace
{
	double ParseFactor(std::wstring factor);
	double ParseUnit(std::wstring unit);
	double RangeInBaseUnit(DeviceCommunication& communication, PTCDeviceType decoderDevice);
	double UnitAndHeadRoomFactor(DeviceCommunication& communication, PTCDeviceType decoderDevice);
}

/// <summary>Query if the device has block mode.</summary>
/// <param name="communication">The device communication instance.</param>
/// <returns>True if it has block mode, false if not.</returns>
bool HasBlockMode(DeviceCommunication& communication)
{
	return CommandList(communication, PTCDeviceType_SignalProcessing).HasCommand(PTCDeviceCommand_DaqMode)
		? ItemList(communication, PTCDeviceType_SignalProcessing, PTCDeviceCommand_DaqMode).IsItemAvailable(L"Block")
		: false;
}

/// <summary>Query if the device is currently in IQ mode.</summary>
/// <param name="communication">The device communication instance.</param>
/// <returns>True if in IQ mode, false if not.</returns>
bool IQMode(DeviceCommunication& communication)
{
	return CommandList(communication, PTCDeviceType_Controller).HasCommand(PTCDeviceCommand_IQMode) &&
		communication.SendGet<int16_t>(PTCDeviceType_Controller, PTCDeviceCommand_IQMode, PTCMiscellaneousTag_StartUpValue) == 1;
}

/// <summary>Gets the bandwidth</summary>
/// <param name="communication">The device communication instance.</param>
/// <returns>The bandwidth.</returns>
std::wstring Bandwidth(DeviceCommunication& communication)
{
	return ItemList(communication, PTCDeviceType_VelocityDecoderDigital, PTCDeviceCommand_Bandwidth).GetCurrentItem();
}

/// <summary>Query if block mode is enabled.</summary>
/// <param name="communication">The device communication instance.</param>
/// <returns>True if block mode enabled, false if not.</returns>
bool BlockMode(DeviceCommunication& communication)
{
	if (!HasBlockMode(communication))
		return false;

	return ItemList(communication, PTCDeviceType_SignalProcessing, PTCDeviceCommand_DaqMode)
		.GetCurrentItem().compare(L"Block") == 0;
}

/// <summary>Gets the block size.</summary>
/// <param name="communication">The device communication instance.</param>
/// <returns>The block size.</returns>
int BlockSize(DeviceCommunication& communication)
{
	return communication.SendGet<int32_t>(PTCDeviceType_SignalProcessing, PTCDeviceCommand_DaqBlockSize);
}

/// <summary>Gets the block count.</summary>
/// <param name="communication">The device communication instance.</param>
/// <returns>The block count.</returns>
int BlockCount(DeviceCommunication& communication)
{
	return communication.SendGet<int16_t>(PTCDeviceType_SignalProcessing, PTCDeviceCommand_DaqBlockCount);
}

/// <summary>Gets the frequency factor. See PrintBaseSampleInfo for further information.</summary>
/// <param name="communication">The device communication instance.</param>
/// <returns>The frequency factor.</returns>
int FrequencyFactor(DeviceCommunication& communication)
{
	// test command set
	CommandList commandList(communication, PTCDeviceType_SignalProcessing);
	if (!commandList.HasCommand(PTCDeviceCommand_DaqBaseSampleRate) ||
		!commandList.HasCommand(PTCDeviceCommand_DaqSampleRate))
	{
		return 1;
	}

	// calculate and return frequency factor
	return communication.SendGet<int32_t>(PTCDeviceType_SignalProcessing, PTCDeviceCommand_DaqSampleRate)
		/ communication.SendGet<int32_t>(PTCDeviceType_SignalProcessing, PTCDeviceCommand_DaqBaseSampleRate);
}

/// <summary>Gets trigger mode.</summary>
/// <param name="communication">The device communication instance.</param>
/// <returns>The trigger mode.</returns>
std::wstring TriggerMode(DeviceCommunication& communication)
{
	return ItemList(communication, PTCDeviceType_SignalProcessing, PTCDeviceCommand_DaqTriggerMode)
		.GetCurrentItem();
}

/// <summary>Gets the trigger edge.</summary>
/// <param name="communication">The device communication instance.</param>
/// <returns>The trigger edge.</returns>
std::wstring TriggerEdge(DeviceCommunication& communication)
{
	return ItemList(communication, PTCDeviceType_SignalProcessing, PTCDeviceCommand_DaqTriggerEdge).GetCurrentItem();
}

/// <summary>Gets the analog trigger channel.</summary>
/// <param name="communication">The device communication instance.</param>
/// <returns>The analog trigger channel.</returns>
std::wstring AnalogTriggerChannel(DeviceCommunication& communication)
{
	return ItemList(communication, PTCDeviceType_SignalProcessing, PTCDeviceCommand_DaqAnalogTriggerSource).GetCurrentItem();
}

/// <summary>Gets the analog trigger level.</summary>
/// <param name="communication">The device communication instance.</param>
/// <returns>The analog trigger level.</returns>
float AnalogTriggerLevel(DeviceCommunication& communication)
{
	return communication.SendGet<float>(PTCDeviceType_SignalProcessing, PTCDeviceCommand_DaqAnalogTriggerLevel);
}

/// <summary>Query if the gated trigger is enabled.</summary>
/// <param name="communication">The device communication instance.</param>
/// <returns>True if gated trigger is enabled, false if not.</returns>
bool GatedTrigger(DeviceCommunication& communication)
{
	return communication.SendGet<int16_t>(PTCDeviceType_SignalProcessing, PTCDeviceCommand_DaqGatedTrigger);
}

/// <summary>Gets the pre-/post-trigger.</summary>
/// <param name="communication">The device communication instance.</param>
/// <returns>The pre-/post-trigger.</returns>
int PrePostTrigger(DeviceCommunication& communication)
{
	return communication.SendGet<int32_t>(PTCDeviceType_SignalProcessing, PTCDeviceCommand_DaqPreTrigger);
}

/// <summary>Gets the unit of a channel.</summary>
/// <param name="communication">The device communication instance.</param>
/// <param name="channelType">The channel type.</param>
/// <returns>The unit.</returns>
std::wstring ChannelUnit(PTCChannelType channelType)
{
	switch (channelType)
	{
		case PTCChannelType_Velocity:
			return L"m/s";
		case PTCChannelType_Displacement:
			return L"m";
		case PTCChannelType_Acceleration:
			return L"m/s²";
		case PTCChannelType_RSSI:
			return L"%";
		case PTCChannelType_Trigger:
		case PTCChannelType_DataValidity:
			return L"bool";
		default:
			return L"";
	}
}

/// <summary>Gets the channel scale factor.</summary>
/// <param name="communication">The device communication instance.</param>
/// <param name="channelType">The channel type.</param>
/// <returns>The scale factor.</returns>
/// [ChannelScalefactor]
double ChannelScaleFactor(DeviceCommunication& communicationHandle,
	DataAcquisition& acquisition, PTCChannelType channelType)
{
	int maxValue = acquisition.ChannelMaxValue(channelType);

	switch (channelType)
	{
		case PTCChannelType_Velocity:
			return UnitAndHeadRoomFactor(communicationHandle, PTCDeviceType_VelocityDecoderDigital) / maxValue;
		case PTCChannelType_Displacement:
			return UnitAndHeadRoomFactor(communicationHandle, PTCDeviceType_DisplacementDecoderDigital) / maxValue;
		case PTCChannelType_Acceleration:
			return UnitAndHeadRoomFactor(communicationHandle, PTCDeviceType_AccelerationDecoderDigital) / maxValue;
		case PTCChannelType_RSSI:
			return 100. / maxValue;
		default:
			return 1. / maxValue;
	}
}

namespace
{
	/// <summary>Gets the unit and head room factor for a signal channel.</summary>
	/// <param name="communicationHandle">Handle of the communication.</param>
	/// <param name="decoderDevice">The decoder device to retrieve the information from.</param>
	/// <returns>A multiplicable factor.</returns>
	double UnitAndHeadRoomFactor(DeviceCommunication& communication, PTCDeviceType decoderDevice)
	{
		return communication.SendGet<float>(decoderDevice, PTCDeviceCommand_HeadroomDigitalOut)
			* RangeInBaseUnit(communication, decoderDevice);
	}

	/// <summary>Gets the current signal range in its respective base unit (m, m/s, m/s²).</summary>
	/// <param name="communication">The device communication instance.</param>
	/// <param name="decoderDevice">The decoder device to retrieve the information from.</param>
	/// <returns>The current range in its respective base unit.</returns>
	double RangeInBaseUnit(DeviceCommunication& communication, PTCDeviceType decoderDevice)
	{
		const auto currentRangeItem = ItemList(communication, decoderDevice,
			PTCDeviceCommand_Range).GetCurrentItem();
		std::wsmatch matches;
		std::regex_search(currentRangeItem, matches,
			std::wregex(LR"(([-+]?[0-9]+\.?[0-9]*)\s*·?(10[³⁶⁹])?\s*(\S*))"));
		return std::stof(matches[1]) * ParseFactor(matches[2]) * ParseUnit(matches[3]);
	}
}
/// [ChannelScalefactor]

namespace
{
	/// <summary>Parse the factor to a multiplicable factor.</summary>
	/// <param name="unit">The factor received from the device.</param>
	/// <returns>A multiplicable factor.</returns>
	double ParseFactor(std::wstring factor)
	{
		if (factor.compare(L"") == 0)
			return 1;
		else if (factor.compare(L"10³") == 0)
			return 1000;
		else if (factor.compare(L"10⁶") == 0)
			return 1000LL * 1000;
		else if (factor.compare(L"10⁹") == 0)
			return 1000LL * 1000 * 1000;
		else
			throw std::runtime_error("Unknown factor received from device: " + ToString(factor));
	}

	/// <summary>Parse the unit to a multiplicable factor.</summary>
	/// <param name="unit">The unit received from the device.</param>
	/// <returns>A multiplicable factor.</returns>
	double ParseUnit(std::wstring unit)
	{
		if (unit.find(L"nm") != std::wstring::npos)
			return 1. / (1000LL * 1000 * 1000);
		else if (unit.find(L"µm") != std::wstring::npos)
			return 1. / (1000LL * 1000);
		else if (unit.find(L"mm") != std::wstring::npos)
			return 1. / 1000;
		else if (unit.find(L"km") != std::wstring::npos)
			return 1000;
		else if (unit.compare(L"m/s²") == 0 || unit.compare(L"m/s") == 0 || unit.compare(L"m") == 0)
			return 1;
		else
			throw std::runtime_error("Unknown unit received from device: " + ToString(unit));
	}
}