// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#include "ChannelList.h"
#include "GetConfig.h"
#include "InteractiveUserConfig.h"
#include "Utils.h"
#include "WriteDataToCsv.h"

#include <IO/DeviceCommunication/AllCommunication.h>
#include <IO/DeviceCommunication/Detail/StringConverter.h>
#include <IO/DeviceCommunication/Utils/ItemList.h>
#include <IO/DataAcquisition/AllAcquisition.h>

#include <chrono>
#include <fstream>
#include <iostream>

using namespace Polytec::IO;
using namespace std::chrono_literals;

namespace
{
	constexpr int c_samplesToReadAtOnce = 250;

	struct ProgramOptions
	{
		std::wstring IpAddress;
		std::wstring OperationMode;
		int SampleCount = 0;
	};

	struct InvalidArgsUsage : public std::exception {};

	void PrintUsage(std::string programName);
	ProgramOptions ParseArguments(int argc, char** argv);
	void SetupDataAcquisition(DeviceCommunication& communication, const ProgramOptions programOptions);
	void AcquireData(DeviceCommunication& communication, DataAcquisition& acquisition, int sampleCount);
	void AcquireAndWriteBlockToCsv(DataAcquisition& acquisition, std::map<Channel, ChannelData>& channels,
		const std::string dateTime, int blockId, int blockSize, int frequencyFactor, int prePostTrigger);
	void SetBlockSize(DeviceCommunication& communication, int blockSize);
	void WaitForTrigger(DeviceCommunication& communication, DataAcquisition& acquisition);
}

/// [main]
int main(int argc, char** argv)
{
	try
	{
		// Handle the command line interface
		const auto programOptions = ParseArguments(argc, argv);

		// Calculate buffer size (for streaming the buffer should
		// be able to hold all data expected to be acquired)
		const std::size_t bufferCapacity = programOptions.OperationMode.compare(L"Streaming") == 0
			? programOptions.SampleCount
			: 10 * c_samplesToReadAtOnce;

		// Open a network communication and data acquisition connection with the device
		auto communication = CreateUdpEthernetCommunication(programOptions.IpAddress);
		auto acquisition = CreateDigitalDataAcquisition(communication, bufferCapacity);

		// Check IQ mode
		FailIf(IQMode(communication), "This example does not support IQ mode (would require other data interpretation)");

		// Stop any possibly running acquisition (some settings
		// cannot be manipulated during an active data acquisition)
		acquisition.StopAcquisition();

		// Check for interactive config mode
		if (programOptions.OperationMode.compare(L"Config") == 0)
		{
			// Perform an interactive configuration
			InteractiveConfiguration(communication);
		}
		else
		{
			// Setup and print configuration
			SetupDataAcquisition(communication, programOptions);
			PrintConfiguration(communication);

			// Start the acquisition stream on the device
			acquisition.StartAcquisition();

			// Read the received data and write it to a file
			AcquireData(communication, acquisition, programOptions.SampleCount);

			// Stop the acquisition stream on the device
			acquisition.StopAcquisition();
		}
	}
	catch (const InvalidArgsUsage&)
	{
		PrintUsage(argv[0]);
		return EXIT_FAILURE;
	}
	catch (std::exception& e)
	{
		std::wcerr << L"ERROR: " << e.what() << std::endl;
		return EXIT_FAILURE;
	}

	return EXIT_SUCCESS;
}
/// [main]

namespace
{
	/// <summary>Print usage.</summary>
	/// <param name="programName">Name of the program.</param>
	void PrintUsage(std::string programName)
	{
		std::wcout << L"Usage:" << std::endl;
		std::cout << programName << " <IP-address> Config" << std::endl;
		std::cout << programName << " <IP-address> Streaming <BaseSampleCount>" << std::endl;
		std::cout << programName << " <IP-address> Block <BlockSize>" << std::endl;
		std::wcout << Divider() << std::endl;
		std::wcout << L"Streaming: Data will be streamed directly from the device without any trigger handling.";
		std::wcout << std::endl;
		std::wcout << L"Block (not available on IVS-500 and VGO-200 devices): In block mode data is acquired and delivered in blocks. ";
		std::wcout << L"This will also give you further options to setup and configure a triggered data acquisition on the device. ";
		std::wcout << L"If a trigger is enabled, the trigger will be used for each block individually. Block acquisition can be especially ";
		std::wcout << L"useful if the bandwidth of your connection to the device is lower than the bandwidth of the acquired signal, as the ";
		std::wcout << L"complete data block can be acquired and buffered on the device while being delivered over the slower connection.";
		std::wcout << std::endl;
		std::wcout << L"Note that data streaming can lead to buffer overflows within the device when used with high bandwidths and/or a ";
		std::wcout << L"large number of active channels as the throughput might be limited by the bandwidth of your network connection. ";
		std::wcout << L"Block mode data acquisition is only limited by the buffer space available on the device (see block size).";
		std::wcout << std::endl;
		std::wcout << Divider() << std::endl;
		std::wcout << L"Sample count and block size are specified as so-called base samples. Base samples are related to the ";
		std::wcout << L"base sample rate of your device as it is the lowest common denominator for all channel sample rates. ";
		std::wcout << L"In order to determine the sample count for a signal (Velocity, ...) or trigger channel you have to multiply the base ";
		std::wcout << L"sample count with the factor of the channel and base sample rate (the so called frequency factor). ";
		std::wcout << L"Use the DAQ base sample rate and DAQ sample rate commands to retrieve your devices sample rates in Hz and ";
		std::wcout << L"calculate the frequency factor.";
		std::wcout << std::endl;
	}

	/// <summary>Parse the command line arguments.</summary>
	/// <param name="argc">The argument count.</param>
	/// <param name="argv">[in] The argument vector.</param>
	ProgramOptions ParseArguments(int argc, char** argv)
	{
		if (argc < 3)
			throw InvalidArgsUsage();

		ProgramOptions programOptions;
		programOptions.IpAddress = ToWString(argv[1]);
		programOptions.OperationMode = ToWString(argv[2]);

		if (argc == 4 && (programOptions.OperationMode.compare(L"Block") == 0
			|| programOptions.OperationMode.compare(L"Streaming") == 0))
		{
			programOptions.SampleCount = std::atoi(argv[3]);
			FailIf(programOptions.SampleCount <= 0, "Sample count / block size has to be a positive integer value.");
		}
		else if (argc != 3 || programOptions.OperationMode.compare(L"Config") != 0)
		{
			throw InvalidArgsUsage();
		}

		return programOptions;
	}

	/// <summary>Sets up the data acquisition.</summary>
	/// <param name="communication">The device communication instance.</param>
	/// <param name="daqMode">The DAQ mode.</param>
	/// <param name="blockSize">Size of a block in base samples (only applied in block mode).</param>
	/// [SetupDataAcquisition]
	void SetupDataAcquisition(DeviceCommunication& communication, const ProgramOptions programOptions)
	{
		const bool isBlockMode = programOptions.OperationMode.compare(L"Block") == 0;
		if (HasBlockMode(communication))
		{
			ItemList(communication, PTCDeviceType_SignalProcessing, PTCDeviceCommand_DaqMode)
				.SetCurrentItem(programOptions.OperationMode);
			if (isBlockMode)
				SetBlockSize(communication, programOptions.SampleCount);
		}
		else
		{
			FailIf(isBlockMode, "This device does not support block mode.");
		}
	}

	/// <summary>Set the block size.</summary>
	/// <param name="communication">The device communication instance.</param>
	/// <param name="blockSize">The block size in base samples.</param>
	void SetBlockSize(DeviceCommunication& communication, int blockSize)
	{
		const auto range = communication.SendGetDevInfo<std::vector<int32_t>>(
			Device{PTCDeviceType_SignalProcessing}, PTCDeviceCommand_DaqBlockSize);
		if (range.size() != 2)
			throw CommunicationException(PTCCommunicationStatusCode_InvalidResponseFormat);
		FailIf(blockSize < range[0] || blockSize > range[1],
			"Specified block size is not within the allowed range.");
		communication.SendSet<int32_t>(PTCDeviceType_SignalProcessing,
			PTCDeviceCommand_DaqBlockSize, blockSize);
	}
	/// [SetupDataAcquisition]

	/// <summary>Acquires incoming data and writes it to CSV files.</summary>
	/// <param name="communication">The device communication instance.</param>
	/// <param name="acquisition">The data acquisition instance.</param>
	/// <param name="sampleCount">Number of samples to be acquired in base samples
	/// 						  (used per block if block mode).</param>
	/// [AcquireData]
	void AcquireData(DeviceCommunication& communication, DataAcquisition& acquisition, int sampleCount)
	{
		const std::string dateTime = GetDateTime();
		const bool isBlockMode = BlockMode(communication);
		const int blockCount = isBlockMode ? BlockCount(communication) : 1;
		const int frequencyFactor = FrequencyFactor(communication);
		const int prePostTrigger = isBlockMode ? PrePostTrigger(communication) : 0;

		FailIf(blockCount == 0, "Endless block mode (blockCount=0) is not supported "
			"by this example. Configure a block count > 0.");

		auto channels = CreateChannelList(communication, acquisition);

		// acquire and write data block by block (single block on streaming)
		for (int blockId = 0; blockId < blockCount; blockId++)
		{
			if (isBlockMode) WaitForTrigger(communication, acquisition);
			AcquireAndWriteBlockToCsv(acquisition, channels, dateTime, blockId, sampleCount,
				frequencyFactor, prePostTrigger);
			if (isBlockMode) acquisition.NextDataAcquisitionBlock();
		}

		std::wcout << L"Acquisition completed" << std::endl;
	}

	/// <summary>Wait for triggerd data if a trigger has been enabled.</summary>
	/// <param name="communication">The device communication instance.</param>
	/// <param name="acquisitionHandle">The data acquisition instance.</param>
	void WaitForTrigger(DeviceCommunication& communication, DataAcquisition& acquisition)
	{
		// only wait if there is a trigger active
		if (TriggerMode(communication).compare(L"None") != 0)
		{
			std::wcout << L"Waiting for trigger...\r" << std::flush;
			while (acquisition.AvailableSamples() == 0);
		}
	}
	/// [AcquireData]

	/// <summary>Acquires a data acquisition block and writes it to a CSV file.</summary>
	/// <param name="acquisition">The data acquisition instance.</param>
	/// <param name="fileStream">The CSV file stream.</param>
	/// <param name="channels">The channels map.</param>
	/// <param name="blockSize">Size of the block to be acquired and written.</param>
	/// <param name="frequencyFactor">The frequency factor.</param>
	/// <param name="prePostTrigger">The pre/post trigger value.</param>
	/// [AcquireAndWriteBlockToCsv]
	void AcquireAndWriteBlockToCsv(DataAcquisition& acquisition, std::map<Channel, ChannelData>& channels,
		const std::string dateTime, int blockId, int blockSize, int frequencyFactor, int prePostTrigger)
	{
		// generate filename and open file
		std::string fileName = dateTime + " AcquisitionData" + std::to_string(blockId) + ".csv";
		std::wofstream fileStream(fileName);
		FailIf(!fileStream.is_open(), "Error opening file.");

		WriteCsvHeaders(fileStream, channels);

		const double sampleInterval = 1 / (acquisition.BaseSampleRateInHz() * frequencyFactor);
		double baseSamplesWritten = 0;

		for (int baseSamplesStillToBeRead = blockSize; baseSamplesStillToBeRead > 0;
			baseSamplesStillToBeRead -= c_samplesToReadAtOnce)
		{
			const size_t baseSampleCount = std::min(c_samplesToReadAtOnce, baseSamplesStillToBeRead);
			const auto measurementData = acquisition.ReadData(baseSampleCount, 1s);

			// copy data from all channels to buffers in the channels map
			for (auto& [channel, channelData] : channels)
			{
				const auto channelSampleCount = measurementData.SampleCount(channel);
				channelData.Samples = measurementData.template Get<int>(channel);
				if (IsSignalChannel(channel.Type()))
					channelData.Overrange = measurementData.template GetOverrange<uint8_t>(channel);
			}

			const double chunkTimestamp = ((baseSamplesWritten * frequencyFactor) - prePostTrigger) * sampleInterval;
			WriteDataToCsv(fileStream, channels, baseSampleCount, frequencyFactor, chunkTimestamp, sampleInterval);
			baseSamplesWritten += baseSampleCount;
		}

		std::wcout << blockSize << L" base samples written to \"";
		std::wcout << ToWString(fileName) << L"\"" << std::endl;
	}
	/// [AcquireAndWriteBlockToCsv]
}
