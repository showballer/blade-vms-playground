// Copyright (c) 2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#include "InteractiveUserConfig.h"

#include "GetConfig.h"
#include "Utils.h"

#include <IO/DeviceCommunication/AllCommunication.h>
#include <IO/DeviceCommunication/Utils/CommandList.h>
#include <IO/DeviceCommunication/Utils/DeviceList.h>
#include <IO/DeviceCommunication/Utils/ItemList.h>
#include <IO/DeviceCommunication/Utils/ChannelActivation.h>

#include <iostream>

namespace
{
	void PrintActiveChannels(DeviceCommunication& communication);
	void PrintFrequencyFactor(DeviceCommunication& communication);

	void UserSelectBandwidth(DeviceCommunication& communication);
	void UserSelectChannelActivation(DeviceCommunication& communication);
	void UserSelectActiveOutputChannel(DeviceCommunication& communication);
	void UserSelectBlockCount(DeviceCommunication& communication);
	std::wstring UserSelectTriggerMode(DeviceCommunication& communication);
	void UserSelectTriggerEdge(DeviceCommunication& communication);
	void UserSelectAnalogTriggerChannel(DeviceCommunication& communication);
	void UserSelectAnalogTriggerLevel(DeviceCommunication& communication);
	void UserSelectGatedTrigger(DeviceCommunication& communication);
	void UserSelectPrePostTrigger(DeviceCommunication& communication);

	std::wstring ListToString(const std::vector<std::wstring>& items)
	{
		std::wstringstream ss;
		auto separator = L"";
		for (const auto& item : items)
		{
			ss << separator;
			ss << item;
			separator = L", ";
		}
		return ss.str();
	}
}

/// <summary>Performs an interactive configuration with the user using the command line.</summary>
/// <param name="communication">The device communication instance.</param>
void InteractiveConfiguration(DeviceCommunication& communication)
{
	UserSelectBandwidth(communication);

	if (CommandList(communication, PTCDeviceType_SignalProcessing).HasCommand(PTCDeviceCommand_DaqActiveChannels))
	{
		// configure channels if desired
		if (IsYes(GetUserInput(L"Do you wish to configure the active channels? (y/N): ")))
			UserSelectChannelActivation(communication);
	}
	else if (CommandList(communication, PTCDeviceType_VelocityDecoderDigital).HasCommand(PTCDeviceCommand_OutputActive))
	{
		// always, as there is only a single channel to be configured
		UserSelectActiveOutputChannel(communication);
	}

	if (HasBlockMode(communication))
	{
		// configure block mode if desired
		if (IsYes(GetUserInput(L"Do you wish to configure the block mode (e.g. trigger)? (y/N): ")))
		{
			UserSelectBlockCount(communication);

			// trigger configuration
			auto triggerMode = UserSelectTriggerMode(communication);
			if (triggerMode.compare(L"None") != 0)
			{
				UserSelectTriggerEdge(communication);
				if (triggerMode.compare(L"Analog") == 0)
				{
					UserSelectAnalogTriggerChannel(communication);
					UserSelectAnalogTriggerLevel(communication);
					UserSelectGatedTrigger(communication);
				}
				UserSelectPrePostTrigger(communication);
			}
		}
	}
	std::wcout << Divider() << std::endl;
	std::wcout << "Configuration completed" << std::endl;
}

/// <summary>Print the current device configuration.</summary>
/// <param name="communication">The device communication instance.</param>
void PrintConfiguration(DeviceCommunication& communication)
{
	std::wcout << L"Bandwidth: " << Bandwidth(communication) << std::endl;
	PrintFrequencyFactor(communication);
	PrintActiveChannels(communication);

	if (HasBlockMode(communication) && BlockMode(communication))
	{
		std::wcout << L"Block size: " << BlockSize(communication) << std::endl;
		std::wcout << L"Block count: " << BlockCount(communication) << std::endl;

		const auto triggerMode = TriggerMode(communication);
		std::wcout << "Trigger mode: " << triggerMode << std::endl;

		if (triggerMode.compare(L"None") != 0)
		{
			std::wcout << L"Trigger edge: " << TriggerEdge(communication) << std::endl;
			if (triggerMode.compare(L"Analog") == 0)
			{
				std::wcout << L"Analog trigger channel: " << AnalogTriggerChannel(communication) << std::endl;
				std::wcout << L"Analog trigger level: " << AnalogTriggerLevel(communication) << std::endl;
				std::wcout << L"Gated trigger: " << (GatedTrigger(communication) ? L"enabled" : L"disabled") << std::endl;
			}
			std::wcout << L"Pre-/Post-Trigger: " << PrePostTrigger(communication) << std::endl;
		}
	} else
	{
		std::wcout << L"Acquisition mode: Streaming" << std::endl;
	}
	std::wcout << Divider() << std::endl;
}

namespace
{
	/// <summary>Print all active channels.</summary>
	/// <param name="communication">The device communication instance.</param>
	void PrintActiveChannels(DeviceCommunication& communication)
	{
		std::map<PTCChannelType, std::vector<int>> activeChannels;
		for (const auto& channel : ActiveChannels(communication))
			activeChannels[channel.Type()].push_back(channel.Number());
		for (const auto& [channelType, channelIds] : activeChannels)
		{
			std::wcout << L"\t" << ChannelTypeToName(channelType) << ": [";
			for (const auto& channelId : channelIds)
				std::wcout << L" " << channelId;
			std::wcout << L" ]" << std::endl;
		}
	}

	/// <summary>Print an info text about base samples and frequency factor.</summary>
	/// <param name="communication">The device communication instance.</param>
	void PrintFrequencyFactor(DeviceCommunication& communication)
	{
		CommandList commandList(communication, PTCDeviceType_SignalProcessing);

		if (commandList.HasCommand(PTCDeviceCommand_DaqBaseSampleRate))
		{
			const int baseSampleRate = communication.SendGet<int32_t>(PTCDeviceType_SignalProcessing, PTCDeviceCommand_DaqBaseSampleRate);
			int daqSampleRate = baseSampleRate;
			if (commandList.HasCommand(PTCDeviceCommand_DaqSampleRate))
			{
				daqSampleRate = communication.SendGet<int32_t>(PTCDeviceType_SignalProcessing, PTCDeviceCommand_DaqSampleRate);
			}
			std::wcout << "Frequency factor: " << daqSampleRate << " Hz / "
				<< baseSampleRate << " Hz = " << daqSampleRate / baseSampleRate << std::endl;
		}
	}

	/// <summary>Let the user select the device bandwidth.</summary>
	/// <param name="communication">The device communication instance.</param>
	/// <returns>True if channels need to be reconfigured, false if not.</returns>
	void UserSelectBandwidth(DeviceCommunication& communication)
	{
		ItemList bandwidth(communication, PTCDeviceType_VelocityDecoderDigital, PTCDeviceCommand_Bandwidth);

		// print available bandwidths
		std::wcout << Divider() << std::endl;
		std::wcout << L"Available bandwidths: ";
		std::wcout << ListToString(bandwidth.GetAvailableItems());
		std::wcout << std::endl;
		const auto currentItem = bandwidth.GetCurrentItem();
		
		// query user
		std::wstringstream userPrompt;
		userPrompt << L"Select one of the bandwidths above [" << currentItem << L"]: ";
		auto userInput = GetUserInput(userPrompt.str());
		
		// set bandwidth
		if (userInput.compare(L"") != 0 && userInput.compare(currentItem) != 0)
			bandwidth.SetCurrentItem(userInput);
	}

	/// <summary>Let the user select the channels to be enabled.</summary>
	/// <remarks>Use this function if the device supports the channel activation command.</remarks>
	/// <param name="communication">The device communication instance.</param>
	void UserSelectChannelActivation(DeviceCommunication& communication)
	{
		std::wcout << Divider() << std::endl;
		std::wcout << L"Channel activation information: Channel availability is dependent on bandwidth and enabled channels. ";
		std::wcout << L"Enabling a channel of type Velocity, Displacement or Acceleration or setting a high bandwidth (e.g. 24 MHz) ";
		std::wcout << L"might limit the availability of other signal channels.";
		std::wcout << std::endl;

		ChannelActivation channelActivation(communication);

		// start with all channels disabled
		channelActivation.DisableAllChannels();

		// go through all channel types and let the user enable each channel one by one
		for (const auto& channelType : channelActivation.GetAllSupportedChannelTypes())
		{
			std::wstringstream userPrompt;
			bool isChannelAvaialble = false;
			const int maxChannelCount = channelActivation.GetMaxChannelCount(channelType);

			// query user for each channel to be enabled if available
			for (int channelId = 0; channelId < maxChannelCount; ++channelId) {
				auto activeIds = channelActivation.GetActiveChannels(channelType);
				if (channelActivation.GetAvailableChannelCount(channelType) - std::size(activeIds) > 0)
				{
					userPrompt << L"Enable " << ChannelTypeToName(channelType);
					userPrompt << L" channel " << channelId << L" (Y/n): ";
					if (!IsNo(GetUserInput(userPrompt.str())))
					{
						activeIds.push_back(channelId);
						channelActivation.SetActiveChannels(channelType, activeIds);
					}
				}
			}
		}
	}

	/// <summary>Let the user select the active output channel on a device.</summary>
	/// <remarks>Use this function if the device does not support the channel activation command.</remarks>
	/// <param name="communication">The device communication instance.</param>
	void UserSelectActiveOutputChannel(DeviceCommunication& communication)
	{
		DeviceList deviceList(communication);

		// get available channels
		bool hasDisplacement = deviceList.HasDevice(PTCDeviceType_DisplacementDecoderDigital);
		bool hasAcceleration = deviceList.HasDevice(PTCDeviceType_AccelerationDecoderDigital);

		// do not prompt the user if there is only a velocity channel
		if (!hasDisplacement && !hasAcceleration)
			return;

		// get currently selected channel
		auto currentValue = [&communication, hasDisplacement, hasAcceleration]() -> std::wstring {
			if (!CommandList(communication, PTCDeviceType_VelocityDecoderDigital).HasCommand(PTCDeviceCommand_OutputActive)
				|| communication.SendGet<int16_t>(PTCDeviceType_VelocityDecoderDigital, PTCDeviceCommand_OutputActive))
			{
				return ChannelTypeToName(PTCChannelType_Velocity);
			}
			else if (hasDisplacement && communication.SendGet<int16_t>(
				PTCDeviceType_DisplacementDecoderDigital, PTCDeviceCommand_OutputActive))
			{
				return ChannelTypeToName(PTCChannelType_Displacement);
			}
			else if (hasAcceleration && communication.SendGet<int16_t>(
				PTCDeviceType_AccelerationDecoderDigital, PTCDeviceCommand_OutputActive))
			{
				return ChannelTypeToName(PTCChannelType_Acceleration);
			}
			return L"";
		}();

		// query user
		std::wstringstream userPrompt;
		userPrompt << L"Select active output channel (";
		userPrompt << "Velocity";
		if (hasDisplacement) userPrompt << ", Displacement";
		if (hasAcceleration) userPrompt << ", Acceleration";
		userPrompt << L") [" << currentValue << L"]: ";
		const auto userInput = GetUserInput(userPrompt.str());

		// set selected channel if specified
		if (userInput.compare(L"") != 0)
		{
			if (userInput.compare(L"Velocity") == 0)
				communication.SendSet<int16_t>(PTCDeviceType_VelocityDecoderDigital, PTCDeviceCommand_OutputActive, 1);
			else if (userInput.compare(L"Displacement") == 0 && hasDisplacement)
				communication.SendSet<int16_t>(PTCDeviceType_DisplacementDecoderDigital, PTCDeviceCommand_OutputActive, 1);
			else if (userInput.compare(L"Acceleration") == 0 && hasAcceleration)
				communication.SendSet<int16_t>(PTCDeviceType_AccelerationDecoderDigital, PTCDeviceCommand_OutputActive, 1);
			else
				FailIf(true, "Invalid input");
		}
	}

	/// <summary>Let the user select the block count.</summary>
	/// <param name="communication">The device communication instance.</param>
	void UserSelectBlockCount(DeviceCommunication& communication)
	{
		// get the current block count and range
		const auto currentValue = communication.SendGet<int16_t>(
			PTCDeviceType_SignalProcessing, PTCDeviceCommand_DaqBlockCount);
		auto range = communication.SendGetDevInfo<std::vector<int16_t>>(
			PTCDeviceType_SignalProcessing, PTCDeviceCommand_DaqBlockCount);

		// 0 = endless mode, endless mode is not supported in this example
		if (range[0] < 1)
			range[0] = 1;

		// query user
		std::wstringstream userPrompt;
		userPrompt << L"Specify the amount of blocks to be acquired between ";
		userPrompt << range[0] << L" and " << range[1];
		userPrompt << L" [" << (currentValue == 0 ? 1 : currentValue) << L"]: ";
		const auto userInput = GetUserInput(userPrompt.str());

		// set block count if specified
		if (userInput.compare(L"") != 0)
		{
			const int16_t blockCount = std::stoi(userInput);
			FailIf(blockCount < range[0] || blockCount > range[1],
				"Specified block count is not within the allowed range.");
			communication.SendSet<int16_t>(PTCDeviceType_SignalProcessing,
				PTCDeviceCommand_DaqBlockCount, blockCount);
		}
		else if (currentValue == 0)
		{
			// make sure block count is not set to 0 (endless mode)
			communication.SendSet<int16_t>(PTCDeviceType_SignalProcessing,
				PTCDeviceCommand_DaqBlockCount, 1);
		}
	}

	/// <summary>Let the user select the trigger mode.</summary>
	/// <param name="communication">The device communication instance.</param>
	/// <param name="triggerMode">[out] The selected trigger mode.</param>
	/// <param name="bufferSize">Size of the trigger mode buffer.</param>
	std::wstring UserSelectTriggerMode(DeviceCommunication& communication)
	{
		ItemList triggerMode(communication, PTCDeviceType_SignalProcessing, PTCDeviceCommand_DaqTriggerMode);
		auto currentItem = triggerMode.GetCurrentItem();

		// query user
		std::wstringstream userPrompt;
		userPrompt << L"Select trigger mode (";
		userPrompt << ListToString(triggerMode.GetAvailableItems());
		userPrompt << L") [" << currentItem << L"]: ";
		const auto userInput = GetUserInput(userPrompt.str());

		// set trigger mode if specified
		if (userInput.compare(L"") != 0)
		{
			triggerMode.SetCurrentItem(userInput);
			currentItem = userInput;
		}
		
		return currentItem;
	}

	/// <summary>Let the user select the trigger edge.</summary>
	/// <param name="communication">The device communication instance.</param>
	void UserSelectTriggerEdge(DeviceCommunication& communication)
	{
		ItemList triggerEdge(communication, PTCDeviceType_SignalProcessing, PTCDeviceCommand_DaqTriggerEdge);

		// query user
		std::wstringstream userPrompt;
		userPrompt << L"Trigger edge (";
		userPrompt << ListToString(triggerEdge.GetAvailableItems());
		userPrompt << L") [" << triggerEdge.GetCurrentItem() << L"]: ";
		const auto userInput = GetUserInput(userPrompt.str());

		// set trigger edge if specified
		if (userInput.compare(L"") != 0)
			triggerEdge.SetCurrentItem(userInput);
	}

	/// <summary>Let the user select the analog trigger channel.</summary>
	/// <param name="communication">The device communication instance.</param>
	void UserSelectAnalogTriggerChannel(DeviceCommunication& communication)
	{
		ItemList triggerSource(communication, PTCDeviceType_SignalProcessing, PTCDeviceCommand_DaqAnalogTriggerSource);
		const auto availableItems = triggerSource.GetAvailableItems();

		// do not prompt user if there is only one channel to choose from
		if (std::size(availableItems) <= 1)
			return;

		// query user
		std::wstringstream userPrompt;
		userPrompt << L"Analog trigger channel (";
		userPrompt << ListToString(availableItems);
		userPrompt << L") [" << triggerSource.GetCurrentItem() << L"]: ";
		const auto userInput = GetUserInput(userPrompt.str());

		// set analog trigger channel if specified
		if (userInput.compare(L"") != 0)
			triggerSource.SetCurrentItem(userInput);
	}

	/// <summary>Let the user select the analog trigger level.</summary>
	/// <param name="communication">The device communication instance.</param>
	void UserSelectAnalogTriggerLevel(DeviceCommunication& communication)
	{
		// get the current analog trigger level and range
		const auto currentValue = communication.SendGet<float>(
			PTCDeviceType_SignalProcessing, PTCDeviceCommand_DaqAnalogTriggerLevel);
		const auto range = communication.SendGetDevInfo<std::vector<float>>(
			PTCDeviceType_SignalProcessing, PTCDeviceCommand_DaqAnalogTriggerLevel);

		std::wcout << L"Analog trigger level is specified as a factor of the trigger "
			L"channel (e.g. Velocity) maximum amplitude." << std::endl;

		// query user
		std::wstringstream userPrompt;
		userPrompt << L"Specify an analog trigger level between ";
		userPrompt << std::fixed << std::setprecision(2) << range[0] << L" and ";
		userPrompt << std::fixed << std::setprecision(2) << range[1];
		userPrompt << L" [" << std::fixed << std::setprecision(2) << currentValue << L"]: ";
		const auto userInput = GetUserInput(userPrompt.str());

		// set analog trigger level if specified
		if (userInput.compare(L"") != 0)
		{
			const float analogtriggerLevel = std::stof(userInput);
			FailIf(analogtriggerLevel < range[0] || analogtriggerLevel > range[1],
				"Specified trigger level is not within the allowed range.");
			communication.SendSet<float>(PTCDeviceType_SignalProcessing,
				PTCDeviceCommand_DaqAnalogTriggerLevel, analogtriggerLevel);
		}
	}

	/// <summary>Let the user enable/disable the gated trigger.</summary>
	/// <param name="communication">The device communication instance.</param>
	void UserSelectGatedTrigger(DeviceCommunication& communication)
	{
		std::wcout << Divider() << std::endl;
		std::wcout << L"Using a trigger mode other than the external trigger (e.g. analog) gives you the option to enable ";
		std::wcout << L"the so-called gated trigger. With the gated trigger enabled, the external trigger signal is used as ";
		std::wcout << L"a gate for the other trigger signal. This means that the active trigger (e.g. analog) only triggers ";
		std::wcout << L"on a trigger event, if call there is also a high signal on the external trigger.";
		std::wcout << std::endl;

		// query user and set gated trigger
		std::wstringstream userPrompt;
		userPrompt << L"Enable gated trigger (y/n) [";
		userPrompt << (communication.SendGet<int16_t>(PTCDeviceType_SignalProcessing,
			PTCDeviceCommand_DaqGatedTrigger) == 0 ? L"No" : L"Yes");
		userPrompt << L"]: ";
		const auto userInput = GetUserInput(userPrompt.str());

		// set gated trigger if specified
		if (userInput.compare(L"") != 0)
			communication.SendSet<int16_t>(PTCDeviceType_SignalProcessing, PTCDeviceCommand_DaqGatedTrigger, IsYes(userInput) ? 1 : 0);
	}

	/// <summary>Let the user select the pre-/post-trigger.</summary>
	/// <param name="communication">The device communication instance.</param>
	void UserSelectPrePostTrigger(DeviceCommunication& communication)
	{
		std::wcout << Divider() << std::endl;
		std::wcout << L"Setting a pre/post-trigger shifts the trigger position relative to the beginning of the acquired data. ";
		std::wcout << L"Its value is specified in signal samples (related to the acquisition sample rate of the signal channels, ";
		std::wcout << L"e.g. Velocity)";
		std::wcout << std::endl;
		std::wcout << L"=0: default, no pre/post-trigger will be acquired and the trigger position will be on the first sample acquired.";
		std::wcout << std::endl;
		std::wcout << L">0: pre-trigger, the specified amount of samples will be acquired in advance to the trigger position.";
		std::wcout << std::endl;
		std::wcout << L"<0: post-trigger, the specified amount of samples will skipped and not acquired after the trigger position.";
		std::wcout << std::endl;
		std::wcout << L"This setting has no effect on the block size specified above.puts";
		std::wcout << std::endl;

		// get the current pre-/post-trigger and range
		const auto currentValue = communication.SendGet<int32_t>(
			PTCDeviceType_SignalProcessing, PTCDeviceCommand_DaqPreTrigger);
		const auto range = communication.SendGetDevInfo<std::vector<int32_t>>(
			PTCDeviceType_SignalProcessing, PTCDeviceCommand_DaqPreTrigger);

		// query user
		std::wstringstream userPrompt;
		userPrompt << L"Specify a pre/post-trigger between ";
		userPrompt << range[0] << L" and " << range[1];
		userPrompt << L" (signal samples) [" << currentValue << L"]: ";
		const auto userInput = GetUserInput(userPrompt.str());

		// set pre-/post-trigger if specified
		if (userInput.compare(L"") != 0)
		{
			const int32_t prePostTrigger = std::stoi(userInput);
			FailIf(prePostTrigger < range[0] || prePostTrigger > range[1],
				"Specified pre-/post-trigger is not within the allowed range.");
			communication.SendSet<int32_t>(PTCDeviceType_SignalProcessing,
				PTCDeviceCommand_DaqPreTrigger, prePostTrigger);
		}
	}
}