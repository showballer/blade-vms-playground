﻿// Copyright (c) 2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#pragma once

#include "ChannelList.h"

#include <IO/DataAcquisition/DataAcquisition.h>
#include <IO/DeviceCommunication/DeviceCommunication.h>

void WriteCsvHeaders(std::wostream& fileStream, std::map<Channel, ChannelData>& channels);
void WriteDataToCsv(std::wostream& fileStream, std::map<Channel, ChannelData>& channels,
	size_t baseSampleCount, int frequencyFactor, double chunkTimestamp, double daqSampleInterval);