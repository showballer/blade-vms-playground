﻿// Copyright (c) 2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#pragma once

#include <IO/DataAcquisition/Channel.h>
#include <IO/DataAcquisition/DataAcquisition.h>
#include <IO/DeviceCommunication/DeviceCommunication.h>

#include <map>
#include <vector>

using namespace Polytec::IO;

/// <summary>Additional channel data used for the acquisition and conversion of the channels data.</summary>
struct ChannelData
{
	double ScaleFactor{};
	std::wstring Unit;
	std::vector<int> Samples;
	std::vector<uint8_t> Overrange;
};

std::map<Channel, ChannelData> CreateChannelList(DeviceCommunication& communication, DataAcquisition& acquisition);