﻿// Copyright (c) 2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#include "WriteDataToCsv.h"

#include "GetConfig.h"
#include "Utils.h"

#include <IO/DataAcquisition/MeasurementData.h>

#include <algorithm>

/// <summary>Print the CSV header row.</summary>
/// <param name="fileStream">The CSV file stream.</param>
/// <param name="channels">The channels map.</param>
void WriteCsvHeaders(std::wostream& fileStream, std::map<Channel, ChannelData>& channels)
{
	fileStream << L"Timestamp (s)";
	for (const auto& [channel, channelData] : channels)
	{
		// DataValidity is not outputed to the CSV file
		if (channel.Type() == PTCChannelType_DataValidity)
			continue;

		fileStream << L";" << ChannelTypeToName(channel.Type()) << L" " << channel.Number() << L" (" << channelData.Unit << L")";
		if (IsSignalChannel(channel.Type()))
			fileStream << L";" << ChannelTypeToName(channel.Type()) << L" " << channel.Number() << L" (Overrange)";
	}
	fileStream << std::endl;
}

/// <summary>Writes the acquired data to a CSV file.</summary>
/// <param name="fileStream">The CSV file stream.</param>
/// <param name="channels">The channels map.</param>
/// <param name="baseSampleCount">Number of base samples to be written to the CSV file.</param>
/// <param name="frequencyFactor">The frequency factor.</param>
/// <param name="chunkTimestamp">The timestamp to use for the first sample of this chunk seconds.</param>
/// <param name="daqSampleInterval">The time between DAQ samples (not base samples).</param>
void WriteDataToCsv(std::wostream& fileStream, std::map<Channel, ChannelData>& channels,
	size_t baseSampleCount, int frequencyFactor, double chunkTimestamp, double daqSampleInterval)
{
	// print samples row by row (single sample from each channel)
	for (size_t n = 0; n < baseSampleCount; n++)
	{
		for (int i = 0; i < frequencyFactor; i++)
		{
			// write timestamp
			fileStream << std::scientific << std::setprecision(8);
			fileStream << chunkTimestamp + (n * frequencyFactor + i) * daqSampleInterval;

			for (const auto& [channel, channelData] : channels)
			{
				// RSSI samples use the base sample rate
				const int index = channel.Type() == PTCChannelType_RSSI ? n : n * frequencyFactor + i;

				if (channel.Type() == PTCChannelType_DataValidity)
				{
					// check data validity, invalid samples indicate lost samples
					FailIf(!channelData.Samples[index], "Lost data packet.");

					// skip printing to CSV
					continue;
				}

				// Important: numeric formatting can be a bottleneck,
				// consider writing binary data for high performance applications
				if (channel.Type() == PTCChannelType_Trigger)
					fileStream << L";" << channelData.Samples[index];
				else
				{
					fileStream << std::scientific << std::setprecision(8);
					fileStream << L";" << channelData.ScaleFactor * channelData.Samples[index];
					if (IsSignalChannel(channel.Type()))
						fileStream << L";" << channelData.Overrange[index];
				}
			}
			fileStream << std::endl;
		}
	}
}
