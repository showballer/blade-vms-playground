﻿// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#pragma once

#include <IO/DeviceCommunication/DeviceCommunication.h>
#include <IO/DataAcquisition/DataAcquisition.h>

using namespace Polytec::IO;

bool HasBlockMode(DeviceCommunication& communication);
bool IQMode(DeviceCommunication& communication);

std::wstring Bandwidth(DeviceCommunication& communication);
bool BlockMode(DeviceCommunication& communication);
int BlockSize(DeviceCommunication& communication);
int BlockCount(DeviceCommunication& communication);
int FrequencyFactor(DeviceCommunication& communication);
std::wstring TriggerMode(DeviceCommunication& communication);
std::wstring TriggerEdge(DeviceCommunication& communication);
std::wstring AnalogTriggerChannel(DeviceCommunication& communication);
float AnalogTriggerLevel(DeviceCommunication& communication);
bool GatedTrigger(DeviceCommunication& communication);
int PrePostTrigger(DeviceCommunication& communication);

double ChannelScaleFactor(DeviceCommunication& communication, DataAcquisition& acquisition, PTCChannelType channelType);
std::wstring ChannelUnit(PTCChannelType channelType);
