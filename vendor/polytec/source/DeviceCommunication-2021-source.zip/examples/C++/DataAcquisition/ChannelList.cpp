﻿// Copyright (c) 2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#include "ChannelList.h"

#include <IO/DeviceCommunication/Utils/ChannelActivation.h>

#include "GetConfig.h"

namespace
{
	ChannelData GetChannelData(DeviceCommunication& communication, DataAcquisition& acquisition, PTCChannelType channelType)
	{
		ChannelData channelData;
		channelData.ScaleFactor = ChannelScaleFactor(communication, acquisition, channelType);
		channelData.Unit = ChannelUnit(channelType);
		return channelData;
	}
}

/// <summary>Creates a map with additional data for all channels active on the device.</summary>
/// <param name="communication">The device communication instance.</param>
/// <param name="acquisition">The data acquisition instance.</param>
/// <returns>A map of all available channels and additional data.</returns>
std::map<Channel, ChannelData> CreateChannelList(DeviceCommunication& communication, DataAcquisition& acquisition)
{
	std::map<Channel, ChannelData> channels;
	for (const auto& channel : ActiveChannels(communication))
		channels.try_emplace(channel, GetChannelData(communication, acquisition, channel.Type()));
	return channels;
}
