// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#pragma once

#include <IO/DataAcquisition/PolyDataAcquisition.h>
#include <IO/DeviceCommunication/Detail/StringConverter.h>
#include <IO/DeviceCommunication/PolyDeviceCommunication.h>

#include <iomanip>
#include <iostream>
#include <string>
#include <sstream>

/// <summary>Fail if condition evaluates true.</summary>
/// <param name="condition">The fail condition.</param>
/// <param name="message">[in] The error message to be printed on fail.</param>
static void FailIf(bool condition, std::string message)
{
	if (condition)
		throw std::runtime_error(message);
}

/// <summary>Returns a divider string.</summary>
static std::wstring Divider()
{
	return L"--------------------------------------------------------------------------------";
}

/// <summary>Gets user input.</summary>
/// <param name="query">User query.</param>
/// <returns>The user input.</returns>
static std::wstring GetUserInput(const std::wstring query)
{
	std::wstring userInput;
	std::wcout << Divider() << std::endl;
	std::wcout << L">>> " << query;
	getline(std::wcin, userInput);
	return userInput;
}

/// <summary>Query if user input is yes.</summary>
/// <param name="userInput">The user input.</param>
/// <returns>True if yes, false if not.</returns>
static bool IsYes(std::wstring userInput)
{
	return userInput[0] == L'y' || userInput[0] == L'Y';
}

/// <summary>Query if user input is no.</summary>
/// <param name="userInput">The user input.</param>
/// <returns>True if no, false if not.</returns>
static bool IsNo(std::wstring userInput)
{
	return userInput[0] == L'n' || userInput[0] == L'N';
}

/// <summary>Channel type to channel name.</summary>
/// <param name="channelType">The channel type.</param>
/// <returns>The channel type name.</returns>
static std::wstring ChannelTypeToName(PTCChannelType channelType)
{
	switch (channelType)
	{
		case PTCChannelType_Velocity:
			return L"Velocity";
		case PTCChannelType_Acceleration:
			return L"Acceleration";
		case PTCChannelType_Displacement:
			return L"Displacement";
		case PTCChannelType_RSSI:
			return L"RSSI";
		case PTCChannelType_Trigger:
			return L"Trigger";
		case PTCChannelType_DataValidity:
			return L"DataValidity";
		default:
			throw std::runtime_error("Unknown channel type: " + std::to_string(channelType));
	}
}

/// <summary>Creates a string from the current date and time.</summary>
/// <param name="dateTimeString">The date time string.</param>
/// <param name="bufferSize">Size of the buffer.</param>
static std::string GetDateTime()
{
	std::stringstream ss;
	const time_t t = time(NULL);
	const struct tm tm = *localtime(&t);
	ss << std::put_time(&tm, "%Y-%m-%d %H%M%S");
	return ss.str();
}
