// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#pragma once

#if defined _WIN32
#include "Windows.h"
static void SleepMilliseconds(int milliseconds)
{
	Sleep(milliseconds);
}
#elif defined __unix__
#include <unistd.h>
static void SleepMilliseconds(int milliseconds)
{
	usleep(1000 * milliseconds);
}
#else
#error function not defined
#endif
