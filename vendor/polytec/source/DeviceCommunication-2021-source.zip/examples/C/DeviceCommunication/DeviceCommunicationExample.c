// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#include "Utils.h"

#include <IO/DeviceCommunication/PolyDeviceCommunication.h>

#include <stdio.h>
#include <string.h>

#define STRING_BUFFER_SIZE 1000

static PTCommunicationHandle OpenCommunication(int argc, char** argv);
static void SelectVelocityRange(PTCommunicationHandle communicationHandle);
static void QueryRangeFromUser(char* buffer, int bufferSize);
static bool IsRangeAvailable(PTCommunicationHandle communicationHandle, const char* selectedRange);
static void AutofocusIfAvailable(PTCommunicationHandle communicationHandle);
static bool HasSensorHead(PTCommunicationHandle communicationHandle);
static bool HasAutofocus(PTCommunicationHandle communicationHandle);
static void WaitUntilAutofocusStopped(PTCommunicationHandle communicationHandle);
static int16_t IsAutofocusRunning(PTCommunicationHandle communicationHandle);
static void CheckSuccess(PTCCommunicationStatusCode status);

/// [main]
int main(int argc, char**argv)
{
	// Open a network or serial communication with the device based on command line arguments provided
	const PTCommunicationHandle communicationHandle = OpenCommunication(argc, argv);

	// Let the user pick a velocity range
	SelectVelocityRange(communicationHandle);

	// Send command to turn on the laser
	if (HasSensorHead(communicationHandle))
		CheckSuccess(PolySendSetInt16(communicationHandle, PTCDeviceType_SensorHead, 0, PTCDeviceCommand_LaserOn, 1));
	else
		printf("Sensor head not connected.\n");

	// Autofocus the laser (if supported by the device connected)
	AutofocusIfAvailable(communicationHandle);

	// Close the communication
	PolyCloseCommunication(communicationHandle);

	return EXIT_SUCCESS;
}
/// [main]

/// <summary>Opens a serial or network communication based on the command line arguments.</summary>
/// <param name="argc">The command line argument count.</param>
/// <param name="argv">[in] The command line argument vector.</param>
/// <returns>A communication handle, 0 if invalid.</returns>
/// [OpenCommunication]
static PTCommunicationHandle OpenCommunication(int argc, char** argv)
{
	PTCommunicationHandle handle = 0;
	const int communicationTimeoutMs = 1000;

	if (argc == 4 && strcmp(argv[1], "Serial") == 0)
	{
		CheckSuccess(PolyOpenSerialCommunication(&handle, argv[2], atoi(argv[3]), communicationTimeoutMs));
	}
	else if (argc == 3 && strcmp(argv[1], "Network") == 0)
	{
		CheckSuccess(PolyOpenUdpEthernetCommunication(&handle, argv[2], communicationTimeoutMs));
	}
	else
	{
		printf("Usage:\n");
		printf("%s Serial COM-port baud_rate\n", argv[0]);
		printf("%s Network device_ip\n", argv[0]);
		exit(EXIT_FAILURE);
	}

	return handle;
}
/// [OpenCommunication]

/// <summary>
/// This function prints a list of available velocity ranges to stdout and lets the user choose
/// one range by index.
/// </summary>
/// <param name="communicationHandle">The device communication handle.</param>
/// [SelectVelocityRange]
static void SelectVelocityRange(PTCommunicationHandle communicationHandle)
{
	// Print all velocity ranges from device
	char rangeList[STRING_BUFFER_SIZE];
	CheckSuccess(PolyItemListGetAvailableItems(communicationHandle, PTCDeviceType_VelocityDecoderDigital, 0,
		PTCDeviceCommand_Range, rangeList, STRING_BUFFER_SIZE));
	printf("Available ranges: %s\n", rangeList);

	// Get current velocity range setting from device
	char currentRange[STRING_BUFFER_SIZE];
	CheckSuccess(PolyItemListGetCurrentItem(communicationHandle, PTCDeviceType_VelocityDecoderDigital, 0,
		PTCDeviceCommand_Range, currentRange, STRING_BUFFER_SIZE));
	printf("Current range: %s\n", currentRange);

	// Get range selection from user
	char selectedRange[STRING_BUFFER_SIZE];
	QueryRangeFromUser(selectedRange, STRING_BUFFER_SIZE);

	// Set new setting on device
	if (!IsRangeAvailable(communicationHandle, selectedRange))
	{
		printf("\"%s\" is not an available range on the connected device.\n", selectedRange);
		exit(EXIT_FAILURE);
	}
	CheckSuccess(PolyItemListSetCurrentItem(communicationHandle, PTCDeviceType_VelocityDecoderDigital, 0,
		PTCDeviceCommand_Range, selectedRange));
}

/// <summary>Queries a range to be set from the user.</summary>
/// <param name="buffer">[out] User input buffer.</param>
/// <param name="bufferSize">Size of the buffer.</param>
static void QueryRangeFromUser(char* buffer, int bufferSize)
{
	printf("Select velocity range: ");
	fflush(stdout);
	if (fgets(buffer, bufferSize, stdin) == NULL)
	{
		printf("Error: Invalid argument provided\n");
		exit(EXIT_FAILURE);
	}

	// Remove trailing newline
	char* pos = strchr(buffer, '\n');
	if (pos != NULL)
		*pos = '\0';
}

/// <summary>Checks if the specified range is available on the device.</summary>
/// <param name="communicationHandle">The device communication handle.</param>
/// <param name="range">The range to be checked for availability.</param>
/// <returns>True if the range is available, false if not.</returns>
static bool IsRangeAvailable(PTCommunicationHandle communicationHandle, const char* range)
{
	bool isAvailable = false;
	CheckSuccess(PolyItemListIsItemAvailable(communicationHandle, PTCDeviceType_VelocityDecoderDigital, 0,
		PTCDeviceCommand_Range, range, &isAvailable));
	return isAvailable;
}
/// [SelectVelocityRange]

/// <summary>This function performs an autofocus and waits until the autofocus has finished.</summary>
/// <param name="communicationHandle">The device communication handle.</param>
static void AutofocusIfAvailable(PTCommunicationHandle communicationHandle)
{
	if (!HasSensorHead(communicationHandle) || !HasAutofocus(communicationHandle))
	{
		printf("Device has no autofocus.\n");
		return;
	}
	// Send autofocus command to device
	printf("Autofocus running...");
	fflush(stdout);
	CheckSuccess(PolySendSetInt16(communicationHandle, PTCDeviceType_SensorHead, 0,
		PTCDeviceCommand_Autofocus, 1));

	WaitUntilAutofocusStopped(communicationHandle);
	printf("\rAutofocus finished. \n");
}

/// <summary>Waits untill the autofocus has stopped.</summary>
/// <param name="communicationHandle">The device communication handle.</param>
static void WaitUntilAutofocusStopped(PTCommunicationHandle communicationHandle)
{
	while (IsAutofocusRunning(communicationHandle))
	{
		SleepMilliseconds(250);
	}
}

/// <summary>Evaluates if the autofocus is running.</summary>
/// <returns>Returns 1 if it is running and 0 if not.</returns>
static int16_t IsAutofocusRunning(PTCommunicationHandle communicationHandle)
{
	int16_t running = -1;
	CheckSuccess(PolySendGetInt16(communicationHandle, PTCDeviceType_SensorHead, 0,
		PTCDeviceCommand_Autofocus, &running));
	return running;
}

/// <summary>Query if the device has a sensor head.</summary>
/// <param name="communicationHandle">The device communication handle.</param>
/// <returns>True if sensor head available.</returns>
/// [HasDeviceAndCommand]
static bool HasSensorHead(PTCommunicationHandle communicationHandle)
{
	bool hasSensorHead = false;
	CheckSuccess(PolyHasDevice(communicationHandle, PTCDeviceType_SensorHead, 0, &hasSensorHead));
	return hasSensorHead;
}

/// <summary>Query if the sensor head has autofocus capabilities.</summary>
/// <param name="communicationHandle">The communication.</param>
/// <returns>True if autofocus, false if not.</returns>
static bool HasAutofocus(PTCommunicationHandle communicationHandle)
{
	bool hasAutofocus = false;
	CheckSuccess(PolyHasCommand(communicationHandle, PTCDeviceType_SensorHead, 0,
		PTCDeviceCommand_Autofocus, &hasAutofocus));
	return hasAutofocus;
}
/// [HasDeviceAndCommand]

/// <summary>
/// Checks the success of a communication status code. If it is not successful the status
/// message is printed and the program is exited.
/// </summary>
/// <param name="status">The communication status code.</param>
/// [CheckSuccess]
static void CheckSuccess(PTCCommunicationStatusCode status)
{
	if (status == PTCCommunicationStatusCode_Success)
		return;

	char message[STRING_BUFFER_SIZE];
	PolyLastCommunicationStatus(message, STRING_BUFFER_SIZE);
	printf("Error: %s\n", message);
	exit(EXIT_FAILURE);
}
/// [CheckSuccess]
