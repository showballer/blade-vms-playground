// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#pragma once

#include <IO/DataAcquisition/PolyDataAcquisition.h>
#include <IO/DeviceCommunication/PolyDeviceCommunication.h>

#include <stdio.h>
#include <string.h>
#include <time.h>

#define STRING_BUFFER_SIZE 1024

/// <summary>
/// Checks the success of a communication status code. If it is not successful the status
/// message is printed and the program is exited.
/// </summary>
/// <param name="status">The communication status code.</param>
static void CheckSuccess(PTCCommunicationStatusCode status)
{
	if (status == PTCCommunicationStatusCode_Success)
		return;

	char message[256];
	PolyLastCommunicationStatus(message, 256);
	fprintf(stderr, "ERROR: %s\n", message);
	exit(EXIT_FAILURE);
}

/// <summary>Fail if condition evaluates true.</summary>
/// <param name="condition">The fail condition.</param>
/// <param name="message">[in] The error message to be printed on fail.</param>
static void FailIf(bool condition, const char message[])
{
	if (condition)
	{
		fprintf(stderr, "ERROR: %s\n", message);
		exit(EXIT_FAILURE);
	}
}

/// <summary>Print divider.</summary>
static void PrintDivider()
{
	puts("--------------------------------------------------------------------------------");
}

/// <summary>Gets user input.</summary>
/// <param name="query">[in] User query.</param>
/// <param name="userInputBuffer">[out] Buffer for user input data.</param>
/// <param name="bufferSize">Size of the input data buffer.</param>
static void GetUserInput(const char query[], char userInputBuffer[], int bufferSize)
{
	PrintDivider();
	printf(">>> %s", query);
	FailIf(fgets(userInputBuffer, bufferSize, stdin) == NULL, "Invalid input");
	userInputBuffer[strcspn(userInputBuffer, "\n")] = 0;
}

/// <summary>Query if user input is yes.</summary>
/// <param name="userInput">The user input.</param>
/// <returns>True if yes, false if not.</returns>
static bool IsYes(const char userInput[])
{
	return userInput[0] == 'y' || userInput[0] == 'Y';
}

/// <summary>Query if user input is no.</summary>
/// <param name="userInput">The user input.</param>
/// <returns>True if no, false if not.</returns>
static bool IsNo(const char userInput[])
{
	return userInput[0] == 'n' || userInput[0] == 'N';
}

/// <summary>Channel type to channel name.</summary>
/// <param name="channelType">The channel type.</param>
/// <returns>The channel type name..</returns>
static char* ChannelTypeToName(PTCChannelType channelType)
{
	switch (channelType)
	{
		case PTCChannelType_Velocity:
			return "Velocity";
		case PTCChannelType_Acceleration:
			return "Acceleration";
		case PTCChannelType_Displacement:
			return "Displacement";
		case PTCChannelType_RSSI:
			return "RSSI";
		case PTCChannelType_Trigger:
			return "Trigger";
		case PTCChannelType_DataValidity:
			return "DataValidity";
		default:
			fprintf(stderr, "ERROR: Unknown channel type %d\n", channelType);
			exit(EXIT_FAILURE);
	}
}

/// <summary>Query if the specified channel type is a signal channel type.</summary>
/// <param name="channelType">The channel type.</param>
/// <returns>True if signal channel, false if not.</returns>
static bool IsSignalChannel(PTCChannelType channelType)
{
	switch (channelType)
	{
		case PTCChannelType_Velocity:
		case PTCChannelType_Acceleration:
		case PTCChannelType_Displacement:
			return true;
		default:
			return false;
	}
}

/// <summary>Creates a string from the current date and time.</summary>
/// <param name="dateTimeString">The date time string.</param>
/// <param name="bufferSize">Size of the buffer.</param>
static void GetDateTime(char dateTimeString[], int bufferSize)
{
	const time_t t = time(NULL);
	const struct tm tm = *localtime(&t);
	FailIf(snprintf(dateTimeString, bufferSize, "%d-%02d-%02d %02d%02d%02d",
		tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday, tm.tm_hour, tm.tm_min, tm.tm_sec) <= 0, "String format error");
}
