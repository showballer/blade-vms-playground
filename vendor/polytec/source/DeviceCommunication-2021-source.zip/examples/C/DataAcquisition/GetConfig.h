﻿// Copyright (c) 2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#pragma once

#include <IO/DataAcquisition/PolyDataAcquisition.h>
#include <IO/DeviceCommunication/PolyDeviceCommunication.h>

bool HasCommand(PTCommunicationHandle communicationHandle, PTCDeviceType deviceType, PTCDeviceCommand deviceCommand);
bool HasBlockMode(PTCommunicationHandle communicationHandle);
bool IQMode(PTCommunicationHandle communicationHandle);

bool BlockMode(PTCommunicationHandle communicationHandle);
int BlockSize(PTCommunicationHandle communicationHandle);
int BlockCount(PTCommunicationHandle communicationHandle);
double BaseSampleRateInHz(PTAcquisitionHandle acquisitionHandle);
int FrequencyFactor(PTCommunicationHandle communicationHandle);
void TriggerMode(PTCommunicationHandle communicationHandle, char triggerMode[], int bufferSize);
float AnalogTriggerLevel(PTCommunicationHandle communicationHandle);
bool GatedTrigger(PTCommunicationHandle communicationHandle);
int PrePostTrigger(PTCommunicationHandle communicationHandle);

double ChannelScaleFactor(PTCommunicationHandle communicationHandle, PTAcquisitionHandle acquisitionHandle, PTCChannelType channelType);
char* ChannelUnit(PTCChannelType channelType);
