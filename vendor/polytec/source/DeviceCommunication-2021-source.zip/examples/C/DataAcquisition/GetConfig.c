﻿// Copyright (c) 2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#include "GetConfig.h"

#include "Utils.h"

#include <IO/DataAcquisition/PolyDataAcquisition.h>

#include <stdio.h>
#include <string.h>

static double ParseFactor(const char* factor);
static double ParseUnit(const char* unit);
static double RangeInBaseUnit(PTCommunicationHandle communicationHandle, PTCDeviceType decoderDevice);
static double UnitAndHeadRoomFactor(PTCommunicationHandle communicationHandle, PTCDeviceType decoderDevice);


/// <summary>Query if the command is available on a device.</summary>
/// <param name="communicationHandle">The communication handle.</param>
/// <returns>True if command available, false if not.</returns>
bool HasCommand(PTCommunicationHandle communicationHandle, PTCDeviceType deviceType, PTCDeviceCommand deviceCommand)
{
	bool hascommand = false;
	CheckSuccess(PolyHasCommand(communicationHandle, deviceType, 0, deviceCommand, &hascommand));
	return hascommand;
}

/// <summary>Query if the device has block mode.</summary>
/// <param name="communicationHandle">The communication handle.</param>
/// <returns>True if it has block mode, false if not.</returns>
bool HasBlockMode(PTCommunicationHandle communicationHandle)
{
	if (!HasCommand(communicationHandle, PTCDeviceType_SignalProcessing, PTCDeviceCommand_DaqMode))
		return false;

	bool hasBlockMode = false;
	CheckSuccess(PolyItemListIsItemAvailable(communicationHandle, PTCDeviceType_SignalProcessing, 0,
		PTCDeviceCommand_DaqMode, "Block", &hasBlockMode));
	return hasBlockMode;
}

/// <summary>Query if the device is currently in IQ mode.</summary>
/// <param name="communicationHandle">The communication handle.</param>
/// <returns>True if in IQ mode, false if not.</returns>
bool IQMode(PTCommunicationHandle communicationHandle)
{
	if (!HasCommand(communicationHandle, PTCDeviceType_Controller, PTCDeviceCommand_IQMode))
		return false;

	int payloadHandle = 0;
	int16_t iqMode = 0;
	CheckSuccess(PolySendGetWithTag(communicationHandle, PTCDeviceType_Controller, 0,
		PTCDeviceCommand_IQMode, PTCMiscellaneousTag_StartUpValue, &payloadHandle));
	CheckSuccess(PolyGetInt16FromPayload(payloadHandle, &iqMode, NULL, 1));
	PolyFreePayload(payloadHandle);
	return iqMode == 1;
}

/// <summary>Query if block mode is enabled.</summary>
/// <param name="communicationHandle">The communication handle.</param>
/// <returns>True if block mode enabled, false if not.</returns>
bool BlockMode(PTCommunicationHandle communicationHandle)
{
	if (!HasBlockMode(communicationHandle))
		return false;

	char daqMode[STRING_BUFFER_SIZE];
	CheckSuccess(PolyItemListGetCurrentItem(communicationHandle, PTCDeviceType_SignalProcessing, 0, PTCDeviceCommand_DaqMode, daqMode, sizeof(daqMode)));
	return strcmp(daqMode, "Block") == 0;
}

/// <summary>Gets the block size.</summary>
/// <param name="communicationHandle">The communication handle.</param>
/// <returns>The block size.</returns>
int BlockSize(PTCommunicationHandle communicationHandle)
{
	int blockSize = 0;
	CheckSuccess(PolySendGetInt32(communicationHandle, PTCDeviceType_SignalProcessing, 0,
		PTCDeviceCommand_DaqBlockSize, &blockSize));
	return blockSize;
}

/// <summary>Gets the block count.</summary>
/// <param name="communicationHandle">The communication handle.</param>
/// <returns>The block count.</returns>
int BlockCount(PTCommunicationHandle communicationHandle)
{
	int16_t blockCount = 0;
	CheckSuccess(PolySendGetInt16(communicationHandle, PTCDeviceType_SignalProcessing, 0,
		PTCDeviceCommand_DaqBlockCount, &blockCount));
	return blockCount;
}

/// <summary>Gets the base sample rate.</summary>
/// <param name="acquisitionHandle">The acquisition handle.</param>
/// <returns>The base sample rate.</returns>
double BaseSampleRateInHz(PTAcquisitionHandle acquisitionHandle)
{
	double baseSampleRate = 0;
	CheckSuccess(PolyBaseSampleRateInHz(acquisitionHandle, &baseSampleRate));
	return baseSampleRate;
}

/// <summary>Gets the frequency factor. See PrintBaseSampleInfo for further information.</summary>
/// <param name="communicationHandle">The communication handle.</param>
/// <returns>The frequency factor.</returns>
int FrequencyFactor(PTCommunicationHandle communicationHandle)
{
	// test command set
	if (!HasCommand(communicationHandle, PTCDeviceType_SignalProcessing, PTCDeviceCommand_DaqBaseSampleRate) ||
		!HasCommand(communicationHandle, PTCDeviceType_SignalProcessing, PTCDeviceCommand_DaqSampleRate))
	{
		return 1;
	}

	// calculate frequency factor
	int baseSampleRate = 0;
	int daqSampleRate = 0;
	CheckSuccess(PolySendGetInt32(communicationHandle, PTCDeviceType_SignalProcessing, 0, PTCDeviceCommand_DaqBaseSampleRate, &baseSampleRate));
	CheckSuccess(PolySendGetInt32(communicationHandle, PTCDeviceType_SignalProcessing, 0, PTCDeviceCommand_DaqSampleRate, &daqSampleRate));
	return daqSampleRate / baseSampleRate;
}

/// <summary>Gets trigger mode.</summary>
/// <param name="communicationHandle">The communication handle.</param>
/// <param name="triggerMode">The trigger mode string buffer.</param>
/// <param name="bufferSize">Size of the buffer.</param>
void TriggerMode(PTCommunicationHandle communicationHandle, char triggerMode[], int bufferSize)
{
	CheckSuccess(PolyItemListGetCurrentItem(communicationHandle, PTCDeviceType_SignalProcessing, 0,
		PTCDeviceCommand_DaqTriggerMode, triggerMode, bufferSize));
}

/// <summary>Gets the analog trigger level.</summary>
/// <param name="communicationHandle">The communication handle.</param>
/// <returns>The analog trigger level.</returns>
float AnalogTriggerLevel(PTCommunicationHandle communicationHandle)
{
	float analogTriggerLevel = 0;
	CheckSuccess(PolySendGetFloat(communicationHandle, PTCDeviceType_SignalProcessing, 0,
		PTCDeviceCommand_DaqAnalogTriggerLevel, &analogTriggerLevel));
	return analogTriggerLevel;
}

/// <summary>Query if the gated trigger is enabled.</summary>
/// <param name="communicationHandle">The communication handle.</param>
/// <returns>True if gated trigger is enabled, false if not.</returns>
bool GatedTrigger(PTCommunicationHandle communicationHandle)
{
	int16_t isGatedTrigger = 0;
	CheckSuccess(PolySendGetInt16(communicationHandle, PTCDeviceType_SignalProcessing, 0,
		PTCDeviceCommand_DaqGatedTrigger, &isGatedTrigger));
	return isGatedTrigger;
}

/// <summary>Gets the pre-/post-trigger.</summary>
/// <param name="communicationHandle">The communication handle.</param>
/// <returns>The pre-/post-trigger in measurement samples (not base samples).</returns>
int PrePostTrigger(PTCommunicationHandle communicationHandle)
{
	int prePostTrigger = 0;
	CheckSuccess(PolySendGetInt32(communicationHandle, PTCDeviceType_SignalProcessing, 0,
		PTCDeviceCommand_DaqPreTrigger, &prePostTrigger));
	return prePostTrigger;
}

/// <summary>Gets the channel scale factor.</summary>
/// <param name="communicationHandle">The communication handle.</param>
/// <param name="channelType">The channel type.</param>
/// <returns>The scale factor.</returns>
/// [ChannelScalefactor]
double ChannelScaleFactor(PTCommunicationHandle communicationHandle,
	PTAcquisitionHandle acquisitionHandle, PTCChannelType channelType)
{
	int maxValue = 0;
	CheckSuccess(PolyChannelMaxValue(acquisitionHandle, channelType, &maxValue));

	switch (channelType)
	{
		case PTCChannelType_Velocity:
			return UnitAndHeadRoomFactor(communicationHandle, PTCDeviceType_VelocityDecoderDigital) / maxValue;
		case PTCChannelType_Displacement:
			return UnitAndHeadRoomFactor(communicationHandle, PTCDeviceType_DisplacementDecoderDigital) / maxValue;
		case PTCChannelType_Acceleration:
			return UnitAndHeadRoomFactor(communicationHandle, PTCDeviceType_AccelerationDecoderDigital) / maxValue;
		case PTCChannelType_RSSI:
			return 100. / maxValue;
		default:
			return 1. / maxValue;
	}
}

/// <summary>Gets the unit and head room factor for a signal channel.</summary>
/// <param name="communicationHandle">The communication handle.</param>
/// <param name="decoderDevice">The decoder device to retrieve the information from.</param>
/// <returns>A multiplicable factor.</returns>
static double UnitAndHeadRoomFactor(PTCommunicationHandle communicationHandle, PTCDeviceType decoderDevice)
{
	float headRoom = 0;
	CheckSuccess(PolySendGetFloat(communicationHandle, decoderDevice, 0,
		PTCDeviceCommand_HeadroomDigitalOut, &headRoom));
	return headRoom * RangeInBaseUnit(communicationHandle, decoderDevice);
}

/// <summary>Gets the current signal range in its respective base unit (m, m/s, m/s²).</summary>
/// <param name="communicationHandle">The communication handle.</param>
/// <param name="decoderDevice">The decoder device to retrieve the information from.</param>
/// <returns>The current range in its respective base unit.</returns>
static double RangeInBaseUnit(PTCommunicationHandle communicationHandle, PTCDeviceType decoderDevice)
{
	char currentRangeItem[STRING_BUFFER_SIZE];
	CheckSuccess(PolyItemListGetCurrentItem(communicationHandle, decoderDevice, 0, PTCDeviceCommand_Range,
		currentRangeItem, sizeof(currentRangeItem)));

	double range = 0;
	char unit[8];
	char factor[8] = "";

	if (strstr(currentRangeItem, u8"·") == NULL)
		FailIf(sscanf(currentRangeItem, u8"%lf %8s", &range, (char*)&unit) != 2,
		"Invalid range received from device");
	else
		FailIf(sscanf(currentRangeItem, u8"%lf·%8s %8s", &range, (char*)&factor, (char*)&unit) != 3,
		"Invalid range received from device");

	return range * ParseFactor(factor) * ParseUnit(unit);
}
/// [ChannelScalefactor]

/// <summary>Gets the unit of a channel.</summary>
/// <param name="communicationHandle">The communication handle.</param>
/// <param name="channelType">The channel type.</param>
/// <returns>The unit.</returns>
char* ChannelUnit(PTCChannelType channelType)
{
	switch (channelType)
	{
		case PTCChannelType_Velocity:
			return "m/s";
		case PTCChannelType_Displacement:
			return "m";
		case PTCChannelType_Acceleration:
			return "m/s²";
		case PTCChannelType_RSSI:
			return "%";
		case PTCChannelType_Trigger:
		case PTCChannelType_DataValidity:
			return "bool";
		default:
			return "";
	}
}

/// <summary>Parse the factor to a multiplicable factor.</summary>
/// <param name="unit">The factor received from the device.</param>
/// <returns>A multiplicable factor.</returns>
static double ParseFactor(const char* factor)
{
	if (strcmp(factor, "") == 0)
		return 1;
	else if (strcmp(factor, u8"10³") == 0)
		return 1000;
	else if (strcmp(factor, u8"10⁶") == 0)
		return 1000LL * 1000;
	else if (strcmp(factor, u8"10⁹") == 0)
		return 1000LL * 1000 * 1000;
	else
	{
		fprintf(stderr, "Unknown factor received from device: %s\n", factor);
		exit(EXIT_FAILURE);
	}
}

/// <summary>Parse the unit to a multiplicable factor.</summary>
/// <param name="unit">The unit received from the device.</param>
/// <returns>A multiplicable factor.</returns>
static double ParseUnit(const char* unit)
{
	if (strstr(unit, u8"nm") != NULL)
		return 1. / (1000LL * 1000 * 1000);
	else if (strstr(unit, u8"µm") != NULL)
		return 1. / (1000LL * 1000);
	else if (strstr(unit, u8"mm") != NULL)
		return 1. / 1000;
	else if (strstr(unit, u8"km") != NULL)
		return 1000;
	else if (strcmp(unit, u8"m/s²") == 0 || strcmp(unit, u8"m/s") == 0 || strcmp(unit, u8"m") == 0)
		return 1;
	else
	{
		fprintf(stderr, "Unknown unit received from device: %s\n", unit);
		exit(EXIT_FAILURE);
	}
}
