// Copyright (c) 2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#include <IO/DeviceCommunication/PolyDeviceCommunication.h>

void InteractiveConfiguration(PTCommunicationHandle communicationHandle);
void PrintConfiguration(PTCommunicationHandle communicationHandle);
