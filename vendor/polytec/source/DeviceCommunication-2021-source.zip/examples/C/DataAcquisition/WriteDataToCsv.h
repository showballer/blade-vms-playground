﻿// Copyright (c) 2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#pragma once

#include "ChannelList.h"

#include <IO/DataAcquisition/PolyDataAcquisition.h>
#include <IO/DeviceCommunication/PolyDeviceCommunication.h>

#include <stdio.h>

void WriteCsvHeaders(FILE* file, ChannelNode* head);
void WriteDataToCsv(FILE* file, ChannelNode* channelsHead, size_t baseSampleCount,
	int frequencyFactor, double chunkTimestamp, double daqSampleInterval);