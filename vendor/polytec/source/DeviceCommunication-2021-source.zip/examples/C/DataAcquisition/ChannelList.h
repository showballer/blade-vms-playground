﻿// Copyright (c) 2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#pragma once

#include <IO/DataAcquisition/PolyDataAcquisition.h>
#include <IO/DeviceCommunication/PolyDeviceCommunication.h>

/// <summary>A node of the channels linked list.</summary>
struct ChannelNode
{
	PTCChannelType ChannelType;
	int ChannelId;
	int SampleCount;
	double ScaleFactor;
	char Unit[20];
	int* Samples;
	uint8_t* Overrange;
	struct ChannelNode* Next;
}
typedef ChannelNode;

ChannelNode* CreateChannelList(PTCommunicationHandle communicationHandle, PTAcquisitionHandle acquisitionHandle,
	const int baseBufferSize, const int frequencyFactor);
void FreeChannelList(ChannelNode* head);