﻿// Copyright (c) 2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#include "ChannelList.h"

#include "GetConfig.h"
#include "Utils.h"

/// <summary>Creates a linked list with additional data for all channels active on the device.</summary>
/// <param name="communicationHandle">The device communication handle.</param>
/// <param name="acquisitionHandle">The data acquisition handle.</param>
/// <param name="baseBufferSize">Base buffer size to be used for all sample buffers (in base samples).</param>
/// <param name="frequencyFactor">The frequency factor.</param>
/// <returns>A pointer to the first channel of the linked list.</returns>
ChannelNode* CreateChannelList(PTCommunicationHandle communicationHandle, PTAcquisitionHandle acquisitionHandle,
	const int baseBufferSize, const int frequencyFactor)
{
	ChannelNode* head = NULL;
	ChannelNode* previousChannel = NULL;

	// channel types
	const PTCChannelType channelTypes[] = {
		PTCChannelType_Velocity,
		PTCChannelType_Acceleration,
		PTCChannelType_Displacement,
		PTCChannelType_RSSI,
		PTCChannelType_Trigger,
		PTCChannelType_DataValidity
	};

	bool channelTypeSupported = false;
	bool isChannelEnabled = false;
	int maxChannelCount = 0;

	// initialize the linked list based on the channel activation methods (get methods are supported for all devices)
	for (int i = 0; i < sizeof(channelTypes); i++)
	{
		CheckSuccess(PolyChannelActivationIsChannelTypeSupported(
			communicationHandle, channelTypes[i], &channelTypeSupported));
		if (channelTypeSupported)
		{
			CheckSuccess(PolyChannelActivationMaxChannelCount(
				communicationHandle, channelTypes[i], &maxChannelCount));
			for (int channelId = 0; channelId < maxChannelCount; ++channelId)
			{
				CheckSuccess(PolyChannelActivationIsChannelEnabled(
					communicationHandle, channelTypes[i], channelId, &isChannelEnabled));
				if (isChannelEnabled)
				{
					ChannelNode* currentChannel = (ChannelNode*)malloc(sizeof(ChannelNode));
					if (!head) head = currentChannel;
					if (previousChannel) previousChannel->Next = currentChannel;

					currentChannel->ChannelType = channelTypes[i];
					currentChannel->ChannelId = channelId;
					currentChannel->SampleCount = baseBufferSize * (channelTypes[i] == PTCChannelType_RSSI ? 1 : frequencyFactor);
					currentChannel->Samples = malloc(currentChannel->SampleCount * sizeof(int));
					currentChannel->Overrange = IsSignalChannel(channelTypes[i])
						? malloc(currentChannel->SampleCount * sizeof(uint8_t))
						: NULL;
					currentChannel->Next = NULL;
					currentChannel->ScaleFactor = ChannelScaleFactor(communicationHandle, acquisitionHandle, channelTypes[i]);
					FailIf(snprintf(currentChannel->Unit, sizeof(currentChannel->Unit), "%s",
						ChannelUnit(channelTypes[i])) < 0, "String format error");

					previousChannel = currentChannel;
				}
			}
		}
	}
	return head;
}

/// <summary>Recusively free all allocated channels back to front.</summary>
/// <param name="head">[in] The head of the Channels linked list.</param>
void FreeChannelList(ChannelNode* head)
{
	FailIf(!head, "Channels not initialized");
	if (head->Next)
		FreeChannelList(head->Next);

	free(head->Samples);
	free(head->Overrange);
	free(head);
}
