// Copyright (c) 2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#include "InteractiveUserConfig.h"

#include "GetConfig.h"
#include "Utils.h"

#include <IO/DataAcquisition/PolyDataAcquisition.h>

#include <stdio.h>
#include <string.h>

static void PrintActiveChannels(PTCommunicationHandle communicationHandle);
static void PrintFrequencyFactor(PTCommunicationHandle communicationHandle);

static void UserSelectBandwidth(PTCommunicationHandle communicationHandle);
static void UserSelectChannelActivation(PTCommunicationHandle communicationHandle);
static char* ActiveOutputChannel(PTCommunicationHandle communicationHandle);
static void UserEnableDisableChannels(PTCommunicationHandle communicationHandle, PTCChannelType channelType);
static void UserSelectActiveOutputChannel(PTCommunicationHandle communicationHandle);
static void UserSelectBlockCount(PTCommunicationHandle communicationHandle);
static void UserSelectTriggerMode(PTCommunicationHandle communicationHandle, char triggerMode[], int bufferSize);
static void UserSelectTriggerEdge(PTCommunicationHandle communicationHandle);
static void UserSelectAnalogTriggerChannel(PTCommunicationHandle communicationHandle);
static void UserSelectAnalogTriggerLevel(PTCommunicationHandle communicationHandle);
static void UserSelectGatedTrigger(PTCommunicationHandle communicationHandle);
static void UserSelectPrePostTrigger(PTCommunicationHandle communicationHandle);

/// <summary>Performs an interactive configuration with the user using the command line.</summary>
/// <param name="communicationHandle">The communication handle.</param>
void InteractiveConfiguration(PTCommunicationHandle communicationHandle)
{
	UserSelectBandwidth(communicationHandle);

	if (HasCommand(communicationHandle, PTCDeviceType_SignalProcessing, PTCDeviceCommand_DaqActiveChannels))
	{
		// configure channels if desired
		char userInput[STRING_BUFFER_SIZE];
		GetUserInput("Do you wish to configure the active channel(s)? (y/N): ", userInput, sizeof(userInput));
		if (IsYes(userInput))
			UserSelectChannelActivation(communicationHandle);
	}
	else if (HasCommand(communicationHandle, PTCDeviceType_VelocityDecoderDigital, PTCDeviceCommand_OutputActive))
	{
		// always, as there is only a single channel to be configured
		UserSelectActiveOutputChannel(communicationHandle);
	}

	if (HasBlockMode(communicationHandle))
	{
		// configure block mode if desired
		char userInput[STRING_BUFFER_SIZE];
		GetUserInput("Do you wish to configure the block mode (e.g. trigger)? (y/N): ",
			userInput, sizeof(userInput));
		if (IsYes(userInput))
		{
			UserSelectBlockCount(communicationHandle);

			// trigger configuration
			char triggerMode[STRING_BUFFER_SIZE];
			UserSelectTriggerMode(communicationHandle, triggerMode, sizeof(triggerMode));
			if (strcmp(triggerMode, "None") != 0)
			{
				UserSelectTriggerEdge(communicationHandle);
				if (strcmp(triggerMode, "Analog") == 0)
				{
					UserSelectAnalogTriggerChannel(communicationHandle);
					UserSelectAnalogTriggerLevel(communicationHandle);
					UserSelectGatedTrigger(communicationHandle);
				}
				UserSelectPrePostTrigger(communicationHandle);
			}
		}
	}

	PrintDivider();
	puts("Configuration completed");
}

/// <summary>Print the current device configuration.</summary>
/// <param name="communicationHandle">The communication handle.</param>
void PrintConfiguration(PTCommunicationHandle communicationHandle)
{
	char bandwidth[STRING_BUFFER_SIZE];
	CheckSuccess(PolyItemListGetCurrentItem(communicationHandle, PTCDeviceType_VelocityDecoderDigital, 0,
		PTCDeviceCommand_Bandwidth, bandwidth, sizeof(bandwidth)));
	printf("Bandwidth: %s\n", bandwidth);
	PrintFrequencyFactor(communicationHandle);
	PrintActiveChannels(communicationHandle);

	if (HasBlockMode(communicationHandle) && BlockMode(communicationHandle))
	{
		puts("Acquisition mode: Block");
		printf("Block size: %d\n", BlockSize(communicationHandle));
		printf("Block count: %d\n", BlockCount(communicationHandle));

		char triggerMode[STRING_BUFFER_SIZE];
		TriggerMode(communicationHandle, triggerMode, sizeof(triggerMode));
		printf("Trigger mode: %s\n", triggerMode);

		if (strcmp(triggerMode, "None") != 0)
		{
			char triggerEdge[STRING_BUFFER_SIZE];
			CheckSuccess(PolyItemListGetCurrentItem(communicationHandle, PTCDeviceType_SignalProcessing, 0,
				PTCDeviceCommand_DaqTriggerEdge, triggerEdge, sizeof(triggerEdge)));
			printf("Trigger edge: %s\n", triggerEdge);

			if (strcmp(triggerMode, "Analog") == 0)
			{
				char analogTriggerChannel[STRING_BUFFER_SIZE];
				CheckSuccess(PolyItemListGetCurrentItem(communicationHandle, PTCDeviceType_SignalProcessing, 0,
					PTCDeviceCommand_DaqAnalogTriggerSource, analogTriggerChannel, sizeof(analogTriggerChannel)));
				printf("Analog trigger channel: %s\n", analogTriggerChannel);
				printf("Analog trigger level: %.2f\n", AnalogTriggerLevel(communicationHandle));
				printf("Gated trigger: %s\n", GatedTrigger(communicationHandle) ? "enabled" : "disabled");
			}
			printf("Pre-/Post-Trigger: %d\n", PrePostTrigger(communicationHandle));
		}
	} else
	{
		puts("Acquisition mode: Streaming");
	}

	PrintDivider();
}

/// <summary>Print all active channels.</summary>
/// <param name="communicationHandle">The communication handle.</param>
static void PrintActiveChannels(PTCommunicationHandle communicationHandle)
{
	bool isSupported = false;
	bool isEnabled = false;
	int maxChannelCount = 0;

	// all possible channel types
	const PTCChannelType channelTypes[] = {
		PTCChannelType_Velocity,
		PTCChannelType_Acceleration,
		PTCChannelType_Displacement,
		PTCChannelType_RSSI,
		PTCChannelType_Trigger,
		PTCChannelType_DataValidity
	};

	puts("Active channels:");
	for (int i = 0; i < 5; i++)
	{
		CheckSuccess(PolyChannelActivationIsChannelTypeSupported(communicationHandle, channelTypes[i], &isSupported));
		if (isSupported)
		{
			printf("\t%s: [", ChannelTypeToName(channelTypes[i]));
			CheckSuccess(PolyChannelActivationMaxChannelCount(communicationHandle, channelTypes[i], &maxChannelCount));
			for (int channelId = 0; channelId < maxChannelCount; channelId++)
			{
				CheckSuccess(PolyChannelActivationIsChannelEnabled(communicationHandle, channelTypes[i], channelId, &isEnabled));
				if (isEnabled)
					printf(" %d", channelId);
			}
			puts(" ]");
		}
	}
}

/// <summary>Print an info text about base samples and frequency factor.</summary>
/// <param name="communicationHandle">The communication handle.</param>
static void PrintFrequencyFactor(PTCommunicationHandle communicationHandle)
{
	int baseSampleRate = 0;
	int daqSampleRate = 0;
	int frequencyFactor = 1;

	if (HasCommand(communicationHandle, PTCDeviceType_SignalProcessing, PTCDeviceCommand_DaqBaseSampleRate))
	{
		CheckSuccess(PolySendGetInt32(communicationHandle, PTCDeviceType_SignalProcessing, 0, PTCDeviceCommand_DaqBaseSampleRate, &baseSampleRate));
		daqSampleRate = baseSampleRate;
		if (HasCommand(communicationHandle, PTCDeviceType_SignalProcessing, PTCDeviceCommand_DaqSampleRate))
			CheckSuccess(PolySendGetInt32(communicationHandle, PTCDeviceType_SignalProcessing, 0, PTCDeviceCommand_DaqSampleRate, &daqSampleRate));
		printf("Frequency factor: %d Hz / %d Hz = %d\n", daqSampleRate, baseSampleRate, daqSampleRate / baseSampleRate);
	}
}

/// <summary>Let the user select the device bandwidth.</summary>
/// <param name="communicationHandle">The communication handle.</param>
/// <returns>True if channels need to be reconfigured, false if not.</returns>
static void UserSelectBandwidth(PTCommunicationHandle communicationHandle)
{
	char bandwidths[STRING_BUFFER_SIZE];
	char currentItem[STRING_BUFFER_SIZE];
	char userInput[STRING_BUFFER_SIZE];
	char userPrompt[STRING_BUFFER_SIZE];

	// get available bandwidths
	CheckSuccess(PolyItemListGetAvailableItems(communicationHandle, PTCDeviceType_VelocityDecoderDigital, 0,
		PTCDeviceCommand_Bandwidth, bandwidths, sizeof(bandwidths)));
	CheckSuccess(PolyItemListGetCurrentItem(communicationHandle, PTCDeviceType_VelocityDecoderDigital, 0,
		PTCDeviceCommand_Bandwidth, currentItem, sizeof(currentItem)));
	PrintDivider();
	printf("Available bandwidths: %s\n", bandwidths);

	// query user and set bandwidth
	FailIf(snprintf(userPrompt, sizeof(userPrompt), "Select one of the bandwidths above [%s]: ", currentItem) < 0, "String format error");
	GetUserInput(userPrompt, userInput, sizeof(userInput));
	if (strcmp(userInput, "") != 0 && strcmp(userInput, currentItem) != 0)
	{
		CheckSuccess(PolyItemListSetCurrentItem(communicationHandle, PTCDeviceType_VelocityDecoderDigital, 0,
			PTCDeviceCommand_Bandwidth, userInput));
	}
}

/// <summary>Let the user select the channels to be enabled.</summary>
/// <remarks>Use this function if the device supports the channel activation command.</remarks>
/// <param name="communicationHandle">The communication handle.</param>
static void UserSelectChannelActivation(PTCommunicationHandle communicationHandle)
{
	PrintDivider();
	puts("Channel activation information: Channel availability is dependent on bandwidth and enabled channels. "
		"Enabling a channel of type Velocity, Displacement or Acceleration or setting a high bandwidth (e.g. 24 MHz) "
		"might limit the availability of other signal channels.");

	// start with all channels disabled
	CheckSuccess(PolyChannelActivationDisableAllChannels(communicationHandle));

	// go through all channel types and let the user enable each channel one by one
	UserEnableDisableChannels(communicationHandle, PTCChannelType_Velocity);
	UserEnableDisableChannels(communicationHandle, PTCChannelType_Acceleration);
	UserEnableDisableChannels(communicationHandle, PTCChannelType_Displacement);
	UserEnableDisableChannels(communicationHandle, PTCChannelType_RSSI);
	UserEnableDisableChannels(communicationHandle, PTCChannelType_Trigger);
}

/// <summary>Let the user enable/disable channels of a specific type.</summary>
/// <param name="communicationHandle">The communication handle.</param>
/// <param name="channelType">The channel type.</param>
static void UserEnableDisableChannels(PTCommunicationHandle communicationHandle, PTCChannelType channelType)
{
	char userPrompt[STRING_BUFFER_SIZE];
	char userInput[STRING_BUFFER_SIZE];
	bool channelTypeSupported = false;
	bool isChannelAvaialble = false;
	int maxChannelCount = 0;

	// skip channel types that are not supported
	CheckSuccess(PolyChannelActivationIsChannelTypeSupported(communicationHandle, channelType, &channelTypeSupported));
	if (!channelTypeSupported)
		return;

	// query user for each channel to be enabled if available
	CheckSuccess(PolyChannelActivationMaxChannelCount(communicationHandle, channelType, &maxChannelCount));
	for (int channelId = 0; channelId < maxChannelCount; ++channelId) {
		CheckSuccess(PolyChannelActivationIsChannelAvailable(communicationHandle, channelType, channelId, &isChannelAvaialble));
		if (isChannelAvaialble)
		{
			FailIf(snprintf(userPrompt, sizeof(userPrompt), "Enable %s channel %d (Y/n): ",
				ChannelTypeToName(channelType), channelId) < 0, "String format error");
			GetUserInput(userPrompt, userInput, sizeof(userInput));
			if (!IsNo(userInput))
				CheckSuccess(PolyChannelActivationEnableChannel(communicationHandle, channelType, channelId));
		}
	}
}

/// <summary>Let the user select the active output channel on a device.</summary>
/// <remarks>Use this function if the device does not support the channel activation command.</remarks>
/// <param name="communicationHandle">The communication handle.</param>
static void UserSelectActiveOutputChannel(PTCommunicationHandle communicationHandle)
{
	char userInput[STRING_BUFFER_SIZE];
	char userPrompt[STRING_BUFFER_SIZE];
	bool hasDisplacement = false;
	bool hasAcceleration = false;

	// get available channels
	CheckSuccess(PolyHasDevice(communicationHandle, PTCDeviceType_DisplacementDecoderDigital, 0, &hasDisplacement));
	CheckSuccess(PolyHasDevice(communicationHandle, PTCDeviceType_AccelerationDecoderDigital, 0, &hasAcceleration));

	// do not prompt the user if there is only a velocity channel
	if (!hasDisplacement && !hasAcceleration)
		return;

	// query user
	FailIf(snprintf(userPrompt, sizeof(userPrompt),
		"Select active output channel (Velocity%s%s) [%s]: ",
		hasDisplacement ? ", Displacement" : "",
		hasAcceleration ? ", Acceleration" : "",
		ActiveOutputChannel(communicationHandle)) < 0, "String format error");
	GetUserInput(userPrompt, userInput, sizeof(userInput));

	// set selected channel if specified
	if (strcmp(userInput, "") != 0)
	{
		if (strcmp(userInput, "Velocity") == 0)
			CheckSuccess(PolySendSetInt16(communicationHandle, PTCDeviceType_VelocityDecoderDigital, 0, PTCDeviceCommand_OutputActive, 1));
		else if (strcmp(userInput, "Displacement") == 0 && hasDisplacement)
			CheckSuccess(PolySendSetInt16(communicationHandle, PTCDeviceType_DisplacementDecoderDigital, 0, PTCDeviceCommand_OutputActive, 1));
		else if (strcmp(userInput, "Acceleration") == 0 && hasAcceleration)
			CheckSuccess(PolySendSetInt16(communicationHandle, PTCDeviceType_AccelerationDecoderDigital, 0, PTCDeviceCommand_OutputActive, 1));
		else
			FailIf(true, "Invalid input\n");
	}
}

/// <summary>Get the active output channel.</summary>
/// <param name="communicationHandle">The communication handle.</param>
/// <returns>The active output channel.</returns>
static char* ActiveOutputChannel(PTCommunicationHandle communicationHandle)
{
	bool isChannelEnabled = false;

	CheckSuccess(PolyChannelActivationIsChannelEnabled(communicationHandle,
		PTCChannelType_Velocity, 0, &isChannelEnabled));
	if (isChannelEnabled)
		return "Velocity";

	CheckSuccess(PolyChannelActivationIsChannelEnabled(communicationHandle,
		PTCChannelType_Displacement, 0, &isChannelEnabled));
	if (isChannelEnabled)
		return "Displacement";

	CheckSuccess(PolyChannelActivationIsChannelEnabled(communicationHandle,
		PTCChannelType_Acceleration, 0, &isChannelEnabled));
	if (isChannelEnabled)
		return "Acceleration";

	return "";
}

/// <summary>Let the user select the block count.</summary>
/// <param name="communicationHandle">The communication handle.</param>
static void UserSelectBlockCount(PTCommunicationHandle communicationHandle)
{
	int16_t range[2];
	int16_t currentValue = 0;
	char userInput[STRING_BUFFER_SIZE];
	char userPrompt[STRING_BUFFER_SIZE];

	// here the high level API can be used as DaqBlockCount is a int16 command
	CheckSuccess(PolySendGetDevInfoRange(communicationHandle, PTCDeviceType_SignalProcessing, 0,
		PTCDeviceCommand_DaqBlockCount, &range[0], &range[1]));
	
	// 0 = endless mode, endless mode is not supported in this example
	if (range[0] < 1)
		range[0] = 1;

	// get the current block count
	CheckSuccess(PolySendGetInt16(communicationHandle, PTCDeviceType_SignalProcessing, 0,
		PTCDeviceCommand_DaqBlockCount, &currentValue));

	// query user
	FailIf(snprintf(userPrompt, sizeof(userPrompt), "Specify the amount of blocks to be acquired between %d and %d [%d]: ",
		range[0], range[1], currentValue == 0 ? 1 : currentValue) < 0, "String format error");
	GetUserInput(userPrompt, userInput, sizeof(userInput));

	// set block count if specified
	if (strcmp(userInput, "") != 0)
	{
		const int16_t blockCount = atoi(userInput);
		FailIf(blockCount < range[0] || blockCount > range[1], "Specified block count is not within the allowed range.");
		CheckSuccess(PolySendSetInt16(communicationHandle, PTCDeviceType_SignalProcessing, 0,
			PTCDeviceCommand_DaqBlockCount, blockCount));
	}
	else if (currentValue == 0)
	{
		// make sure block count is not set to 0 (endless mode)
		CheckSuccess(PolySendSetInt16(communicationHandle, PTCDeviceType_SignalProcessing, 0,
			PTCDeviceCommand_DaqBlockCount, 1));
	}
}

/// <summary>Let the user select the trigger mode.</summary>
/// <param name="communicationHandle">The communication handle.</param>
/// <param name="triggerMode">[out] The selected trigger mode.</param>
/// <param name="bufferSize">Size of the trigger mode buffer.</param>
static void UserSelectTriggerMode(PTCommunicationHandle communicationHandle, char triggerMode[], int bufferSize)
{
	char availableItems[STRING_BUFFER_SIZE];
	char currentItem[STRING_BUFFER_SIZE];
	char userPrompt[STRING_BUFFER_SIZE];

	// get current & available items
	CheckSuccess(PolyItemListGetAvailableItems(communicationHandle, PTCDeviceType_SignalProcessing, 0,
		PTCDeviceCommand_DaqTriggerMode, availableItems, sizeof(availableItems)));
	CheckSuccess(PolyItemListGetCurrentItem(communicationHandle, PTCDeviceType_SignalProcessing, 0,
		PTCDeviceCommand_DaqTriggerMode, currentItem, sizeof(currentItem)));

	// query user
	FailIf(snprintf(userPrompt, sizeof(userPrompt), "Select trigger mode (%s) [%s]: ",
		availableItems, currentItem) < 0, "String format error");
	GetUserInput(userPrompt, triggerMode, bufferSize);

	// set trigger mode if specified
	if (strcmp(triggerMode, "") != 0)
		CheckSuccess(PolyItemListSetCurrentItem(communicationHandle, PTCDeviceType_SignalProcessing, 0,
		PTCDeviceCommand_DaqTriggerMode, triggerMode));
	else
		strncpy(triggerMode, currentItem, bufferSize);
}

/// <summary>Let the user select the trigger edge.</summary>
/// <param name="communicationHandle">The communication handle.</param>
static void UserSelectTriggerEdge(PTCommunicationHandle communicationHandle)
{
	char availableItems[STRING_BUFFER_SIZE];
	char currentItem[STRING_BUFFER_SIZE];
	char userInput[STRING_BUFFER_SIZE];
	char userPrompt[STRING_BUFFER_SIZE];

	// get current & available items
	CheckSuccess(PolyItemListGetAvailableItems(communicationHandle, PTCDeviceType_SignalProcessing, 0,
		PTCDeviceCommand_DaqTriggerEdge, availableItems, sizeof(availableItems)));
	CheckSuccess(PolyItemListGetCurrentItem(communicationHandle, PTCDeviceType_SignalProcessing, 0,
		PTCDeviceCommand_DaqTriggerEdge, currentItem, sizeof(currentItem)));

	// query user
	FailIf(snprintf(userPrompt, sizeof(userPrompt), "Trigger edge (%s) [%s]: ",
		availableItems, currentItem) < 0, "String format error");
	GetUserInput(userPrompt, userInput, sizeof(userInput));

	// set trigger edge if specified
	if (strcmp(userInput, "") != 0)
		CheckSuccess(PolyItemListSetCurrentItem(communicationHandle, PTCDeviceType_SignalProcessing, 0,
			PTCDeviceCommand_DaqTriggerEdge, userInput));
}

/// <summary>Let the user select the analog trigger channel.</summary>
/// <param name="communicationHandle">The communication handle.</param>
static void UserSelectAnalogTriggerChannel(PTCommunicationHandle communicationHandle)
{
	char availableItems[STRING_BUFFER_SIZE];
	char currentItem[STRING_BUFFER_SIZE];
	char userInput[STRING_BUFFER_SIZE];
	char userPrompt[STRING_BUFFER_SIZE];

	// get current & available items
	CheckSuccess(PolyItemListGetAvailableItems(communicationHandle, PTCDeviceType_SignalProcessing, 0,
		PTCDeviceCommand_DaqAnalogTriggerSource, availableItems, sizeof(availableItems)));
	CheckSuccess(PolyItemListGetCurrentItem(communicationHandle, PTCDeviceType_SignalProcessing, 0,
		PTCDeviceCommand_DaqAnalogTriggerSource, currentItem, sizeof(currentItem)));

	// do not prompt user if there is only one channel to choose from
	if (strchr(availableItems, ',') == NULL)
		return;

	// query user
	FailIf(snprintf(userPrompt, sizeof(userPrompt), "Analog trigger channel (%s) [%s]: ",
		availableItems, currentItem) < 0, "String format error");
	GetUserInput(userPrompt, userInput, sizeof(userInput));

	// set trigger edge if specified
	if (strcmp(userInput, "") != 0)
		CheckSuccess(PolyItemListSetCurrentItem(communicationHandle, PTCDeviceType_SignalProcessing, 0,
			PTCDeviceCommand_DaqAnalogTriggerSource, userInput));
}

/// <summary>Let the user select the analog trigger level.</summary>
/// <param name="communicationHandle">The communication handle.</param>
static void UserSelectAnalogTriggerLevel(PTCommunicationHandle communicationHandle)
{
	float currentValue = 0;
	float range[2];
	char userInput[STRING_BUFFER_SIZE];
	char userPrompt[STRING_BUFFER_SIZE];

	// low level API has to be used as there is no high level support for float ranges
	// see use of PolySendGetDevInfoRange for int16 ranges below
	PTPayloadHandle payloadHandle = 0;
	CheckSuccess(PolySendGetDevInfo(communicationHandle, PTCDeviceType_SignalProcessing, 0,
		PTCDeviceCommand_DaqAnalogTriggerLevel, &payloadHandle));
	CheckSuccess(PolyGetFloatFromPayload(payloadHandle, range, NULL, sizeof(range)));
	PolyFreePayload(payloadHandle);

	// get the current analog trigger level
	CheckSuccess(PolySendGetFloat(communicationHandle, PTCDeviceType_SignalProcessing, 0,
		PTCDeviceCommand_DaqAnalogTriggerLevel, &currentValue));

	// query user
	puts("Analog trigger level is specified as a factor of the trigger channel (e.g. Velocity) maximum amplitude.");
	FailIf(snprintf(userPrompt, sizeof(userPrompt), "Specify an analog trigger level between %.2f and %.2f [%.2f]: ",
		range[0], range[1], currentValue) < 0, "String format error");
	GetUserInput(userPrompt, userInput, sizeof(userInput));

	// set analog trigger level if specified
	if (strcmp(userInput, "") != 0)
	{
		const float analogTriggerLevel = (float)atof(userInput);
		FailIf(analogTriggerLevel < range[0] || analogTriggerLevel > range[1],
			"Specified trigger level is not within the allowed range.");
		CheckSuccess(PolySendSetFloat(communicationHandle, PTCDeviceType_SignalProcessing, 0,
			PTCDeviceCommand_DaqAnalogTriggerLevel, analogTriggerLevel));
	}
}

/// <summary>Let the user enable/disable the gated trigger.</summary>
/// <param name="communicationHandle">The communication handle.</param>
static void UserSelectGatedTrigger(PTCommunicationHandle communicationHandle)
{
	int16_t currentValue = 0;
	char userInput[STRING_BUFFER_SIZE];
	char userPrompt[STRING_BUFFER_SIZE];

	PrintDivider();
	puts("Using a trigger mode other than the external trigger (e.g. analog) gives you the option to enable "
		"the so-called gated trigger. With the gated trigger enabled, the external trigger signal is used as "
		"a gate for the other trigger signal. This means that the active trigger (e.g. analog) only triggers "
		"on a trigger event, if call there is also a high signal on the external trigger.");

	// get current gated trigger value
	CheckSuccess(PolySendGetInt16(communicationHandle, PTCDeviceType_SignalProcessing, 0,
		PTCDeviceCommand_DaqGatedTrigger, &currentValue));

	// query user and set gated trigger
	FailIf(snprintf(userPrompt, sizeof(userPrompt), "Enable gated trigger (y/n) [%s]: ",
		currentValue == 0 ? "No" : "Yes") < 0, "String format error");
	GetUserInput(userPrompt, userInput, sizeof(userInput));

	// set gated trigger if specified
	if (strcmp(userInput, "") != 0)
	{
		CheckSuccess(PolySendSetInt16(communicationHandle, PTCDeviceType_SignalProcessing, 0,
			PTCDeviceCommand_DaqGatedTrigger, IsYes(userInput) ? 1 : 0));
	}
}

/// <summary>Let the user select the pre-/post-trigger.</summary>
/// <param name="communicationHandle">The communication handle.</param>
static void UserSelectPrePostTrigger(PTCommunicationHandle communicationHandle)
{
	int32_t currentValue = 0;
	int32_t range[2];
	char userPrompt[STRING_BUFFER_SIZE];
	char userInput[STRING_BUFFER_SIZE];

	PrintDivider();
	puts("Setting a pre/post-trigger shifts the trigger position relative to the beginning of the acquired data. "
		"Its value is specified in signal samples (related to the acquisition sample rate of the signal channels, "
		"e.g. Velocity)\n"
		"=0: default, no pre/post-trigger will be acquired and the trigger position will be on the first sample acquired.\n"
		">0: pre-trigger, the specified amount of samples will be acquired in advance to the trigger position.\n"
		"<0: post-trigger, the specified amount of samples will skipped and not acquired after the trigger position.\n"
		"This setting has no effect on the block size specified above.puts");

	// low level API has to be used as there is no high level support for int32 ranges
	// see use of PolySendGetDevInfoRange for int16 ranges below
	PTPayloadHandle payloadHandle = 0;
	CheckSuccess(PolySendGetDevInfo(communicationHandle, PTCDeviceType_SignalProcessing, 0,
		PTCDeviceCommand_DaqPreTrigger, &payloadHandle));
	CheckSuccess(PolyGetInt32FromPayload(payloadHandle, range, NULL, sizeof(range)));
	PolyFreePayload(payloadHandle);

	// get current pre-/post-trigger value
	CheckSuccess(PolySendGetInt32(communicationHandle, PTCDeviceType_SignalProcessing, 0,
		PTCDeviceCommand_DaqPreTrigger, &currentValue));

	// query user and set pre-/post-trigger
	FailIf(snprintf(userPrompt, sizeof(userPrompt), "Specify a pre/post-trigger within %d and %d (signal samples) [%d]: ",
		range[0], range[1], currentValue) < 0, "String format error");
	GetUserInput(userPrompt, userInput, sizeof(userInput));

	if (strcmp(userInput, "") != 0)
	{
		const int prePostTrigger = atoi(userInput);
		FailIf(prePostTrigger < range[0] || prePostTrigger > range[1], "Specified pre-/post-trigger is not within the allowed range.");
		CheckSuccess(PolySendSetInt32(communicationHandle, PTCDeviceType_SignalProcessing, 0,
			PTCDeviceCommand_DaqPreTrigger, prePostTrigger));
	}
}
