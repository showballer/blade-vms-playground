// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#pragma warning(disable: 4996) // strcpy, scanf ...

#include "ChannelList.h"
#include "InteractiveUserConfig.h"
#include "GetConfig.h"
#include "Utils.h"
#include "WriteDataToCsv.h"

#include <IO/DeviceCommunication/PolyDeviceCommunication.h>
#include <IO/DataAcquisition/PolyDataAcquisition.h>

#include <signal.h>
#include <stdio.h>

#ifndef min
#define min(a,b) (((a) < (b)) ? (a) : (b))
#endif

static struct ProgramOptions ParseArguments(int argc, char** argv);
static void SetupDataAcquisition(PTCommunicationHandle communicationHandle, struct ProgramOptions programOptions);
static void AcquireData(PTCommunicationHandle communicationHandle, PTAcquisitionHandle acquisitionHandle, int sampleCount);
static void AcquireAndWriteBlockToCsv(PTAcquisitionHandle acquisitionHandle, ChannelNode* channelsHead, const char dateTimeString[],
	int blockId, int blockSize, int frequencyFactor, int prePostTrigger, int baseBufferSize);
static void SetBlockSize(PTCommunicationHandle communicationHandle, int blockSize);
static void WaitForTrigger(PTCommunicationHandle communicationHandle, PTAcquisitionHandle acquisitionHandle);

static const int c_samplesToReadAtOnce = 250;
static const int c_timeout_ms = 1000;

struct ProgramOptions
{
	char IpAddress[STRING_BUFFER_SIZE];
	char OperationMode[STRING_BUFFER_SIZE];
	int SampleCount;
};

/// [main]
int main(int argc, char** argv)
{
	PTCommunicationHandle communicationHandle = 0;
	PTAcquisitionHandle acquisitionHandle = 0;

	// Handle the command line interface
	const struct ProgramOptions programOptions = ParseArguments(argc, argv);

	// Calculate the data acquisition ring buffer size (for streaming the buffer should be able
	// to hold all data expected to be acquired if real time processing is not guaranteed)
	const size_t bufferCapacity = strcmp(programOptions.OperationMode, "Streaming") == 0
		? programOptions.SampleCount
		: 10 * c_samplesToReadAtOnce;

	// Open a network communication and data acquisition connection with the device
	CheckSuccess(PolyOpenUdpEthernetCommunication(&communicationHandle,
		programOptions.IpAddress, c_timeout_ms));
	CheckSuccess(PolyOpenDataAcquisition(&acquisitionHandle,
		communicationHandle, bufferCapacity));

	// Check IQ mode
	FailIf(IQMode(communicationHandle), "This example does not support IQ mode (would require other data interpretation).");

	// Stop any possibly running acquisition (some settings
	// cannot be manipulated during an active data acquisition)
	CheckSuccess(PolyStopDataAcquisition(acquisitionHandle));

	if (strcmp(programOptions.OperationMode, "Config") == 0)
	{
		// Perform an interactive configuration
		InteractiveConfiguration(communicationHandle);
	}
	else
	{
		// Setup and print configuration
		SetupDataAcquisition(communicationHandle, programOptions);
		PrintConfiguration(communicationHandle);

		// Start the acquisition stream on the device
		CheckSuccess(PolyStartDataAcquisition(acquisitionHandle));

		// Read the received data and write it to a file
		AcquireData(communicationHandle, acquisitionHandle, programOptions.SampleCount);

		// Stop the acquisition stream on the device
		CheckSuccess(PolyStopDataAcquisition(acquisitionHandle));
	}

	// Close all connection handles
	PolyCloseDataAcquisition(acquisitionHandle);
	PolyCloseCommunication(communicationHandle);

	return EXIT_SUCCESS;
}
/// [main]

/// <summary>Parse the command line arguments.</summary>
/// <param name="argc">The argument count.</param>
/// <param name="argv">[in] The argument vector.</param>
static struct ProgramOptions ParseArguments(int argc, char** argv)
{
	struct ProgramOptions programOptions;
	if (argc == 4 && (strcmp(argv[2], "Block") == 0 || strcmp(argv[2], "Streaming") == 0))
	{
		programOptions.SampleCount = atoi(argv[3]);
		FailIf(programOptions.SampleCount <= 0, "Sample count / block size has to be a positive integer value.");
	}
	else if (argc != 3 || strcmp(argv[2], "Config") != 0)
	{
		// print usage and exit
		puts("Usage:");
		printf("%s <IP-address> Config\n", argv[0]);
		printf("%s <IP-address> Streaming <BaseSampleCount>\n", argv[0]);
		printf("%s <IP-address> Block <BlockSize>\n", argv[0]);
		PrintDivider();
		puts("Streaming: Data will be streamed directly from the device without any trigger handling.");
		puts("Block (not available on IVS-500 and VGO-200 devices): In block mode data is acquired and delivered in blocks. "
			"This will also give you further options to setup and configure a triggered data acquisition on the device. "
			"If a trigger is enabled, the trigger will be used for each block individually. Block acquisition can be especially "
			"useful if the bandwidth of your connection to the device is lower than the bandwidth of the acquired signal, as the "
			"complete data block is guaranteed to be able to be buffered on the device, while being delivered over the slower connection.");
		puts("Note that data streaming can lead to buffer overflows within the device when used with high bandwidths and/or a "
			"large number of active channels as the throughput might be limited by the bandwidth of your network connection. "
			"Block mode data acquisition is only limited by the buffer space available on the device (see block size).");
		PrintDivider();
		puts("Sample count and block size are specified as so-called base samples. Base samples are related to the "
			"base sample rate of your device as it is the lowest common denominator for all channel sample rates. "
			"In order to determine the sample count for a signal (Velocity, ...) or trigger channel you have to multiply the base "
			"sample count with the factor of the channel and base sample rate (the so called frequency factor). "
			"Use the DAQ base sample rate and DAQ sample rate commands to retrieve your devices sample rates in Hz and "
			"calculate the frequency factor.");
		exit(EXIT_FAILURE);
	}
	strncpy(programOptions.IpAddress, argv[1], sizeof(programOptions.IpAddress));
	strncpy(programOptions.OperationMode, argv[2], sizeof(programOptions.OperationMode));
	return programOptions;
}

/// <summary>Sets up the data acquisition.</summary>
/// <param name="communicationHandle">The communication handle.</param>
/// <param name="daqMode">The DAQ mode.</param>
/// <param name="blockSize">Size of a block in base samples (only applied in block mode).</param>
/// [SetupDataAcquisition]
static void SetupDataAcquisition(PTCommunicationHandle communicationHandle,
	struct ProgramOptions programOptions)
{
	const bool isBlockMode = strcmp(programOptions.OperationMode, "Block") == 0;
	if (HasBlockMode(communicationHandle))
	{
		CheckSuccess(PolyItemListSetCurrentItem(communicationHandle,
			PTCDeviceType_SignalProcessing, 0,
			PTCDeviceCommand_DaqMode, programOptions.OperationMode));
		if (isBlockMode)
			SetBlockSize(communicationHandle, programOptions.SampleCount);
	}
	else
	{
		FailIf(isBlockMode, "This device does not support block mode.");
	}
}

/// <summary>Set the block size.</summary>
/// <param name="communication">The communication handle.</param>
/// <param name="blockSize">The block size in base samples.</param>
static void SetBlockSize(PTCommunicationHandle communicationHandle, int blockSize)
{
	int32_t range[2];

	// low level API has to be used as there is no high level support for int32 ranges
	// see PolySendGetDevInfoRange for int16 ranges
	PTPayloadHandle payloadHandle = 0;
	CheckSuccess(PolySendGetDevInfo(communicationHandle, PTCDeviceType_SignalProcessing, 0,
		PTCDeviceCommand_DaqBlockSize, &payloadHandle));
	CheckSuccess(PolyGetInt32FromPayload(payloadHandle, range, NULL, sizeof(range)));
	PolyFreePayload(payloadHandle);

	FailIf(blockSize < range[0] || blockSize > range[1],
		"Specified block size is not within the allowed range.");
	CheckSuccess(PolySendSetInt32(communicationHandle, PTCDeviceType_SignalProcessing, 0,
		PTCDeviceCommand_DaqBlockSize, blockSize));
}
/// [SetupDataAcquisition]

/// <summary>Acquires incoming data and writes it to CSV files.</summary>
/// <param name="communicationHandle">The device communication handle.</param>
/// <param name="acquisitionHandle">The data acquisition handle.</param>
/// <param name="sampleCount">Number of samples to be acquired in base samples
/// 						  (used per block if block mode).</param>
/// [AcquireData]
static void AcquireData(PTCommunicationHandle communicationHandle,
	PTAcquisitionHandle acquisitionHandle, int sampleCount)
{
	const size_t baseBufferSize = c_samplesToReadAtOnce;
	const bool isBlockMode = BlockMode(communicationHandle);
	const int blockCount = isBlockMode ? BlockCount(communicationHandle) : 1;
	const int prePostTrigger = isBlockMode ? PrePostTrigger(communicationHandle) : 0;
	const int frequencyFactor = FrequencyFactor(communicationHandle);

	FailIf(blockCount == 0, "Endless block mode (blockCount=0) "
		"is not supported by this example. Configure a block count > 0.");

	ChannelNode* channelsHead = CreateChannelList(communicationHandle, acquisitionHandle,
		baseBufferSize, frequencyFactor);

	char dateTimeString[STRING_BUFFER_SIZE];
	GetDateTime(dateTimeString, sizeof(dateTimeString));

	// acquire and write data block by block (single block on streaming)
	for (int blockId = 0; blockId < blockCount; blockId++)
	{
		if (isBlockMode) WaitForTrigger(communicationHandle, acquisitionHandle);
		AcquireAndWriteBlockToCsv(acquisitionHandle, channelsHead, dateTimeString, blockId,
			sampleCount, frequencyFactor, prePostTrigger, baseBufferSize);
		if (isBlockMode) CheckSuccess(PolyNextDataAcquisitionBlock(acquisitionHandle));
	}

	puts("Acquisition completed");

	// free allocated buffers
	FreeChannelList(channelsHead);
}

/// <summary>Wait for triggerd data if a trigger has been enabled.</summary>
/// <param name="acquisitionHandle">Handle of the acquisition.</param>
static void WaitForTrigger(const PTCommunicationHandle communicationHandle,
	const PTAcquisitionHandle acquisitionHandle)
{
	// only wait if there is a trigger active
	char triggerMode[STRING_BUFFER_SIZE];
	TriggerMode(communicationHandle, triggerMode, sizeof(triggerMode));
	if (strcmp(triggerMode, "None") == 0)
		return;

	printf("Waiting for trigger...\r");
	fflush(stdout);

	// wait for the first samples to be available
	size_t availableBaseSamples = 0;
	while (availableBaseSamples == 0)
		CheckSuccess(PolyAvailableSamples(acquisitionHandle, &availableBaseSamples));
}
/// [AcquireData]

/// <summary>Acquires a data acquisition block and writes it to a CSV file.</summary>
/// <param name="acquisitionHandle">The data acquisition handle.</param>
/// <param name="channelsHead">[in,out] The head of the channels linked list.</param>
/// <param name="dateTime">The current date and time as a string.</param>
/// <param name="blockId">ID of the current block being acquired.</param>
/// <param name="blockSize">Size of the block to be acquired and written.</param>
/// <param name="frequencyFactor">The frequency factor.</param>
/// <param name="prePostTrigger">The pre/post trigger value.</param>
/// <param name="baseBufferSize">The base channel buffer size (in base samples).</param>
/// [AcquireAndWriteBlockToCsv]
static void AcquireAndWriteBlockToCsv(PTAcquisitionHandle acquisitionHandle, ChannelNode* channelsHead,
	const char dateTime[], int blockId, int blockSize, int frequencyFactor, int prePostTrigger, int baseBufferSize)
{
	// generate filename and open file
	char fileName[STRING_BUFFER_SIZE];
	FailIf(snprintf(fileName, sizeof(fileName), "%s AcquisitionData%d.csv",
		dateTime, blockId) <= 0, "String format error");
	FILE* file = fopen(fileName, "w");
	FailIf(file == NULL, "Error opening file.");

	WriteCsvHeaders(file, channelsHead);

	const double sampleInterval = 1 / (BaseSampleRateInHz(acquisitionHandle) * frequencyFactor);
	double baseSamplesWritten = 0;

	for (int baseSamplesStillToBeRead = blockSize; baseSamplesStillToBeRead > 0;
		baseSamplesStillToBeRead -= baseBufferSize)
	{
		size_t baseSampleCount = min(baseBufferSize, baseSamplesStillToBeRead);
		CheckSuccess(PolyReadData(acquisitionHandle, baseSampleCount, c_timeout_ms));

		// copy data from all channels to buffers in the channels linked list
		for (ChannelNode* currentChannel = channelsHead; currentChannel;
			currentChannel = currentChannel->Next)
		{
			size_t channelSampleCount = 0;
			CheckSuccess(PolyExtractedSampleCount(acquisitionHandle, currentChannel->ChannelType,
				currentChannel->ChannelId, &channelSampleCount));
			FailIf((size_t)currentChannel->SampleCount < channelSampleCount,
				"Logic error: Data to be read exceeds sample buffer");
			
			// copy signal data
			CheckSuccess(PolyGetInt32Data(acquisitionHandle, currentChannel->ChannelType,
				currentChannel->ChannelId, currentChannel->Samples, channelSampleCount));
			
			// copy overrange data if available
			if (IsSignalChannel(currentChannel->ChannelType))
			{
				CheckSuccess(PolyGetOverrange(acquisitionHandle, currentChannel->ChannelType,
					currentChannel->ChannelId, currentChannel->Overrange, channelSampleCount));
			}
		}

		const double chunkTimestamp = ((baseSamplesWritten * frequencyFactor) - prePostTrigger) * sampleInterval;
		WriteDataToCsv(file, channelsHead, baseSampleCount, frequencyFactor, chunkTimestamp, sampleInterval);
		baseSamplesWritten += baseSampleCount;
	}

	printf("%d base samples written to \"%s\"\n", blockSize, fileName);
	fclose(file);
}
/// [AcquireAndWriteBlockToCsv]
