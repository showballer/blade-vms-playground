﻿// Copyright (c) 2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#include "WriteDataToCsv.h"

#include "Utils.h"

/// <summary>Print the CSV header row.</summary>
/// <param name="file">The CSV file handle.</param>
/// <param name="channelsHead">The head of the channels linked list.</param>
void WriteCsvHeaders(FILE* file, ChannelNode* channelsHead)
{
	fputs("Timestamp (s)", file);
	for (ChannelNode* currentChannel = channelsHead; currentChannel; currentChannel = currentChannel->Next)
	{
		// DataValidity is not outputed to the CSV file
		if (currentChannel->ChannelType == PTCChannelType_DataValidity)
			continue;

		fprintf(file, ";%s %d (%s)", ChannelTypeToName(currentChannel->ChannelType), currentChannel->ChannelId, currentChannel->Unit);
		if (IsSignalChannel(currentChannel->ChannelType))
			fprintf(file, ";%s %d (Overrange)", ChannelTypeToName(currentChannel->ChannelType), currentChannel->ChannelId);
	}
	fputs("\n", file);
}

/// <summary>Writes the acquired data to a CSV file.</summary>
/// <param name="file">The CSV file handle.</param>
/// <param name="channelsHead">The head of the channels linked list.</param>
/// <param name="baseSampleCount">Number of base samples to be acquired and written to the CSV file.</param>
/// <param name="frequencyFactor">The frequency factor.</param>
/// <param name="chunkTimestamp">The timestamp to use for the first sample of this chunk seconds.</param>
/// <param name="daqSampleInterval">The time between DAQ samples (not base samples).</param>
void WriteDataToCsv(FILE* file, ChannelNode* channelsHead, size_t baseSampleCount, int frequencyFactor,
	double chunkTimestamp, double daqSampleInterval)
{
	// print samples row by row (single sample from each channel)
	for (size_t n = 0; n < baseSampleCount; n++)
	{
		for (int i = 0; i < frequencyFactor; i++)
		{
			// write timestamp
			fprintf(file, "%.8e", chunkTimestamp + (n * frequencyFactor + i) * daqSampleInterval);

			for (ChannelNode* currentChannel = channelsHead; currentChannel; currentChannel = currentChannel->Next)
			{
				// RSSI samples use the base sample rate
				const int index = currentChannel->ChannelType == PTCChannelType_RSSI ? n : n * frequencyFactor + i;

				if (currentChannel->ChannelType == PTCChannelType_DataValidity)
				{
					// check data validity, invalid samples indicate lost samples
					FailIf(!currentChannel->Samples[index], "Lost data packet.");

					// skip printing to CSV
					continue;
				}

				// Important: numeric formatting can be a bottleneck,
				// consider writing binary data for high performance applications
				if (currentChannel->ChannelType == PTCChannelType_Trigger)
					fprintf(file, ";%d", currentChannel->Samples[index]);
				else
				{
					fprintf(file, ";%.8e", currentChannel->ScaleFactor * currentChannel->Samples[index]);
					if (IsSignalChannel(currentChannel->ChannelType))
						fprintf(file, ";%d", currentChannel->Overrange[index]);;
				}
			}
			fputs("\n", file);
		}
	}
}
