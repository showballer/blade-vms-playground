// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#include "DataPlot.h"

#include "DataAcquisitionModel.h"

#include <QPainter>
#include <QPaintEvent>

#include <chrono>
#include <stdexcept>

namespace Polytec::DevicePanel
{
	/// <summary>Constructs a data plot. The plot shows acquired data.</summary>
	/// <param name="daqModel">The data acquisition model.</param>
	/// <param name="channel">The channel.</param>
	/// <param name="parent">[in,out] The parent widget.</param>
	DataPlot::DataPlot(const DataAcquisitionModel& daqModel, const Polytec::IO::Channel& channel, QWidget* parent)
		: QWidget(parent)
		, m_daqModel(daqModel)
		, m_channel(channel)
		, m_backgroundBrush(QBrush(Qt::black))
		, m_seriesColor(Qt::green)
		, m_overrangeColor(255, 125, 0) // orrange
	{
		setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
	}

	/// <summary>Sets the x-coordinate size in samples.</summary>
	/// <exception cref="std::invalid_argument">Throws an invalid argument exception when the size is
	/// not positive.</exception>
	/// <param name="xSize">The size in samples.</param>
	void DataPlot::SetXSize(int xSize)
	{
		if (xSize <= 0)
			throw std::invalid_argument("DataPlot: xSize must be greater than 0");

		m_xSize = xSize;
	}

	/// <summary>Sets the y-coordinate range.</summary>
	/// <exception cref="std::invalid_argument">Throws an invalid argument exception when the minimum
	/// is not smaller than the maximum.</exception>
	/// <param name="yMin">The minimum.</param>
	/// <param name="yMax">The maximum.</param>
	void DataPlot::SetYRange(double yMin, double yMax)
	{
		if (yMin >= yMax)
			throw std::invalid_argument("DataPlot: yMin must be smaller than yMax");

		m_yMin = yMin;
		m_yMax = yMax;
	}

	QSize DataPlot::sizeHint() const
	{
		return QSize(500, 250);
	}

	void DataPlot::paintEvent(QPaintEvent* event)
	{
		QPainter painter(this);
		painter.setRenderHint(QPainter::Antialiasing);

		painter.fillRect(event->rect(), m_backgroundBrush);
		PaintSeries(painter);
	}

	void DataPlot::PaintSeries(QPainter& painter)
	{

		std::pair<int, int> nextMinMax;
		for (int x = 0; x < width(); x++)
		{
			const auto dataRange = std::make_pair(
				DataIteratorForXCoordinate(AcquiredData(), x),
				DataIteratorForXCoordinate(AcquiredData(), x + 1));

			if (dataRange.first == AcquiredData().cend())
			{
				break;
			}

			painter.setPen(IsSignalChannel(m_channel) && DataOutOfRange(x)
				? m_overrangeColor
				: m_seriesColor);

			const auto lastMinMax = std::exchange(nextMinMax, MinMax(dataRange));
			painter.drawLine(
				QPoint(x, YCoordinate(nextMinMax.first)),
				QPoint(x, YCoordinate(nextMinMax.second)));
			painter.drawLine(
				QPoint(x-1, YCoordinate(lastMinMax.first)),
				QPoint(x, YCoordinate(nextMinMax.first)));
			painter.drawLine(
				QPoint(x-1, YCoordinate(lastMinMax.second)),
				QPoint(x, YCoordinate(nextMinMax.second)));
		}
	}

	DataPlot::DataIterator DataPlot::DataIteratorForXCoordinate(const std::vector<int>& acquiredData, int xCoordinate) const
	{
		if (width() == 0)
		{
			return acquiredData.cend();
		}
		const auto offset = (m_xSize * xCoordinate / width());
		return offset > acquiredData.size()
			? acquiredData.cend()
			: acquiredData.cbegin() + offset;
	}

	const std::vector<int>& DataPlot::AcquiredData() const
	{
		return m_daqModel.AcquiredData(m_channel);
	}

	std::pair<int, int> DataPlot::MinMax(const DataRange& dataRange) const
	{
		const auto minMax = std::minmax_element(dataRange.first, dataRange.second);
		return {*minMax.first, *minMax.second};
	}

	int DataPlot::YCoordinate(int dataValue) const
	{
		constexpr int verticalPadding = 2;
		const int h = height() - 2 * verticalPadding;
		const int yWindow = h * (m_yMax - dataValue) / (m_yMax - m_yMin);
		return yWindow + verticalPadding;
	}

	bool DataPlot::DataOutOfRange(int xCoordinate) const
	{
		const auto& overrangeData = m_daqModel.AcquiredOverrange(m_channel);
		// Looking for overrange also in the preceding coordinate, since lines are drawn from x-1 to x
		const auto begin = DataIteratorForXCoordinate(overrangeData, std::max(0, xCoordinate - 1));
		const auto end = DataIteratorForXCoordinate(overrangeData, xCoordinate + 1);
		return begin != overrangeData.cend()
			&& *std::max_element(begin, end) != 0;
	}
}
