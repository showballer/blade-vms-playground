// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#include "AboutDialog.h"

#include <QLabel>
#include <QVBoxLayout>

#include <sstream>

using namespace Polytec::DevicePanel;

/// <summary>Constructs an about dialog with licensing information.</summary>
/// <param name="parent">[in,out] The parent widget.</param>
AboutDialog::AboutDialog(QWidget* parent)
	: QMessageBox(parent)
	, m_layout(new QVBoxLayout)
{
	setWindowTitle("License information");
	setText("<b>Copyright notice</b>");
	std::stringstream license;

	license << u8"Copyright (c) 2016-2021 Polytec GmbH, Waldbronn" << std::endl;
	license << std::endl;

	license << "This program is free software: you can redistribute it and/or modify" << std::endl;
	license << "it under the terms of the GNU Lesser General Public License as" << std::endl;
	license << "published by the Free Software Foundation, version 3." << std::endl;
	license << std::endl;

	license << "This program is distributed in the hope that it will be useful, but" << std::endl;
	license << "WITHOUT ANY WARRANTY; without even the implied warranty of" << std::endl;
	license << "MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU" << std::endl;
	license << "Lesser General Lesser Public License for more details." << std::endl;
	license << std::endl;

	license << "You should have received a copy of the GNU Lesser General Public License" << std::endl;
	license << "along with this program. If not, see <http://www.gnu.org/licenses/>." << std::endl;
	license << std::endl;

	license << "---------------------------------------------------------------------" << std::endl;
	license << std::endl;

	license << "This program uses Qt which is free software. The use of Qt" << std::endl;
	license << "is covered by the GNU LGPL v.3." << std::endl;

	setInformativeText(QString::fromStdString(license.str()));
}
