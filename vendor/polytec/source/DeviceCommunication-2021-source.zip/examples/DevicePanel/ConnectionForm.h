// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#pragma once

#include <QWidget>

#include <memory>

class QFormLayout;
class QComboBox;
class QLabel;
class QLineEdit;

namespace Polytec
{
	namespace IO
	{
		class DeviceCommunication;
	}
	namespace DevicePanel
	{
		class ConnectionForm : public QWidget
		{
			Q_OBJECT

		public:
			explicit ConnectionForm(QWidget* parent = nullptr);
			~ConnectionForm() noexcept;

			Polytec::IO::DeviceCommunication CreateCommunication() const;
			void SetBaudRate(const QString& baudRate);

		signals:
			void Connect();

		private:
			void CreateCommunicatioProtocolSelection();
			void CreateEthernetForm();
			void CreateSerialForm();
			void FillCachedData();

			enum class CommunicationType { None, Serial, Udp, Tcp };
			CommunicationType GetCommunicationType() const;
			void UpdateCommunicationType(const std::wstring& communicationType);


			QFormLayout* m_layout{};
			QComboBox* m_communicationProtocolSelection{};
			QLineEdit* m_ethernetEdit{};
			QComboBox* m_serialEdit{};
			QComboBox* m_serialBaudRateEdit{};
			QLabel* m_ethernetLabel{};
			QLabel* m_serialLabel{};
			QLabel* m_serialBaudRateLabel{};
		};
	}
}
