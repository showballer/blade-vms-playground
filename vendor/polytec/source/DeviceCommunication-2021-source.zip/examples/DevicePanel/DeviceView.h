// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#pragma once

#include "CommunicationModel.h"

#include <QTabWidget>

namespace Polytec
{
	namespace DevicePanel
	{
		class CommunicationView;
		class DataAcquisitionView;
		class DataAcquisitionModel;

		class DeviceView : public QTabWidget
		{
			Q_OBJECT

		public:
			explicit DeviceView(Polytec::IO::DeviceCommunication communication, QWidget* parent = nullptr);
			DeviceView(const DeviceView&) = delete;
			DeviceView& operator=(const DeviceView&) = delete;
			DeviceView(DeviceView&&) = delete;
			DeviceView& operator=(DeviceView&&) = delete;
			~DeviceView();
			CommunicationView* GetCommunicationView() { return m_communicationView; }

		signals:
			void ExceptionThrown(const std::exception& e) const;

		private:
			void AddAcquisitionTab();
			void RemoveAcquisitionTab();
			std::unique_ptr<DataAcquisitionModel> CreateDaqModel();

			CommunicationModel m_communicationModel;
			std::unique_ptr<DataAcquisitionModel> m_daqModel;
			CommunicationView* m_communicationView{};
			std::unique_ptr<DataAcquisitionView> m_daqView{};
			int m_daqTabId = -1;
		};
	}
}
