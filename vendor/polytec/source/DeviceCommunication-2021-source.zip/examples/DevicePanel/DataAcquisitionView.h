// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#pragma once

#include <QWidget>

#include <chrono>
#include <vector>

class QBoxLayout;
class QComboBox;
class QPushButton;
class QWidget;

namespace Polytec
{
	namespace IO
	{
		class AcquisitionException;
		class Channel;
		class CommunicationException;
	}
	namespace DevicePanel
	{
		class CommunicationModel;
		class DataAcquisitionModel;
		class DataPlot;

		class DataAcquisitionView : public QWidget
		{
			Q_OBJECT

		public:
			DataAcquisitionView(CommunicationModel& communicationModel,
				DataAcquisitionModel& daqModel, QWidget* parent = nullptr);

		signals:
			void OnExceptionThrown(const std::exception& e) const;

		private:
			void AddStartStopButton();
			void AddTimeIntervalComboBox();
			void UpdateTimeInterval();
			void SetButtonsState(bool operationMode);
			void UpdatePlots();
			void AddTitle(const Polytec::IO::Channel& channel);
			void AddPlot(const Polytec::IO::Channel& channel);

			void timerEvent(QTimerEvent* event) override;

			template<typename Sender, typename Signal, typename Slot, typename... Args>
			QMetaObject::Connection ConnectHandled(const Sender* sender, void(Signal::* signal)(Args...), Slot slot);


			CommunicationModel& m_communicationModel;
			DataAcquisitionModel& m_daqModel;
			QBoxLayout* m_layout{};
			QComboBox* m_timeIntervalControl{};
			QPushButton* m_startButton{};
			QPushButton* m_stopButton{};
			QWidget* m_plots{};
		};
	}
}
