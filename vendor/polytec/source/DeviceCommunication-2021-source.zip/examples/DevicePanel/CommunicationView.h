// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#pragma once
#include "CommunicationModel.h"

#include <IO/DeviceCommunication/DeviceCommunication.h>
#include <IO/DeviceCommunication/PTCDeviceType.h>

#include <QWidget>

class QComboBox;
class QFormLayout;
class QLabel;
class QLineEdit;
class QProgressBar;
class QSpinBox;
class QString;
class QTimerEvent;

namespace Polytec
{
	namespace IO
	{
		class CommunicationException;
	}

	namespace DevicePanel
	{
		class CommunicationView : public QWidget
		{
			Q_OBJECT

		public:
			explicit CommunicationView(CommunicationModel& model, QWidget* parent = nullptr);

		signals:
			void OnExceptionThrown(const Polytec::IO::CommunicationException& e) const;
			void OnBaudRateChanged(const QString& baudRate) const;

		private:
			void CreateNameLabel();
			void CreateBandwidth();
			void CreateVelocityRange();
			void CreateVelocityMaximumRange();
			void CreateTrackingFilter();
			void CreateHighPass();
			QComboBox* CreateComboBox(const Polytec::IO::Device& device, PTCDeviceCommand command);
			void UpdateDemodulation();
			void UpdateComboBox(QComboBox* comboBox, const Polytec::IO::Device& device, PTCDeviceCommand command);
			void FillComboBox(QComboBox& box, const std::string& list);
			void CreateFocusButtons();
			void CreateFocusPositionBox();
			void CreateAutofocusLimitsBox();
			void UpdateAutofocusLimits(const std::pair<int, int>& range);
			void CreateBaudRateCombo();
			void CreateAseFilterSwitch();
			void CreateLaserSwitch();
			void CreateSignalLevelBar();
			void UpdateSignalLevel();
			void UpdateOverrange();
			void CreateTemperatureLabel();
			void CreateUserSettingsSaveButton();
			void CreateUserSettingsBox();
			void CreatePowerUpFocusPosition();

			void timerEvent(QTimerEvent* event) override;
			void Update();
			void UpdateTemperature();

			template<typename Sender, typename Signal, typename Slot, typename... Args>
			QMetaObject::Connection ConnectHandled(const Sender* sender, void(Signal::* signal)(Args...), Slot slot);

			CommunicationModel& m_model;
			QFormLayout* m_layout{};
			QComboBox* m_sampleRate{};
			QComboBox* m_bandwidth{};
			QComboBox* m_velocityRange{};
			QComboBox* m_velocityMaximumRange{};
			QComboBox* m_trackingFilter{};
			QComboBox* m_highPass{};
			QLineEdit* m_focusPositionBox{};
			QLineEdit* m_limiterMin{};
			QLineEdit* m_limiterMax{};
			QProgressBar* m_signalLevelBar{};
			QLabel* m_overrangeLabel{};
			QLabel* m_temperatureLabel{};
		};
	}
}
