// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#include "CommunicationView.h"

#include <IO/DeviceCommunication/AllCommunication.h>

#include <QButtonGroup>
#include <QCheckBox>
#include <QComboBox>
#include <QDoubleSpinBox>
#include <QErrorMessage>
#include <QFormLayout>
#include <QGroupBox>
#include <QHBoxLayout>
#include <QLabel>
#include <QLineEdit>
#include <QMessageBox>
#include <QProgressBar>
#include <QPushButton>
#include <QRadioButton>
#include <QSpinBox>
#include <QStandardItemModel>
#include <QTimer>
#include <QtGlobal>

#include <algorithm>
#include <sstream>

using namespace Polytec::DevicePanel;

namespace
{
	constexpr int c_timerIntervalMilliseconds = 2'000;

	QString GetDegreeCelsius()
	{
		return QString::fromLatin1("�C");
	}

	void SetComboBoxItem(QComboBox& comboBox, int index, bool enable)
	{
		const QStandardItemModel* model = qobject_cast<const QStandardItemModel*>(comboBox.model());
		QStandardItem* item = model->item(index);
		if (enable)
		{
			item->setFlags(Qt::ItemIsSelectable | Qt::ItemIsEnabled);
			item->setData(QVariant(), Qt::TextColorRole);
		}
		else
		{
			item->setFlags(item->flags() & ~(Qt::ItemIsSelectable | Qt::ItemIsEnabled));
			item->setData(comboBox.palette().color(QPalette::Disabled, QPalette::Text), Qt::TextColorRole);
		}
	}

	class ExpandingLabel : public QLabel
	{
	public:
		ExpandingLabel(QString text, QWidget* parent = nullptr)
			: QLabel(text, parent)
		{
			setSizePolicy(QSizePolicy::Preferred, QSizePolicy::Expanding);
		}
	};
}

/// <summary>
/// Constructs a communication view. The communication view enables the user to communicate with
/// the connected device.
/// </summary>
/// <param name="model">[in,out] The communication model.</param>
/// <param name="parent">[in,out] The parent widget.</param>
CommunicationView::CommunicationView(CommunicationModel& model, QWidget* parent)
	: QWidget(parent)
	, m_model(model)
	, m_layout(new QFormLayout(this))
{
	setLayout(m_layout);
	m_layout->setFieldGrowthPolicy(QFormLayout::AllNonFixedFieldsGrow);

	CreateNameLabel();
	CreateBandwidth();
	CreateVelocityRange();
	CreateVelocityMaximumRange();
	CreateTrackingFilter();
	CreateHighPass();
	CreateFocusButtons();
	CreateFocusPositionBox();
	CreateAutofocusLimitsBox();
	CreateAseFilterSwitch();
	CreateLaserSwitch();
	CreateSignalLevelBar();
	CreateTemperatureLabel();
	CreateBaudRateCombo();
	CreateUserSettingsSaveButton();
	CreateUserSettingsBox();
	CreatePowerUpFocusPosition();

	startTimer(c_timerIntervalMilliseconds);
	UpdateDemodulation();
	Update();
}

void CommunicationView::CreateNameLabel()
{
	std::string name = m_model.GetName();
	m_layout->addRow(new ExpandingLabel(tr("Name:")), new QLabel(QString::fromStdString(name)));
}

void CommunicationView::CreateBandwidth()
{
	if (!m_model.HasBandwith())
		return;
	const auto decoder = Polytec::IO::Device(PTCDeviceType_VelocityDecoderDigital);
	m_bandwidth = CreateComboBox(decoder, PTCDeviceCommand_Bandwidth);
	m_layout->addRow(new ExpandingLabel(tr("Bandwidth:")), m_bandwidth);

	ConnectHandled(m_bandwidth, QOverload<int>::of(&QComboBox::currentIndexChanged),
		[this](int index) { UpdateDemodulation(); });

	connect(&m_model, &CommunicationModel::DecoderLocked,
		[this](bool locked) { m_bandwidth->setDisabled(locked); });
}

void CommunicationView::CreateVelocityRange()
{
	if (!m_model.HasVelocityRange())
		return;
	const auto decoder = Polytec::IO::Device(PTCDeviceType_VelocityDecoderDigital);
	m_velocityRange = CreateComboBox(decoder, PTCDeviceCommand_Range);
	auto* hLayout = new QHBoxLayout;
	m_overrangeLabel = new QLabel(tr("Overrange"));
	hLayout->addWidget(m_velocityRange);
	hLayout->addWidget(m_overrangeLabel);
	m_velocityRange->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
	m_layout->addRow(new ExpandingLabel(tr("Velocity:")), hLayout);

	ConnectHandled(m_velocityRange, QOverload<int>::of(&QComboBox::currentIndexChanged),
		[this](int index) { UpdateDemodulation(); });

	connect(&m_model, &CommunicationModel::DecoderLocked,
		[this](bool locked) { m_velocityRange->setDisabled(locked); });
}

void CommunicationView::CreateVelocityMaximumRange()
{
	if (!m_model.HasVelocityMaximumRange())
		return;
	const auto decoder = Polytec::IO::Device(PTCDeviceType_VelocityDecoderDigital);
	m_velocityMaximumRange = CreateComboBox(decoder, PTCDeviceCommand_MaximumVelocityRange);
	m_layout->addRow(new ExpandingLabel(tr("Velocity maximum range:")), m_velocityMaximumRange);

	ConnectHandled(m_velocityRange, QOverload<int>::of(&QComboBox::currentIndexChanged),
		[this](int index) { UpdateDemodulation(); });

	connect(&m_model, &CommunicationModel::DecoderLocked,
		[this](bool locked) { m_velocityMaximumRange->setDisabled(locked); });
}

void CommunicationView::CreateTrackingFilter()
{
	if (!m_model.HasTrackingFilter())
		return;
	const auto decoder = Polytec::IO::Device(PTCDeviceType_VelocityDecoderDigital);
	m_trackingFilter = CreateComboBox(decoder, PTCDeviceCommand_TrackingFilterRange);
	m_layout->addRow(new ExpandingLabel(tr("Tracking Filter:")), m_trackingFilter);

	ConnectHandled(m_trackingFilter, QOverload<int>::of(&QComboBox::currentIndexChanged),
		[this](int index) { UpdateDemodulation(); });

	connect(&m_model, &CommunicationModel::DecoderLocked,
		[this](bool locked) { m_trackingFilter->setDisabled(locked); });
}

void CommunicationView::CreateHighPass()
{
	if (!m_model.HasHighPass())
		return;
	const auto decoder = Polytec::IO::Device(PTCDeviceType_VelocityDecoderDigital);
	m_highPass = CreateComboBox(decoder, PTCDeviceCommand_HighPass);
	m_layout->addRow(new ExpandingLabel(tr("High-Pass Filter:")), m_highPass);

	connect(&m_model, &CommunicationModel::DecoderLocked,
		[this](bool locked) { m_highPass->setDisabled(locked); });
}

QComboBox* CommunicationView::CreateComboBox(const Polytec::IO::Device& device, PTCDeviceCommand command)
{
	auto comboBox = new QComboBox(this);

	std::string valueList = m_model.GetCommunication().SendGetValueList<std::string>(device, command);
	FillComboBox(*comboBox, valueList);

	int index = m_model.GetCommunication().SendGet<int16_t>(device, command);
	comboBox->setCurrentIndex(index);

	ConnectHandled(comboBox, QOverload<int>::of(&QComboBox::currentIndexChanged),
		[this, device, command](int index)
	{
		m_model.SendSetIndex(device, command, index);
	});

	return comboBox;
}

void CommunicationView::UpdateDemodulation()
{
	UpdateComboBox(m_bandwidth, {PTCDeviceType_VelocityDecoderDigital}, PTCDeviceCommand_Bandwidth);
	UpdateComboBox(m_velocityRange, {PTCDeviceType_VelocityDecoderDigital}, PTCDeviceCommand_Range);
	UpdateComboBox(m_velocityMaximumRange, {PTCDeviceType_VelocityDecoderDigital}, PTCDeviceCommand_MaximumVelocityRange);
	UpdateComboBox(m_trackingFilter, {PTCDeviceType_VelocityDecoderDigital}, PTCDeviceCommand_TrackingFilterRange);
	UpdateComboBox(m_highPass, {PTCDeviceType_VelocityDecoderDigital}, PTCDeviceCommand_HighPass);
}

void CommunicationView::UpdateComboBox(QComboBox* comboBox, const Polytec::IO::Device& device, PTCDeviceCommand command)
{
	if (comboBox)
	{
		comboBox->setCurrentIndex(m_model.GetCommunication().SendGet<std::int16_t>(device, command));
		const auto devInfo = m_model.GetCommunication().SendGetDevInfo<std::vector<std::int16_t>>(device, command);
		for (int idx = 0; idx < comboBox->count(); idx++)
		{
			const bool enabled = std::find(begin(devInfo), end(devInfo), idx) != end(devInfo);
			SetComboBoxItem(*comboBox, static_cast<int>(idx), enabled);
		}
	}
}

void CommunicationView::FillComboBox(QComboBox& box, const std::string& list)
{
	std::stringstream stream(list);
	std::string item;
	while (std::getline(stream, item, ','))
		box.addItem(QString::fromStdString(item));
}

void CommunicationView::CreateFocusButtons()
{
	if (!m_model.HasAutofocus())
		return;

	auto* hLayout = new QHBoxLayout;
	auto* near = new QPushButton(tr("N"));
	auto* autofocus = new QPushButton(tr("Autofocus"));
	auto* far = new QPushButton(tr("F"));
	hLayout->addWidget(near);
	hLayout->addWidget(autofocus);
	hLayout->addWidget(far);
	m_layout->addRow(new ExpandingLabel(tr("Focus:")), hLayout);

	ConnectHandled(autofocus, &QPushButton::clicked, [this](bool) { m_model.SwitchAutofocusState(); });

	ConnectHandled(near, &QPushButton::pressed, [this]() { m_model.MoveFocusNear(); });
	ConnectHandled(near, &QPushButton::released, [this]() { m_model.StopMoveFocus(); });

	ConnectHandled(far, &QPushButton::pressed, [this]() { m_model.MoveFocusFar(); });
	ConnectHandled(far, &QPushButton::released, [this]() { m_model.StopMoveFocus(); });
}

void CommunicationView::CreateFocusPositionBox()
{
	if (!m_model.HasAutofocus())
		return;

	m_focusPositionBox = new QLineEdit;
	m_focusPositionBox->setValidator(new QIntValidator(this));
	m_layout->addRow(new ExpandingLabel(tr("Focus Position:")), m_focusPositionBox);

	ConnectHandled(m_focusPositionBox, &QLineEdit::editingFinished, [this]()
	{
		int position = m_focusPositionBox->text().toInt();
		m_model.MoveFocus(position);
	});
	connect(&m_model, &CommunicationModel::FocusRunning,
		[this](bool running) { m_focusPositionBox->setEnabled(!running); });
	connect(&m_model, &CommunicationModel::FocusChanged,
		[this](int position) { m_focusPositionBox->setText(QString::number(position)); });
}

void CommunicationView::CreateAutofocusLimitsBox()
{
	if (!m_model.HasAutofocusRange())
		return;

	auto limiterGroup = new QGroupBox;
	limiterGroup->setCheckable(true);

	auto limiterForm = new QFormLayout(limiterGroup);
	m_limiterMin = new QLineEdit;
	m_limiterMax = new QLineEdit;
	limiterForm->addRow(new QLabel(tr("Minimum")), m_limiterMin);
	limiterForm->addRow(new QLabel(tr("Maximum")), m_limiterMax);

	m_layout->addRow(new ExpandingLabel(tr("Autofocus Range:")), limiterGroup);

	auto limiter = m_model.GetAutofocusLimits();
	UpdateAutofocusLimits(limiter);

	auto range = m_model.GetFocusRange();
	limiterGroup->setChecked(limiter != range);

	ConnectHandled(limiterGroup, &QGroupBox::clicked,
		[this](bool on) { m_model.SetAutofocusLimitsEnabled(on); });

	ConnectHandled(m_limiterMin, &QLineEdit::editingFinished,
		[this]() { m_model.SetAutofocusLimitMinimum(m_limiterMin->text().toInt()); });

	ConnectHandled(m_limiterMax, &QLineEdit::editingFinished,
		[this]() { m_model.SetAutofocusLimitMaximum(m_limiterMax->text().toInt()); });

	connect(&m_model, &CommunicationModel::AutofocusLimitsModified,
		[this](std::pair<int, int> range) { UpdateAutofocusLimits(range); });
}

void CommunicationView::UpdateAutofocusLimits(const std::pair<int, int>& range)
{
	if (!m_model.HasAutofocusRange())
		return;
	m_limiterMin->setText(QString::number(range.first));
	m_limiterMax->setText(QString::number(range.second));
}

void CommunicationView::CreateAseFilterSwitch()
{
	if (!m_model.HasAseFilter())
		return;
	auto aseOn = new QRadioButton(tr("On"));
	auto aseOff = new QRadioButton(tr("Off"));
	auto aseGroup = new QButtonGroup(this);
	aseGroup->addButton(aseOn);
	aseGroup->addButton(aseOff);
	auto aseLayout = new QHBoxLayout;
	aseLayout->addWidget(aseOn);
	aseLayout->addWidget(aseOff);
	aseLayout->setAlignment(Qt::AlignLeft);

	m_layout->addRow(new ExpandingLabel(tr("ASE Filter:")), aseLayout);

	if (m_model.IsAseFilterOn())
		aseOn->setChecked(true);
	else
		aseOff->setChecked(true);

	ConnectHandled(aseOn, &QRadioButton::clicked, [this](bool) { m_model.SetAseFilterOn(true); });
	ConnectHandled(aseOff, &QRadioButton::clicked, [this](bool) { m_model.SetAseFilterOn(false); });
}

void CommunicationView::CreateBaudRateCombo()
{
	if (!m_model.HasBaudrate())
		return;

	const auto comboBox = CreateComboBox(
		Polytec::IO::Device(PTCDeviceType_Controller), PTCDeviceCommand_BaudRate);

	m_layout->addRow(new ExpandingLabel(tr("Baud Rate:")), comboBox);

	ConnectHandled(comboBox, QOverload<const QString&>::of(&QComboBox::currentIndexChanged),
		[this, comboBox](const QString& rate) { emit OnBaudRateChanged(rate); });
}

void CommunicationView::CreateLaserSwitch()
{
	if (!m_model.HasLaser())
		return;
	auto laserOn = new QRadioButton(tr("On"));
	auto laserOff = new QRadioButton(tr("Off"));
	auto laserGroup = new QButtonGroup(this);
	laserGroup->addButton(laserOn);
	laserGroup->addButton(laserOff);
	auto laserLayout = new QHBoxLayout;
	laserLayout->addWidget(laserOn);
	laserLayout->addWidget(laserOff);
	laserLayout->setAlignment(Qt::AlignLeft);

	m_layout->addRow(new ExpandingLabel(tr("Laser:")), laserLayout);

	if (m_model.IsLaserOn())
		laserOn->setChecked(true);
	else
		laserOff->setChecked(true);

	ConnectHandled(laserOn, &QRadioButton::clicked, [this](bool) { m_model.SetLaser(true); });
	ConnectHandled(laserOff, &QRadioButton::clicked, [this](bool) { m_model.SetLaser(false); });
}

void CommunicationView::CreateSignalLevelBar()
{
	if (!m_model.HasSignalLevel())
		return;
	m_signalLevelBar = new QProgressBar;
	m_layout->addRow(new ExpandingLabel(tr("Signal Level:")), m_signalLevelBar);

	auto range = m_model.GetSignalLevelRange();
	m_signalLevelBar->setMinimum(range.first);
	m_signalLevelBar->setMaximum(range.second);

	UpdateSignalLevel();
	UpdateOverrange();
}

void CommunicationView::UpdateSignalLevel()
{
	if (!m_model.HasSignalLevel())
		return;
	const int signalLevel = m_model.GetSignalLevel();
	m_signalLevelBar->setValue(signalLevel);
}

void CommunicationView::UpdateOverrange()
{
	if (!m_model.HasOverrange())
		return;
	if (m_model.GetOverrange())
		m_overrangeLabel->setStyleSheet("QLabel { color: red }");
	else
		m_overrangeLabel->setStyleSheet("QLabel { color: gray }");
}

void CommunicationView::CreateTemperatureLabel()
{
	if (!m_model.HasTemperature())
		return;
	m_temperatureLabel = new QLabel;
	m_layout->addRow(new ExpandingLabel(tr("Temperature:")), m_temperatureLabel);
}

void CommunicationView::CreateUserSettingsSaveButton()
{
	if (!m_model.HasUserSettings())
		return;
	auto saveButton = new QPushButton(tr("Save"));
	m_layout->addRow(new ExpandingLabel(tr("Save User1 Settings:")), saveButton);

	ConnectHandled(saveButton, &QPushButton::clicked, [this](bool) { m_model.SaveUserSettings(); });
}

void CommunicationView::CreateUserSettingsBox()
{
	if (!m_model.HasUserSettings())
		return;
	const auto controller = Polytec::IO::Device(PTCDeviceType_Controller);
	const auto comboBox = CreateComboBox(controller, PTCDeviceCommand_PowerUpSettings);
	m_layout->addRow(new ExpandingLabel(tr("Power-Up User Settings:")), comboBox);
}

void CommunicationView::CreatePowerUpFocusPosition()
{
	if (!m_model.HasPowerUpFocusPosition())
		return;

	auto autofocusButton = new QRadioButton(tr("Autofocus"));
	auto focusPositionButton = new QRadioButton(tr("Focus Position"));
	auto powerUpGroup = new QButtonGroup(this);
	powerUpGroup->addButton(autofocusButton);
	powerUpGroup->addButton(focusPositionButton);

	auto powerUpFocusPositionBox = new QLineEdit;
	powerUpFocusPositionBox->setValidator(new QIntValidator(this));
	const int position = m_model.GetPowerUpFocusPosition();
	powerUpFocusPositionBox->setText(QString::number(std::max(0, position)));

	auto powerUpLayout = new QHBoxLayout;
	powerUpLayout->addWidget(autofocusButton);
	powerUpLayout->addWidget(focusPositionButton);
	powerUpLayout->addWidget(powerUpFocusPositionBox);
	powerUpLayout->setAlignment(Qt::AlignLeft);

	if (m_model.GetPowerUpFocusPosition() == -1)
	{
		autofocusButton->setChecked(true);
		powerUpFocusPositionBox->setEnabled(false);
	}
	else
	{
		focusPositionButton->setChecked(true);
		powerUpFocusPositionBox->setEnabled(true);
	}

	m_layout->addRow(new ExpandingLabel(tr("Power-Up Focus Position:")), powerUpLayout);

	ConnectHandled(powerUpFocusPositionBox, &QLineEdit::editingFinished, [this, powerUpFocusPositionBox]()
	{
		int position = powerUpFocusPositionBox->text().toInt();
		m_model.SetPowerUpFocusPosition(position);
	});
	ConnectHandled(autofocusButton, &QRadioButton::clicked, [this, powerUpFocusPositionBox](bool)
	{
		m_model.SetPowerUpFocusPosition(-1);
		powerUpFocusPositionBox->setEnabled(false);
	});
	ConnectHandled(focusPositionButton, &QRadioButton::clicked, [this, powerUpFocusPositionBox](bool)
	{
		int position = powerUpFocusPositionBox->text().toInt();
		m_model.SetPowerUpFocusPosition(position);
		powerUpFocusPositionBox->setEnabled(true);
	});
	connect(&m_model, &CommunicationModel::PowerUpFocusPositionModified,
		[this, powerUpFocusPositionBox](int position)
	{
		powerUpFocusPositionBox->setText(QString::number(position));
	});
}

void CommunicationView::timerEvent(QTimerEvent*)
{
	try
	{
		Update();
	}
	catch (const Polytec::IO::CommunicationException& e)
	{
		OnExceptionThrown(e);
	}
}

void CommunicationView::Update()
{
	UpdateSignalLevel();
	UpdateOverrange();
	UpdateTemperature();
	m_model.CheckFocusChanged();
}

void CommunicationView::UpdateTemperature()
{
	if (m_model.HasTemperature())
	{
		const float temperature = m_model.GetTemperature();
		m_temperatureLabel->setText(QString::number(temperature, 'f', 1) + GetDegreeCelsius());
	}
}

template<typename Sender, typename Signal, typename Slot, typename... Args>
QMetaObject::Connection CommunicationView::ConnectHandled(const Sender* sender,
	void(Signal::* signal)(Args...), Slot slot)
{
	return connect(sender, signal, [this, slot](Args... args)
	{
		try
		{
			slot(args...);
		}
		catch (const Polytec::IO::CommunicationException& e)
		{
			OnExceptionThrown(e);
		}
	});
}
