// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#pragma once

#include <QWidget>

class QLayout;
class QPushButton;

namespace Polytec
{
	namespace DevicePanel
	{
		class AboutDialog;

		class SideBar : public QWidget
		{
			Q_OBJECT

		public:
			explicit SideBar(QWidget* parent = nullptr);

			void SetConnectionState(bool connected);

		signals:
			void ConnectClicked();
			void DisconnectClicked();

		private:
			void CreateConnectButton();
			void CreateDisconnectButton();
			void CreateAboutButton();

			QLayout* m_layout{};
			QPushButton* m_connectButton{};
			QPushButton* m_disconnectButton{};
			AboutDialog* m_aboutDialog{};
		};
	}
}
