// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#include "ConnectionForm.h"

#include "Utils.h"

#include <IO/DeviceCommunication/AllCommunication.h>

#include <QButtonGroup>
#include <QComboBox>
#include <QFormLayout>
#include <QGroupBox>
#include <QLabel>
#include <QLineEdit>
#include <QRadioButton>
#include <QSpinBox>
#include <QVBoxLayout>

using namespace Polytec::DevicePanel;
using namespace std::chrono_literals;

namespace
{
	class ComPortComboBox : public QComboBox
	{
	public:
		ComPortComboBox(QWidget* parent)
			: QComboBox(parent)
		{}

	private:
		void showPopup()
		{
			auto comPorts = Polytec::DevicePanel::Utils::FindComPorts();
			clear();
			for (const auto& port : comPorts)
				addItem(QString::fromStdWString(port));
			QComboBox::showPopup();
		}
	};
}

/// <summary>
/// Constructs a connection form. The connection form enables the user to create an Ethernet or a
/// serial communication to a device. Settings from the last usage are read from the cache file.
/// </summary>
/// <param name="parent">[in,out] The parent widget.</param>
ConnectionForm::ConnectionForm(QWidget* parent)
	: QWidget(parent)
	, m_layout(new QFormLayout(this))
	, m_communicationProtocolSelection(new QComboBox(this))
	, m_ethernetEdit(new QLineEdit(this))
	, m_serialEdit(new ComPortComboBox(this))
	, m_serialBaudRateEdit(new QComboBox(this))
	, m_ethernetLabel(new QLabel(tr("Hostname / IP-address:"), this))
	, m_serialLabel(new QLabel(tr("COM-Port:"), this))
	, m_serialBaudRateLabel(new QLabel(tr("Baud Rate:"), this))
{
	m_layout->setAlignment(Qt::AlignTop);
	setLayout(m_layout);

	CreateCommunicatioProtocolSelection();
	CreateEthernetForm();
	CreateSerialForm();
	UpdateCommunicationType(m_communicationProtocolSelection->currentText().toStdWString());

	FillCachedData();
}

/// <summary>Destructor. Writes current settings to a cache file.</summary>
ConnectionForm::~ConnectionForm() noexcept
{
	Utils::WriteCache({
		{L"Connection_Type", m_communicationProtocolSelection->currentText().toStdWString()},
		{L"Ethernet_Connection", m_ethernetEdit->text().toStdWString()},
		{L"Serial_ComPort", m_serialEdit->currentText().toStdWString()},
		{L"Serial_BaudRate", m_serialBaudRateEdit->currentText().toStdWString()}});
}

/// <summary>Creates a device communication based on the user input.</summary>
/// <returns>The new device communication instance.</returns>
Polytec::IO::DeviceCommunication ConnectionForm::CreateCommunication() const
{
	switch (GetCommunicationType())
	{
		case CommunicationType::Serial:
		{
			const auto comPort = m_serialEdit->currentText().toStdWString();
			const int baudRate = m_serialBaudRateEdit->currentText().toInt();
			return Polytec::IO::CreateSerialCommunication(comPort, baudRate, 6s);
		}
		case CommunicationType::Udp:
		{
			const auto hostname = m_ethernetEdit->text().toStdWString();
			return Polytec::IO::CreateUdpEthernetCommunication(hostname, 6s);
		}
		case CommunicationType::Tcp:
		{
			const auto hostname = m_ethernetEdit->text().toStdWString();
			return Polytec::IO::CreateTcpEthernetCommunication(hostname, 6s);
		}
		default:
		{
			throw std::logic_error("No communication type selected");
		}
	}
}

/// <summary>Sets baud rate in the baud rate edit line.</summary>
/// <param name="baudRate">The baud rate to be set.</param>
void ConnectionForm::SetBaudRate(const QString& baudRate)
{
	m_serialBaudRateEdit->setCurrentText(baudRate);
}

void ConnectionForm::CreateCommunicatioProtocolSelection()
{
	m_communicationProtocolSelection->addItem(tr("Serial"));
	m_communicationProtocolSelection->addItem(tr("UDP"));
	m_communicationProtocolSelection->addItem(tr("TCP"));
	m_layout->addRow(new QLabel(tr("Communication Protocol:")), m_communicationProtocolSelection);

	connect(m_communicationProtocolSelection, &QComboBox::currentTextChanged,
		[this] (const QString& text) { UpdateCommunicationType(text.toStdWString()); });
}

void ConnectionForm::CreateEthernetForm()
{
	m_layout->addRow(m_ethernetLabel, m_ethernetEdit);

	connect(m_ethernetEdit, &QLineEdit::returnPressed, this, &ConnectionForm::Connect);
}

void ConnectionForm::CreateSerialForm()
{
	m_layout->addRow(m_serialLabel, m_serialEdit);
	m_layout->addRow(m_serialBaudRateLabel, m_serialBaudRateEdit);

	m_serialEdit->setEditable(true);

	m_serialBaudRateEdit->addItem("115200");
	m_serialBaudRateEdit->addItem("9600");
	m_serialBaudRateEdit->setValidator(new QIntValidator(0, 1e9, this));
	m_serialBaudRateEdit->setEditable(true);
}

void ConnectionForm::FillCachedData()
{
	auto cache = Utils::ReadCache();
	m_ethernetEdit->setText(QString::fromStdWString(cache[L"Ethernet_Connection"]));
	m_serialEdit->setCurrentText(QString::fromStdWString(cache[L"Serial_ComPort"]));
	m_serialBaudRateEdit->setCurrentText(QString::fromStdWString(cache[L"Serial_BaudRate"]));
	UpdateCommunicationType(cache[L"Connection_Type"]);
}

auto ConnectionForm::GetCommunicationType() const -> CommunicationType
{
	const auto communicationProtocol = m_communicationProtocolSelection->currentText().toStdWString();
	if (communicationProtocol == L"Serial")
		return CommunicationType::Serial;
	else if (communicationProtocol == L"UDP")
		return CommunicationType::Udp;
	else if (communicationProtocol == L"TCP")
		return CommunicationType::Tcp;
	else
		return CommunicationType::None;
}

void ConnectionForm::UpdateCommunicationType(const std::wstring& communicationType)
{
	m_communicationProtocolSelection->setCurrentText(QString::fromStdWString(communicationType));
	if (communicationType == L"Serial")
	{
		m_ethernetLabel->hide();
		m_ethernetEdit->hide();
		m_serialEdit->show();
		m_serialLabel->show();
		m_serialBaudRateEdit->show();
		m_serialBaudRateLabel->show();
	}
	else if (communicationType == L"UDP" || communicationType == L"TCP")
	{
		m_ethernetEdit->show();
		m_ethernetLabel->show();
		m_serialEdit->hide();
		m_serialLabel->hide();
		m_serialBaudRateEdit->hide();
		m_serialBaudRateLabel->hide();
	}
}
