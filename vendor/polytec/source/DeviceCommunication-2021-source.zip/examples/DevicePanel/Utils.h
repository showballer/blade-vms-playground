// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#pragma once

#include <map>
#include <string>
#include <vector>

namespace Polytec
{
	namespace DevicePanel
	{
		namespace Utils
		{
			std::map<std::wstring, std::wstring> ReadCache();
			void WriteCache(std::map<std::wstring, std::wstring> data);
			std::vector<std::wstring> FindComPorts();
		}
	}
}
