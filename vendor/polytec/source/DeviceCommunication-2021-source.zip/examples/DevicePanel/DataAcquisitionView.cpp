// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#include "DataAcquisitionView.h"

#include "DataAcquisitionModel.h"
#include "DataPlot.h"

#include <IO/DeviceCommunication/CommunicationException.h>

#include <QComboBox>
#include <QPushButton>
#include <QLabel>
#include <QVBoxLayout>

#include <array>

using namespace Polytec::DevicePanel;
using namespace std::chrono_literals;

namespace
{
	constexpr std::array<std::chrono::duration<double>, 10> c_timeIntervals = {5us, 20us, 50us, 200us, 500us, 2ms, 5ms, 20ms, 50ms, 200ms};

	QString GetTitle(PTCChannelType channelType)
	{
		switch (channelType)
		{
			case PTCChannelType_Velocity:
				return QObject::tr("Velocity");
			case PTCChannelType_Displacement:
				return QObject::tr("Displacement");
			case PTCChannelType_Acceleration:
				return QObject::tr("Acceleration");
			case PTCChannelType_SignalLevel:
				return QObject::tr("Signal Level");
			case PTCChannelType_Trigger:
				return QObject::tr("Trigger");
			default:
				return QObject::tr("Unknown channel type");
		}
	}
}

/// <summary>Constructs a data acquisition view. The data acquisition view enables the user
/// 		 to start and stop the data acquisition and to see plots of the received data.</summary>
/// <param name="communicationModel">[in,out] The communication model.</param>
/// <param name="daqModel">[in,out] The data acquisition model.</param>
/// <param name="parent">[in,out] The parent widget.</param>
DataAcquisitionView::DataAcquisitionView(CommunicationModel& communicationModel,
	DataAcquisitionModel& daqModel, QWidget* parent)
	: QWidget(parent)
	, m_communicationModel(communicationModel)
	, m_daqModel(daqModel)
	, m_layout(new QVBoxLayout(this))
	, m_plots(new QWidget(this))
{
	setLayout(m_layout);
	m_layout->setAlignment(Qt::AlignTop);

	AddStartStopButton();
	AddTimeIntervalComboBox();
	UpdatePlots();
	SetButtonsState(m_daqModel.DataAcquisitionStarted());

	startTimer(100);
}

void DataAcquisitionView::AddStartStopButton()
{
	auto buttonsWidget = new QWidget;
	auto buttonsLayout = new QHBoxLayout(buttonsWidget);
	m_layout->addWidget(buttonsWidget);

	m_startButton = new QPushButton(tr("Start"));
	m_stopButton = new QPushButton(tr("Stop"));
	buttonsLayout->addWidget(m_startButton);
	buttonsLayout->addWidget(m_stopButton);

	ConnectHandled(m_startButton, &QPushButton::clicked, [this](bool)
	{
		m_daqModel.StartDataAcquisition();
		UpdatePlots();
		UpdateTimeInterval();
		SetButtonsState(true);
	});
	ConnectHandled(m_stopButton, &QPushButton::clicked, [this](bool)
	{
		m_daqModel.StopDataAcquisition();
		SetButtonsState(false);
	});
}

void DataAcquisitionView::AddTimeIntervalComboBox()
{
	m_timeIntervalControl = new QComboBox;
	m_layout->addWidget(m_timeIntervalControl);
	for (const auto& interval : c_timeIntervals)
	{
		const auto intervalString = interval < std::chrono::milliseconds(1)
			? QString::number(interval / std::chrono::microseconds(1)) + QString::fromUtf8(u8" �s")
			: QString::number(interval / std::chrono::milliseconds(1)) + " ms";
		m_timeIntervalControl->addItem(intervalString);
	}
	m_timeIntervalControl->setCurrentText("2 ms");

	connect(m_timeIntervalControl, QOverload<int>::of(&QComboBox::currentIndexChanged), [this](int index)
	{
		UpdateTimeInterval();
	});
}

void DataAcquisitionView::UpdateTimeInterval()
{
	const auto interval = c_timeIntervals[m_timeIntervalControl->currentIndex()];
	const int baseSamples = static_cast<int>(m_daqModel.SampleRate() * interval / std::chrono::duration<double>(1));
	m_daqModel.Reset(baseSamples);
	for (int idx = 0; idx < m_plots->layout()->count(); idx++)
	{
		if (auto plot = dynamic_cast<DataPlot*>(m_plots->layout()->itemAt(idx)->widget());
			plot != nullptr)
		{
			plot->SetXSize(baseSamples * m_daqModel.FrequencyFactor(plot->Channel()));
		}
	}
}

void DataAcquisitionView::SetButtonsState(bool operationMode)
{
	m_startButton->setEnabled(!operationMode);
	m_stopButton->setEnabled(operationMode);
	m_timeIntervalControl->setEnabled(!operationMode);
}

void DataAcquisitionView::UpdatePlots()
{
	m_layout->removeWidget(m_plots);
	delete m_plots;

	m_layout->addWidget(m_plots = new QWidget(this));
	m_plots->setLayout(new QVBoxLayout(this));
	for (const auto& channel : m_daqModel.Channels())
	{
		if (channel.Type() != PTCChannelType_DataValidity)
		{
			AddTitle(channel);
			AddPlot(channel);
		}
	}
	UpdateTimeInterval();
}

void DataAcquisitionView::AddTitle(const Polytec::IO::Channel& channel)
{
	m_plots->layout()->addWidget(new QLabel(GetTitle(channel.Type())));
}

void DataAcquisitionView::AddPlot(const Polytec::IO::Channel& channel)
{
	auto plot = new DataPlot(m_daqModel, channel);
	m_plots->layout()->addWidget(plot);
	plot->SetYRange(m_daqModel.ChannelMin(channel), m_daqModel.ChannelMax(channel));
}

void DataAcquisitionView::timerEvent(QTimerEvent* /*event*/)
{
	try
	{
		m_daqModel.Update();
	}
	catch (const std::exception& e)
	{
		OnExceptionThrown(e);
	}
	update();
}

template<typename Sender, typename Signal, typename Slot, typename... Args>
QMetaObject::Connection DataAcquisitionView::ConnectHandled(const Sender* sender,
	void(Signal::* signal)(Args...), Slot slot)
{
	return connect(sender, signal, [this, slot](Args... args)
	{
		try
		{
			slot(args...);
		}
		catch (const std::exception& e)
		{
			OnExceptionThrown(e);
		}
	});
}
