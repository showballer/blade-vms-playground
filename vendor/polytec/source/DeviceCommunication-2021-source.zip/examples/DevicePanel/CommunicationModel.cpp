// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#include "CommunicationModel.h"

#include <IO/DeviceCommunication/AllCommunication.h>
#include <IO/DeviceCommunication/Utils/CommandList.h>

#include <gsl/gsl>
#include <sstream>
#include <vector>

using namespace Polytec::DevicePanel;
using namespace std::literals;

/// <summary>Constructs a communication model.</summary>
/// <param name="communication">The device communication instance.</param>
CommunicationModel::CommunicationModel(Polytec::IO::DeviceCommunication communication)
	: m_communication(std::move(communication))
	, m_temperatureDeviceAndCommand(GetTemperatureDeviceAndCommand())
	, m_isIVS500(IsIVS500())
{
	InitializeAutofocusLimits();
	EnableWriteLock();
}

/// <summary>Destructor.</summary>
CommunicationModel::~CommunicationModel()
{
	DisableWriteLock();
}

std::pair<Polytec::IO::Device, PTCDeviceCommand> CommunicationModel::GetTemperatureDeviceAndCommand() const
{
	std::vector<std::pair<IO::Device, PTCDeviceCommand>> possibleResults =
	{
		{PTCDeviceType_SensorHead, PTCDeviceCommand_BraggCellTemperature},
		{PTCDeviceType_Controller, PTCDeviceCommand_FPGATemperature},
		{PTCDeviceType_Controller, PTCDeviceCommand_Temperature}
	};
	for (const auto& result : possibleResults)
	{
		if (HasCommand(result.first, result.second))
			return result;
	}
	return {IO::Device(), PTCDeviceCommand_Unknown};
}

bool CommunicationModel::IsIVS500() const
{
	return m_communication.SendGet<std::wstring>(PTCDeviceType_Controller, PTCDeviceCommand_Name)
		== L"IVS-500 Vibrometer Controller";
}

void CommunicationModel::EnableWriteLock()
{
	if (!HasCommand(PTCDeviceType_Controller, PTCDeviceCommand_WriteLock))
		return;
	const auto exclusiveIndex = GetIndex(PTCDeviceType_Controller, PTCDeviceCommand_WriteLock, "Exclusive");
	m_communication.SendSet<std::int16_t>(PTCDeviceType_Controller, PTCDeviceCommand_WriteLock, exclusiveIndex);
	const auto actualIndex = m_communication.SendGet<std::int16_t>(PTCDeviceType_Controller, PTCDeviceCommand_WriteLock);
	if (exclusiveIndex != actualIndex)
		throw IO::CommunicationException(PTCCommunicationStatusCode_WriteLockFailed);
}

void CommunicationModel::DisableWriteLock()
{
	try
	{
		if (!HasCommand(PTCDeviceType_Controller, PTCDeviceCommand_WriteLock))
			return;
		const auto readOnlyIndex = GetIndex(PTCDeviceType_Controller, PTCDeviceCommand_WriteLock, "ReadOnly");
		m_communication.SendSet<std::int16_t>(PTCDeviceType_Controller, PTCDeviceCommand_WriteLock, readOnlyIndex);
	}
	catch (const std::exception&)
	{
		// If a runtime error occurs like a lost connection, the write lock will timeout on the device
	}

}

void CommunicationModel::InitializeAutofocusLimits()
{
	if (!HasAutofocusRange())
		return;
	auto area = m_communication.SendGet<std::vector<int16_t>>(m_sensorHead, PTCDeviceCommand_AutofocusArea);
	if (area.size() == 2)
		m_autofocusLimits = {area[0], area[1]};
	else
		throw Polytec::IO::CommunicationException(PTCCommunicationStatusCode_InvalidResponseFormat, "Invalid autofocus limits while initialization.");
}

/// <summary>Gets the device communication instance.</summary>
/// <returns>The device communication instance.</returns>
Polytec::IO::DeviceCommunication& CommunicationModel::GetCommunication()
{
	return m_communication;
}

/// <summary>Sends a set-index command.</summary>
/// <param name="device">The device.</param>
/// <param name="deviceCommand">The device command.</param>
/// <param name="index">The index.</param>
void CommunicationModel::SendSetIndex(const Polytec::IO::Device& device, PTCDeviceCommand deviceCommand, int index)
{
	m_communication.SendSet<int16_t>(device, deviceCommand, index);
}

/// <summary>Evaluates if the device communication has an Ethernet communication.</summary>
bool CommunicationModel::HasEthernetCommunication() const
{
	return !m_communication.DeviceIPAddress().empty();
}

/// <summary>Gets the name of the controller, e.g. IVS-500.</summary>
std::string CommunicationModel::GetName() const
{
	return m_communication.SendGet<std::string>(m_controller, PTCDeviceCommand_Name);
}

/// <summary>Gets the current focus position.</summary>
/// <returns>The focus position. The range of this value can be queried by GetFocusRange.</returns>
int CommunicationModel::GetFocusPosition() const
{
	return m_communication.SendGet<int16_t>(m_sensorHead, PTCDeviceCommand_FocusPosition);
}

/// <summary>
/// Evaluates if the focus is currently running, due to an autofocus command or a focus position
/// command.
/// </summary>
bool CommunicationModel::IsFocusRunning() const
{
	return m_communication.SendGet<int16_t>(m_sensorHead, PTCDeviceCommand_Autofocus) ||
		m_communication.SendGet<int16_t>(m_sensorHead, PTCDeviceCommand_FocusProgress);
}

/// <summary>
/// Checks if the focus position changed and if the focus has started or stopped running. A
/// change is signaled by emitting a corresponding signal.
/// </summary>
void CommunicationModel::CheckFocusChanged()
{
	if (!HasAutofocus())
		return;

	const int currentPosition = m_communication.SendGet<int16_t>(m_sensorHead, PTCDeviceCommand_FocusPosition);
	if (m_focusPosition != currentPosition)
	{
		m_focusPosition = currentPosition;
		emit FocusChanged(currentPosition);
	}

	const bool currentlyRunning = m_communication.SendGet<int16_t>(m_sensorHead, PTCDeviceCommand_FocusProgress)
		|| m_communication.SendGet<int16_t>(m_sensorHead, PTCDeviceCommand_Autofocus);
	if (m_focusRunning != currentlyRunning)
	{
		m_focusRunning = currentlyRunning;
		emit FocusRunning(currentlyRunning);
	}
}

/// <summary>Starts the autofocus if it is not running. Stops the autofocus if it is running.</summary>
void CommunicationModel::SwitchAutofocusState()
{
	if (!m_communication.SendGet<int16_t>(m_sensorHead, PTCDeviceCommand_FocusProgress))
	{
		int status = m_communication.SendGet<int16_t>(m_sensorHead, PTCDeviceCommand_Autofocus);
		m_communication.SendSet<int16_t>(m_sensorHead, PTCDeviceCommand_Autofocus, !status);
		CheckFocusChanged();
	}
}

/// <summary>Move focus the focus to the given position.</summary>
/// <param name="position">The position. The possible range for the position can be queried by
/// GetFocusRange.</param>
void CommunicationModel::MoveFocus(int position)
{
	if (!m_communication.SendGet<int16_t>(m_sensorHead, PTCDeviceCommand_FocusProgress) &&
		!m_communication.SendGet<int16_t>(m_sensorHead, PTCDeviceCommand_Autofocus))
	{
		position = ValidateFocusPosition(position);
		m_communication.SendSet<int16_t>(m_sensorHead, PTCDeviceCommand_FocusPosition, position);
		CheckFocusChanged();
	}
}

/// <summary>Starts moving the focus to near.</summary>
void CommunicationModel::MoveFocusNear()
{
	MoveFocus(m_isIVS500
		? GetFocusRange().second // Workaround for inverted IVS-500 focus position
		: GetFocusRange().first);
}

/// <summary>Starts moving the focus to far.</summary>
void CommunicationModel::MoveFocusFar()
{
	MoveFocus(m_isIVS500
		? GetFocusRange().first // Workaround for inverted IVS-500 focus position
		: GetFocusRange().second);
}

/// <summary>Stops moving the focus.</summary>
void CommunicationModel::StopMoveFocus()
{
	m_communication.SendSet<int16_t>(m_sensorHead, PTCDeviceCommand_FocusProgress, 0);
	CheckFocusChanged();
}

/// <summary>Gets the possible focus position range.</summary>
/// <returns>The focus position range [min, max].</returns>
std::pair<int, int> CommunicationModel::GetFocusRange() const
{
	return GetRange(PTCDeviceType_SensorHead, PTCDeviceCommand_FocusPosition);
}

/// <summary>Gets the autofocus limits. This is a range limiting the autofocus.</summary>
/// <exception cref="Polytec::IO::CommunicationException">Throws a communication exception when the
/// response format from the device is invalid.</exception>
/// <returns>The autofocus limits [min, max].</returns>
std::pair<int, int> CommunicationModel::GetAutofocusLimits() const
{
	auto area = m_communication.SendGet<std::vector<int16_t>>(m_sensorHead, PTCDeviceCommand_AutofocusArea);
	if (area.size() == 2)
		return{area[0], area[1]};
	else
		throw Polytec::IO::CommunicationException(PTCCommunicationStatusCode_InvalidResponseFormat, "Invalid autofocus limits.");
}

/// <summary>Sets the autofocus limit minimum. The autofocus will be limited by this minimum.</summary>
/// <param name="min">The autofocus limiter minimum.</param>
void CommunicationModel::SetAutofocusLimitMinimum(int min)
{
	if (min >= m_autofocusLimits.second)
	{
		m_autofocusLimits.first = m_autofocusLimits.second - 1;
		emit AutofocusLimitsModified(m_autofocusLimits);
	}
	else if (min < GetFocusRange().first)
	{
		m_autofocusLimits.first = GetFocusRange().first;
		emit AutofocusLimitsModified(m_autofocusLimits);
	}
	else
	{
		m_autofocusLimits.first = min;
	}

	SendSetAutofocusLimits(m_autofocusLimits.first, m_autofocusLimits.second);
}

/// <summary>Sets the autofocus limit maximum. The autofocus will be limited by this maximum.</summary>
/// <param name="min">The autofocus limiter maximum.</param>
void CommunicationModel::SetAutofocusLimitMaximum(int max)
{
	if (max <= m_autofocusLimits.first)
	{
		m_autofocusLimits.second = m_autofocusLimits.first + 1;
		emit AutofocusLimitsModified(m_autofocusLimits);
	}
	else if (max > GetFocusRange().second)
	{
		m_autofocusLimits.second = GetFocusRange().second;
		emit AutofocusLimitsModified(m_autofocusLimits);
	}
	else
	{
		m_autofocusLimits.second = max;
	}

	SendSetAutofocusLimits(m_autofocusLimits.first, m_autofocusLimits.second);
}

/// <summary>Enables or disables the autofocus limits.</summary>
/// <param name="on">True for enable and false for disable.</param>
void CommunicationModel::SetAutofocusLimitsEnabled(bool on)
{
	if (on)
		SendSetAutofocusLimits(m_autofocusLimits.first, m_autofocusLimits.second);
	else
		SendSetAutofocusLimits(GetFocusRange().first, GetFocusRange().second);
}

/// <summary>Query if this device is currently in IQ mode.</summary>
/// <returns>True if in IQ mode, false if not.</returns>
bool CommunicationModel::IsIqModeActive() const
{
	return HasCommand(PTCDeviceType_Controller, PTCDeviceCommand_IQMode) &&
		m_communication.SendGet<int16_t>(PTCDeviceType_Controller, PTCDeviceCommand_IQMode, PTCMiscellaneousTag_StartUpValue) == 1;
}

int CommunicationModel::ValidateFocusPosition(int position) const
{
	const auto focusRange = GetFocusRange();
	if (position < focusRange.first)
		position = focusRange.first;
	else if (position > focusRange.second)
		position = focusRange.second;
	return position;
}

void CommunicationModel::SendSetAutofocusLimits(int16_t min, int16_t max)
{
	m_communication.SendSet<std::vector<int16_t>>(m_sensorHead, PTCDeviceCommand_AutofocusArea, {min, max});
}

/// <summary>Evaluates if the ASE-filter is enabled.</summary>
bool CommunicationModel::IsAseFilterOn() const
{
	return m_communication.SendGet<int16_t>(m_velocityDecoder, PTCDeviceCommand_AseFilterOn);
}

/// <summary>Enables or disables the ASE-filter.</summary>
/// <param name="on">True for enable and false for disable.</param>
void CommunicationModel::SetAseFilterOn(bool on)
{
	m_communication.SendSet<int16_t>(m_velocityDecoder, PTCDeviceCommand_AseFilterOn, on);
}

/// <summary>Gets baud rate, e.g. 9600 or 115200.</summary>
int CommunicationModel::GetBaudRate() const
{
	return m_communication.SendGet<int16_t>(m_controller, PTCDeviceCommand_BaudRate);
}

/// <summary>Sets baud rate, e.g. 9600 or 115200.</summary>
void CommunicationModel::SetBaudRate(int value)
{
	m_communication.SendSet<int16_t>(m_controller, PTCDeviceCommand_BaudRate, value);
}

/// <summary>Evaluates if the laser is on.</summary>
bool CommunicationModel::IsLaserOn() const
{
	return m_communication.SendGet<int16_t>(m_sensorHead, PTCDeviceCommand_LaserOn);
}

/// <summary>Sets a laser.</summary>
/// <param name="on">True for on, false for off.</param>
void CommunicationModel::SetLaser(bool on)
{
	m_communication.SendSet<int16_t>(m_sensorHead, PTCDeviceCommand_LaserOn, on);
}

/// <summary>Gets the signal level range.</summary>
/// <exception cref="Polytec::IO::CommunicationException">Throws a communication exception when the
/// response has an invalid format.</exception>
/// <returns>The signal level range [min, max].</returns>
std::pair<int, int> CommunicationModel::GetSignalLevelRange() const
{
	auto range = m_communication.SendGetDevInfo<std::vector<int16_t>>(m_sensorHead, PTCDeviceCommand_SignalLevel);
	if (range.size() == 2)
		return{range[0], range[1]};
	else
		throw Polytec::IO::CommunicationException(PTCCommunicationStatusCode_InvalidResponseFormat, "Invalid signal level range. Received " + std::to_string(range.size()) + " values.");
}

/// <summary>Gets the current signal level.</summary>
int CommunicationModel::GetSignalLevel() const
{
	return m_communication.SendGet<int16_t>(m_sensorHead, PTCDeviceCommand_SignalLevel);
}

/// <summary>Evaluates if the current velocity signal value is overrange.</summary>
bool CommunicationModel::GetOverrange() const
{
	return m_communication.SendGet<int16_t>(m_velocityDecoder, PTCDeviceCommand_Overrange);
}

/// <summary>Gets the controller temperature.</summary>
float CommunicationModel::GetTemperature() const
{
	return m_communication.SendGet<float>(m_temperatureDeviceAndCommand.first, m_temperatureDeviceAndCommand.second);
}

/// <summary>
/// Saves the user settings to User1. Settings like velocity range, high pass are saved and can
/// later be loaded, for example at start-up.
/// </summary>
void CommunicationModel::SaveUserSettings()
{
	const int16_t index = GetIndex(PTCDeviceType_Controller, PTCDeviceCommand_SaveUserSettings, "User1");
	m_communication.SendSet<int16_t>(m_controller, PTCDeviceCommand_SaveUserSettings, index);
}

/// <summary>Gets the power-up focus position.</summary>
int CommunicationModel::GetPowerUpFocusPosition() const
{
	return m_communication.SendGet<int16_t>(m_sensorHead, PTCDeviceCommand_PowerUpFocusPosition);
}

/// <summary>Sets the power-up focus position.</summary>
void CommunicationModel::SetPowerUpFocusPosition(int position)
{
	constexpr int autofocusPosition = -1;

	const int validPosition
		= (position != autofocusPosition ? ValidateFocusPosition(position) : autofocusPosition);

	if (validPosition != position)
		emit PowerUpFocusPositionModified(validPosition);
	m_communication.SendSet<int16_t>(m_sensorHead, PTCDeviceCommand_PowerUpFocusPosition, validPosition);
}

/// <summary>Gets the measurement base sample rate.</summary>
/// <returns>The measurement base sample rate.</returns>
int CommunicationModel::GetDaqBaseSampleRate() const
{
	return gsl::narrow<int>(m_communication.SendGet<int32_t>(m_signalProcessing, PTCDeviceCommand_DaqBaseSampleRate));
}

/// <summary>Gets the headroom for the velocity data channel.</summary>
float CommunicationModel::GetHeadroomVelocity() const
{
	return GetFloatFromCache(PTCDeviceType_VelocityDecoderDigital, PTCDeviceCommand_HeadroomDigitalOut);
}

Polytec::IO::ProtocolType CommunicationModel::GetProtocolType() const
{
	return static_cast<IO::ProtocolType>(
		m_communication.SendGet<int16_t>(m_signalProcessing, PTCDeviceCommand_DAQProtocolType));
}

int CommunicationModel::GetIndex(PTCDeviceType deviceType,
	PTCDeviceCommand deviceCommand, const std::string& label) const
{
	if (m_indexCache.count({deviceType, deviceCommand, label}) == 0)
	{
		const auto valueList = m_communication.SendGetValueList<std::string>(deviceType, deviceCommand);
		std::stringstream stream(valueList);
		std::string item;
		for (int n = 0; std::getline(stream, item, ','); n++)
			m_indexCache[{deviceType, deviceCommand, item}] = n;
	}
	if (m_indexCache.count({deviceType, deviceCommand, label}))
	{
		return m_indexCache[{ deviceType, deviceCommand, label }];
	}
	else
	{
		throw Polytec::IO::CommunicationException(PTCCommunicationStatusCode_InvalidArgument);
	}
}

std::pair<int, int> CommunicationModel::GetRange(PTCDeviceType deviceType, PTCDeviceCommand deviceCommand) const
{
	if (m_rangeCache.count({deviceType, deviceCommand}) == 0)
	{
		const auto range = m_communication.SendGetValueList<std::vector<int16_t>>(deviceType, deviceCommand);
		if (range.size() == 2)
			m_rangeCache[{ deviceType, deviceCommand }] = {range[0], range[1]};
		else
			throw Polytec::IO::CommunicationException(PTCCommunicationStatusCode_InvalidResponseFormat, "Invalid range.");
	}
	return m_rangeCache[{ deviceType, deviceCommand }];
}

float CommunicationModel::GetFloatFromCache(PTCDeviceType deviceType, PTCDeviceCommand deviceCommand) const
{
	if (m_floatValueCache.count({deviceType, deviceCommand}) == 0)
	{
		const float value = m_communication.SendGet<float>(deviceType, deviceCommand);
		m_floatValueCache[{ deviceType, deviceCommand }] = value;
	}
	return m_floatValueCache[{ deviceType, deviceCommand }];
}

bool CommunicationModel::HasCommand(IO::Device device, PTCDeviceCommand command) const
{
	if (m_commandLists.find(device) == std::cend(m_commandLists))
	{
		if (!m_deviceList.HasDevice(device))
			return false;
		else
			m_commandLists.try_emplace(device, m_communication, device);
	}
	return m_commandLists.at(device).HasCommand(command);
}
