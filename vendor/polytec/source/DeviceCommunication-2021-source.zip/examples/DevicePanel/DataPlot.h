// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#pragma once

#include "CommunicationModel.h"

#include <IO/DataAcquisition/Channel.h>

#include <QBrush>
#include <QWidget>

namespace Polytec
{
	namespace DevicePanel
	{
		class DataAcquisitionModel;

		class DataPlot : public QWidget
		{
			Q_OBJECT

		public:
			DataPlot(const DataAcquisitionModel &daqModel,
				const Polytec::IO::Channel& channel, QWidget* parent = nullptr);

			void SetXSize(int xMax);
			void SetYRange(double yMin, double yMax);
			IO::Channel Channel() { return m_channel; }

		private:
			using DataIterator = std::vector<int>::const_iterator;
			using DataRange = std::pair<DataIterator, DataIterator>;

			QSize sizeHint() const override;
			void paintEvent(QPaintEvent* event) override;
			void PaintSeries(QPainter& painter);
			DataIterator DataIteratorForXCoordinate(const std::vector<int>& acquiredData, int xCoordinate) const;
			const std::vector<int>& AcquiredData() const;
			std::pair<int, int> MinMax(const DataRange& dataRange) const;
			int YCoordinate(int dataValue) const;
			bool DataOutOfRange(int xCoordinate) const;


			const DataAcquisitionModel& m_daqModel;
			IO::Channel m_channel;
			const QBrush m_backgroundBrush;
			const QColor m_seriesColor;
			const QColor m_overrangeColor;
			std::size_t m_xSize = 500;
			double m_yMin = 0;
			double m_yMax = 1;
		};
	}
}
