// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#include "Utils.h"

#include <IO/DeviceCommunication/AllCommunication.h>

#include <QDir>

#include <array>
#include <chrono>
#include <fstream>
#include <future>
#include <sstream>

using namespace std::chrono_literals;

namespace
{
	const std::string c_cachePath = QDir::homePath().toStdString() + "/.device_panel.cache";

	bool ComPortAvailable(const std::wstring& comPort)
	{
		try
		{
			Polytec::IO::CreateSerialCommunication(comPort, 115'200, std::chrono::seconds(0));
		}
		catch (const Polytec::IO::CommunicationException& e)
		{
			return e.GetStatusCode() != PTCCommunicationStatusCode_SystemError;
		}
		return true;
	}
}

/// <summary>Reads settings from the cache file.</summary>
/// <returns>The cache settings.</returns>
std::map<std::wstring, std::wstring> Polytec::DevicePanel::Utils::ReadCache()
{
	std::wifstream in(c_cachePath);
	std::map<std::wstring, std::wstring> data;
	std::wstring line;
	while (std::getline(in, line))
	{
		std::wstringstream stream(line);
		std::wstring cmd, value;
		stream >> cmd >> value;
		data[cmd] = value;
	}
	return data;
}

/// <summary>Writes settings to the cache file.</summary>
/// <param name="data">The cache settings.</param>
void Polytec::DevicePanel::Utils::WriteCache(std::map<std::wstring, std::wstring> data)
{
	std::wofstream out(c_cachePath);
	for (const auto& entry : data)
		out << entry.first << " " << entry.second << "\n";
	out.flush();
}

/// <summary>Find all available serial ports.</summary>
/// <returns>The found serial ports.</returns>
std::vector<std::wstring> Polytec::DevicePanel::Utils::FindComPorts()
{
	#ifndef _WIN32
	#pragma message "warning: not implemented"
	return {};
	#endif
	constexpr int minPort = 1;
	constexpr int maxPort = 256;
	std::array<std::future<bool>, maxPort + 1> portAvailable;
	auto portName = [](int port) { return L"COM" + std::to_wstring(port); };
	for (int port = minPort; port <= maxPort; port++)
		portAvailable[port] = std::async(ComPortAvailable, portName(port));
	std::vector<std::wstring> portList;
	for (int port = minPort; port <= maxPort; port++)
	{
		if (portAvailable[port].get())
			portList.push_back(portName(port));
	}
	return portList;
}
