// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#pragma once

#include <IO/DataAcquisition/Detail/ProtocolType.h>
#include <IO/DeviceCommunication/DeviceCommunication.h>
#include <IO/DeviceCommunication/Device.h>
#include <IO/DeviceCommunication/Utils/DeviceList.h>

#include <QObject>

#include <map>
#include <memory>
#include <set>
#include <string>
#include <vector>

namespace Polytec
{
	namespace IO
	{
		class CommandList;
	}

	namespace DevicePanel
	{
		class CommunicationModel : public QObject
		{
			Q_OBJECT

		public:
			explicit CommunicationModel(Polytec::IO::DeviceCommunication communication);
			CommunicationModel(const CommunicationModel&) = delete;
			CommunicationModel& operator=(const CommunicationModel&) = delete;
			CommunicationModel(CommunicationModel&&) = delete; // Could be implemented if needed
			CommunicationModel& operator=(CommunicationModel&&) = delete; // Could be implemented if needed
			~CommunicationModel();

		private:
			std::pair<IO::Device, PTCDeviceCommand> GetTemperatureDeviceAndCommand() const;
			bool IsIVS500() const;
			void InitializeAutofocusLimits();
			void EnableWriteLock();
			void DisableWriteLock();

		public:
			Polytec::IO::DeviceCommunication& GetCommunication();
			void SendSetIndex(const Polytec::IO::Device& device, PTCDeviceCommand deviceCommand, int index);
			bool HasEthernetCommunication() const;
			bool HasBaudrate() const { return HasCommand(PTCDeviceType_Controller, PTCDeviceCommand_BaudRate); }
			bool HasUserSettings() const { return HasCommand(PTCDeviceType_Controller, PTCDeviceCommand_SaveUserSettings); }
			bool HasAutofocus() const { return HasCommand(PTCDeviceType_SensorHead, PTCDeviceCommand_Autofocus); }
			bool HasPowerUpFocusPosition() const { return HasCommand(PTCDeviceType_SensorHead, PTCDeviceCommand_PowerUpFocusPosition); }
			bool HasAutofocusRange() const { return HasCommand(PTCDeviceType_SensorHead, PTCDeviceCommand_AutofocusArea); }
			bool HasLaser() const { return HasCommand(PTCDeviceType_SensorHead, PTCDeviceCommand_LaserOn); }
			bool HasSignalLevel() const { return HasCommand(PTCDeviceType_SensorHead, PTCDeviceCommand_SignalLevel); }
			bool HasTemperature() const { return m_temperatureDeviceAndCommand.second != PTCDeviceCommand_Unknown; }
			bool HasVelocityRange() const { return HasCommand(PTCDeviceType_VelocityDecoderDigital, PTCDeviceCommand_Range); }
			bool HasVelocityMaximumRange() const { return HasCommand(PTCDeviceType_VelocityDecoderDigital, PTCDeviceCommand_MaximumVelocityRange); }
			bool HasBandwith() const { return HasCommand(PTCDeviceType_VelocityDecoderDigital, PTCDeviceCommand_Bandwidth); }
			bool HasTrackingFilter() const { return HasCommand(PTCDeviceType_VelocityDecoderDigital, PTCDeviceCommand_TrackingFilterRange); }
			bool HasHighPass() const { return HasCommand(PTCDeviceType_VelocityDecoderDigital, PTCDeviceCommand_HighPass); }
			bool HasAseFilter() const { return HasCommand(PTCDeviceType_VelocityDecoderDigital, PTCDeviceCommand_AseFilterOn); }
			bool HasOverrange() const { return HasCommand(PTCDeviceType_VelocityDecoderDigital, PTCDeviceCommand_Overrange); }
			bool HasDataAcquisition() const { return HasCommand(PTCDeviceType_SignalProcessing, PTCDeviceCommand_DAQProtocolType); }

			std::string GetName() const;
			int GetFocusPosition() const;
			bool IsFocusRunning() const;
			void CheckFocusChanged();
			void SwitchAutofocusState();
			void MoveFocus(int position);
			void MoveFocusNear();
			void MoveFocusFar();
			void StopMoveFocus();
			std::pair<int, int> GetFocusRange() const;
			std::pair<int, int> GetAutofocusLimits() const;
			void SetAutofocusLimitMinimum(int min);
			void SetAutofocusLimitMaximum(int max);
			void SetAutofocusLimitsEnabled(bool on);
			bool IsIqModeActive() const;

		signals:
			void FocusRunning(bool running) const;
			void FocusChanged(int position) const;
			void AutofocusLimitsModified(std::pair<int, int> range) const;
			void DecoderLocked(bool locked) const;

		private:
			int ValidateFocusPosition(int position) const;
			void SendSetAutofocusLimits(int16_t min, int16_t max);

		public:
			bool IsAseFilterOn() const;
			void SetAseFilterOn(bool on);
			int GetBaudRate() const;
			void SetBaudRate(int value);
			bool IsLaserOn() const;
			void SetLaser(bool on);
			std::pair<int, int> GetSignalLevelRange() const;
			int GetSignalLevel() const;
			bool GetOverrange() const;
			float GetTemperature() const;
			void SaveUserSettings();
			int GetPowerUpFocusPosition() const;
			void SetPowerUpFocusPosition(int position);

		signals:
			void PowerUpFocusPositionModified(int position) const;

		public:
			int GetDaqBaseSampleRate() const;
			float GetHeadroomVelocity() const;
			IO::ProtocolType GetProtocolType() const;

		private:
			int GetIndex(PTCDeviceType deviceType, PTCDeviceCommand deviceCommand, const std::string& label) const;
			std::pair<int, int> GetRange(PTCDeviceType deviceType, PTCDeviceCommand deviceCommand) const;
			float GetFloatFromCache(PTCDeviceType deviceType, PTCDeviceCommand deviceCommand) const;
			bool HasCommand(IO::Device device, PTCDeviceCommand command) const;

			using IndexKey = std::tuple<PTCDeviceType, PTCDeviceCommand, std::string>;
			mutable std::map<IndexKey, int> m_indexCache;

			using RangeKey = std::pair<PTCDeviceType, PTCDeviceCommand>;
			mutable std::map<RangeKey, std::pair<int, int>> m_rangeCache;

			using FloatValueKey = std::pair<PTCDeviceType, PTCDeviceCommand>;
			mutable std::map<FloatValueKey, float> m_floatValueCache;

			Polytec::IO::DeviceCommunication m_communication;
			const Polytec::IO::Device m_controller{PTCDeviceType_Controller};
			const Polytec::IO::Device m_sensorHead{PTCDeviceType_SensorHead};
			const Polytec::IO::Device m_velocityDecoder{PTCDeviceType_VelocityDecoderDigital};
			const Polytec::IO::Device m_signalProcessing{PTCDeviceType_SignalProcessing};

			IO::DeviceList m_deviceList{m_communication};
			mutable std::map<IO::Device, IO::CommandList> m_commandLists;

			const std::pair<IO::Device, PTCDeviceCommand> m_temperatureDeviceAndCommand;
			const bool m_isIVS500{};
			std::pair<int, int> m_autofocusLimits;
			int m_focusPosition{-1};
			bool m_focusRunning{false};
			int m_sampleRate{};
		};
	}
}
