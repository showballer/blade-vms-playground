// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#pragma once

#include <QWidget>

#include <string>

class QBoxLayout;
class QMessageBox;

namespace Polytec
{
	namespace DevicePanel
	{
		class ConnectionForm;
		class DeviceView;
		class SideBar;

		class MainWindow : public QWidget
		{
			Q_OBJECT

		public:
			explicit MainWindow(QWidget* parent = 0);

		private:
			void CreateSideBar();
			void CreateConnectionForm();
			void CreateErrorDialog();
			void CreateDeviceView();

			void OpenConnection();
			void CloseConnection();
			void ShowConnectionForm();
			void ShowError(const std::string& message);

			QBoxLayout* m_layout{};
			ConnectionForm* m_connectionForm{};
			SideBar* m_sideBar{};
			DeviceView* m_deviceView{};
			QMessageBox* m_errorDialog{};
		};
	}
}
