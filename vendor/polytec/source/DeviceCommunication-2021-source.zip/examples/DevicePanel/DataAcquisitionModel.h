// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#pragma once

#include "CommunicationModel.h"

#include <IO/DataAcquisition/AllAcquisition.h>

#include <chrono>
#include <functional>
#include <map>

namespace Polytec
{
	namespace DevicePanel
	{
		class CommunicationModel;

		class DataAcquisitionModel
		{
			using Channel = Polytec::IO::Channel;

		public:
			DataAcquisitionModel(CommunicationModel& communicationModel);
			void Reset(int baseSamplesToAcquire);
			std::vector<Channel> Channels() const;
			int ChannelMin(const Channel& channel) const;
			int ChannelMax(const Channel& channel) const;
			double SampleRate() const;
			int FrequencyFactor(const Channel& channel) const;
			const std::vector<int>& AcquiredData(const Channel& channel) const;
			const std::vector<int>& AcquiredOverrange(const Channel& channel) const;
			void Update();
			void StartDataAcquisition();
			void StopDataAcquisition();
			bool DataAcquisitionStarted() const { return m_acquisition.IsAcquisitionStarted(); }

		private:
			Polytec::IO::DataAcquisition CreateDataAcquisition(std::size_t baseSamples);
			double Headroom(const Channel& channel) const;
			void StopPendingAcquisition();
			void ConfigureBlockAcquisition(int baseSamplesToAcquire);
			void ConfigureChannelActivation();
			void DiscardUnneededSamples();
			void ClearBuffer();

			CommunicationModel& m_communicationModel;
			Polytec::IO::DataAcquisition m_acquisition;
			const bool m_withBlockMode{};
			std::map<Channel, std::vector<int>> m_data;
			std::map<Channel, std::vector<int>> m_overrange;
			int m_baseSamplesToAcquire{};
			int m_acquiredBaseSamples{};
			std::vector<IO::Channel> m_activeChannels;
			std::chrono::steady_clock::time_point m_lastBufferUpdate;
		};
	}
}
