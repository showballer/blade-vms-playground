#include "DataAcquisitionModel.h"

#include <IO/DataAcquisition/Detail/DataFormatIVS500.h>
#include <IO/DeviceCommunication/Utils/ChannelActivation.h>
#include <IO/DeviceCommunication/Utils/CommandList.h>
#include <IO/DeviceCommunication/Utils/ItemList.h>

namespace
{
	constexpr std::chrono::duration<double> c_refreshInterval{std::chrono::milliseconds(500)};
}

namespace Polytec::DevicePanel
{
	/// <summary>Constructs a data acquisition model.</summary>
	/// <param name="communicationModel">[in,out] The communication model.</param>
	DataAcquisitionModel::DataAcquisitionModel(CommunicationModel& communicationModel)
		: m_communicationModel(communicationModel)
		, m_withBlockMode(IO::CommandList(m_communicationModel.GetCommunication(), PTCDeviceType_SignalProcessing)
			.HasCommand(PTCDeviceCommand_DaqMode))
	{
		if (m_communicationModel.IsIqModeActive())
			throw std::runtime_error("The device panel does not support IQ mode. Reboot your device in normal mode.");

		StopPendingAcquisition();
		ClearBuffer();
	}

	/// <summary>Resets the acquired samples buffer to the given size of base samples.</summary>
	void DataAcquisitionModel::Reset(int baseSamplesToAcquire)
	{
		ConfigureBlockAcquisition(baseSamplesToAcquire);
		ConfigureChannelActivation();
		if (std::exchange(m_baseSamplesToAcquire, baseSamplesToAcquire) != baseSamplesToAcquire)
		{
			m_acquisition = {}; // Freeing acquisition ports first.
			// Creating a data acquisition with fitting buffer so that displayed data
			// is not unnecessarily delayed by passing through large buffers.
			m_acquisition = CreateDataAcquisition(m_baseSamplesToAcquire);
		}
		ClearBuffer();
	}

	/// <summary>Gets all the available channels for the data format.</summary>
	std::vector<IO::Channel> DataAcquisitionModel::Channels() const
	{
		return m_activeChannels;
	}

	/// <summary>Returns the channel minimum value for the given channel.</summary>
	int DataAcquisitionModel::ChannelMin(const Channel& channel) const
	{
		return m_acquisition.ChannelMinValue(channel.Type()) / Headroom(channel);
	}

	/// <summary>Returns the channel maximum value for the given channel.</summary>
	int DataAcquisitionModel::ChannelMax(const Channel& channel) const
	{
		return m_acquisition.ChannelMaxValue(channel.Type()) / Headroom(channel);
	}

	/// <summary>Returns the sample rate for the data format.</summary>
	double DataAcquisitionModel::SampleRate() const
	{
		switch (m_communicationModel.GetProtocolType())
		{
			case IO::ProtocolType::IVS500Hotfix:
			case IO::ProtocolType::IVS500:
				return IO::DataFormatIVS500<IO::ProtocolType::IVS500>::SampleRateHertz;
			case IO::ProtocolType::VGO200Pioneer:
				return IO::DataFormatIVS500<IO::ProtocolType::VGO200Pioneer>::SampleRateHertz;
			default:
				return m_communicationModel.GetDaqBaseSampleRate();
		}
	}

	/// <summary>
	/// Frequency factor means samples per base sample for the given channel. E.g. for VFX-F-110 RSSI
	/// samples are acquired at 250 kHz and other channels may be acquired at higher rates.
	/// </summary>
	int DataAcquisitionModel::FrequencyFactor(const Channel& channel) const
	{
		if (IO::CommandList(m_communicationModel.GetCommunication(), PTCDeviceType_SignalProcessing)
			.HasCommand(PTCDeviceCommand_DaqSampleRate))
		{
			return channel == PTCChannelType_RSSI
				? 1
				: (m_communicationModel.GetCommunication().SendGet<int32_t>(PTCDeviceType_SignalProcessing, PTCDeviceCommand_DaqSampleRate)
				/ m_communicationModel.GetCommunication().SendGet<int32_t>(PTCDeviceType_SignalProcessing, PTCDeviceCommand_DaqBaseSampleRate));
		}
		else
		{
			return 1;
		}
	}

	/// <summary>Returns the acquired data for the given channel.</summary>
	/// <param name="channel">The channel.</param>
	/// <returns>Returns the acquired data as vector of int.</returns>
	const std::vector<int>& DataAcquisitionModel::AcquiredData(const Channel& channel) const
	{
		return m_data.at(channel);
	}

	const std::vector<int>& DataAcquisitionModel::AcquiredOverrange(const Channel& channel) const
	{
		return m_overrange.at(channel);
	}

	/// <summary>
	/// Reads available data from the data acquisition ring buffer and copies it to this data buffer.
	/// The data is accumulated until the refresh interval expires. Then all collected data is
	/// cleared and filled again.
	/// </summary>
	void DataAcquisitionModel::Update()
	{
		if (!m_acquisition.IsAcquisitionStarted())
		{
			return;
		}
		else if (m_acquiredBaseSamples == m_baseSamplesToAcquire
			&& std::chrono::steady_clock::now() - m_lastBufferUpdate < c_refreshInterval)
		{
			return;
		}
		else if (m_acquiredBaseSamples == m_baseSamplesToAcquire)
		{
			if (m_withBlockMode)
			{
				m_acquisition.NextDataAcquisitionBlock();
			}
			ClearBuffer();
			DiscardUnneededSamples();
		}
		const auto measurementData = m_acquisition.ReadAvailableData(m_baseSamplesToAcquire - m_acquiredBaseSamples);
		m_acquiredBaseSamples += gsl::narrow_cast<int>(measurementData.BaseSampleCount());
		for (const auto& channel : Channels())
		{
			const auto channelData = measurementData.template Get<int>(channel);
			m_data[channel].insert(m_data[channel].end(), channelData.begin(), channelData.end());
			if (IsSignalChannel(channel))
			{
				const auto channelData = measurementData.template GetOverrange<int>(channel);
				m_overrange[channel].insert(m_overrange[channel].end(), channelData.begin(), channelData.end());
			}
		}
		m_lastBufferUpdate = std::chrono::steady_clock::now();
	}

	/// <summary>Starts data acquisition.</summary>
	void DataAcquisitionModel::StartDataAcquisition()
	{
		m_acquisition.StartAcquisition();
		m_activeChannels = m_acquisition.ActiveChannels();
		m_communicationModel.DecoderLocked(true);
	}

	/// <summary>Stops data acquisition.</summary>
	void DataAcquisitionModel::StopDataAcquisition()
	{
		m_acquisition.StopAcquisition();
		m_communicationModel.DecoderLocked(false);
	}

	Polytec::IO::DataAcquisition DataAcquisitionModel::CreateDataAcquisition(std::size_t baseSamples)
	{
		const auto capacity = m_withBlockMode
			? 2 * baseSamples // small buffer for VFX-F-110, VIO-130 (which have an internal ring buffer in the device)
			: 2'500'000; // approx. 10 s buffer for IVS-500, VGO-200 (which have no internal ring buffer in the device)
		return Polytec::IO::CreateDigitalDataAcquisition(m_communicationModel.GetCommunication(), capacity);
	}

	double DataAcquisitionModel::Headroom(const Channel& channel) const
	{
		switch (channel.Type())
		{
			case PTCChannelType_Velocity:
				return m_communicationModel.GetCommunication().SendGet<float>(PTCDeviceType_VelocityDecoderDigital, PTCDeviceCommand_HeadroomDigitalOut);
			case PTCChannelType_Displacement:
				return m_communicationModel.GetCommunication().SendGet<float>(PTCDeviceType_DisplacementDecoderDigital, PTCDeviceCommand_HeadroomDigitalOut);
			case PTCChannelType_Acceleration:
				return m_communicationModel.GetCommunication().SendGet<float>(PTCDeviceType_AccelerationDecoderDigital, PTCDeviceCommand_HeadroomDigitalOut);
			case PTCChannelType_RSSI:
			case PTCChannelType_Trigger:
				return 1.;
			default:
				throw std::runtime_error("Unkown headroom for channel type: " + std::to_string(static_cast<int>(channel.Type())));
		}
	}

	void DataAcquisitionModel::StopPendingAcquisition()
	{
		IO::ItemList(m_communicationModel.GetCommunication(), PTCDeviceType_SignalProcessing, PTCDeviceCommand_OperationMode)
			.SetCurrentItem(L"Off");
	}

	void DataAcquisitionModel::ConfigureBlockAcquisition(int baseSamplesToAcquire)
	{
		if (!m_withBlockMode)
		{
			return;
		}
		IO::ItemList(m_communicationModel.GetCommunication(), PTCDeviceType_SignalProcessing, PTCDeviceCommand_DaqMode)
			.SetCurrentItem(L"Block");
		IO::ItemList(m_communicationModel.GetCommunication(), PTCDeviceType_SignalProcessing, PTCDeviceCommand_DaqTriggerMode)
			.SetCurrentItem(L"None");
		m_communicationModel.GetCommunication()
			.SendSet<int32_t>(PTCDeviceType_SignalProcessing, PTCDeviceCommand_DaqBlockSize, baseSamplesToAcquire);
		m_communicationModel.GetCommunication()
			.SendSet<int16_t>(PTCDeviceType_SignalProcessing, PTCDeviceCommand_DaqBlockCount, 0);
	}

	void DataAcquisitionModel::ConfigureChannelActivation()
	{
		if (!IO::CommandList(m_communicationModel.GetCommunication(), PTCDeviceType_SignalProcessing)
			.HasCommand(PTCDeviceCommand_DaqActiveChannels))
		{
			return;
		}
		IO::ChannelActivation channelActivation(m_communicationModel.GetCommunication());
		channelActivation.DisableAllChannels();
		for (const auto channelType : channelActivation.GetAllSupportedChannelTypes())
		{
			std::vector<int> activeChannels(channelActivation.GetAvailableChannelCount(channelType));
			std::iota(activeChannels.begin(), activeChannels.end(), 0);
			channelActivation.SetActiveChannels(channelType, activeChannels);
		}
	}

	void DataAcquisitionModel::DiscardUnneededSamples()
	{
		if (m_withBlockMode)
			return;
		m_acquisition.ReadAvailableData(std::max( // discard
			0,
			gsl::narrow_cast<int>(m_acquisition.AvailableSamples() - m_baseSamplesToAcquire)));

	}

	void DataAcquisitionModel::ClearBuffer()
	{
		m_acquiredBaseSamples = 0;
		for (const auto& channel : Channels())
			m_data[channel].clear();
		for (const auto& channel : Channels())
			m_overrange[channel].clear();
	}
}
