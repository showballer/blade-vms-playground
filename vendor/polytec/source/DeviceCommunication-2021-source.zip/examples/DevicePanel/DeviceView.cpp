// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#include "DeviceView.h"

#include "CommunicationView.h"
#include "DataAcquisitionModel.h"
#include "DataAcquisitionView.h"

#include <IO/DeviceCommunication/CommunicationException.h>

using namespace Polytec::DevicePanel;

/// <summary>
/// Creates a device view. The device view contains a tab for the device communication and a tab
/// for the data acquisition.
/// </summary>
/// <param name="communication">The device communication instance.</param>
/// <param name="parent">[in,out] The parent widget.</param>
DeviceView::DeviceView(Polytec::IO::DeviceCommunication communication, QWidget* parent)
	: QTabWidget(parent)
	, m_communicationModel(std::move(communication))
	, m_communicationView(new CommunicationView(m_communicationModel))
{
	addTab(m_communicationView, QString(tr("Configuration")));
	AddAcquisitionTab();

	connect(m_communicationView, &CommunicationView::OnExceptionThrown,
		[this](const Polytec::IO::CommunicationException& e) { ExceptionThrown(e); });
}

/// <summary>Destructor.</summary>
DeviceView::~DeviceView() = default;

void DeviceView::AddAcquisitionTab()
{
	if (m_communicationModel.HasEthernetCommunication() && m_communicationModel.HasDataAcquisition())
	{
		m_daqModel = CreateDaqModel();
		m_daqView = std::make_unique<DataAcquisitionView>(m_communicationModel, *m_daqModel);
		m_daqTabId = addTab(m_daqView.get(), QString(tr("Data Acquisition")));

		connect(m_daqView.get(), &DataAcquisitionView::OnExceptionThrown,
			[this](const std::exception& e) { ExceptionThrown(e); });
	}
}

void DeviceView::RemoveAcquisitionTab()
{
	if (m_daqTabId >= 0)
	{
		removeTab(m_daqTabId);
		m_daqTabId = -1;
	}
}

std::unique_ptr<DataAcquisitionModel> DeviceView::CreateDaqModel()
{
	return std::make_unique<DataAcquisitionModel>(m_communicationModel);
}
