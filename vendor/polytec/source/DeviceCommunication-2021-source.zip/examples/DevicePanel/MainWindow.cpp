// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#include "MainWindow.h"

#include "CommunicationView.h"
#include "ConnectionForm.h"
#include "DataAcquisitionView.h"
#include "DeviceView.h"
#include "SideBar.h"

#include <IO/DeviceCommunication/CommunicationException.h>

#include <QBoxLayout>
#include <QMessageBox>

using namespace Polytec::DevicePanel;

namespace
{
	const auto g_title = QWidget::tr("Polytec Device Panel");
}

/// <summary>
/// Creates the main window. The main window has a connection form. Once a connection is
/// established, the device view will be displayed.
/// </summary>
/// <param name="parent">[in,out] The parent widget.</param>
MainWindow::MainWindow(QWidget *parent)
	: QWidget(parent)
	, m_layout(new QBoxLayout(QBoxLayout::Direction::RightToLeft))
	, m_connectionForm(new ConnectionForm)
	, m_sideBar(new SideBar)
	, m_errorDialog(new QMessageBox(this))
{
	setMinimumSize(500, 600);
	setLayout(m_layout);
	setWindowTitle(g_title);

	CreateSideBar();
	CreateConnectionForm();
	CreateErrorDialog();

	ShowConnectionForm();
}

void MainWindow::CreateSideBar()
{
	connect(m_sideBar, &SideBar::ConnectClicked, [this] { OpenConnection(); });
	connect(m_sideBar, &SideBar::DisconnectClicked, [this] { CloseConnection(); });
	m_layout->addWidget(m_sideBar);
}

void MainWindow::CreateConnectionForm()
{
	connect(m_connectionForm, &ConnectionForm::Connect, [this] { OpenConnection(); });
	m_layout->addWidget(m_connectionForm);
}

void MainWindow::CreateErrorDialog()
{
	m_errorDialog->setIcon(QMessageBox::Icon::Warning);
	m_errorDialog->setWindowTitle(g_title);
}

void MainWindow::CreateDeviceView()
{
	auto communication = m_connectionForm->CreateCommunication();
	m_deviceView = new DeviceView(std::move(communication));
	m_layout->addWidget(m_deviceView);

	connect(m_deviceView, &DeviceView::ExceptionThrown, [this](const std::exception& e)
	{
		CloseConnection();
		ShowError(e.what());
	});
	connect(m_deviceView->GetCommunicationView(), &CommunicationView::OnBaudRateChanged,
		[this](const QString& baudRate)
	{
		m_connectionForm->SetBaudRate(baudRate);
	});
}

void MainWindow::OpenConnection()
{
	if (m_deviceView)
		return;

	try
	{
		m_connectionForm->hide();
		CreateDeviceView();
		m_sideBar->SetConnectionState(true);
	}
	catch (const std::exception& e)
	{
		CloseConnection();
		ShowError(e.what());
	}
}

void MainWindow::CloseConnection()
{
	if (m_deviceView)
	{
		m_deviceView->deleteLater();
		m_deviceView = nullptr;
	}
	ShowConnectionForm();
}

void MainWindow::ShowConnectionForm()
{
	m_connectionForm->show();
	m_sideBar->SetConnectionState(false);
}

void MainWindow::ShowError(const std::string& message)
{
	m_errorDialog->setText(QString::fromStdString(message));
	m_errorDialog->show();
}
