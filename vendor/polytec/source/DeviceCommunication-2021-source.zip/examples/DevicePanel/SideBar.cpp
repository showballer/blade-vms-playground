// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#include "SideBar.h"

#include "AboutDialog.h"

#include <QPushButton>
#include <QVBoxLayout>

using namespace Polytec::DevicePanel;

/// <summary>Constructs the side bar. The side bar has a connect, a disconnect and an about button.</summary>
/// <param name="parent">[in,out] The parent widget.</param>
SideBar::SideBar(QWidget *parent)
	: QWidget(parent)
	, m_layout(new QVBoxLayout)
	, m_connectButton(new QPushButton(tr("Connect")))
	, m_disconnectButton(new QPushButton(tr("Disconnect")))
	, m_aboutDialog(new AboutDialog(this))
{
	m_layout->setAlignment(Qt::AlignTop);
	setLayout(m_layout);
	setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Preferred);

	CreateConnectButton();
	CreateDisconnectButton();
	CreateAboutButton();
}

/// <summary>Sets the connection state, i.e. enables and disables the connection buttons.</summary>
/// <param name="connected">True for connected and false for disconnected.</param>
void SideBar::SetConnectionState(bool connected)
{
	m_connectButton->setEnabled(!connected);
	m_disconnectButton->setEnabled(connected);
}

void SideBar::CreateConnectButton()
{
	connect(m_connectButton, &QPushButton::clicked, [this]() { ConnectClicked(); });
	m_layout->addWidget(m_connectButton);
}

void SideBar::CreateDisconnectButton()
{
	connect(m_disconnectButton, &QPushButton::clicked, [this]() { DisconnectClicked(); });
	m_layout->addWidget(m_disconnectButton);
}

void SideBar::CreateAboutButton()
{
	auto aboutButton = new QPushButton(tr("License"));
	connect(aboutButton, &QPushButton::clicked, [this]() { m_aboutDialog->show(); });
	m_layout->addWidget(aboutButton);
}
