// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#pragma once

#include <QMessageBox>

class QBoxLayout;

namespace Polytec
{
	namespace DevicePanel
	{
		class AboutDialog : public QMessageBox
		{
			Q_OBJECT;

		public:
			AboutDialog(QWidget* parent = nullptr);

		private:
			QBoxLayout* m_layout;
		};
	}
}
