// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#include "MainWindow.h"

#include <QApplication>
#include <QDir>
#include <QTranslator>

#include <iostream>

int main(int argc, char* argv[])
{
	QApplication app(argc, argv);

	QTranslator translator;
	translator.load("DevicePanel_de");
	app.installTranslator(&translator);
	std::cout << QDir::currentPath().toStdString() << std::endl;

	Polytec::DevicePanel::MainWindow w;
	w.show();

	return app.exec();
}
