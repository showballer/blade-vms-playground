\mainpage Overview

[TOC]

\internal

This file is part of the doxygen documentation.
See `./doc/documentation.html` and `./doc/documentation.chm` for the full documentation including a formatted version of this file.

\endinternal


The Device Communication Software is intended to be used to control %Polytec devices such as a VFX-F-110, VIO-130, VGO-200 or IVS-500.
The software provides an application programming interface (API) in C and C++ that can also be used with other languages using the C interface.
The source code is portable C++ code and is free software under the LGPL v.3 (see [LGPL](\ref lgpl) and [GPL](\ref gpl)).

This release provides all sources needed to build the Device Communication Software as well as comprehensive usage examples in C, C++, Python and LabVIEW.
Furthermore prebuilt Windows binaries of all DLLs and examples are included.


# Folder structure

directory	| contents
------------|---------
.			| VC Redistributables, license information, README.md and base CMakeLists.txt
./build32	| 32 bit Windows binaries (DLLs, C and C++ example executables), Python `polytec` package, Python examples and LabVIEW examples
./build64	| 64 bit Windows binaries (DLLs, C and C++ example executables), Python `polytec` package, Python examples and LabVIEW examples
./examples	| C and C++ examples source code
./include	| Device Communication Software headers defining the C and C++ interface (see [File List](files.html) to get an overview over this directory).
./src		| Device Communication Software implementation


# API structure
The Device Communication Software consistes of two main modules: Device Communication and Data Acquisition.

## Device Communication
The Device Communication module can be used to send commands to a device and read values from it via an Ethernet or serial connection.
For example this can be used to switch on the laser, configure a data acquisition or get the current focus position of the sensor head.

## Data Acquisition
The Data Acquisition module facilitates access to the measurement data sent from a device via an Ethernet connection.


# What to read next
 -	\ref gettingStarted
 -	\ref networkInfo
 -	\ref examplesOverview


\copyright (c) 2016-2021 %Polytec GmbH, Waldbronn Released under the terms of the GNU Lesser General Public License version 3.
