// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#include <IO/DataAcquisition/Detail/TcpDataAcquisition.h>

#include <IO/DataAcquisition/Detail/RealTimePriorityGuard.h>
#include <IO/DeviceCommunication/CommunicationException.h>
#include <IO/DeviceCommunication/Detail/DataWriter.h>
#include <IO/DeviceCommunication/Detail/StringConverter.h>

#include <iostream>

using boost::asio::ip::udp;
using namespace Polytec::IO;

namespace
{
	constexpr int c_tcpDaqPort = 60'113;
};

/// <summary>
/// Constructs an TCP data acquisition instance. The instance will listen to incoming data.
/// </summary>
/// <exception cref="std::invalid_argument">Thrown when no network packet format was specified.</exception>
/// <param name="address">The IP address of the data acquisition server.</param>
/// <param name="packetFormat">The packet format, that provides information about the
/// packet length.</param>
TcpDataAcquisition::TcpDataAcquisition(const std::wstring& address, std::unique_ptr<INetworkPacketFormat>&& packetFormat)
try : m_packetFormat(std::move(packetFormat))
, m_address(address)
, m_socket(m_ioService)
{
	if (!m_packetFormat)
		throw std::invalid_argument("Invalid packet format for TCP data acquisition.");
	ResolveHostname(ToString(address));
	ConnectAsync();
}
catch (const boost::system::system_error& e)
{
	throw CommunicationException(PTCCommunicationStatusCode_SystemError, e.what());
}

/// <summary>
/// Runs the ioService. This function call is blocking until Shutdown is called.
/// </summary>
void TcpDataAcquisition::Run()
{
	RealTimePriorityGuard priorityGuard;
	m_ioService.run();
}

/// <summary>Handles an error that occurs while running the acquisition.</summary>
/// <param name="e">The error to handle.</param>
void TcpDataAcquisition::HandleError(const std::exception& e) const
{
	std::wcout << L"TCP data acuqisition failed: " << e.what() << std::endl;
	throw;
}

void TcpDataAcquisition::ResolveHostname(const std::string& hostname)
{
	using boost::asio::ip::tcp;
	try
	{
		tcp::resolver resolver(m_ioService);
		m_deviceEndpoint = *resolver.resolve({tcp::v4(), hostname, std::to_string(c_tcpDaqPort)});
	}
	catch (const boost::system::system_error& e)
	{
		throw CommunicationException(PTCCommunicationStatusCode_SystemError,
			"Failed to resolve hostname: " + std::string(e.what()));
	}
}

void TcpDataAcquisition::ReceiveHeaderAsync()
{
	m_buffer.resize(m_packetFormat->GetBaseHeaderSize());
	async_read(m_socket, boost::asio::buffer(m_buffer),
		[this](boost::system::error_code errorCode, std::size_t bytesReceived)
	{
		HandleReceiveHeader(bytesReceived, errorCode);
	});
}

void TcpDataAcquisition::HandleReceiveHeader(std::size_t bytesReceived, boost::system::error_code errorCode)
{
	if (errorCode || bytesReceived != std::size(m_buffer))
	{
		ConnectAsync();
		return;
	}
	ReceiveBodyAsync();
}

void TcpDataAcquisition::ReceiveBodyAsync()
{
	const auto headerSize = m_packetFormat->GetBaseHeaderSize();
	const auto bodySize = m_packetFormat->GetBodySize(m_buffer);
	m_buffer.resize(headerSize + bodySize);
#pragma warning(suppress: 26481) // Don't use pointer arithmetic. Use span instead (bounds.1).
	async_read(m_socket, boost::asio::buffer(std::data(m_buffer) + headerSize, bodySize),
		[this](boost::system::error_code errorCode, std::size_t bytesReceived)
	{
		HandleReceiveBody(bytesReceived, errorCode);
	});
}

void TcpDataAcquisition::HandleReceiveBody(std::size_t bytesReceived, boost::system::error_code errorCode)
{
	if (errorCode || bytesReceived != std::size(m_buffer) - m_packetFormat->GetBaseHeaderSize())
	{
		ConnectAsync();
		return;
	}

	m_dataAvailableSignal(m_address, m_buffer);
	ReceiveHeaderAsync();
}

void TcpDataAcquisition::ConnectAsync()
{
	m_socket.async_connect(m_deviceEndpoint, [this](boost::system::error_code errorCode) { HandleConnectAsync(errorCode); });
}

void TcpDataAcquisition::HandleConnectAsync(boost::system::error_code errorCode)
{
	if (errorCode)
	{
		ConnectAsync();
		return;
	}
	ReceiveHeaderAsync();
}
