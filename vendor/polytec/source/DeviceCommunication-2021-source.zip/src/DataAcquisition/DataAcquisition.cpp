// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#include <IO/DataAcquisition/DataAcquisition.h>

#include <IO/DataAcquisition/Detail/DataAcquisitionListener.h>
#include <IO/DataAcquisition/Detail/IVS500Deinterlacer.h>
#include <IO/DataAcquisition/Detail/VFXF110Deinterlacer.h>
#include <IO/DataAcquisition/MeasurementData.h>
#include <IO/DeviceCommunication/CommunicationException.h>
#include <IO/DeviceCommunication/Device.h>
#include <IO/DeviceCommunication/DeviceCommunication.h>
#include <IO/DeviceCommunication/Utils/CommandList.h>
#include <IO/DeviceCommunication/Utils/ItemList.h>

#include <chrono>

using namespace Polytec;

namespace
{
	bool HasComputeModule(const IO::DeviceCommunication& communication)
	{
		return IO::CommandList(communication, PTCDeviceType_Controller).HasCommand(PTCDeviceCommand_PackageVersion);
	}

	std::unique_ptr<IO::IDeinterlacer> Deinterlacer(IO::DeviceCommunication& communication)
	{
		const auto protocol = static_cast<IO::ProtocolType>(
			communication.SendGet<int16_t>(PTCDeviceType_SignalProcessing, PTCDeviceCommand_DAQProtocolType));

		switch (protocol)
		{
			case IO::ProtocolType::IVS500Hotfix:
			case IO::ProtocolType::IVS500:
			case IO::ProtocolType::VGO200Pioneer:
				return std::make_unique<IO::IVS500Deinterlacer>(communication);
			case IO::ProtocolType::VFXF110:
				return std::make_unique<IO::VFXF110Deinterlacer>(communication);
			default:
				throw std::runtime_error("No deinterlacer implemented for protocol type: " + std::to_string(gsl::narrow_cast<int>(protocol)));
		}
	}
}

namespace Polytec::IO
{
	DataAcquisition CreateDigitalDataAcquisition(DeviceCommunication& communication, std::size_t capacity)
	{
		if (communication.DeviceIPAddress().empty())
		{
			throw CommunicationException(PTCCommunicationStatusCode_LogicError, "Communication is not a network communication.");
		}
		if (!DeviceList(communication).HasDevice(PTCDeviceType_SignalProcessing))
		{
			throw CommunicationException(PTCCommunicationStatusCode_RuntimeError, "Device has no digital data acquisition interface.");
		}
		// Assuming that devices with compute module provide a TCP interface (opposed to IVS-500 and PSV-F-500 SW1 with a UDP interface)
		auto listener = HasComputeModule(communication)
			? GetTcpListener(communication.DeviceIPAddress())
			: GetUdpListener();

		return DataAcquisition(communication, capacity, listener);
	}

	class DataAcquisitionImplementation
	{
	public:
		DataAcquisitionImplementation(std::shared_ptr<DataAcquisitionListener> listener, DeviceCommunication& communication)
			: Listener(listener)
			, DeviceIpAddress(communication.DeviceIPAddress())
			, OperationMode(communication, PTCDeviceType_SignalProcessing, PTCDeviceCommand_OperationMode)
		{}

		DataAcquisitionImplementation(const DataAcquisitionImplementation&) = delete;
		DataAcquisitionImplementation(DataAcquisitionImplementation&&) = delete;
		DataAcquisitionImplementation& operator=(const DataAcquisitionImplementation&) = delete;
		DataAcquisitionImplementation& operator=(DataAcquisitionImplementation&&) = delete;

		~DataAcquisitionImplementation()
		{
			Listener->Close(DeviceIpAddress);
		}

		std::shared_ptr<DataAcquisitionListener> Listener;
		std::wstring DeviceIpAddress;
		IO::ItemList OperationMode;
		std::atomic<bool> Started{false};
	};

	DataAcquisition::DataAcquisition() = default;
	DataAcquisition::DataAcquisition(DataAcquisition && rhs) noexcept = default;
	DataAcquisition& DataAcquisition::operator=(DataAcquisition && rhs) noexcept = default;
	DataAcquisition::~DataAcquisition() noexcept = default;


	DataAcquisition::DataAcquisition(
		DeviceCommunication& communication, std::size_t capacity, std::shared_ptr<DataAcquisitionListener> listener)
		: m_implementation(std::make_unique<DataAcquisitionImplementation>(std::move(listener), communication))
	{
		CheckImplementation();
		m_implementation->Listener->Open(m_implementation->DeviceIpAddress, capacity, Deinterlacer(communication));
	}

	void DataAcquisition::StartAcquisition()
	{
		CheckImplementation();
		m_implementation->Listener->ClearBuffer(m_implementation->DeviceIpAddress);
		m_implementation->OperationMode.SetCurrentItem(L"DAQ");
		m_implementation->Started.store(true, std::memory_order_relaxed);
	}

	void DataAcquisition::StopAcquisition()
	{
		CheckImplementation();
		m_implementation->Listener->ShutdownBuffer(m_implementation->DeviceIpAddress);
		m_implementation->OperationMode.SetCurrentItem(L"Off");
		m_implementation->Started.store(false, std::memory_order_relaxed);
	}

	bool DataAcquisition::IsAcquisitionStarted() const
	{
		CheckImplementation();
		return m_implementation->Started.load(std::memory_order_relaxed);
	}

	std::vector<Channel> DataAcquisition::ActiveChannels() const
	{
		CheckImplementation();
		CheckStarted();
		return m_implementation->Listener->Deinterlacer(m_implementation->DeviceIpAddress).ActiveChannels();
	}

	void DataAcquisition::NextDataAcquisitionBlock()
	{
		CheckImplementation();
		CheckStarted();
		m_implementation->Listener->NextBlock(m_implementation->DeviceIpAddress);
	}

	MeasurementData DataAcquisition::ReadAvailableData(std::size_t sampleCount)
	{
		CheckImplementation();
		CheckStarted();
		return m_implementation->Listener->ReadAvailableData(m_implementation->DeviceIpAddress, sampleCount);
	}

	MeasurementData DataAcquisition::ReadData(std::size_t sampleCount, const std::chrono::duration<double>& timeout)
	{
		CheckImplementation();
		CheckStarted();
		return m_implementation->Listener->ReadData(m_implementation->DeviceIpAddress, sampleCount, timeout);
	}

	void DataAcquisition::Close()
	{
		m_implementation = nullptr;
	}

	std::size_t DataAcquisition::AvailableSamples() const
	{
		CheckImplementation();
		return m_implementation->Listener->Size(m_implementation->DeviceIpAddress);
	}

	int32_t DataAcquisition::ChannelMinValue(PTCChannelType channelType) const
	{
		return boost::numeric_cast<int32_t>(
			m_implementation->Listener->Deinterlacer(m_implementation->DeviceIpAddress).ChannelMinValue(channelType));
	}

	int32_t DataAcquisition::ChannelMaxValue(PTCChannelType channelType) const
	{
		return boost::numeric_cast<int32_t>(
			m_implementation->Listener->Deinterlacer(m_implementation->DeviceIpAddress).ChannelMaxValue(channelType));
	}

	double DataAcquisition::BaseSampleRateInHz() const
	{
		return m_implementation->Listener->Deinterlacer(m_implementation->DeviceIpAddress).BaseSampleRateHertz();
	}

	void DataAcquisition::CheckImplementation() const
	{
		if (!m_implementation)
		{
			throw std::logic_error("Failed to access invalid data acquisition object.");
		}
	}

	void DataAcquisition::CheckStarted() const
	{
		if (!m_implementation->Started.load(std::memory_order_relaxed))
		{
			throw CommunicationException(PTCCommunicationStatusCode_LogicError,
				"Acquisition not started.");
		}
	}
}
