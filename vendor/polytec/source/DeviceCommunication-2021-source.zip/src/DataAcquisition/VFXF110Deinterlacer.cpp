// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#include <IO/DataAcquisition/Detail/VFXF110Deinterlacer.h>

#include <IO/DataAcquisition/Channel.h>
#include <IO/DeviceCommunication/CommunicationException.h>
#include <IO/DeviceCommunication/DeviceCommunication.h>
#include <IO/DeviceCommunication/Utils/ChannelActivation.h>

#include <boost/numeric/conversion/cast.hpp>

using namespace Polytec;

namespace
{
	#pragma warning(push)
	#pragma warning(disable: 26490) // Don't use reinterpret_cast (type.1).
	template <typename T, typename U>
	gsl::span<T> ConvertSpan(const gsl::span<U>& from)
	{
		if (from.size_bytes() % sizeof(T) != 0)
		{
			throw std::logic_error("Conversion of span failed. Sizes don't match.");
		}
		return { reinterpret_cast<T*>(from.data()), from.size_bytes() / int{sizeof(T)} };
	}
	#pragma warning(pop)

	void CopyMaskedSignal(const gsl::span<int32_t>& destination, const gsl::span<const int32_t>& source, int32_t mask)
	{
		std::transform(source.begin(), source.end(), destination.begin(), [mask](int value)
		{
			return value & mask;
		});
	}

	void Copy(const IO::Channel& channel, IO::IDeinterlacer::SignalProperty signalProperty,
		const gsl::span<std::byte>& destination, const gsl::span<const std::byte>& source)
	{
		if (destination.size() != source.size())
		{
			throw std::logic_error("Can't copy deinterlaced data. Source and destination are of different size: "
				+ std::to_string(destination.size()) + ", " + std::to_string(source.size()));
		}

		if (!IsSignalChannel(channel))
		{
			std::memcpy(destination.data(), source.data(), source.size());
		}
		else if (signalProperty == IO::IDeinterlacer::SignalProperty::Overrange)
		{
			CopyMaskedSignal(ConvertSpan<int32_t>(destination), ConvertSpan<const int32_t>(source), CM::VFX::c_overrangeMask);
		}
		else
		{
			CopyMaskedSignal(ConvertSpan<int32_t>(destination), ConvertSpan<const int32_t>(source), CM::VFX::c_signalMask);
		}
	}
}

namespace Polytec::CM::VFX
{
	/// <summary>Gets VFX-F-110 base sample data format.</summary>
	/// <param name="frequencyFactor">The frequency factor.</param>
	/// <param name="isChannelActive">Callback function that evaluates if a given channel is active.</param>
	/// <returns>The base sample data format.</returns>
	IO::BaseSampleDataFormat GetBaseSampleDataFormat(int frequencyFactor, const std::function<bool(const IO::Channel&)>& isChannelActive)
	{
		auto addChannel = [offset = int{ 0 }](IO::OffsetSpan& span, int size) mutable
		{
			span.Offset = std::exchange(offset, offset + size);
			span.Size = size;
		};

		IO::BaseSampleDataFormat baseSample{};
		addChannel(baseSample[PTCChannelType_Trigger], sizeof(TriggerType) * frequencyFactor * isChannelActive(PTCChannelType_Trigger));
		addChannel(baseSample[PTCChannelType_Velocity], sizeof(SignalType) * frequencyFactor * isChannelActive(PTCChannelType_Velocity));
		addChannel(baseSample[PTCChannelType_Displacement], sizeof(SignalType) * frequencyFactor * isChannelActive(PTCChannelType_Displacement));
		addChannel(baseSample[PTCChannelType_Acceleration], sizeof(SignalType) * frequencyFactor * isChannelActive(PTCChannelType_Acceleration));
		addChannel(baseSample[PTCChannelType_RSSI], sizeof(RssiType) * isChannelActive(PTCChannelType_RSSI));
		return baseSample;
	}
}

namespace Polytec::IO
{
	/// <summary>Constructor.</summary>
	/// <param name="communication">The communication.</param>
	VFXF110Deinterlacer::VFXF110Deinterlacer(DeviceCommunication& communication)
		: m_communication(communication)
		, m_baseSampleRate(m_communication.SendGet<int32_t>(PTCDeviceType_SignalProcessing, PTCDeviceCommand_DaqBaseSampleRate))
	{}

	void VFXF110Deinterlacer::UpdateConfiguration()
	{
		m_measurementFrequencyFactor
			= m_communication.SendGet<int32_t>(PTCDeviceType_SignalProcessing, PTCDeviceCommand_DaqSampleRate)
			/ m_baseSampleRate;

		m_activeChannels = EvaluateActiveChannels();

		m_baseSampleOffsets = CM::VFX::GetBaseSampleDataFormat(m_measurementFrequencyFactor,
			[this](const IO::Channel& channel) { return IsActive(channel); });

		m_measurementNumber = m_communication.SendGet<int32_t>(PTCDeviceType_SignalProcessing, PTCDeviceCommand_DaqMeasurementNumber);

		m_blockSize = m_daqMode.GetCurrentItem() == L"Block"
			? m_communication.SendGet<int32_t>(PTCDeviceType_SignalProcessing, PTCDeviceCommand_DaqBlockSize)
			: std::optional<int>();

		CheckAllBaseSampleOffsetsDefined();
	}

	DataAcquisitionPayloadType VFXF110Deinterlacer::PayloadType(const Channel& channel) const
	{
		switch (channel.Type())
		{
			case PTCChannelType_Velocity:
			case PTCChannelType_Displacement:
			case PTCChannelType_Acceleration:
				return DataAcquisitionPayloadType::Int32;
			case PTCChannelType_RSSI:
				return DataAcquisitionPayloadType::Int16;
			case PTCChannelType_Trigger:
				return DataAcquisitionPayloadType::UInt8;
			default:
				throw CommunicationException(PTCCommunicationStatusCode_InvalidArgument, "Channel not supported by VFX-F-110.");
		}
	}

	std::size_t VFXF110Deinterlacer::ChannelSampleCount(const Channel& channel, const SourceData& source) const
	{
		switch (channel.Type())
		{
			case PTCChannelType_Velocity:
			case PTCChannelType_Displacement:
			case PTCChannelType_Acceleration:
			case PTCChannelType_Trigger:
				return m_measurementFrequencyFactor * BaseSampleCount(source);
			case PTCChannelType_RSSI:
				return BaseSampleCount(source);
			default:
				throw CommunicationException(PTCCommunicationStatusCode_InvalidArgument, "Channel not supported by VFX-F-110.");
		}
	}

	std::size_t VFXF110Deinterlacer::BaseSampleSize() const
	{
		return m_measurementFrequencyFactor * sizeof(CM::VFX::SignalType) * IsActive(PTCChannelType_Velocity)
			+ m_measurementFrequencyFactor * sizeof(CM::VFX::SignalType) * IsActive(PTCChannelType_Displacement)
			+ m_measurementFrequencyFactor * sizeof(CM::VFX::SignalType) * IsActive(PTCChannelType_Acceleration)
			+ m_measurementFrequencyFactor * sizeof(CM::VFX::TriggerType) * IsActive(PTCChannelType_Trigger)
			+ sizeof(CM::VFX::RssiType) * IsActive(PTCChannelType_RSSI);
	}

	void VFXF110Deinterlacer::CopySamplesForChannel(const Channel& channel, SignalProperty signalProperty,
		const SourceData& source, const DestinationData& destination) const
	{
		if (!IsActive(channel))
		{
			throw CommunicationException(PTCCommunicationStatusCode_LogicError, "Can't get data from inactive channel type: " + std::to_string(channel.Type()));
		}
		const auto channelData = m_baseSampleOffsets.at(channel);
		const auto baseSampleSize = BaseSampleSize();
		const auto baseSampleCount = BaseSampleCount(source);
		if (baseSampleCount * channelData.Size != destination.size())
		{
			throw std::logic_error("VFX-F-110 destiantion buffer doesn't match deinterlaced data.");
		}
		for (size_t sampleIndex = 0; sampleIndex < baseSampleCount; ++sampleIndex)
		{
			const auto sourceSample = source.subspan(sampleIndex * baseSampleSize, baseSampleSize);
			const auto sourceChannelData = sourceSample.subspan(channelData.Offset, channelData.Size);
			const auto destinationSample = destination.subspan(sampleIndex * channelData.Size, channelData.Size);
			Copy(channel, signalProperty, destinationSample, sourceChannelData);
		}
	}

	int64_t VFXF110Deinterlacer::ChannelMinValue(PTCChannelType channelType) const
	{
		switch (channelType)
		{
			case PTCChannelType_Velocity:
			case PTCChannelType_Displacement:
			case PTCChannelType_Acceleration:
				return std::numeric_limits<int32_t>::min();
			case PTCChannelType_RSSI:
				return 0;
			case PTCChannelType_Trigger:
				return 0;
			default:
				throw CommunicationException(PTCCommunicationStatusCode_InvalidArgument, "Channel not supported by VFX-F-110.");
		}

	}

	int64_t VFXF110Deinterlacer::ChannelMaxValue(PTCChannelType channelType) const
	{
		switch (channelType)
		{
			case PTCChannelType_Velocity:
			case PTCChannelType_Displacement:
			case PTCChannelType_Acceleration:
				return std::numeric_limits<int32_t>::max();
			case PTCChannelType_RSSI:
				return 511;
			case PTCChannelType_Trigger:
				return 1;
			default:
				throw CommunicationException(PTCCommunicationStatusCode_InvalidArgument, "Channel not supported by VFX-F-110.");
		}
	}

	std::vector<Channel> VFXF110Deinterlacer::ActiveChannels() const
	{
		return m_activeChannels;
	}

	std::vector<Channel> VFXF110Deinterlacer::EvaluateActiveChannels() const
	{
		std::vector<Channel> result;
		auto channels = m_communication.SendGet<std::vector<int16_t>>(PTCDeviceType_SignalProcessing, PTCDeviceCommand_DaqActiveChannels);
		const auto removeBegin = std::remove_if(channels.begin(), channels.end(), [this](int16_t channel)
		{
			return std::vector<int16_t>{-1} == m_communication.SendGet<std::vector<int16_t>>(
				PTCDeviceType_SignalProcessing, PTCDeviceCommand_DaqActiveChannels, static_cast<PTCMiscellaneousTag>(channel));
		});
		std::transform(channels.begin(), removeBegin, std::back_inserter(result), [](int16_t channelTag) -> Channel
		{
			return ToChannelType(static_cast<PTCMiscellaneousTag>(channelTag));
		});
		return result;
	}

	bool VFXF110Deinterlacer::IsActive(const Channel& channel) const
	{
		return std::find(m_activeChannels.cbegin(), m_activeChannels.cend(), channel) != std::cend(m_activeChannels);
	}

	std::size_t VFXF110Deinterlacer::BaseSampleCount(const SourceData& source) const
	{
		if (const auto baseSampleSize = BaseSampleSize();
			baseSampleSize == 0 || source.size() % baseSampleSize != 0)
		{
			throw std::logic_error("Can't count VFX-F-110 samples. The data doesn't match the expected format.");
		}
		return source.size() / BaseSampleSize();
	}

	void VFXF110Deinterlacer::CheckAllBaseSampleOffsetsDefined() const
	{
		for (const auto& channel : m_activeChannels)
		{
			if (m_baseSampleOffsets.find(channel) == m_baseSampleOffsets.cend())
			{
				throw std::logic_error("No base sample offset defined for active channel.");
			}
		}
	}
}
