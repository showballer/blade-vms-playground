// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#include <IO/DataAcquisition/Detail/DataAcquisitionHeader.h>

#include <IO/DataAcquisition/Detail/DataUse.h>
#include <IO/DeviceCommunication/Detail/DataReader.h>
#include <IO/DeviceCommunication/Detail/DataWriter.h>

#include <gsl/gsl>

namespace
{
	constexpr uint8_t c_reservedByte = 0;
	constexpr std::size_t c_ivsHeaderLength = 24;
	constexpr std::size_t c_vfxHeaderLength = 32;

	void CheckHeaderLength(std::size_t expected, std::size_t actual)
	{
		if (expected != actual)
		{
			throw std::runtime_error("The header has not the expected header length.");
		}
	}
}

namespace Polytec::IO
{
	void SaveDataAcquisitionHeader(DataWriter& writer, const DataAcquisitionHeader& header)
	{
		switch (header.ProtocolType)
		{
			case ProtocolType::IVS500:
			case ProtocolType::VGO200Pioneer:
				writer.Write(gsl::narrow<uint16_t>(header.ProtocolType));
				writer.Write(gsl::narrow<uint16_t>(header.PayloadLength));
				writer.Write(gsl::narrow<uint8_t>(header.PayloadType));
				writer.Write(gsl::narrow<uint8_t>(header.DataUse));
				writer.Write(c_reservedByte);
				writer.Write(c_reservedByte);
				writer.Write(gsl::narrow<uint64_t>(header.SequenceNumber));
				writer.Write(gsl::narrow<uint64_t>(header.DacSequence));
				return;
			case ProtocolType::VFXF110:
				writer.Write(gsl::narrow<uint16_t>(header.ProtocolType));
				writer.Write(gsl::narrow<uint16_t>(c_vfxHeaderLength));
				writer.Write(gsl::narrow<uint32_t>(header.PayloadLength));
				writer.Write(gsl::narrow<uint8_t>(header.DataUse));
				writer.Write(gsl::narrow<uint8_t>(header.SequenceFlags));
				writer.Write(gsl::narrow<uint64_t>(header.SequenceNumber));
				writer.Write(gsl::narrow<uint64_t>(header.DacSequence));
				writer.Write(gsl::narrow<int32_t>(header.MeasurementNumber));
				// The last two reserved bytes are filled with protocol type.
				// This may give the possibility to redefine the first two bytes as HeaderVersion.
				writer.Write(gsl::narrow<uint16_t>(header.ProtocolType));
				return;
			default:
				throw std::runtime_error("Save header: Data acquisition protocol type not supported: "
					+ std::to_string(static_cast<int>(header.ProtocolType)));
		}

	}

	DataAcquisitionHeader LoadDataAcquisitionHeader(DataReader& reader)
	{
		DataAcquisitionHeader header{};
		header.ProtocolType = static_cast<ProtocolType>(reader.Read<uint16_t>());
		switch (header.ProtocolType)
		{
			case ProtocolType::IVS500:
			case ProtocolType::VGO200Pioneer:
				header.PayloadLength = reader.Read<uint16_t>();
				header.PayloadType = static_cast<DataAcquisitionPayloadType>(reader.Read<uint8_t>());
				header.DataUse = static_cast<DataUse>(reader.Read<uint8_t>());
				reader.Read<uint8_t>(); // reserved byte
				reader.Read<uint8_t>(); // reserved byte
				header.SequenceNumber = reader.Read<uint64_t>();
				header.DacSequence = reader.Read<uint64_t>();
				return header;
			case ProtocolType::VFXF110:
				CheckHeaderLength(c_vfxHeaderLength, reader.Read<uint16_t>());
				header.PayloadLength = reader.Read<uint32_t>();
				header.DataUse = static_cast<DataUse>(reader.Read<uint8_t>());
				header.SequenceFlags = reader.Read<uint8_t>();
				header.SequenceNumber = reader.Read<uint64_t>();
				header.DacSequence = reader.Read<uint64_t>();
				header.MeasurementNumber = reader.Read<int32_t>();
				reader.Read<uint8_t>(); // reserved byte
				reader.Read<uint8_t>(); // reserved byte
				return header;
			default:
				throw std::runtime_error("Load header: Data acquisition protocol type not supported: "
					+ std::to_string(static_cast<int>(header.ProtocolType)));
		}
	}

	std::size_t LoadDataAcquisitionPacketLength(DataReader& reader)
	{
		const auto protocolType = static_cast<ProtocolType>(reader.Read<uint16_t>());
		switch (protocolType)
		{
			case ProtocolType::IVS500:
			case ProtocolType::VGO200Pioneer:
			{
				const auto payloadLength = reader.Read<uint16_t>();
				return c_ivsHeaderLength + payloadLength;
			}
			case ProtocolType::VFXF110:
			{
				const auto headerLength = reader.Read<uint16_t>();
				const auto payloadLength = reader.Read<uint32_t>();
				return headerLength + payloadLength;
			}
			default:
			{
				throw std::runtime_error("Load packet length: Data acquisition protocol type not supported: "
					+ std::to_string(static_cast<int>(protocolType)));
			}
		}
	}
}
