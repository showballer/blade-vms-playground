// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#define BUILD_DAQAPI // This is needed to export symbols when creating a DLL. It is used in PolyDataAcquisition.h.
#include <IO/DataAcquisition/PolyDataAcquisition.h>

#include <IO/DataAcquisition/DataAcquisition.h>
#include <IO/DataAcquisition/MeasurementData.h>
#include <IO/DataAcquisition/Detail/IVS500Deinterlacer.h>
#include <IO/DeviceCommunication/CommunicationException.h>
#include <IO/DeviceCommunication/Detail/CommunicationResource.h>
#include <IO/DeviceCommunication/Detail/HandleManager.h>
#include <IO/DeviceCommunication/Detail/PayloadTypeTraits.h>
#include <IO/DeviceCommunication/Detail/StringConverter.h>
#include <IO/DeviceCommunication/PTCCommunicationStatusCode.h>
#include <IO/DeviceCommunication/Utils/ChannelActivation.h>

#include <codecvt>
#include <locale>
#include <mutex>

#pragma warning(disable: 4996) // strncpy

using namespace Polytec::IO;

namespace
{
	struct AcquisitionResource
	{
		Polytec::IO::DataAcquisition DataAcquisition;
		Polytec::IO::MeasurementData MeasurementData;
	};

	template <typename T>
	void CheckValid(const T* value)
	{
		if (!value)
		{
			throw CommunicationException(PTCCommunicationStatusCode_InvalidArgument, "Argument may not be null.");
		}
	}

	template<typename TPayload>
	PTCCommunicationStatusCode GetChannelData(PTAcquisitionHandle acquisitionHandle,
		PTCChannelType channelType, int channelId, TPayload* destination, std::size_t bufferSize, bool overrangeFlag)
	{
		return Try([acquisitionHandle, channelType, channelId, destination, bufferSize, overrangeFlag]
		{
			CheckValid(destination);
			const auto& measurementData = GetHandleManager<AcquisitionResource>().Get(acquisitionHandle).MeasurementData;
			const auto source = overrangeFlag
				? measurementData.GetOverrange<TPayload>({channelType, channelId})
				: measurementData.Get<TPayload>({channelType, channelId});
			if (bufferSize != source.size())
			{
				throw CommunicationException(PTCCommunicationStatusCode_RangeError,
					"Sample count for this channel does not match the extracted count of samples by the last read call."
					"Requested samples: " + std::to_string(bufferSize)
					+ ". Available samples: " + std::to_string(source.size()) + ".");
			}
			std::copy(source.cbegin(), source.cend(),
				std::begin(gsl::span(destination, bufferSize)));
		});
	}
	
	ChannelActivation& GetChannelActivation(PTCommunicationHandle communicationHandle)
	{
		return GetHandleManager<CommunicationResource>().Get(communicationHandle).ChannelActivation();
	}

	bool UsesIvsProtocol(PTCommunicationHandle communicationHandle)
	{
		const auto daqProtocolType = static_cast<ProtocolType>(GetHandleManager<CommunicationResource>().Get(communicationHandle).DeviceCommunication()
			.SendGet<int16_t>(PTCDeviceType_SignalProcessing, PTCDeviceCommand_DAQProtocolType));
		return daqProtocolType == ProtocolType::IVS500
			|| daqProtocolType == ProtocolType::IVS500Hotfix
			|| daqProtocolType == ProtocolType::VGO200Pioneer;
	}

	bool HasDaqActiveChannelsCommand(PTCommunicationHandle communicationHandle)
	{
		return GetHandleManager<CommunicationResource>().Get(communicationHandle)
			.CommandList(PTCDeviceType_SignalProcessing, 0).HasCommand(PTCDeviceCommand_DaqActiveChannels);
	}

	bool IsIvsChannelTypeSupported(PTCommunicationHandle communicationHandle, PTCChannelType channelType)
	{
		switch (channelType)
		{
			case PTCChannelType_Displacement:
				return GetHandleManager<CommunicationResource>().Get(communicationHandle)
					.DeviceList().HasDevice(PTCDeviceType_DisplacementDecoderDigital);
			case PTCChannelType_Acceleration:
				return GetHandleManager<CommunicationResource>().Get(communicationHandle)
					.DeviceList().HasDevice(PTCDeviceType_AccelerationDecoderDigital);
			case PTCChannelType_Velocity:
			case PTCChannelType_DataValidity:
			case PTCChannelType_RSSI:
			case PTCChannelType_Trigger:
				return true;
			default:
				return false;
		}
	}
}

extern "C"
PTCCommunicationStatusCode PolyOpenDataAcquisition(PTAcquisitionHandle* acquisitionHandle,
	PTCommunicationHandle communicationHandle, size_t bufferCapacity)
{
	return Try([acquisitionHandle, communicationHandle, bufferCapacity]
	{
		CheckValid(acquisitionHandle);
		*acquisitionHandle = 0;
		auto& communicationResource = GetHandleManager<CommunicationResource>().Get(communicationHandle);
		*acquisitionHandle = GetHandleManager<AcquisitionResource>().Create(AcquisitionResource{
			CreateDigitalDataAcquisition(communicationResource.DeviceCommunication(), bufferCapacity),
			MeasurementData()});
	});
}

extern "C"
void PolyCloseDataAcquisition(PTAcquisitionHandle handle)
{
	GetHandleManager<AcquisitionResource>().Delete(handle);
}

extern "C"
PTCCommunicationStatusCode PolyStartDataAcquisition(PTAcquisitionHandle acquisitionHandle)
{
	return Try([acquisitionHandle]
	{
		GetHandleManager<AcquisitionResource>().Get(acquisitionHandle)
			.DataAcquisition.StartAcquisition();
	});
}

extern "C"
PTCCommunicationStatusCode PolyStopDataAcquisition(PTAcquisitionHandle acquisitionHandle)
{
	return Try([acquisitionHandle]
	{
		GetHandleManager<AcquisitionResource>().Get(acquisitionHandle)
			.DataAcquisition.StopAcquisition();
	});
}

extern "C"
PTCCommunicationStatusCode PolyNextDataAcquisitionBlock(PTAcquisitionHandle acquisitionHandle)
{
	return Try([acquisitionHandle]
	{
		GetHandleManager<AcquisitionResource>().Get(acquisitionHandle)
			.DataAcquisition.NextDataAcquisitionBlock();
	});
}

extern "C"
PTCCommunicationStatusCode PolyReadData(PTAcquisitionHandle acquisitionHandle,
	std::size_t requestedSamples, int timeoutInMilliseconds)
{
	return Try([acquisitionHandle, requestedSamples, timeoutInMilliseconds]
	{
		auto& measurementData = GetHandleManager<AcquisitionResource>().Get(acquisitionHandle).MeasurementData;
		measurementData = GetHandleManager<AcquisitionResource>().Get(acquisitionHandle)
			.DataAcquisition.ReadData(requestedSamples, std::chrono::milliseconds(timeoutInMilliseconds));
	});
}

extern "C"
PTCCommunicationStatusCode PolyReadAvailableData(PTAcquisitionHandle acquisitionHandle,
	std::size_t requestedSamples, std::size_t* extractedSamples)
{
	return Try([acquisitionHandle, requestedSamples, extractedSamples]
	{
		if (extractedSamples)
		{
			*extractedSamples = 0;
		}
		auto& measurementData = GetHandleManager<AcquisitionResource>().Get(acquisitionHandle).MeasurementData;
		measurementData = GetHandleManager<AcquisitionResource>().Get(acquisitionHandle)
			.DataAcquisition.ReadAvailableData(requestedSamples);
		if (extractedSamples)
		{
			*extractedSamples = measurementData.BaseSampleCount();
		}
	});
}

extern "C"
PTCCommunicationStatusCode PolyAvailableSamples(PTAcquisitionHandle acquisitionHandle,
	size_t* availableBaseSamples)
{
	return Try([acquisitionHandle, availableBaseSamples]
	{
		*availableBaseSamples = GetHandleManager<AcquisitionResource>().Get(acquisitionHandle)
			.DataAcquisition.AvailableSamples();
	});
}

extern "C"
PTCCommunicationStatusCode PolyExtractedSampleCount(PTAcquisitionHandle acquisitionHandle,
	PTCChannelType channelType, int channelId, size_t* extractedSamples)
{
	return Try([acquisitionHandle, channelType, channelId, extractedSamples]
	{
		*extractedSamples = GetHandleManager<AcquisitionResource>().Get(acquisitionHandle)
			.MeasurementData.SampleCount({channelType, channelId});
	});
}

extern "C"
PTCCommunicationStatusCode PolyGetUInt8Data(PTAcquisitionHandle acquisitionHandle,
	PTCChannelType channelType, int channelId, uint8_t* dataBuffer, std::size_t bufferSize)
{
	return GetChannelData(acquisitionHandle, channelType, channelId, dataBuffer, bufferSize, false);
}

extern "C"
PTCCommunicationStatusCode PolyGetInt16Data(PTAcquisitionHandle acquisitionHandle,
	PTCChannelType channelType, int channelId, int16_t* dataBuffer, std::size_t bufferSize)
{
	return GetChannelData(acquisitionHandle, channelType, channelId, dataBuffer, bufferSize, false);
}

extern "C"
PTCCommunicationStatusCode PolyGetUInt16Data(PTAcquisitionHandle acquisitionHandle,
	PTCChannelType channelType, int channelId, uint16_t* dataBuffer, std::size_t bufferSize)
{
	return GetChannelData(acquisitionHandle, channelType, channelId, dataBuffer, bufferSize, false);
}

extern "C"
PTCCommunicationStatusCode PolyGetInt32Data(PTAcquisitionHandle acquisitionHandle,
	PTCChannelType channelType, int channelId, int32_t* dataBuffer, size_t bufferSize)
{
	return GetChannelData(acquisitionHandle, channelType, channelId, dataBuffer, bufferSize, false);
}

extern "C"
PTCCommunicationStatusCode PolyGetOverrange(PTAcquisitionHandle acquisitionHandle,
	PTCChannelType channelType, int channelId, uint8_t* dataBuffer, size_t bufferSize)
{
	return GetChannelData(acquisitionHandle, channelType, channelId, dataBuffer, bufferSize, true);
}

extern "C"
PTCCommunicationStatusCode PolyChannelMinValue(PTAcquisitionHandle acquisitionHandle,
	PTCChannelType channelType, int32_t* minValue)
{
	return Try([acquisitionHandle, channelType, minValue]
	{
		CheckValid(minValue);
		*minValue = GetHandleManager<AcquisitionResource>().Get(acquisitionHandle)
			.DataAcquisition.ChannelMinValue(channelType);
	});
}

extern "C"
PTCCommunicationStatusCode PolyChannelMaxValue(PTAcquisitionHandle acquisitionHandle,
	PTCChannelType channelType, int32_t* maxValue)
{
	return Try([acquisitionHandle, channelType, maxValue]
	{
		CheckValid(maxValue);
		*maxValue = GetHandleManager<AcquisitionResource>().Get(acquisitionHandle)
			.DataAcquisition.ChannelMaxValue(channelType);
	});
}

extern "C"
PTCCommunicationStatusCode PolyChannelActivationMaxChannelCount(PTCommunicationHandle communicationHandle,
	PTCChannelType channelType, int* count)
{
	return Try([communicationHandle, channelType, count]
	{
		CheckValid(count);
		if (HasDaqActiveChannelsCommand(communicationHandle))
		{
			auto channelActivation = GetChannelActivation(communicationHandle);
			const auto supportedTypes = channelActivation.GetAllSupportedChannelTypes();
			*count = std::find(std::cbegin(supportedTypes), std::cend(supportedTypes), channelType) != std::cend(supportedTypes)
				? channelActivation.GetMaxChannelCount(channelType)
				: 0;
		}
		else if (UsesIvsProtocol(communicationHandle))
		{
			*count = IsIvsChannelTypeSupported(communicationHandle, channelType) ? 1 : 0;
		}
		else
		{
			throw CommunicationException(PTCCommunicationStatusCode_LogicError, "Unable to determine channel activation.");
		}
	});
}

extern "C"
PTCCommunicationStatusCode PolyChannelActivationIsChannelTypeSupported(PTCommunicationHandle communicationHandle,
	PTCChannelType channelType, bool* result)
{
	return Try([communicationHandle, channelType, result]
	{
		CheckValid(result);
		if (HasDaqActiveChannelsCommand(communicationHandle))
		{
			const auto supportedTypes = GetChannelActivation(communicationHandle).GetAllSupportedChannelTypes();
			*result = std::find(std::cbegin(supportedTypes), std::cend(supportedTypes), channelType) != std::cend(supportedTypes);
		}
		else if (UsesIvsProtocol(communicationHandle))
		{
			*result = IsIvsChannelTypeSupported(communicationHandle, channelType);
		}
		else
		{
			throw CommunicationException(PTCCommunicationStatusCode_LogicError, "Unable to determine channel activation.");
		}
	});
}

extern "C"
PTCCommunicationStatusCode PolyChannelActivationIsChannelAvailable(PTCommunicationHandle communicationHandle,
	PTCChannelType channelType, int channelId, bool* result)
{
	return Try([communicationHandle, channelType, channelId, result]
	{
		CheckValid(result);
		if (HasDaqActiveChannelsCommand(communicationHandle))
		{
			const auto& channelActivation = GetChannelActivation(communicationHandle);
			const auto supportedTypes = channelActivation.GetAllSupportedChannelTypes();
			if (std::find(std::cbegin(supportedTypes), std::cend(supportedTypes), channelType) == std::cend(supportedTypes))
			{
				*result = false;
			}
			else
			{
				const auto maxChannelCount = channelActivation.GetMaxChannelCount(channelType);
				const auto activeChannels = channelActivation.GetActiveChannels(channelType);
				const auto currentChannelCount = gsl::narrow<std::size_t>(channelActivation.GetAvailableChannelCount(channelType));
				*result = channelId < maxChannelCount &&
					(currentChannelCount > std::size(activeChannels) ||
					std::find(std::cbegin(activeChannels), std::cend(activeChannels), channelId) != std::cend(activeChannels));
			}
		}
		else if (UsesIvsProtocol(communicationHandle))
		{
			*result = channelId == 0 && IsIvsChannelTypeSupported(communicationHandle, channelType);
		}
		else
		{
			throw CommunicationException(PTCCommunicationStatusCode_LogicError, "Unable to determine channel activation.");
		}
	});
}

extern "C"
PTCCommunicationStatusCode PolyChannelActivationEnableChannel(PTCommunicationHandle communicationHandle,
	PTCChannelType channelType, int channelId)
{
	return Try([communicationHandle, channelType, channelId]
	{	
		if (HasDaqActiveChannelsCommand(communicationHandle))
		{
			auto& channelActivation = GetChannelActivation(communicationHandle);
			auto activeChannels = channelActivation.GetActiveChannels(channelType);
			if (std::find(std::cbegin(activeChannels), std::cend(activeChannels), channelId) == std::cend(activeChannels))
				activeChannels.push_back(channelId);
			channelActivation.SetActiveChannels(channelType, activeChannels);
		}
		else
		{
			throw CommunicationException(PTCCommunicationStatusCode_LogicError,
				"The device does not support the DaqActiveChannels command.");
		}
	});
}

extern "C"
PTCCommunicationStatusCode PolyChannelActivationDisableChannel(PTCommunicationHandle communicationHandle,
	PTCChannelType channelType, int channelId)
{
	return Try([communicationHandle, channelType, channelId]
	{	
		if (HasDaqActiveChannelsCommand(communicationHandle))
		{
			auto& channelActivation = GetChannelActivation(communicationHandle);
			auto activeChannels = channelActivation.GetActiveChannels(channelType);
			const auto pos = std::find(std::cbegin(activeChannels), std::cend(activeChannels), channelId);
			if (pos != std::cend(activeChannels))
				activeChannels.erase(pos);
			channelActivation.SetActiveChannels(channelType, activeChannels);
		}
		else
		{
			throw CommunicationException(PTCCommunicationStatusCode_LogicError,
				"The device does not support the DaqActiveChannels command.");
		}
	});
}

extern "C"
PTCCommunicationStatusCode PolyChannelActivationDisableAllChannels(PTCommunicationHandle communicationHandle)
{
	return Try([communicationHandle]
	{
		if (HasDaqActiveChannelsCommand(communicationHandle))
		{
			GetChannelActivation(communicationHandle).DisableAllChannels();
		}
		else
		{
			throw CommunicationException(PTCCommunicationStatusCode_LogicError,
				"The device does not support the DaqActiveChannels command.");
		}
	});
}

extern "C"
PTCCommunicationStatusCode PolyChannelActivationIsChannelEnabled(PTCommunicationHandle communicationHandle,
	PTCChannelType channelType, int channelId, bool* result)
{
	return Try([communicationHandle, channelType, channelId, result]
	{
		CheckValid(result);
		if (HasDaqActiveChannelsCommand(communicationHandle))
		{
			const auto activeChannels = GetChannelActivation(communicationHandle).GetActiveChannels(channelType);
			*result =
				std::find(std::cbegin(activeChannels), std::cend(activeChannels), channelId)
				!= std::cend(activeChannels);
		}
		else if (UsesIvsProtocol(communicationHandle))
		{
			auto interlacer = IVS500Deinterlacer(GetHandleManager<CommunicationResource>()
				.Get(communicationHandle).DeviceCommunication());
			interlacer.UpdateConfiguration();
			const auto activeChannels = interlacer.ActiveChannels();
			*result =
				std::find(std::cbegin(activeChannels), std::cend(activeChannels), Channel(channelType, channelId))
				!= std::cend(activeChannels);
		}
		else
		{
			throw CommunicationException(PTCCommunicationStatusCode_LogicError, "Unable to determine channel activation.");
		}
	});
}

extern "C"
DAQAPI PTCCommunicationStatusCode PolyBaseSampleRateInHz(PTAcquisitionHandle acquisitionHandle, double* baseSampleRate)
{
	return Try([acquisitionHandle, baseSampleRate]
	{
		CheckValid(baseSampleRate);
		*baseSampleRate = GetHandleManager<AcquisitionResource>().Get(acquisitionHandle)
			.DataAcquisition.BaseSampleRateInHz();
	});
}
