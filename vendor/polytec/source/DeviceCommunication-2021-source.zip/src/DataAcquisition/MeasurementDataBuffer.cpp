// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#include <IO/DataAcquisition/Detail/MeasurementDataBuffer.h>

#include <IO/DataAcquisition/Detail/DataAcquisitionError.h>
#include <IO/DataAcquisition/Detail/DataAcquisitionHeader.h>
#include <IO/DataAcquisition/Detail/MeasurementDataBuffer.h>
#include <IO/DataAcquisition/MeasurementData.h>
#include <IO/DeviceCommunication/Detail/DataReader.h>
#include <IO/DeviceCommunication/Detail/StringConverter.h>

#include <algorithm>
#include <chrono>
#include <thread>

namespace
{
	/// <summary>A timer class counting the time since it's construction</summary>
	class Timer
	{
		using steady_clock = std::chrono::steady_clock;
		const std::chrono::time_point<steady_clock> m_start = steady_clock::now();
	public:
		/// <summary>Get the time that has elapsed since the timer object has been constructed</summary>
		/// <returns>Elapsed time</returns>
		std::chrono::microseconds ElapsedTime()
		{
			const auto now = steady_clock::now();
			return std::chrono::duration_cast<std::chrono::microseconds>(now - m_start);
		}
	};

	using namespace Polytec::IO;

	std::string ToErrorMessage(DataAcquisitionError error)
	{
		switch (error)
		{
			case DataAcquisitionError::NoError:
				return "No error.";
			case DataAcquisitionError::UnknownError:
				return "Unknown error.";
			case DataAcquisitionError::GeneratorBufferUnderflow:
				return "Generator buffer underflow.";
			case DataAcquisitionError::GeneratorSequenceError:
				return "Generator sequence error.";
			case DataAcquisitionError::GeneratorSequenceErrorOutputData:
				return "Generator sequence error output data.";
			case DataAcquisitionError::GeneratorSequenceErrorFillFiFo:
				return "Generator sequence error fill data.";
			case DataAcquisitionError::DataAcquisitionBufferOverflow:
				return "Data acquisition internal buffer overflow.";
			case DataAcquisitionError::DataAcquisitionDataLoss:
				return "Data acquisition internal data loss.";
			default:
				return "Error code = " + std::to_string(static_cast<int>(error));
		}
	}
}

namespace Polytec::IO
{
	/// <summary>
	/// Constructs a measurement data buffer instance. A ring buffer will be created.
	/// </summary>
	/// <param name="capacity">The capacity of the ring buffer.</param>
	MeasurementDataBuffer::MeasurementDataBuffer(std::size_t capacity, std::unique_ptr<IDeinterlacer> deinterlacer)
		: m_capacity(capacity)
		, m_deinterlacer(std::move(deinterlacer))
	{
		Reset();
	}

	/// <summary>
	/// Writes data to the ring buffer. If errors occur, they will be logged if logging is enabled.
	/// </summary>
	/// <param name="header">The data header.</param>
	/// <param name="data">The pointer to the data.</param>
	/// <param name="dataSizeBytes">The data size in bytes.</param>
	void MeasurementDataBuffer::Write(const gsl::span<const std::byte>& data)
	{
		const std::lock_guard lock(m_mutex);
		try
		{
			IO::DataReader reader(data);
			const auto header = LoadDataAcquisitionHeader(reader);
			DoWrite(header, gsl::span(reader.Data(), reader.BytesAvailable()));
		}
		catch (const CommunicationException& e)
		{
			m_errorState.Set(e.GetStatusCode(), ToWString(e.AdditionalInformation()));
		}
		catch (const std::overflow_error& e)
		{
			m_errorState.Set(PTCCommunicationStatusCode_BufferOverflow, ToWString(e.what()));
		}
		catch (const std::exception& e)
		{
			m_errorState.Set(PTCCommunicationStatusCode_RuntimeError, ToWString(e.what()));
		}
	}

	void MeasurementDataBuffer::DoWrite(const DataAcquisitionHeader& header, const gsl::span<const std::byte>& data)
	{
		if (m_errorState.IsErrorState()
			|| header.DataUse == DataUse::Void
			|| m_deinterlacer->MeasurementNumber() != header.MeasurementNumber)
		{
			return;
		}

		CheckHeaderConsistency(header, data.size());
		CheckNoError(header, data);

		if (!m_hasStarted)
		{
			m_hasStarted = true;
			m_sequenceNumber = header.SequenceNumber;
		}

		if (m_deinterlacer->DataLossControl())
		{
			for (; m_sequenceNumber < header.SequenceNumber; m_sequenceNumber++) // writing one packet at a time to avoid memory overconsumption
				m_ringBuffer->Write(m_deinterlacer->DataLossControl()->CreateDataForInvalidPacket());
		}
		else if (m_sequenceNumber != header.SequenceNumber)
		{
			throw std::runtime_error("Unexpected packet loss detected.");
		}

		if (m_sequenceNumber == header.SequenceNumber)
		{
			const auto newSamples = CreateValidSamples(data);

			m_ringBuffer->SizeToWrite() >= newSamples.size() // write one sample at a time if an overflow is expected
				? m_ringBuffer->Write(newSamples)
				: WriteOneSampleAtATime(newSamples);

			m_sequenceNumber++;
		}
		/// else the data packet is already written to the buffer (this may happen if redundancy data is sent, e.g. from IVS-500)
	}

	void MeasurementDataBuffer::CheckHeaderConsistency(
		const DataAcquisitionHeader& header, std::size_t dataSizeBytes) const
	{
		if (header.ProtocolType != m_deinterlacer->ProtocolType())
		{
			throw CommunicationException(PTCCommunicationStatusCode_InvalidArgument,
				"The channel policy does not match the received data format.");
		}
		if (header.PayloadLength != dataSizeBytes)
		{
			throw CommunicationException(PTCCommunicationStatusCode_RuntimeError,
				"The received payload does not match the specified length defined in the header.");
		}
		if (m_deinterlacer->BaseSampleSize() == 0
			|| dataSizeBytes % m_deinterlacer->BaseSampleSize() != 0)
		{
			throw CommunicationException(PTCCommunicationStatusCode_RuntimeError,
				"The received payload size does not match to the expected sample format.");
		}
		if (header.DataUse != DataUse::Data &&
			header.DataUse != DataUse::Redundancy &&
			header.DataUse != DataUse::Error)
		{
			throw CommunicationException(PTCCommunicationStatusCode_RuntimeError,
				"The received packet is not a data packet.");
		}
	}

	void MeasurementDataBuffer::CheckNoError(const DataAcquisitionHeader& header, const gsl::span<const std::byte>& data) const
	{
		if (header.DataUse == DataUse::Error)
		{
			throw CommunicationException(PTCCommunicationStatusCode_RuntimeError,
				"Error packet received: " + (std::size(data) > 0
				? ToErrorMessage(gsl::narrow_cast<DataAcquisitionError>(data[0]))
				: "No error code received.")
			);
		}
	}

	void MeasurementDataBuffer::WriteOneSampleAtATime(const gsl::span<const std::byte>& samples)
	{
		const auto baseSampleSize = m_deinterlacer->BaseSampleSize();
		for (size_t sampleIndex = 0; sampleIndex < samples.size() / baseSampleSize; sampleIndex++)
		{
			if (!m_deinterlacer->DataLossControl())
			{
				WaitForBytesAvailableToWrite(baseSampleSize);
			}
			m_ringBuffer->Write(samples.subspan(sampleIndex * baseSampleSize, baseSampleSize));
		}
	}

	void MeasurementDataBuffer::WaitForBytesAvailableToWrite(std::size_t size) const
	{
		while (!m_isShuttingDown.load(std::memory_order_relaxed)
			&& m_ringBuffer->SizeToWrite() < size)
		{
			std::this_thread::sleep_for(std::chrono::milliseconds(5));
		}
	}

	gsl::span<const std::byte> MeasurementDataBuffer::CreateValidSamples(const gsl::span<const std::byte>& source)
	{
		if (m_deinterlacer->DataLossControl())
		{
			m_validSamplesBuffer = m_deinterlacer->DataLossControl()->MakeValidSamples(std::vector<std::byte>(source.begin(), source.end()));
			return m_validSamplesBuffer;
		}
		else
		{
			return source;
		}
	}

	/// <summary>Resets the ring buffer.</summary>
	void MeasurementDataBuffer::Reset()
	{
		Shutdown();
		Initialize();
	}

	void MeasurementDataBuffer::NextBlock()
	{
		if (!m_deinterlacer->BlockSize().has_value())
		{
			throw CommunicationException(PTCCommunicationStatusCode_RangeError,
				"Calling next block is not supported when block mode is disabled.");
		}
		if (m_readCounter % gsl::narrow_cast<std::size_t>(m_deinterlacer->BlockSize().value()) != 0)
		{
			throw CommunicationException(PTCCommunicationStatusCode_RangeError,
				"Calling next block is not supported when block is not entirely read.");
		}
		m_readCounter = 0;
	}

	/// <summary>
	/// Reads available data from the buffer. If the requested maximum number of samples is not
	/// available, only the currently available data is read from the ring buffer.
	/// </summary>
	/// <param name="maxSampleCount">The maximum number of samples to read.</param>
	/// <returns>The available data.</returns>
	MeasurementData MeasurementDataBuffer::ReadAvailableData(std::size_t maxSampleCount)
	{
		const std::size_t count = std::min(maxSampleCount, AvailableSamples());
		if (count == 0 && m_errorState.IsErrorState())
		{
			const auto state = m_errorState.Get();
			throw CommunicationException(state.first, ToString(state.second));
		}
		std::vector<std::byte> outputSamples(count * m_deinterlacer->BaseSampleSize());
		m_ringBuffer->Read(outputSamples);
		m_readCounter += count;
		return MeasurementData(std::move(outputSamples), m_deinterlacer->Clone());
	}

	/// <summary>
	/// Reads data from the buffer. This function is blocking until the requested samples are
	/// available or the timeout expires. If the given timeout is expired, an exception is thrown.
	/// </summary>
	/// <exception cref="CommunicationException">Thrown if the timeout is exceeded.</exception>
	/// <param name="sampleCount">The number of samples to read.</param>
	/// <param name="timeout">The timeout.</param>
	/// <returns>The data.</returns>
	MeasurementData MeasurementDataBuffer::ReadData(std::size_t sampleCount, const std::chrono::duration<double>& timeout)
	{
		CheckReadOutOfRange(sampleCount);
		Timer timer;
		while (true)
		{
			const bool errorState = m_errorState.IsErrorState(); // get error state before samples available for thread safety
			const std::size_t availableSamples = AvailableSamples();
			if (availableSamples >= sampleCount)
			{
				std::vector<std::byte> outputSamples(sampleCount * m_deinterlacer->BaseSampleSize());
				m_ringBuffer->Read(outputSamples);
				m_readCounter += sampleCount;
				return MeasurementData(std::move(outputSamples), m_deinterlacer->Clone());
			}
			else if (errorState)
			{
				const auto state = m_errorState.Get();
				throw CommunicationException(state.first, ToString(state.second));
			}
			if (timer.ElapsedTime() > timeout)
			{
				throw CommunicationException(PTCCommunicationStatusCode_Timeout);
			}
			const std::size_t missingSamples = sampleCount - availableSamples;

			const double secondsToWait = missingSamples / m_deinterlacer->BaseSampleRateHertz();

			std::this_thread::sleep_for(std::chrono::duration<double>(secondsToWait));
		}
	}

	std::size_t MeasurementDataBuffer::AvailableSamples() const
	{
		const auto availableSamples = m_ringBuffer->Size() / m_deinterlacer->BaseSampleSize();
		return m_deinterlacer->BlockSize().has_value()
			? std::min(availableSamples, gsl::narrow_cast<std::size_t>(m_deinterlacer->BlockSize().value()) - m_readCounter)
			: availableSamples;
	}

	void MeasurementDataBuffer::CheckReadOutOfRange(std::size_t sampleCount) const
	{
		if (sampleCount > m_ringBuffer->Capacity() / m_deinterlacer->BaseSampleSize())
		{
			throw CommunicationException(PTCCommunicationStatusCode_RangeError,
				"A sample count larger than the ring buffer capacity is not supported.");
		}
		if (const auto blockSize = m_deinterlacer->BlockSize();
			blockSize.has_value()
			&& m_readCounter + sampleCount > gsl::narrow_cast<std::size_t>(blockSize.value()))
		{
			throw CommunicationException(PTCCommunicationStatusCode_RangeError,
				"The requested sample count is out of range for the configured block size.");
		}
	}

	void MeasurementDataBuffer::Initialize()
	{
		const std::lock_guard lock(m_mutex);
		m_deinterlacer->UpdateConfiguration();
		ResetRingBuffer(m_capacity * m_deinterlacer->BaseSampleSize());
		m_errorState.Clear();
		m_readCounter = 0;
		m_isShuttingDown.store(false, std::memory_order_relaxed);
		m_hasStarted = false;
	}

	void MeasurementDataBuffer::ResetRingBuffer(std::size_t capacity)
	{
		if (m_ringBuffer && m_ringBuffer->Capacity() == capacity)
		{
			m_ringBuffer->Clear();
		}
		else
		{
			m_ringBuffer.reset(); // first deallocate
			m_ringBuffer = std::make_unique<RingBuffer<std::byte>>(m_capacity * m_deinterlacer->BaseSampleSize());
		}
	}

	std::pair<PTCCommunicationStatusCode, std::wstring> MeasurementDataBuffer::ErrorState::Get() const
	{
		const std::lock_guard lock(m_mutex);
		return { m_statucCode, m_errorMessage };
	}

	bool MeasurementDataBuffer::ErrorState::IsErrorState() const
	{
		return m_statucCode != PTCCommunicationStatusCode_Success;
	}

	void MeasurementDataBuffer::ErrorState::Set(PTCCommunicationStatusCode statusCode, std::wstring errorMessage)
	{
		const std::lock_guard lock(m_mutex);
		m_statucCode = statusCode;
		m_errorMessage = std::move(errorMessage);
	}

	void MeasurementDataBuffer::ErrorState::Clear()
	{
		const std::lock_guard lock(m_mutex);
		m_statucCode = PTCCommunicationStatusCode_Success;
		m_errorMessage.clear();
	}
}
