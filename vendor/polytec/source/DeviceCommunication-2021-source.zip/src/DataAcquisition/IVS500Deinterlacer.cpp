// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#include <IO/DataAcquisition/Detail/IVS500Deinterlacer.h>

#include <IO/DeviceCommunication/DeviceCommunication.h>
#include <IO/DeviceCommunication/Utils/CommandList.h>
#include <IO/DeviceCommunication/Utils/ChannelActivation.h>

#include <map>

using namespace Polytec;

namespace
{
	std::unique_ptr<IO::IDeinterlacer> InitializeStaticDeinterlacer(const IO::DeviceCommunication& communication)
	{
		const auto dataFormat = static_cast<IO::ProtocolType>(
			communication.SendGet<int16_t>(PTCDeviceType_SignalProcessing, PTCDeviceCommand_DAQProtocolType));
		switch (dataFormat)
		{
			case IO::ProtocolType::IVS500Hotfix:
			case IO::ProtocolType::IVS500:
				return std::make_unique<IO::StaticDeinterlacer<IO::DataFormatIVS500<IO::ProtocolType::IVS500>>>();
			case IO::ProtocolType::VGO200Pioneer:
				return std::make_unique<IO::StaticDeinterlacer<IO::DataFormatIVS500<IO::ProtocolType::VGO200Pioneer>>>();
			default:
				throw std::runtime_error("Unknown IVS-500 deinterlacer data format " + std::to_string(static_cast<int>(dataFormat)) + ".");
		}
		
	}
}

namespace Polytec::IO
{
	/// <summary>Constructor.</summary>
	/// <param name="communication">The communication.</param>
	IVS500Deinterlacer::IVS500Deinterlacer(DeviceCommunication& communication)
		: m_communication(communication)
		, m_staticDeinterlacer(InitializeStaticDeinterlacer(m_communication))
		, m_devices(m_communication)
		, m_hasChannelActivation(CommandList(m_communication, PTCDeviceType_VelocityDecoderDigital).HasCommand(PTCDeviceCommand_OutputActive))
	{}

	void IVS500Deinterlacer::UpdateConfiguration()
	{
		m_activechannels = Polytec::IO::ActiveChannels(m_communication);
	}

	DataAcquisitionPayloadType IVS500Deinterlacer::PayloadType(const IO::Channel& channel) const
	{
		return m_staticDeinterlacer->PayloadType(channel);
	}

	std::size_t IVS500Deinterlacer::ChannelSampleCount(const IO::Channel& channel, const SourceData& source) const
	{
		return m_staticDeinterlacer->ChannelSampleCount(channel, source);
	}

	std::size_t IVS500Deinterlacer::BaseSampleSize() const
	{
		return m_staticDeinterlacer->BaseSampleSize();
	}

	void IVS500Deinterlacer::CopySamplesForChannel(const IO::Channel& channel, SignalProperty signalProperty,
		const SourceData& source, const DestinationData& destination) const
	{
		if (!IsActiveDecoder(channel))
		{
			throw CommunicationException(PTCCommunicationStatusCode_LogicError, "Channel not active: " + std::to_string(channel.Type()));
		}
		m_staticDeinterlacer->CopySamplesForChannel(channel, signalProperty, source, destination);
	}

	int64_t IVS500Deinterlacer::ChannelMinValue(PTCChannelType channelType) const
	{
		return m_staticDeinterlacer->ChannelMinValue(channelType);
	}

	int64_t IVS500Deinterlacer::ChannelMaxValue(PTCChannelType channelType) const
	{
		return m_staticDeinterlacer->ChannelMaxValue(channelType);
	}

	bool IVS500Deinterlacer::IsActiveDecoder(const Channel& channel) const
	{
		return std::find(std::cbegin(m_activechannels),
			std::cend(m_activechannels), channel) != std::cend(m_activechannels);
	}
}
