// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#include <IO/DataAcquisition/Detail/DataAcquisitionPacketFormat.h>
#include <IO/DataAcquisition/Detail/DataAcquisitionHeader.h>
#include <IO/DeviceCommunication/Detail/DataReader.h>

namespace Polytec::IO
{
	std::size_t DataAcquisitionPacketFormat::GetBodySize(const std::vector<std::byte>& headerData) const
	{
		DataReader reader(headerData);
		return LoadDataAcquisitionPacketLength(reader) - GetBaseHeaderSize();
	}
}
