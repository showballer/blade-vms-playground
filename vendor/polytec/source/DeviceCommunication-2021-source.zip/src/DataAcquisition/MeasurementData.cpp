// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#include <IO/DataAcquisition/MeasurementData.h>

namespace Polytec::IO
{
	MeasurementData::MeasurementData(std::vector<std::byte>&& data, std::unique_ptr<IDeinterlacer> deinterlacer)
		: m_data(std::move(data))
		, m_deinterlacer(std::move(deinterlacer))
	{}

	std::size_t MeasurementData::BaseSampleCount() const
	{
		CheckValid();
		if (m_deinterlacer->BaseSampleSize() == 0
			|| m_data.size() % m_deinterlacer->BaseSampleSize() != 0)
		{
			throw std::logic_error("Measurement data doesn't match to sample format.");
		}
		return m_data.size() / m_deinterlacer->BaseSampleSize();
	}

	std::size_t MeasurementData::SampleCount(const Channel & channel) const
	{
		return m_deinterlacer->ChannelSampleCount(channel, m_data);
	}

	void MeasurementData::CheckValid() const
	{
		if (!m_deinterlacer)
		{
			throw CommunicationException(PTCCommunicationStatusCode_LogicError, "Cannot use empty measurement data.");
		}
	}
}
