// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#include <IO/DataAcquisition/Detail/RealTimePriorityGuard.h>

#include <iostream>
#include <cstring>

using namespace Polytec::IO;

#pragma warning(suppress: 26426) // Global initializer calls a non-constexpr function 'Polytec::IO::RealTimePriorityGuard::GetProcessPriority' (i.22).
const RealTimePriorityGuard::NativePriorityValue RealTimePriorityGuard::s_initialProcessPriority = RealTimePriorityGuard::GetProcessPriority();
std::size_t RealTimePriorityGuard::s_instanceCount = 0;
#pragma warning(suppress: 26426) // Global initializer calls a non-constexpr function 'std::mutex::mutex' (i.22).
std::mutex RealTimePriorityGuard::s_mutex;

RealTimePriorityGuard::RealTimePriorityGuard()
	: m_initialThreadPriority(GetThreadPriority())
{
	std::lock_guard<std::mutex> lock(s_mutex);
	s_instanceCount++;
	SetThreadPriority(RealTimeThreadPriority());
	SetProcessPriority(HighProcessPriority());
}

RealTimePriorityGuard::~RealTimePriorityGuard()
{
#pragma warning(suppress: 26447) // The function is declared 'noexcept' but calls function 'mutex>()' which may throw exceptions (f.6).
	std::lock_guard<std::mutex> lock(s_mutex);
	s_instanceCount--;
#pragma warning(suppress: 26447) // The function is declared 'noexcept' but calls function 'SetThreadPriority()' which may throw exceptions (f.6).
	SetThreadPriority(m_initialThreadPriority);
	if (s_instanceCount == 0)
#pragma warning(suppress: 26447) // The function is declared 'noexcept' but calls function 'SetProcessPriority()' which may throw exceptions (f.6).
		SetProcessPriority(s_initialProcessPriority);
}

#ifdef _WIN32
#include <windows.h>

RealTimePriorityGuard::NativePriorityValue RealTimePriorityGuard::GetProcessPriority()
{
	return ::GetPriorityClass(::GetCurrentProcess());
}

RealTimePriorityGuard::NativePriorityValue RealTimePriorityGuard::GetThreadPriority()
{
	return ::GetThreadPriority(::GetCurrentThread());
}

void RealTimePriorityGuard::SetProcessPriority(NativePriorityValue priority)
{
	::SetPriorityClass(::GetCurrentProcess(), priority);
}

void RealTimePriorityGuard::SetThreadPriority(NativePriorityValue priority)
{
	::SetThreadPriority(::GetCurrentThread(), priority);
}

RealTimePriorityGuard::NativePriorityValue RealTimePriorityGuard::HighProcessPriority()
{
	return HIGH_PRIORITY_CLASS;
}

RealTimePriorityGuard::NativePriorityValue RealTimePriorityGuard::RealTimeThreadPriority()
{
	return THREAD_PRIORITY_TIME_CRITICAL;
}

#elif defined(unix) || defined(__unix) || defined(__unix__)

#include <pthread.h>
#include <sys/resource.h>
#include <sys/syscall.h>
#include <sys/types.h>
#include <unistd.h>
#define gettid() syscall(SYS_gettid) // see: https://stackoverflow.com/questions/30680550/c-gettid-was-not-declared-in-this-scope

RealTimePriorityGuard::NativePriorityValue RealTimePriorityGuard::GetProcessPriority()
{
	return ::getpriority(PRIO_PROCESS, ::getpid());
}

RealTimePriorityGuard::NativePriorityValue RealTimePriorityGuard::GetThreadPriority()
{
	int policy{};
	sched_param param{};
	::pthread_getschedparam(::pthread_self(), &policy, &param);
	return param.sched_priority;
}

void RealTimePriorityGuard::SetProcessPriority(NativePriorityValue priority)
{
	const auto state = ::setpriority(PRIO_PROCESS, ::getpid(), priority);
	if (state != 0)
		std::wcerr << L"Process priority could not be set. " << std::strerror(errno) << std::endl;
}

void RealTimePriorityGuard::SetThreadPriority(NativePriorityValue priority)
{
	const auto state = ::pthread_setschedprio(::pthread_self(), priority);
	if (state != 0)
		std::wcerr << L"Thread priority could not be set. " << std::strerror(errno) << std::endl;
}

RealTimePriorityGuard::NativePriorityValue RealTimePriorityGuard::HighProcessPriority()
{
	return -20;
}

RealTimePriorityGuard::NativePriorityValue RealTimePriorityGuard::RealTimeThreadPriority()
{
	pthread_attr_t threadAttributes{};
	::pthread_attr_init(&threadAttributes);
	int policy{};
	::pthread_attr_getschedpolicy(&threadAttributes, &policy);
	::pthread_attr_destroy(&threadAttributes);
	return ::sched_get_priority_max(policy);
}

#else
#error RealTimePriorityGuard not implemented for this platform.
#endif
