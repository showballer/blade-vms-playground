// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#include <IO/DataAcquisition/Detail/UdpDataAcquisition.h>

#include <IO/DataAcquisition/Detail/RealTimePriorityGuard.h>
#include <IO/DeviceCommunication/CommunicationException.h>
#include <IO/DeviceCommunication/Detail/DataWriter.h>
#include <IO/DeviceCommunication/Detail/StringConverter.h>

#include <iostream>
#include <gsl/gsl_util>

using boost::asio::ip::udp;
using namespace Polytec::IO;

namespace
{
	constexpr std::size_t c_maxUdpPacketSize = 65'507;
}

/// <summary>
/// Constructs an UDP data acquisition instance. The instance will listen to incoming data.
/// </summary>
/// <param name="port">The port to be opened for listening.</param>
/// <param name="receiveBufferSize">Size of the UDP receive buffer of the operating system.</param>
UdpDataAcquisition::UdpDataAcquisition(int port, ReceiveBufferSize receiveBufferSize)
try : m_buffer(c_maxUdpPacketSize)
, m_socket(m_ioService, udp::endpoint(udp::v4(), gsl::narrow_cast<unsigned short>(port)))
{
	const boost::asio::socket_base::receive_buffer_size option(receiveBufferSize.Value);
	m_socket.set_option(option);
	ReceiveAsync();
}
catch (const boost::system::system_error& e)
{
	throw CommunicationException(PTCCommunicationStatusCode_SystemError, e.what());
}

/// <summary>
/// Runs the data acquisition. This function call is blocking until Shutdown is called.
/// </summary>
void UdpDataAcquisition::Run()
{
	RealTimePriorityGuard priorityGuard;
	m_ioService.run();
}

/// <summary>Handles an error that occurs while running the acquisition.</summary>
/// <param name="e">The error to handle.</param>
void UdpDataAcquisition::HandleError(const std::exception& e) const
{
	std::wcout << L"UDP data acuqisition failed: " << e.what() << std::endl;
	throw;
}

void UdpDataAcquisition::ReceiveAsync()
{
	m_buffer.resize(c_maxUdpPacketSize);
	m_socket.async_receive_from(boost::asio::buffer(m_buffer), m_deviceEndpoint,
		[this](boost::system::error_code errorCode, std::size_t bytesReceived)
	{
		HandleReceive(bytesReceived, errorCode);
	});
}

void UdpDataAcquisition::HandleReceive(std::size_t bytesReceived, boost::system::error_code errorCode)
{
	if (errorCode)
	{
		throw boost::system::system_error(errorCode);
	}

	m_buffer.resize(bytesReceived);
	const auto ipAddress = m_deviceEndpoint.address().to_string();
	m_dataAvailableSignal(ToWString(ipAddress), m_buffer);
	ReceiveAsync();
}
