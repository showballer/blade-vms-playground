// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#include <IO/DataAcquisition/Detail/DataAcquisitionListener.h>

#include <IO/DataAcquisition/Detail/DataAcquisitionPacketFormat.h>
#include <IO/DataAcquisition/Detail/TcpDataAcquisition.h>
#include <IO/DataAcquisition/Detail/UdpDataAcquisition.h>
#include <IO/DataAcquisition/MeasurementData.h>

#include <IO/DataAcquisition/Detail/DataAcquisitionHeader.h>

using namespace Polytec::IO;

/// <summary>
/// Gets an UDP data acquisition listener. The listener may be a shared object listen to data
/// from several devices.
/// </summary>
/// <returns>The UDP listener.</returns>
std::shared_ptr<DataAcquisitionListener> Polytec::IO::GetUdpListener()
{
	static std::mutex mutex;
	static std::weak_ptr<DataAcquisitionListener> g_listener;

	std::lock_guard<std::mutex> lock(mutex);
	std::shared_ptr<DataAcquisitionListener> udpListener = g_listener.lock();
	if (!udpListener)
	{
		auto client = std::make_unique<UdpDataAcquisition>(60'113);
		udpListener = std::make_shared<DataAcquisitionListener>(std::move(client));
		g_listener = udpListener;
	}
	return udpListener;
}

/// <summary>
/// Gets an TCP data acquisition listener.
/// </summary>
/// <returns>The TCP listener.</returns>
std::unique_ptr<DataAcquisitionListener> Polytec::IO::GetTcpListener(const std::wstring& address)
{
	auto client = std::make_unique<TcpDataAcquisition>(address, std::make_unique<DataAcquisitionPacketFormat>());
	return std::make_unique<DataAcquisitionListener>(std::move(client));
}

/// <summary>Constructor.</summary>
/// <param name="client">The data acquisition client, e.g. an UDP or a TCP client.</param>
DataAcquisitionListener::DataAcquisitionListener(std::unique_ptr<IDataAcquisitionClient> client)
	: m_client(std::move(client))
	, m_clientThread(*m_client)
{
	if (m_client == nullptr)
	{
		throw std::invalid_argument("Invalid data acquisition client.");
	}
	m_client->ConnectOnDataAvailable([this](const std::wstring& ipAddress, const gsl::span<const std::byte>& data)
	{
		Write(ipAddress, data);
	});
	m_clientThread.Start();
}

#pragma warning(push)
#pragma warning(disable: 26447) // The function is declared 'noexcept' but calls function '...' which may throw exceptions (f.6).)
/// <summary>Destructor must be out-of-line if std::unique_ptr<> members exist, see http://herbsutter.com/gotw/_100/</summary>
DataAcquisitionListener::~DataAcquisitionListener() noexcept
{
	for (auto& it : m_buffers)
	{
		it.second.Shutdown();
	}
}
#pragma warning(pop)

/// <summary>Opens a ring buffer for data from the given IP address.</summary>
/// <exception cref="CommunicationException">Thrown if the buffer is already open.</exception>
/// <param name="ipAddress">The IP address or hostname.</param>
/// <param name="capacity">The capacity of the buffer.</param>
/// <param name="deinterlacer">The deinterlacer.</param>
void DataAcquisitionListener::Open(const std::wstring& ipAddress, std::size_t capacity, std::unique_ptr<IDeinterlacer> deinterlacer)
{
	if (ipAddress.empty())
	{
		throw CommunicationException(PTCCommunicationStatusCode_InvalidArgument);
	}
	else if (m_buffers.count(ipAddress) == 0)
	{
		std::lock_guard<std::mutex> lock(m_bufferMutex);
		m_buffers.try_emplace(ipAddress, capacity, std::move(deinterlacer));
	}
	else
	{
		throw CommunicationException(PTCCommunicationStatusCode_LogicError, "Listener for this IP address already opened.");
	}
}

/// <summary>Clears the ring buffer.</summary>
/// <param name="ipAddress">The IP address.</param>
void DataAcquisitionListener::ClearBuffer(const std::wstring& ipAddress)
{
	m_buffers.at(ipAddress).Reset();
}

/// <summary>Next acquisition block.</summary>
/// <param name="ipAddress">The IP address.</param>
void DataAcquisitionListener::NextBlock(const std::wstring& ipAddress)
{
	m_buffers.at(ipAddress).NextBlock();
}

void DataAcquisitionListener::ShutdownBuffer(const std::wstring& ipAddress)
{
	m_buffers.at(ipAddress).Shutdown();
}

#pragma warning(push)
#pragma warning(disable: 26447) // The function is declared 'noexcept' but calls function '...' which may throw exceptions (f.6).)
/// <summary>
/// Stops listening to the given IP address. Further incoming data will be discarded.
/// </summary>
/// <param name="ipAddress">The IP address.</param>
void DataAcquisitionListener::Close(const std::wstring& ipAddress) noexcept
{
	if (m_buffers.find(ipAddress) != m_buffers.cend())
	{
		m_buffers.at(ipAddress).Shutdown();
		EraseBuffer(ipAddress);
	}
}
#pragma warning(pop)

/// <summary>
/// Writes the incoming data from the given IP address to the corresponding buffer. If the buffer
/// is not open, the data is discarded.
/// </summary>
/// <param name="ipAddress">The IP address.</param>
/// <param name="data">The binary data.</param>
void DataAcquisitionListener::Write(const std::wstring& ipAddress, const gsl::span<const std::byte> & data)
{
	std::lock_guard<std::mutex> lock(m_bufferMutex);

	if (!m_buffers.count(ipAddress))
	{
		return;
	}

	m_buffers.at(ipAddress).Write(data);
}

/// <summary>
/// Reads available data from the ring buffer. This function is not blocking.
/// If the requested maximum number of samples is not available, only the currently
/// available data is read from the ring buffer.
/// </summary>
/// <param name="ipAddress">The IP address.</param>
/// <param name="maxSampleCount">The maximum number of samples to read.</param>
/// <returns>The available data.</returns>
MeasurementData DataAcquisitionListener::ReadAvailableData(
	const std::wstring& ipAddress, std::size_t maxSampleCount)
{
	return m_buffers.at(ipAddress).ReadAvailableData(maxSampleCount);
}

/// <summary>
/// Reads data from the ring buffer. This function is blocking until the requested data is
/// available or the timeout is expired. If the given timeout is expired, an exception is thrown.
/// </summary>
/// <param name="ipAddress">The IP address.</param>
/// <param name="sampleCount">The number of samples to read.</param>
/// <param name="timeout">The timeout.</param>
/// <returns>The data.</returns>
MeasurementData DataAcquisitionListener::ReadData(const std::wstring& ipAddress,
	std::size_t sampleCount, const std::chrono::duration<double>& timeout)
{
	return m_buffers.at(ipAddress).ReadData(sampleCount, timeout);
}

/// <summary>
/// Evaluates the size of the ring buffer corresponding to the given IP address. The size is the
/// number of samples which are readable. The maximum size is the capacity of the buffer.
/// </summary>
/// <param name="ipAddress">The IP address.</param>
/// <returns>The size of the ring buffer.</returns>
std::size_t DataAcquisitionListener::Size(const std::wstring& ipAddress) const
{
	return m_buffers.at(ipAddress).AvailableSamples();
}

void DataAcquisitionListener::EraseBuffer(const std::wstring& ipAddress)
{
	std::lock_guard<std::mutex> lock(m_bufferMutex);
	m_buffers.erase(ipAddress);
}
