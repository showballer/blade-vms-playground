// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#include <IO/DeviceCommunication/Detail/CommunicationImplementation.h>

#include <IO/DeviceCommunication/CommunicationException.h>
#include <IO/DeviceCommunication/Detail/CommandType.h>
#include <IO/DeviceCommunication/Detail/DataReader.h>
#include <IO/DeviceCommunication/Detail/DataWriter.h>
#include <IO/DeviceCommunication/Detail/MsgResponse.h>
#include <IO/DeviceCommunication/Detail/MsgRequest.h>
#include <IO/DeviceCommunication/Detail/MsgHeader.h>
#include <IO/DeviceCommunication/Detail/PayloadType.h>
#include <IO/DeviceCommunication/Detail/StringConverter.h>
#include <IO/DeviceCommunication/Device.h>
#include <IO/DeviceCommunication/PTCDeviceCommand.h>
#include <IO/DeviceCommunication/PTCMiscellaneousTag.h>
#include <IO/DeviceCommunication/PTCCommunicationStatusCode.h>

#include <gsl/gsl>
#include <gsl/span_ext>
#include <optional>
#include <sstream>

using namespace Polytec::IO;

namespace
{
	using namespace std::chrono;

	class Timer
	{
		const time_point<steady_clock> m_start = steady_clock::now();
	public:
		milliseconds ElapsedTime()
		{
			const auto now = steady_clock::now();
			return duration_cast<milliseconds>(now - m_start);
		}
	};

	void CheckNoErrorCode(const MsgResponse& packet, PTCDeviceCommand deviceCommand)
	{
		if (IsError(packet))
		{
			std::string info = "Device command: " + std::to_string(deviceCommand);
			throw CommunicationException(GetStatusCode(packet), info);
		}
	}

	std::wstring GetStringPayload(const gsl::span<const std::byte>& commandData)
	{
		DataReader reader(commandData);
		std::wstring payload;
		reader.Read(payload);
		return payload;
	}

	void CheckAcknowledged(PayloadType payloadType, const gsl::span<const std::byte>& payloadData, PTCDeviceCommand deviceCommand)
	{
		if (!IsStringPayloadType(payloadType) || GetStringPayload(payloadData) != L"*")
		{
			const std::wstring info = L"Has not received expected acknowledge. Device command: " + std::to_wstring(deviceCommand)
				+ L". Payload: \"" + FormatBinaryData(payloadData) + L"\".";
			throw CommunicationException(PTCCommunicationStatusCode_InvalidResponseFormat, ToString(info));
		}
	}

	std::vector<std::byte> ConvertRequestLatin1FromUTF8(const std::vector<std::byte>& data)
	{
		try
		{
			return Latin1FromUTF8(data);
		}
		catch (const std::exception& e)
		{
			throw CommunicationException(PTCCommunicationStatusCode_InvalidArgument, e.what());
		}
	}

	std::vector<std::byte> ConvertResponseUTF8FromLatin1(const std::vector<std::byte>& data)
	{
		try
		{
			return UTF8FromLatin1(data);
		}
		catch (const std::exception& e)
		{
			throw CommunicationException(PTCCommunicationStatusCode_InvalidResponseFormat, e.what());
		}
	}

	template <typename TException, typename TFunction>
	decltype(auto) TryAsLongAs(const TFunction& function, const std::function<bool(const TException&)>& retryCondition)
	{
		while (true)
		{
			try
			{
				return function();
			}
			catch (const TException& e)
			{
				if (retryCondition(e))
				{
					continue;
				}
				else
				{
					throw;
				}
			}
		}
	}
}

namespace Polytec::IO
{
	/// <summary>
	/// Helper method to create binary data dump as string.
	/// </summary>
	/// <param name="commandData">The binary data.</param>
	/// <returns>The binary data formatted as string.</returns>
	std::wstring FormatBinaryData(const gsl::span<const std::byte>& commandData)
	{
		std::wstringstream stream;
		constexpr std::ptrdiff_t c_max = 1'000;
		for (std::size_t idx = 0; idx < std::size(commandData); idx++)
		{
			if (idx > c_max)
			{
				stream << L"...";
				break;
			}
			stream << L"0x" << std::hex << static_cast<int>(commandData[idx]) << L" ";
		}
		return stream.str();
	}

	/// <summary>
	/// Constructs a communication implementation instance with the given timeout. The timeout will
	/// be applied when sending commands to the device.
	/// </summary>
	/// <param name="timeout">The timeout.</param>
	/// <param name="communication">[in,out] The communication, e.g. serial or UDP.</param>
	CommunicationImplementation::CommunicationImplementation(std::chrono::duration<float> timeout, std::unique_ptr<ICommunication>&& communication)
		: m_communication(std::move(communication))
	{
		SetTimeout(timeout);
		CheckCommunication();
	}

	/// <summary>Checks if there is a device which responds to commands.</summary>
	/// <exception cref="CommunicationException">Thrown when the device has sent no name.</exception>
	void CommunicationImplementation::CheckCommunication()
	{
		const auto [payloadType, commandData] = SendGet(CommandType::Get, Device(PTCDeviceType_Controller), PTCDeviceCommand_Name,
			PTCMiscellaneousTag_None, c_payloadType<void>, {});
		if (!IsStringPayloadType(payloadType) || std::empty(commandData))
		{
			throw CommunicationException(PTCCommunicationStatusCode_InvalidResponseFormat, "Received not a controller name by communication checking.");
		}
	}

	/// <summary>
	/// Sets a timeout. The timeout will be applied when commands are send to the device.
	/// </summary>
	/// <param name="timeout">The timeout.</param>
	void CommunicationImplementation::SetTimeout(std::chrono::duration<float> timeout)
	{
		m_communication->SetTimeout(timeout);
	}

	/// <summary>Gets the timeout.</summary>
	/// <returns>The timeout.</returns>
	std::chrono::duration<float> CommunicationImplementation::GetTimeout() const
	{
		return m_communication->GetTimeout();
	}

	/// <summary>
	/// Enables retries for subsequent commands. Requests may not receive an reply within the given
	/// timeout. If retries are enabled, the request are retried.
	/// </summary>
	/// <param name="countOfRetries">The count of retries. E.g. 1 for one retry (resulting in overall
	/// 2 attempts until a timeout exception may happen).</param>
	void CommunicationImplementation::EnableRetries(int countOfRetries)
	{
		if (countOfRetries < 0)
		{
			throw std::invalid_argument("Count of communication retries must not be negative.");
		}
		m_countOfRetries = countOfRetries;
	}

	/// <summary>
	/// Sends a Get-command to the device and receives a response.
	/// </summary>
	/// <param name="commandType">The command type, e.g. Get, GetDevInfo, GetValueList.</param>
	/// <param name="device">The device, e.g. Controller.</param>
	/// <param name="deviceCommand">The device command, e.g. PTCDeviceCommand_Name.</param>
	/// <param name="tag">The miscellaneous tag (only needed for some commands).</param>
	/// <param name="requestType">[out] The payload type of the request input parameters.</param>
	/// <param name="requestData">[out] The payload data of the request input parameters.</param>
	/// <returns>The response payload.</returns>
	auto CommunicationImplementation::SendGet(CommandType commandType, const Device& device,
		PTCDeviceCommand deviceCommand, PTCMiscellaneousTag tag,
		PayloadType requestType, const std::vector<std::byte>& requestData) -> ResponsePayload
	{
		std::lock_guard<std::mutex> lock(m_mutex);
		return TryAsLongAs<IO::CommunicationException>([this, commandType, &device, deviceCommand, tag, requestType, &requestData]
		{
			return DoSend(commandType, device, deviceCommand, tag, requestType, requestData);
		},
			[this, retryCount = 0](const IO::CommunicationException& e) mutable
		{
			return e.GetStatusCode() == PTCCommunicationStatusCode_Timeout && retryCount++ < m_countOfRetries;
		});
	}

	/// <summary>Sends a Set-command and checks if the device sends an acknowledge.</summary>
	/// <param name="commandType">The command type, e.g. Set.</param>
	/// <param name="device">The device, e.g. Controller.</param>
	/// <param name="deviceCommand">The device command, e.g. PTCDeviceCommand_Name.</param>
	/// <param name="tag">The miscellaneous tag (only needed for some commands).</param>
	/// <param name="payloadType">The payload type of the sent payload data.</param>
	/// <param name="commandData">The payload data to be sent.</param>
	void CommunicationImplementation::SendSet(CommandType commandType, const Device& device,
		PTCDeviceCommand deviceCommand, PTCMiscellaneousTag tag,
		PayloadType payloadType, const std::vector<std::byte>& commandData)
	{
		std::lock_guard<std::mutex> lock(m_mutex);
		TryAsLongAs<IO::CommunicationException>([this, commandType, &device, deviceCommand, tag, &payloadType, &commandData]
		{
			const auto [responseType, responseData] = DoSend(commandType, device, deviceCommand, tag, payloadType, commandData);
			CheckAcknowledged(responseType, responseData, deviceCommand);
		},
			[this, retryCount = 0](const IO::CommunicationException& e) mutable
		{
			return e.GetStatusCode() == PTCCommunicationStatusCode_Timeout && retryCount++ < m_countOfRetries;
		});
	}

	/// <summary>Sends a message data packet to the device.</summary>
	/// <param name="packet">[in] The packet to be sent.</param>
	/// <returns>The message response.</returns>
	MsgResponse CommunicationImplementation::SendMsgDataPacket(MsgRequest&& packet)
	{
		std::lock_guard<std::mutex> lock(m_mutex);
		const int cmdNumber = DoSendMsgDataPacket(std::move(packet));
		return DoReceiveMsgDataPacket(cmdNumber);
	}

	auto CommunicationImplementation::DoSend(CommandType commandType,
		const Device& device, PTCDeviceCommand deviceCommand, PTCMiscellaneousTag tag,
		PayloadType requestType, const std::vector<std::byte>& requestData) -> ResponsePayload
	{
		MsgRequest packet;
		packet.SetDeviceCommand(deviceCommand);
		packet.SetDeviceType(device.Type());
		packet.SetDeviceNumber(device.Number());
		packet.SetCommandType(commandType);
		packet.SetMiscellaneousTag(tag);
		packet.SetPayloadType(requestType);
		packet.SetCommandData(requestData);
		const int commandNumber = DoSendMsgDataPacket(std::move(packet));

		MsgResponse response = DoReceiveMsgDataPacketWithErrorInfo(commandNumber, deviceCommand);
		CheckNoErrorCode(response, deviceCommand);
		m_supportsUTF8 |= (PayloadType::UTF8 == response.GetPayloadType());
		ConvertResponseStringEncoding(response);

		return { response.GetPayloadType(), response.GetCommandData() };
	}

	int CommunicationImplementation::DoSendMsgDataPacket(MsgRequest&& packet)
	{
		packet.SetCommandNumber(m_cmdNumber);
		packet.SetResponsePort(m_communication->ResponsePort());
		ConvertRequestStringEncoding(packet);

		const auto data = m_packetBuilder.Build(packet);
		m_communication->SendData(data);
		return m_cmdNumber++;
	}

	MsgResponse CommunicationImplementation::DoReceiveMsgDataPacketWithErrorInfo(int commandNumber, PTCDeviceCommand deviceCommand)
	{
		try
		{
			return DoReceiveMsgDataPacket(commandNumber);
		}
		catch (const CommunicationException& e)
		{
			throw CommunicationException(e.GetStatusCode(), e.AdditionalInformation() + " - Device Command: " + std::to_string(static_cast<int>(deviceCommand)));
		}
	}

	/// <summary>Receives a message data packet from the device of the given command number.</summary>
	/// <remarks>When other responses received first, they will be stored in a buffer.</remarks>
	/// <exception cref="CommunicationException">A communication exception will be thrown if the
	/// response from the device will not be received within the timeout.</exception>
	/// <param name="cmdNumber">The command number.</param>
	/// <returns>The received message data packet.</returns>
	MsgResponse CommunicationImplementation::DoReceiveMsgDataPacket(int cmdNumber)
	{
		Timer timer;
		while (true)
		{
			if (m_responseBuffer.Contains(cmdNumber))
			{
				return m_responseBuffer.Extract(cmdNumber);
			}
			else if (timer.ElapsedTime() <= m_communication->GetTimeout())
			{
				CollectDataPacket();
			}
			else
			{
				throw CommunicationException(PTCCommunicationStatusCode_Timeout, "Collecting the response packet has been timed out.");
			}
		}
	}

	/// <summary>Collects a message data packet and stores it in the data packet buffer.</summary>
	void CommunicationImplementation::CollectDataPacket()
	{
		const auto messageData = m_communication->ReceiveData();
		if (messageData.empty())
		{
			throw CommunicationException(PTCCommunicationStatusCode_Timeout);
		}
		DataReader reader(messageData);
		MsgHeader header;
		MsgResponse packet;
		header.Load(reader);
		packet.Load(reader, header.GetMsgType());
		m_responseBuffer.Add(packet);
	}

	void CommunicationImplementation::ConvertRequestStringEncoding(MsgRequest& request) const
	{
		if (request.GetPayloadType() == PayloadType::UTF8 && !m_supportsUTF8)
		{
			const auto iso8859_1 = ConvertRequestLatin1FromUTF8(request.GetCommandData());
			request.SetCommandData(iso8859_1);
			request.SetPayloadType(PayloadType::Ascii);
		}
	}

	void CommunicationImplementation::ConvertResponseStringEncoding(MsgResponse& response) const
	{
		if (response.GetPayloadType() == PayloadType::Ascii)
		{
			const auto utf8 = ConvertResponseUTF8FromLatin1(response.GetCommandData());
			response.SetCommandData(utf8);
			response.SetPayloadType(PayloadType::UTF8);
		}
	}
}
