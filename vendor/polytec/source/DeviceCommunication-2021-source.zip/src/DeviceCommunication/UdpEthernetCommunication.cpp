// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#include <IO/DeviceCommunication/Detail/UdpEthernetCommunication.h>

#include <IO/DeviceCommunication/CommunicationException.h>
#include <IO/DeviceCommunication/Detail/NetworkUtils.h>
#include <IO/DeviceCommunication/Detail/StringConverter.h>
#include <IO/DeviceCommunication/PTCCommunicationStatusCode.h>

using boost::asio::ip::udp;
using namespace Polytec::IO;

namespace
{
	constexpr int c_portDevice = 60'100;
	constexpr std::size_t c_bufferSize = 65'000;
}

/// <summary>Constructs an instance for UDP ethernet communication.</summary>
/// <param name="hostname">The hostname or IP address of the device.</param>
UdpEthernetCommunication::UdpEthernetCommunication(const std::wstring& hostname)
	: m_buffer(c_bufferSize)
	, m_socket(CreateSocket<udp>(m_ioService))
	, m_deviceEndpoint(ResolveHostname<udp>(m_ioService, ToString(hostname), c_portDevice))
	, m_deadlineTimer(m_ioService, [this] { m_socket.cancel(); })
{}

/// <summary>Receiving data from socket.</summary>
/// <returns>The received binary data.</returns>
std::vector<std::byte> UdpEthernetCommunication::ReceiveData()
{
	try
	{
		return TryReceiveData();
	}
	catch (const boost::system::system_error& e)
	{
		throw CommunicationException(PTCCommunicationStatusCode_SystemError,
			std::string("Failed to receive data: ") + e.what());
	}
}

/// <summary>Sends data to the device over the socket.</summary>
/// <exception cref="CommunicationException">Thrown when a Communication error condition occurs.</exception>
/// <param name="data">The send binary data.</param>
void UdpEthernetCommunication::SendData(const std::vector<std::byte>& data)
{
	try
	{
		m_socket.send_to(boost::asio::buffer(data), m_deviceEndpoint);
	}
	catch (const boost::system::system_error& e)
	{
		throw CommunicationException(PTCCommunicationStatusCode_SystemError,
			"Failed to send data: " + std::string(e.what()));
	}
}

/// <summary>Gets the response port where responses will be received.</summary>
/// <returns>The response port.</returns>
int UdpEthernetCommunication::ResponsePort() const
{
	return m_socket.local_endpoint().port();
}

/// <summary>Gets the device IP address.</summary>
/// <returns>The IP address as string.</returns>
std::wstring UdpEthernetCommunication::DeviceIPAddress() const
{
	return ToWString(m_senderEndpoint.address().to_string());
}

std::vector<std::byte> UdpEthernetCommunication::TryReceiveData()
{
	m_buffer.resize(c_bufferSize);
	const auto length = m_deadlineTimer.ReadUntilDeadLine(m_timeout, [this](const auto& readHandler)
	{
		m_socket.async_receive_from(boost::asio::buffer(m_buffer), m_senderEndpoint, readHandler);
	});
	m_buffer.resize(length);
	return m_buffer;
}
