// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#include <IO/DeviceCommunication/Detail/MsgRequest.h>

#include <IO/DeviceCommunication/CommunicationException.h>
#include <IO/DeviceCommunication/Detail/CommandType.h>
#include <IO/DeviceCommunication/Detail/DataReader.h>
#include <IO/DeviceCommunication/Detail/DataWriter.h>
#include <IO/DeviceCommunication/Detail/MsgType.h>
#include <IO/DeviceCommunication/Device.h>
#include <IO/DeviceCommunication/PTCDeviceCommand.h>
#include <IO/DeviceCommunication/PTCDeviceType.h>

#include <gsl/gsl_util>

using namespace Polytec::IO;

/// <summary>Loads the message data packet from the binary data reader.</summary>
/// <exception cref="std::logic_error">Raised when a logic error condition occurs.</exception>
/// <param name="reader">[in,out] The reader from which the message data packet will be read.</param>
/// <param name="msgType">The message type.</param>
void MsgRequest::Load(DataReader& reader, MsgType msgType)
{
	const auto payloadSize = ReadPayloadSize(reader, msgType);

	reader.Read(m_commandNumber);
	reader.Read(m_responsePort);
	reader.Read(m_commandType);
	reader.Read(m_deviceType);
	reader.Read(m_deviceNumber);
	reader.Read(m_deviceCommand);
	reader.Read(m_miscellaneousTag);
	reader.Read(m_payloadType);

	m_commandData = reader.ExtractData(payloadSize);
}

/// <summary>Saves this message data packet to the binary data.</summary>
/// <param name="writer">[in,out] The binary data writer that will save the message data packet.</param>
/// <param name="msgType">The type of message data packet.</param>
void MsgRequest::Save(DataWriter& writer, MsgType msgType) const
{
	WritePacketLength(writer, msgType, std::size(m_commandData));

	writer.Write(m_commandNumber);
	writer.Write(m_responsePort);
	writer.Write(m_commandType);
	writer.Write(m_deviceType);
	writer.Write(m_deviceNumber);
	writer.Write(m_deviceCommand);
	writer.Write(m_miscellaneousTag);
	writer.Write(m_payloadType);
	writer.Write(m_commandData);
}

/// <summary>
/// Sets the command number. When a command is sent to a device with a command number, the
/// response from the device will have the same number.
/// </summary>
/// <param name="value">The command number.</param>
void MsgRequest::SetCommandNumber(int value)
{
	m_commandNumber = gsl::narrow_cast<uint16_t>(value);
}

/// <summary>
/// Sets the response port for an Ethernet communication. The command response will be send to this port.
/// </summary>
/// <param name="value">The response port.</param>
void MsgRequest::SetResponsePort(int value)
{
	m_responsePort = gsl::narrow_cast<uint16_t>(value);
}

/// <summary>Sets the command type, e.g. Get, GetDevInfo, GetValueList, Set.</summary>
/// <param name="value">The command type.</param>
void MsgRequest::SetCommandType(CommandType value)
{
	m_commandType = static_cast<uint8_t>(value);
}

/// <summary>Sets the device type and device number.</summary>
/// <param name="device">The device.</param>
void MsgRequest::SetDevice(const Device device)
{
	SetDeviceType(device.Type());
	SetDeviceNumber(device.Number());
}

/// <summary>
/// Sets the device type to which the device command belongs, e.g. controller, sensor head.
/// </summary>
/// <param name="value">The device type.</param>
void MsgRequest::SetDeviceType(PTCDeviceType value)
{
	m_deviceType = static_cast<uint8_t>(value);
}

/// <summary>Sets the device number, e.g. 0 if only one device of this type exists.</summary>
/// <param name="value">The device number.</param>
void MsgRequest::SetDeviceNumber(int value)
{
	m_deviceNumber = gsl::narrow_cast<uint8_t>(value);
}

/// <summary>Sets the device command, e.g. PTCDeviceCommand_Name.</summary>
/// <param name="value">The device command.</param>
void MsgRequest::SetDeviceCommand(PTCDeviceCommand value)
{
	m_deviceCommand = static_cast<uint16_t>(value);
}

/// <summary>
/// Sets the miscellaneous tag, e.g. PTCMiscellaneousTag_None (only some commands need a
/// miscellaneous tag).
/// </summary>
/// <param name="value">The miscellaneous tag.</param>
void MsgRequest::SetMiscellaneousTag(PTCMiscellaneousTag value)
{
	m_miscellaneousTag = static_cast<uint16_t>(value);
}

/// <summary>Sets the payload type of the command data, e.g. PayloadType::Int16.</summary>
/// <param name="value">The payload type.</param>
void MsgRequest::SetPayloadType(PayloadType value)
{
	m_payloadType = static_cast<uint8_t>(value);
}

/// <summary>Sets the command data.</summary>
/// <param name="value">The command data.</param>
void MsgRequest::SetCommandData(const std::vector<std::byte>& value)
{
	m_commandData = value;
}

/// <summary>
/// Gets the command number. When a command is sent to a device with a command number, the
/// response from the device will have the same number.
/// </summary>
/// <returns>The command number.</returns>
int MsgRequest::GetCommandNumber() const
{
	return m_commandNumber;
}

/// <summary>
/// Gets the response port for an Ethernet communication. The command response will be send to
/// this port.
/// </summary>
/// <returns>The response port.</returns>
int MsgRequest::GetResponsePort() const
{
	return m_responsePort;
}

/// <summary>Gets the command type, e.g. Get, GetDevInfo, GetValueList, Set.</summary>
/// <returns>The command type.</returns>
CommandType MsgRequest::GetCommandType() const
{
	return static_cast<CommandType>(m_commandType);
}

/// <summary>
/// Gets the device with type and number to which the device command belongs, e.g. controller,
/// sensor head.
/// </summary>
/// <returns>The device.</returns>
Device MsgRequest::GetDevice() const
{
	return Device(static_cast<PTCDeviceType>(m_deviceType), m_deviceNumber);
}

/// <summary>
/// Gets the device type to which the device command belongs, e.g. controller, sensor head.
/// </summary>
/// <returns>The device type.</returns>
PTCDeviceType MsgRequest::GetDeviceType() const
{
	return static_cast<PTCDeviceType>(m_deviceType);
}

/// <summary>Gets the device number, e.g. 0 if only one device of this type exists.</summary>
/// <returns>The device number.</returns>
int MsgRequest::GetDeviceNumber() const
{
	return m_deviceNumber;
}

/// <summary>Gets the device command, e.g. PTCDeviceCommand_Name.</summary>
/// <returns>The device command.</returns>
PTCDeviceCommand MsgRequest::GetDeviceCommand() const
{
	return static_cast<PTCDeviceCommand>(m_deviceCommand);
}

/// <summary>
/// Gets the miscellaneous tag, e.g. PTCMiscellaneousTag_None (only some commands need a
/// miscellaneous tag).
/// </summary>
/// <returns>The miscellaneous tag.</returns>
PTCMiscellaneousTag MsgRequest::GetMiscellaneousTag() const
{
	return static_cast<PTCMiscellaneousTag>(m_miscellaneousTag);
}

/// <summary>Gets the payload type of the command data, e.g. PayloadType::Int16.</summary>
/// <returns>The payload type.</returns>
PayloadType MsgRequest::GetPayloadType() const
{
	return static_cast<PayloadType>(m_payloadType);
}

/// <summary>Gets the command data.</summary>
/// <returns>The command data.</returns>
const std::vector<std::byte>& MsgRequest::GetCommandData() const
{
	return m_commandData;
}
