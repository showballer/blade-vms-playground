// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#include <IO/DeviceCommunication/Detail/MsgResponse.h>

#include <IO/DeviceCommunication/CommunicationException.h>
#include <IO/DeviceCommunication/Detail/DataReader.h>
#include <IO/DeviceCommunication/Detail/DataWriter.h>
#include <IO/DeviceCommunication/Detail/MsgType.h>
#include <IO/DeviceCommunication/PTCCommunicationStatusCode.h>

#include <sstream>

using namespace Polytec::IO;

/// <summary>Gets a message data packet for the response: Acknowledged.</summary>
/// <returns>The acknowledged message data packet.</returns>
MsgResponse MsgResponse::Acknowledged()
{
	return FromPayload<std::string>("*");
}

/// <summary>Gets a message data packet for an error message.</summary>
/// <param name="errorCode">The error code.</param>
/// <returns>The error message data packet.</returns>
MsgResponse MsgResponse::Error(PTCCommunicationStatusCode errorCode)
{
	return FromPayload<std::string>("# " + std::to_string(errorCode));
}

/// <summary>Loads the message data packet from the binary data reader.</summary>
/// <exception cref="CommunicationException">A communication exception is thrown when the read
/// packet length does not fit to the actual size of the data.</exception>
/// <param name="reader">[in,out] The reader from which the message data packet will be read.</param>
/// <param name="msgType">The message type.</param>
void MsgResponse::Load(DataReader& reader, MsgType msgType)
{
	const auto payloadSize = ReadPayloadSize(reader, msgType);

	reader.Read(m_commandNumber);
	reader.Read(m_payloadType);
	if (reader.BytesAvailable() != payloadSize)
	{
		throw CommunicationException(PTCCommunicationStatusCode_InvalidResponseFormat, "Response has not the expected payload size.");
	}
	m_commandData = reader.ExtractData(payloadSize);
}

/// <summary>Saves this message data packet to the binary data.</summary>
/// <param name="writer">[in,out] The binary data writer that will save the binary data.</param>
/// <param name="msgType">The type of message data packet.</param>
void MsgResponse::Save(DataWriter& writer, MsgType msgType) const
{
	WritePacketLength(writer, msgType, std::size(m_commandData));

	writer.Write(m_commandNumber);
	writer.Write(m_payloadType);
	writer.Write(m_commandData);
}

/// <summary>
/// Sets the command number. When a command is sent to a device with a command number, the
/// response from the device will have the same number.
/// </summary>
/// <param name="value">The command number.</param>
void MsgResponse::SetCommandNumber(int value)
{
	m_commandNumber = gsl::narrow_cast<uint16_t>(value);
}

/// <summary>Sets the payload type of the command data.</summary>
/// <param name="value">The payload type.</param>
void MsgResponse::SetPayloadType(PayloadType value)
{
	m_payloadType = static_cast<uint8_t>(value);
}

/// <summary>Sets the binary command data.</summary>
/// <param name="value">The command data.</param>
void MsgResponse::SetCommandData(const std::vector<std::byte>& value)
{
	m_commandData = value;
}

/// <summary>
/// Gets the command number. When a command is sent to a device with a command number, the
/// response from the device will have the same number.
/// </summary>
/// <returns>The command number.</returns>
int MsgResponse::GetCommandNumber() const
{
	return m_commandNumber;
}

/// <summary>Gets the payload type of the command data.</summary>
/// <returns>The payload type.</returns>
PayloadType MsgResponse::GetPayloadType() const
{
	return static_cast<PayloadType>(m_payloadType);
}

/// <summary>Gets the binary command data.</summary>
/// <returns>The command data.</returns>
const std::vector<std::byte>& MsgResponse::GetCommandData() const
{
	return m_commandData;
}

/// <summary>Determines if the payload type corresponds to a string.</summary>
/// <param name="type">The payload type.</param>
/// <returns>Returns true if the payload type correponds to a string.</returns>
#pragma warning(suppress: 26497) // The function 'Polytec::IO::IsStringPayloadType' could be marked constexpr if compile-time evaluation is desired (f.4).
bool Polytec::IO::IsStringPayloadType(PayloadType type)
{
	return type == PayloadType::Ascii || type == PayloadType::UTF8;
}

/// <summary>Determines if the response packet is an error packet.</summary>
/// <param name="response">The response packet.</param>
/// <returns>True if it is an error packet.</returns>
bool Polytec::IO::IsError(const MsgResponse& response)
{
	if (!IsStringPayloadType(response.GetPayloadType()))
	{
		return false;
	}
	DataReader reader(response.GetCommandData());
	std::string cmd;
	reader.Read(cmd);
	return !cmd.empty() && cmd.front() == '#';
}

/// <summary>Gets the status code of a response packet.</summary>
/// <param name="response">The response packet.</param>
/// <returns>It returns the error code if the response packet is an error packet and else it returns success.</returns>
PTCCommunicationStatusCode Polytec::IO::GetStatusCode(const MsgResponse& response)
{
	if (!IsStringPayloadType(response.GetPayloadType()))
	{
		return PTCCommunicationStatusCode_Success;
	}
	DataReader reader(response.GetCommandData());
	std::string cmd;
	reader.Read(cmd);
	if (cmd.empty() || cmd.front() != '#')
	{
		return PTCCommunicationStatusCode_Success;
	}
	std::stringstream stream(cmd);
	char hashSign;
	int errorCode;
	stream >> hashSign;
	stream >> errorCode;
	return stream
		? static_cast<PTCCommunicationStatusCode>(errorCode)
		: PTCCommunicationStatusCode_InvalidResponseFormat;
}
