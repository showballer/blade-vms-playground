// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#include <IO/DeviceCommunication/Detail/MsgResponseBuffer.h>

#include <IO/DeviceCommunication/Detail/MsgResponse.h>

#include <algorithm>
#include <stdexcept>

namespace
{
	std::size_t CircularUInt16Distance(int lhs, int rhs)
	{
		constexpr int max = std::numeric_limits<uint16_t>::max();
		const auto distance0 = std::abs(lhs - rhs);
		const auto distance1 = lhs + std::abs(max - rhs) + 1;
		const auto distance2 = rhs + std::abs(max - lhs) + 1;
		return std::min(distance0, std::min(distance1, distance2));
	}
}

namespace Polytec::IO
{
	/// <summary>Constructor.</summary>
	/// <param name="bufferRange">The buffer range specifies the range of packets that are kept in the
	/// buffer.</param>
	MsgResponseBuffer::MsgResponseBuffer(std::size_t bufferRange)
		: m_bufferRange(bufferRange)
	{}

	/// <summary>
	/// Adds a response packet to the buffer. Packets that are outdated are erased from the buffer. A
	/// packet is defined outdated if it is not in the intervall [N - buffferRange, N + bufferRange]
	/// where N is the command number of the currently added packet.
	/// </summary>
	/// <param name="packet">The packet to add.</param>
	void MsgResponseBuffer::Add(MsgResponse packet)
	{
		if (Contains(packet.GetCommandNumber()))
		{
			Extract(packet.GetCommandNumber());
		}
		EraseOutdatedPackets(packet.GetCommandNumber());
		m_responseBuffer.push_back(std::move(packet));
	}

	/// <summary>Evaluates if a packet with given command number is in the buffer.</summary>
	/// <param name="commandNumber">The command number.</param>
	/// <returns>If the buffer contains a given command number.</returns>
	bool MsgResponseBuffer::Contains(int commandNumber) const
	{
		return Find(commandNumber) != std::cend(m_responseBuffer);
	}

	/// <summary>Extracts a packet with given commandNumber.</summary>
	/// <exception cref="std::out_of_range">Thrown when the command number is not in the buffer.</exception>
	/// <param name="commandNumber">The command number.</param>
	/// <returns>The response packet.</returns>
	MsgResponse MsgResponseBuffer::Extract(int commandNumber)
	{
		const auto found = Find(commandNumber);
		if (found == std::cend(m_responseBuffer))
		{
			throw std::out_of_range("Command number out of range. Can't extract packet from message response buffer.");
		}
		const MsgResponse response = *found;
		m_responseBuffer.erase(found);
		return response;
	}

	std::vector<MsgResponse>::const_iterator MsgResponseBuffer::Find(int commandNumber) const
	{
		const auto matchesCommandNumber = [commandNumber](const auto& element) -> bool { return element.GetCommandNumber() == commandNumber; };
		return std::find_if(std::cbegin(m_responseBuffer), std::cend(m_responseBuffer), matchesCommandNumber);
	}

	void MsgResponseBuffer::EraseOutdatedPackets(int commandNumber)
	{
		const auto outdated = [this, commandNumber](const auto& element) -> bool
		{
			return CircularUInt16Distance(element.GetCommandNumber(), commandNumber) >= m_bufferRange;
		};
		const auto removeBegin = std::remove_if(std::begin(m_responseBuffer), std::end(m_responseBuffer), outdated);
		m_responseBuffer.erase(removeBegin, m_responseBuffer.cend());
	}
}
