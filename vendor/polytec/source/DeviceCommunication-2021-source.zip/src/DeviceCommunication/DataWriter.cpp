// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#include <IO/DeviceCommunication/Detail/DataWriter.h>

#include <IO/DeviceCommunication/CommunicationException.h>
#include <IO/DeviceCommunication/Detail/StringConverter.h>

#include <codecvt>
#include <iterator>

using namespace Polytec::IO;

/// <summary>Constructs an instance of binary data from a vector of bytes.</summary>
/// <param name="data">The data that will be copied to the new binary data instance.</param>
DataWriter::DataWriter(std::vector<std::byte>& data)
	: m_data(data)
{}

/// <summary>Writes the data of given size to the binary data buffer.</summary>
/// <exception cref="CommunicationException">Thrown when a null data pointer is passed.</exception>
/// <param name="data">The pointer to the data.</param>
/// <param name="size">The size of the data in bytes.</param>
void DataWriter::Write(const void* data, std::size_t size)
{
	if (data == nullptr)
	{
		if (size != 0)
			throw CommunicationException(PTCCommunicationStatusCode_InvalidArgument);
		return;
	}
	const auto* begin = static_cast<const std::byte*>(data);
	m_data.resize(std::size(m_data) + size);
#pragma warning(suppress: 26481) // Don't use pointer arithmetic. Use span instead (bounds.1).
	std::copy(begin, begin + size, std::end(m_data) - size);
}

/// <summary>Writes the given string to the binary data buffer.</summary>
/// <param name="str">The string to be written.</param>
void DataWriter::Write(const std::wstring& str)
{
	Write(ToString(str));
}

/// <summary>Writes the given string to the binary data buffer.</summary>
/// <param name="str">The string to be written.</param>
void DataWriter::Write(const std::string& str)
{
	Write(std::data(str), size(str));
}

/// <summary>Writes the given string to the binary data buffer.</summary>
/// <param name="str">The string to be written.</param>
void DataWriter::Write(const char* str)
{
	Write(str, std::strlen(str));
}

/// <summary>Writes the given binary data to the binary data buffer.</summary>
/// <param name="binaryData">The binary data to be written.</param>
void DataWriter::Write(const std::vector<std::byte>& binaryData)
{
	Write(binaryData.data(), binaryData.size());
}

/// <summary>Clears the binary data buffer.</summary>
void DataWriter::Clear()
{
	m_data.clear();
}
