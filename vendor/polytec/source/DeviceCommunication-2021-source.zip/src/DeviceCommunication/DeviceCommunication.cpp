// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#include <IO/DeviceCommunication/DeviceCommunication.h>

#include <IO/DeviceCommunication/CommunicationException.h>
#include <IO/DeviceCommunication/Detail/CommandType.h>
#include <IO/DeviceCommunication/Detail/CommunicationImplementation.h>
#include <IO/DeviceCommunication/Detail/DataReader.h>
#include <IO/DeviceCommunication/Detail/DataWriter.h>
#include <IO/DeviceCommunication/Detail/MsgPacketFormat.h>
#include <IO/DeviceCommunication/Detail/MsgResponse.h>
#include <IO/DeviceCommunication/Detail/MsgRequest.h>
#include <IO/DeviceCommunication/Detail/PayloadTypeTraits.h>
#include <IO/DeviceCommunication/Detail/PayloadType.h>
#include <IO/DeviceCommunication/Detail/SerialCommunication.h>
#include <IO/DeviceCommunication/Detail/StringConverter.h>
#include <IO/DeviceCommunication/Detail/TcpEthernetCommunication.h>
#include <IO/DeviceCommunication/Detail/UdpEthernetCommunication.h>
#include <IO/DeviceCommunication/PTCDeviceCommand.h>
#include <IO/DeviceCommunication/PTCDeviceType.h>
#include <IO/DeviceCommunication/PTCCommunicationStatusCode.h>

using namespace Polytec::IO;

namespace
{
	bool AreCompatible(PayloadType lhs, PayloadType rhs)
	{
		return lhs == rhs || (IsStringPayloadType(lhs) && IsStringPayloadType(rhs));
	}

	template<typename TPayload>
	void CheckPayloadType(PayloadType type, PTCDeviceCommand deviceCommand, const gsl::span<const std::byte>& payloadData)
	{
		if (!AreCompatible(type, c_payloadType<TPayload>) || type == PayloadType::Unknown)
		{
			std::wstring info = L"Device Command: " + std::to_wstring(deviceCommand)
				+ L", Payload Type: " + std::to_wstring(static_cast<int>(type))
				+ L", Payload: " + FormatBinaryData(payloadData);
			throw CommunicationException(PTCCommunicationStatusCode_ReceivedWrongPayloadType, info);
		}
	}

	template<typename TPayload>
	TPayload GetPayload(const std::vector<std::byte>& data)
	{
		try
		{
			TPayload payload{};
			DataReader reader(data);
			reader.Read(payload);
			if (reader.BytesAvailable() != 0)
			{
				throw std::runtime_error("The received payload has a larger size than expected.");
			}
			return payload;
		}
		catch (const std::exception& e)
		{
			throw CommunicationException(PTCCommunicationStatusCode_InvalidResponseFormat, e.what());
		}
	}

}

DeviceCommunication Polytec::IO::CreateUdpEthernetCommunication(const std::wstring& ipAddress,
	std::chrono::duration<float> timeout)
{
	return DeviceCommunication(timeout, std::make_unique<UdpEthernetCommunication>(ipAddress));
}

DeviceCommunication Polytec::IO::CreateTcpEthernetCommunication(const std::wstring& ipAddress,
	std::chrono::duration<float> timeout)
{
	return DeviceCommunication(timeout, std::make_unique<TcpEthernetCommunication>(ipAddress, std::make_unique<MsgPacketFormat>()));
}

DeviceCommunication Polytec::IO::CreateSerialCommunication(
	const std::wstring& comPort, int baudRate, std::chrono::duration<float> timeout)
{
	return DeviceCommunication(timeout, std::make_unique<SerialCommunication>(comPort, baudRate));
}

DeviceCommunication::DeviceCommunication(const std::chrono::duration<float>& timeout, std::unique_ptr<ICommunication> communication)
	: m_implementation(std::make_unique<CommunicationImplementation>(timeout, std::move(communication)))
{
	CheckImplementation();
}

/// <summary>Constructor, destructor, and move operators must be out-of-line if std::unique_ptr<> members exist, see http://herbsutter.com/gotw/_100/</summary>
DeviceCommunication::DeviceCommunication() = default;
DeviceCommunication::DeviceCommunication(DeviceCommunication&&) noexcept = default;
DeviceCommunication& DeviceCommunication::operator=(DeviceCommunication&&) noexcept = default;
DeviceCommunication::~DeviceCommunication() = default;

bool DeviceCommunication::IsOpen() const
{
	if (!m_implementation)
		return false;
	try
	{
		m_implementation->CheckCommunication();
		return true;
	}
	catch (const std::exception&)
	{
		return false;
	}
}

void DeviceCommunication::Close()
{
	m_implementation = nullptr;
}

void DeviceCommunication::SetTimeout(std::chrono::duration<float> timeout)
{
	if (m_implementation)
		m_implementation->SetTimeout(timeout);
}

std::chrono::duration<float> DeviceCommunication::GetTimeout() const
{
	CheckImplementation();
	return m_implementation->GetTimeout();
}

std::wstring DeviceCommunication::DeviceIPAddress() const
{
	return m_implementation->DeviceIPAddress();
}

void DeviceCommunication::EnableRetries(int countOfRetries)
{
	if (m_implementation)
		m_implementation->EnableRetries(countOfRetries);
}

template<typename TPayload>
TPayload DeviceCommunication::SendGet(const Device& device, PTCDeviceCommand deviceCommand,
	PTCMiscellaneousTag tag) const
{
	return DoSendGet<TPayload>(CommandType::Get, device, deviceCommand, tag,
		c_payloadType<void>, {});
}

template<typename TPayload>
TPayload DeviceCommunication::SendGetDevInfo(const Device& device, PTCDeviceCommand deviceCommand,
	PTCMiscellaneousTag tag) const
{
	return DoSendGet<TPayload>(CommandType::GetDevInfo, device, deviceCommand, tag,
		c_payloadType<void>, {});
}

template<typename TPayload>
TPayload DeviceCommunication::SendGetValueList(const Device& device, PTCDeviceCommand deviceCommand,
	PTCMiscellaneousTag tag) const
{
	return DoSendGet<TPayload>(CommandType::GetValueList, device, deviceCommand, tag,
		c_payloadType<void>, {});
}

template<typename TPayload>
void DeviceCommunication::SendSet(const Device& device, PTCDeviceCommand deviceCommand, const TPayload& payload,
	PTCMiscellaneousTag tag)
{
	CheckImplementation();
	const auto data = DataWriter::ToBinaryData(payload);
	m_implementation->SendSet(CommandType::Set, device, deviceCommand, tag, c_payloadType<TPayload>, data);
}

void DeviceCommunication::SendSet(const Device& device, PTCDeviceCommand deviceCommand, PTCMiscellaneousTag tag) const
{
	CheckImplementation();
	m_implementation->SendSet(CommandType::Set, device, deviceCommand, tag, c_payloadType<void>, {});
}

template<typename TResult, typename TPayload>
TResult DeviceCommunication::SendParamGet(const Device& device, PTCDeviceCommand deviceCommand,
	const TPayload& parameters, PTCMiscellaneousTag tag) const
{
	return DoSendGet<TResult>(CommandType::Get, device, deviceCommand, tag,
		c_payloadType<TPayload>, DataWriter::ToBinaryData(parameters));
}

template<typename TResult, typename TPayload>
TResult DeviceCommunication::SendParamGetDevInfo(const Device& device, PTCDeviceCommand deviceCommand,
	const TPayload& parameters, PTCMiscellaneousTag tag) const
{
	return DoSendGet<TResult>(CommandType::GetDevInfo, device, deviceCommand, tag,
		c_payloadType<TPayload>, DataWriter::ToBinaryData(parameters));
}

template<typename TResult, typename TPayload>
TResult DeviceCommunication::SendParamGetValueList(const Device& device, PTCDeviceCommand deviceCommand,
	const TPayload& parameters, PTCMiscellaneousTag tag) const
{
	return DoSendGet<TResult>(CommandType::GetValueList, device, deviceCommand, tag,
		c_payloadType<TPayload>, DataWriter::ToBinaryData(parameters));
}


MsgResponse DeviceCommunication::SendMsgDataPacket(MsgRequest packet)
{
	CheckImplementation();
	return m_implementation->SendMsgDataPacket(std::move(packet));
}

CommunicationImplementation& DeviceCommunication::GetImpl() const
{
	CheckImplementation();
	return *m_implementation;
}

template<typename TResult>
TResult DeviceCommunication::DoSendGet(CommandType commandType, const Device& device,
	PTCDeviceCommand deviceCommand, PTCMiscellaneousTag tag,
	PayloadType requestType, const std::vector<std::byte>& requestData) const
{
	CheckImplementation();
	const auto [responseType, responseData]
		= m_implementation->SendGet(commandType, device, deviceCommand, tag, requestType, requestData);
	CheckPayloadType<TResult>(responseType, deviceCommand, responseData);
	return GetPayload<TResult>(responseData);
}

void DeviceCommunication::CheckImplementation() const
{
	if (!m_implementation)
		throw std::logic_error("Could not send command. No communication has been opened.");
}

#define INSTANTIATION_HELPER(TYPE)\
template TYPE DeviceCommunication::SendGet(const Device&, PTCDeviceCommand, PTCMiscellaneousTag) const;\
template TYPE DeviceCommunication::SendGetDevInfo(const Device&, PTCDeviceCommand, PTCMiscellaneousTag) const;\
template TYPE DeviceCommunication::SendGetValueList(const Device&, PTCDeviceCommand, PTCMiscellaneousTag) const;\
template TYPE DeviceCommunication::SendParamGet(const Device&, PTCDeviceCommand, const int32_t&, PTCMiscellaneousTag) const;\
template TYPE DeviceCommunication::SendParamGet(const Device&, PTCDeviceCommand, const std::vector<int32_t>&, PTCMiscellaneousTag) const;\
template TYPE DeviceCommunication::SendParamGetDevInfo(const Device&, PTCDeviceCommand, const int32_t&, PTCMiscellaneousTag) const;\
template TYPE DeviceCommunication::SendParamGetDevInfo(const Device&, PTCDeviceCommand, const std::vector<int32_t>&, PTCMiscellaneousTag) const;\
template TYPE DeviceCommunication::SendParamGetValueList(const Device&, PTCDeviceCommand, const int32_t&, PTCMiscellaneousTag) const;\
template TYPE DeviceCommunication::SendParamGetValueList(const Device&, PTCDeviceCommand, const std::vector<int32_t>&, PTCMiscellaneousTag) const;\
template void DeviceCommunication::SendSet(const Device&, PTCDeviceCommand, const TYPE&, PTCMiscellaneousTag);

using Array2Int = std::array<int32_t, 2>;
INSTANTIATION_HELPER(std::byte);
INSTANTIATION_HELPER(uint8_t);
INSTANTIATION_HELPER(int16_t);
INSTANTIATION_HELPER(uint16_t);
INSTANTIATION_HELPER(int32_t);
INSTANTIATION_HELPER(uint32_t);
INSTANTIATION_HELPER(float);
INSTANTIATION_HELPER(double);
INSTANTIATION_HELPER(HexData);
INSTANTIATION_HELPER(std::vector<std::byte>);
INSTANTIATION_HELPER(std::vector<uint8_t>);
INSTANTIATION_HELPER(std::vector<int16_t>);
INSTANTIATION_HELPER(std::vector<uint16_t>);
INSTANTIATION_HELPER(Array2Int);
INSTANTIATION_HELPER(std::vector<int32_t>);
INSTANTIATION_HELPER(std::vector<uint32_t>);
INSTANTIATION_HELPER(std::vector<float>);
INSTANTIATION_HELPER(std::vector<double>);
INSTANTIATION_HELPER(std::vector<HexData>);
INSTANTIATION_HELPER(std::string);
INSTANTIATION_HELPER(std::wstring);
