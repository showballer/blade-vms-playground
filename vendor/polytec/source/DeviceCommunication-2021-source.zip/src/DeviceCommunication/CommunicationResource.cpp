// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#include <IO/DeviceCommunication/Detail/CommunicationResource.h>

#include <IO/DeviceCommunication/CommunicationException.h>

namespace
{
	struct LastCommunicationError
	{
		static auto& GetInstance() { return Polytec::PhoenixSingleton<LastCommunicationError>::GetInstance(); }
		std::string Message;
	};

	void SaveLastCommunicationError(std::string message)
	{
		LastCommunicationError::GetInstance().Message = std::move(message);
	}
}

namespace Polytec::IO
{
	CommunicationResource::CommunicationResource(Polytec::IO::DeviceCommunication communication)
		: m_deviceCommunication{std::move(communication)}
		, m_deviceList{m_deviceCommunication}
	{}

	const Polytec::IO::CommandList& CommunicationResource::CommandList(PTCDeviceType deviceType, int deviceNumber)
	{
		const Device device{deviceType, deviceNumber};
		if (m_commandLists.find(device) == std::cend(m_commandLists))
		{
			m_commandLists.try_emplace(device, m_deviceCommunication, device);
		}
		return m_commandLists.at(device);
	}

	Polytec::IO::ItemList& CommunicationResource::ItemList(PTCDeviceType deviceType, int deviceNumber, PTCDeviceCommand deviceCommand)
	{
		const Device device{deviceType, deviceNumber};
		const std::pair<Device, PTCDeviceCommand> key = std::make_pair(device, deviceCommand);

		if (m_itemList.find(key) == std::cend(m_itemList))
		{
			m_itemList.try_emplace(key, m_deviceCommunication, device, deviceCommand);
		}
		return m_itemList.at(key);
	}

	Polytec::IO::ChannelActivation& CommunicationResource::ChannelActivation()
	{
		if (!m_channelActivation.has_value()) {
			m_channelActivation.emplace(m_deviceCommunication);
		}

		return m_channelActivation.value();
	}

	std::string GetLastCommunicationError()
	{
		return LastCommunicationError::GetInstance().Message;
	}

	PTCCommunicationStatusCode Try(const std::function<void()>& f)
	{
		try
		{
			f();
			SaveLastCommunicationError("Success");
			return PTCCommunicationStatusCode_Success;
		} catch (const CommunicationException& e)
		{
			SaveLastCommunicationError(e.what());
			return e.GetStatusCode();
		} catch (const std::bad_alloc& e)
		{
			SaveLastCommunicationError(e.what());
			return PTCCommunicationStatusCode_BadAlloc;
		} catch (const std::exception& e)
		{
			SaveLastCommunicationError(e.what());
			return PTCCommunicationStatusCode_UnknownError;
		}
	}
}
