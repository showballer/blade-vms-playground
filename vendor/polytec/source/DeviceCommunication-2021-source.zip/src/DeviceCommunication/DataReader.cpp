// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#include <IO/DeviceCommunication/Detail/DataReader.h>

#include <IO/DeviceCommunication/CommunicationException.h>
#include <IO/DeviceCommunication/Detail/MsgHeader.h>
#include <IO/DeviceCommunication/Detail/StringConverter.h>
#include <IO/DeviceCommunication/PTCCommunicationStatusCode.h>

#include <boost/numeric/conversion/cast.hpp>

#include <sstream>

using namespace Polytec::IO;

/// <summary>Constructs an instance of a data reader relating to the given binary data.</summary>
/// <param name="binaryData">The binary data that will be read by the data reader.</param>
DataReader::DataReader(gsl::span<const std::byte> binaryData)
	: m_binaryData(std::move(binaryData))
{}

/// <summary>
/// Reads data from the binary data and copies it to the given string. This will read all data
/// from the binary data.
/// </summary>
/// <param name="str">[out] The read binary data as string.</param>
void DataReader::Read(std::string& str)
{
	str.clear();
#pragma warning(suppress: 26429) // Symbol 'data' is never tested for nullness, it can be marked as not_null (f.23).
	auto data = m_binaryData.data();
	for (; m_index < m_binaryData.size(); m_index++)
#pragma warning(suppress: 26481) // Don't use pointer arithmetic. Use span instead (bounds.1).
		str += static_cast<char>(data[m_index]);
}

/// <summary>
/// Reads data from the binary data and copies it to the given string. This will read all data
/// from the binary data.
/// </summary>
/// <param name="str">[out] The read binary data as string.</param>
void DataReader::Read(std::wstring& str)
{
	std::string byteStr;
	Read(byteStr);
	str = ToWString(byteStr);
}

/// <summary>Extracts the data of given size from the related binary data buffer.</summary>
/// <exception cref="std::out_of_range">An out of range exception is thrown when the requested
/// data is not available.</exception>
/// <param name="size">The size in bytes of the requested data.</param>
/// <returns>The extracted binary data.</returns>
std::vector<std::byte> DataReader::ExtractData(std::size_t size)
{
	CheckBytesAvailable(size);
#pragma warning(suppress: 26481) // Don't use pointer arithmetic. Use span instead (bounds.1).
	auto first = m_binaryData.data() + m_index;
#pragma warning(suppress: 26481) // Don't use pointer arithmetic. Use span instead (bounds.1).
	auto last = first + size;
	m_index += size;
	return std::vector<std::byte>(first, last);
}

/// <summary>Gets a pointer to the binary data at the current read position.</summary>
/// <returns>An byte pointer to the current data.</returns>
const std::byte* DataReader::Data() const
{
#pragma warning(suppress: 26481) // Don't use pointer arithmetic. Use span instead (bounds.1).
	return m_binaryData.data() + m_index;
}

/// <summary>Bytes available to be read.</summary>
/// <returns>The available bytes of data.</returns>
std::size_t DataReader::BytesAvailable() const
{
	return m_binaryData.size() - m_index;
}

/// <summary>Gets a span to the binary data at the current read position.</summary>
/// <returns>A span to the current data.</returns>
gsl::span<const std::byte> DataReader::Span() const
{
	return m_binaryData.subspan(m_index);
}

/// <summary>Evaluates if the end of the binary data buffer is reached.</summary>
/// <returns>
/// True if all bytes are read from the binary data buffer. False if there is data to be read.
/// </returns>
bool DataReader::EndOfBuffer() const
{
	return m_index >= m_binaryData.size();
}

/// <summary>Gets the current read index.</summary>
/// <returns>The current read index.</returns>
std::size_t Polytec::IO::DataReader::Index() const
{
	return m_index;
}

/// <summary>Sets the read index.</summary>
/// <remarks>The next read will be from the specified index.</remarks>
/// <param name="index">The read index.</param>
void Polytec::IO::DataReader::Index(std::size_t index)
{
	if (index > m_binaryData.size())
		throw std::out_of_range("The specified index is larger than the size of the binary data.");
	m_index = index;
}

void DataReader::CheckBytesAvailable(std::size_t size) const
{
	if (size > BytesAvailable())
	{
		std::stringstream stream;
		stream << "Reading binary data out of range. ";
		stream << "Index: " << m_index << ". ";
		stream << "Bytes to read: " << size << ". ";
		stream << "Binary data size: " << std::size(m_binaryData) << ". ";
		throw std::out_of_range(stream.str());
	}
}
