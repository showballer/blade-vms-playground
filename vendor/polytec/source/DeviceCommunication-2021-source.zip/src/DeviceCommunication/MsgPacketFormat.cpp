// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#include <IO/DeviceCommunication/Detail/MsgPacketFormat.h>

#include <IO/DeviceCommunication/Detail/DataReader.h>
#include <IO/DeviceCommunication/Detail/DataWriter.h>
#include <IO/DeviceCommunication/Detail/MsgHeader.h>

namespace Polytec::IO
{
	std::size_t MsgPacketFormat::GetBodySize(const std::vector<std::byte>& headerData) const
	{
		DataReader reader(headerData);
		MsgHeader header;
		header.Load(reader);
		return header.GetMsgSize() - GetBaseHeaderSize();
	}
}
