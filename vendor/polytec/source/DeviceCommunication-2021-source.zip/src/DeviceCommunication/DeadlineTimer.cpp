// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#include <IO/DeviceCommunication/Detail/DeadlineTimer.h>

#include <IO/DeviceCommunication/CommunicationException.h>

namespace Polytec::IO
{
	/// <summary>Constructor.</summary>
	/// <exception cref="std::invalid_argument">Thrown if the deadline-expired callback argument is
	/// invalid.</exception>
	/// <param name="ioService">[in,out] The io-service.</param>
	/// <param name="onDeadlineExpired">The deadline-expired callback. This callback should be used
	/// to cancel the IO operation.</param>
	DeadlineTimer::DeadlineTimer(boost::asio::io_service& ioService, std::function<void()> onDeadlineExpired)
		: m_ioService(ioService)
		, m_deadlineTimer(m_ioService)
		, m_onDeadlineExpired(std::move(onDeadlineExpired))
	{
		if (m_onDeadlineExpired == nullptr)
		{
			throw std::invalid_argument("On deadline expired callback invalid.");
		}

		// The IO operation will be canceled as soon as the deadline timer expires.
		// For that purpose the deadline performs an asynchronous wait until expiration.
		// Before receiving data the expiration time is set. Elsewise the deadline is disabled.
		m_deadlineTimer.expires_at(boost::posix_time::pos_infin);
		CheckDeadline();
	}

	/// <summary>Reads until dead line timer expires.</summary>
	/// <exception cref="CommunicationException">Thrown the read operation fails.</exception>
	/// <param name="timeout">The timeout.</param>
	/// <param name="asyncRead">The asynchronous read operation.</param>
	/// <returns>The number of bytes that have been read. Returns 0 on timeout.</returns>
	[[nodiscard]] std::size_t DeadlineTimer::ReadUntilDeadLine(const std::chrono::duration<float>& timeout, const AsyncReadFunction& asyncRead)
	{
		const auto ms = std::chrono::duration_cast<std::chrono::milliseconds>(timeout);
		m_deadlineTimer.expires_from_now(boost::posix_time::millisec(ms.count()));

		boost::system::error_code errorCode = boost::asio::error::would_block;
		std::size_t length = 0;

		asyncRead([&errorCode, &length](const boost::system::error_code &pErrorCode, std::size_t pLength)
		{
			errorCode = pErrorCode;
			length = pLength;
		});

		// Run the io-service until the socket receives data or fails.
		// When the deadline expires the IO operation is canceled.
		do
		{
			m_ioService.run_one();
		} while (errorCode == boost::asio::error::would_block);

		if (!length && errorCode != boost::asio::error::operation_aborted)
		{
			throw CommunicationException(PTCCommunicationStatusCode_SystemError, "Failed to read: " + errorCode.message());
		}

		return length;
	}

	/// <summary>
	/// Checks if the timeout deadline has expired. If this is the case the operation is canceled.
	/// </summary>
	void DeadlineTimer::CheckDeadline()
	{
		if (m_deadlineTimer.expires_at() <= boost::asio::deadline_timer::traits_type::now())
		{
			m_onDeadlineExpired();
			m_deadlineTimer.expires_at(boost::posix_time::pos_infin);
		}
		m_deadlineTimer.async_wait([this](const boost::system::error_code &)
		{
			CheckDeadline();
		});
	}
}
