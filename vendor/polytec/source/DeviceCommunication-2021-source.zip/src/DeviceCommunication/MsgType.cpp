// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#include <IO/DeviceCommunication/Detail/MsgType.h>

#include <IO/DeviceCommunication/CommunicationException.h>
#include <IO/DeviceCommunication/Detail/DataReader.h>
#include <IO/DeviceCommunication/Detail/DataWriter.h>
#include <IO/DeviceCommunication/Detail/MsgRequest.h>
#include <IO/DeviceCommunication/Detail/MsgResponse.h>

#include <map>

using namespace Polytec::IO;

namespace
{
	const std::map<MsgType, std::size_t> c_basePacketLength =
#pragma warning(suppress: 26426) // Global initializer calls a non-constexpr function 'std::map<enum Polytec::IO::MsgType,unsigned int,std::less<enum Polytec::IO::MsgType>,std::allocator<std::pair<enum Polytec::IO::MsgType const ,unsigned int> > >::map<enum Polytec::IO::MsgType,unsigned int,std::less<enum Polytec::IO::MsgType>,std::allocator<std::pair<enum Polytec::IO::MsgType const ,unsigned int> > >' (i.22).
	{
		{MsgType::Request, 14},
		{MsgType::LargeRequest, 16},
		{MsgType::Response, 5},
		{MsgType::LargeResponse, 7}
	};

	std::size_t SubtractBasePacketLength(std::size_t packetLength, MsgType msgTypeOfRhs)
	{
		const auto baseLength = c_basePacketLength.at(msgTypeOfRhs);
		if (packetLength < baseLength)
			throw std::logic_error("Invalid payload size.");
		return packetLength - baseLength;
	}

	template<typename T>
	T AddBasePacketLength(std::size_t payloadSize, MsgType msgType)
	{
		const std::size_t packetLength = c_basePacketLength.at(msgType) + payloadSize;
		if (packetLength > std::numeric_limits<T>::max())
			throw std::logic_error("Payload too large for message type.");
		return gsl::narrow_cast<T>(packetLength);
	}
}

/// <summary>Reads the payload size from a message packet.</summary>
/// <exception cref="std::logic_error">Raised if the message type is unknown.</exception>
/// <param name="reader">[in,out] The reader that reads from the message packet.</param>
/// <param name="msgType">Type of the message.</param>
/// <returns>The payload size.</returns>
std::size_t Polytec::IO::ReadPayloadSize(DataReader& reader, MsgType msgType)
{
	switch (msgType)
	{
		case MsgType::Response:
		case MsgType::Request:
		{
			std::uint16_t packetLength{};
			reader.Read(packetLength);
			return SubtractBasePacketLength(packetLength, msgType);
		}

		case MsgType::LargeResponse:
		case MsgType::LargeRequest:
		{
			std::uint32_t packetLength{};
			reader.Read(packetLength);
			return SubtractBasePacketLength(packetLength, msgType);
		}

		default:
			throw std::logic_error("Unknown message type.");
	}
}

/// <summary>Writes the packet length to a message packet.</summary>
/// <exception cref="CommunicationException">Thrown if the message type is unknown.</exception>
/// <param name="dataWriter">[in,out] The data writer that writes to the message packet.</param>
/// <param name="msgType">Type of the message.</param>
/// <param name="payloadSize">Size of the payload.</param>
void Polytec::IO::WritePacketLength(DataWriter& dataWriter, MsgType msgType, std::size_t payloadSize)
{
	switch (msgType)
	{
		case MsgType::Response:
		case MsgType::Request:
			return dataWriter.Write(AddBasePacketLength<std::uint16_t>(payloadSize, msgType));

		case MsgType::LargeResponse:
		case MsgType::LargeRequest:
			return dataWriter.Write(AddBasePacketLength<std::uint32_t>(payloadSize, msgType));

		default:
			throw CommunicationException(PTCCommunicationStatusCode_InvalidArgument);
	}
}

/// <summary>The size of the message request in bytes depending on the message type.</summary>
/// <param name="packet">The packet.</param>
/// <param name="msgType">Type of the message.</param>
/// <returns>The size of the packet.</returns>
std::size_t Polytec::IO::Size(const MsgRequest &packet, MsgType msgType)
{
	return AddBasePacketLength<std::size_t>(std::size(packet.GetCommandData()), msgType);
}

/// <summary>The size of the message response in bytes depending on the message type.</summary>
/// <param name="packet">The packet.</param>
/// <param name="msgType">Type of the message.</param>
/// <returns>The size of the packet.</returns>
std::size_t Polytec::IO::Size(const MsgResponse &packet, MsgType msgType)
{
	return AddBasePacketLength<std::size_t>(std::size(packet.GetCommandData()), msgType);
}

/// <summary>
/// Evaluates the message type for a message request. Large packets (whose length doesn't fit in
/// an uint16_t) need to be send by a large message type. For backward compatibility smaller
/// packet will be sent by the basic message types.
/// </summary>
/// <exception cref="std::logic_error">Raised if the packet is too large for any message type.</exception>
/// <param name="packet">The packet.</param>
/// <returns>The message type.</returns>
MsgType Polytec::IO::EvaluateMsgType(const MsgRequest &packet)
{
	if (Size(packet, MsgType::Request) <= std::numeric_limits<uint16_t>::max())
		return MsgType::Request;
	else if (Size(packet, MsgType::LargeRequest) <= std::numeric_limits<uint32_t>::max())
		return MsgType::LargeRequest;
	else
		throw std::logic_error("Message request is too large for message types.");
}

/// <summary>
/// Evaluates the message type for a message response. Large packets (whose length doesn't fit in
/// an uint16_t) need to be send by a large message type. For backward compatibility smaller
/// packet will be sent by the basic message types.
/// </summary>
/// <exception cref="std::logic_error">Raised if the packet is too large for any message type.</exception>
/// <param name="packet">The packet.</param>
/// <returns>The message type.</returns>
MsgType Polytec::IO::EvaluateMsgType(const MsgResponse &packet)
{
	if (Size(packet, MsgType::Response) <= std::numeric_limits<uint16_t>::max())
		return MsgType::Response;
	else if (Size(packet, MsgType::LargeResponse) <= std::numeric_limits<uint32_t>::max())
		return MsgType::LargeResponse;
	else
		throw std::logic_error("Message request is too large for message types.");
}
