// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#include <IO/DeviceCommunication/Detail/SerialCommunication.h>

#include <IO/DeviceCommunication/CommunicationException.h>
#include <IO/DeviceCommunication/Detail/Base64Serialization.h>
#include <IO/DeviceCommunication/Detail/StringConverter.h>
#include <IO/DeviceCommunication/PTCCommunicationStatusCode.h>

#include <optional>

using boost::asio::serial_port_base;
using namespace Polytec::IO;

/// <summary>
/// Constructs an instance for serial communication with given serial port name and baud rate.
/// The timeout will be applied for incoming packets.
/// </summary>
/// <param name="serialPortName">Name of the serial port.</param>
/// <param name="baudRate">The baud rate.</param>
SerialCommunication::SerialCommunication(const std::wstring& serialPortName, int baudRate)
try
	: m_serialPort(m_ioService, IO::ToString(serialPortName))
	, m_deadlineTimer(m_ioService, [this] { m_serialPort.cancel(); })
{
	m_serialPort.set_option(serial_port_base::baud_rate(baudRate));
	m_serialPort.set_option(serial_port_base::stop_bits(serial_port_base::stop_bits::type::one));
	m_serialPort.set_option(serial_port_base::parity(serial_port_base::parity::type::none));
	m_serialPort.set_option(serial_port_base::character_size(8));

	ClearInternalSerialPortBuffer();
	ClearDeviceSerialPortBuffer();
}
catch (const boost::system::system_error& e)
{
	throw CommunicationException(PTCCommunicationStatusCode_SystemError, e.what());
}

/// <summary>
/// Sends the data to the device over serial port. This function locks a mutex to ensure that
/// only one packet is sent after the other.
/// </summary>
/// <param name="data">The send binary data.</param>
void SerialCommunication::SendData(const std::vector<std::byte>& data)
{
	std::lock_guard<std::mutex> lock(m_writeMutex);

	std::string base64Str = ToBase64String(data);
	base64Str += "\n";
	boost::asio::write(m_serialPort, boost::asio::buffer(base64Str));
}

/// <summary>Receiving data from serial port and converting the received Base64 data.</summary>
/// <returns>Returns the received data. Returns empty data if the timeout has expired.</returns>
std::vector<std::byte> SerialCommunication::ReceiveData()
{

	const auto readCharacter([this]()
	{
		char c{};
		const auto length = m_deadlineTimer.ReadUntilDeadLine(m_timeout, [this, &c](const auto& readHandler)
		{
			// Read several single characters instead of using boost::asio::async_read_until(m_serialPort, buffer, '\n', readHandler).
			// We will get a better performance by a factor of ~10.
			// See also "boost C++ read from serial port with timeout example"
			// http://www.ridgesolutions.ie/index.php/2012/12/13/boost-c-read-from-serial-port-with-timeout-example/
			boost::asio::async_read(m_serialPort, boost::asio::buffer(&c, 1), readHandler);
		});
		return length
			? std::optional<char>(c)
			: std::nullopt;
	});

	std::string response;
	response.reserve(64);

	while (true)
	{
		const auto c = readCharacter();
		if (!c.has_value())
		{
			return {}; // timeout
		}
		else if (c == '\n')
		{
			break;
		}
		response += c.value();
	}

	if (response.length() % 4 != 0)
		throw CommunicationException(PTCCommunicationStatusCode_InvalidResponseFormat);

	return ParseBase64String<std::byte>(response);
}

/// <summary>
/// Gets the response port. The response port is not needed for a serial communication.
/// </summary>
/// <returns>Always zero.</returns>
int SerialCommunication::ResponsePort() const
{
	return 0;
}

/// <summary>Gets the device IP address. This is not needed for a serial communication.</summary>
/// <returns>An empty string.</returns>
std::wstring SerialCommunication::DeviceIPAddress() const
{
	return {};
}

/// <summary>Clears the serial port read buffer of the device.</summary>
void SerialCommunication::ClearInternalSerialPortBuffer()
{
	// The lineFeed as a string is necessary here. When using the literal \n directly, a \0 is added to
	// the buffer.
	std::string lineFeed = "\n";
	boost::asio::write(m_serialPort, boost::asio::buffer(lineFeed));
}

#if defined _WIN32
#include <windows.h>

/// <summary>Clears the internal receive and transmission serial port buffers.</summary>
void SerialCommunication::ClearDeviceSerialPortBuffer()
{
	const auto portHandle = m_serialPort.lowest_layer().native_handle();
	::PurgeComm(portHandle, PURGE_RXABORT | PURGE_TXABORT | PURGE_RXCLEAR | PURGE_TXCLEAR);
	::ClearCommError(portHandle, nullptr, nullptr);
}
#elif defined(unix) || defined(__unix) || defined(__unix__)
#include <unistd.h>
void SerialCommunication::ClearDeviceSerialPortBuffer()
{
	const auto portHandle = m_serialPort.lowest_layer().native_handle();
	::tcflush(m_serialPort.lowest_layer().native_handle(), TCIOFLUSH);
}
#else
#error "ClearDeviceSerialPortBuffer not defined."
#endif
