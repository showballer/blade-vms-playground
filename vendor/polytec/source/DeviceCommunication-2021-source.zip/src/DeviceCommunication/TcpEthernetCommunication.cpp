// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#include <IO/DeviceCommunication/Detail/TcpEthernetCommunication.h>

#include <IO/DeviceCommunication/CommunicationException.h>
#include <IO/DeviceCommunication/Detail/DataReader.h>
#include <IO/DeviceCommunication/Detail/NetworkUtils.h>
#include <IO/DeviceCommunication/Detail/StringConverter.h>
#include <IO/DeviceCommunication/PTCCommunicationStatusCode.h>

using namespace Polytec::IO;
using tcp = boost::asio::ip::tcp;

namespace
{
	constexpr int c_portDevice = 60100;
	constexpr std::size_t c_bufferSize = 65000;
}

/// <summary>Constructs an instance for TCP ethernet communication.</summary>
/// <param name="hostname">The hostname or IP address of the device.</param>
/// <param name="packetFormat">[in,out] The network packet format to facilitate packets for
/// stream based protocols.</param>
TcpEthernetCommunication::TcpEthernetCommunication(const std::wstring& hostname, std::unique_ptr<INetworkPacketFormat>&& packetFormat)
try
	: m_socket(CreateSocket<tcp>(m_ioService))
	, m_deviceEndpoint(ResolveHostname<tcp>(m_ioService, ToString(hostname), c_portDevice))
	, m_buffer(c_bufferSize)
	, m_packetFormat(std::move(packetFormat))
	, m_deadlineTimer(m_ioService, [this] { m_socket.cancel(); })
{
	if (!m_packetFormat)
		throw std::invalid_argument("Invalid packet format for TCP communication.");
	m_socket.connect(m_deviceEndpoint);
}
catch (const boost::system::system_error& e)
{
	throw CommunicationException(PTCCommunicationStatusCode_SystemError, e.what());
}

std::vector<std::byte> TcpEthernetCommunication::ReceiveData()
{
	const auto headerSize = m_packetFormat->GetBaseHeaderSize();
	m_buffer.resize(headerSize);
	const auto length = m_deadlineTimer.ReadUntilDeadLine(m_timeout, [this](const auto& readHandler)
	{
		boost::asio::async_read(m_socket, boost::asio::buffer(m_buffer), readHandler);
	});
	if (!length)
	{
		return {};
	}

	const auto packetSize = m_packetFormat->GetBodySize(m_buffer);
	return ReceiveDataBlocks(headerSize, packetSize, 250'000); // for a timeout of 2 seconds this is stable with a minimum download speed of 1 Mbit/s
}

std::vector<std::byte> TcpEthernetCommunication::ReceiveDataBlocks(std::size_t headerSize, std::size_t packetSize, std::size_t blockSize)
{
	m_buffer.resize(headerSize + packetSize);
	const auto packet = gsl::make_span(m_buffer).subspan(headerSize, packetSize);
	for (std::size_t offset = 0; offset < boost::numeric_cast<std::size_t>(packet.size()); offset += blockSize)
	{
		const std::size_t size = std::min(packet.size() - offset, blockSize);
		const auto block = packet.subspan(offset, size);
		const auto length = m_deadlineTimer.ReadUntilDeadLine(m_timeout, [this, &block](const auto& readHandler)
		{
			boost::asio::async_read(m_socket, boost::asio::buffer(block.data(), block.size()), readHandler);
		});
		if (!length)
		{
			return {};
		}
	}
	return m_buffer;
}

void TcpEthernetCommunication::SendData(const std::vector<std::byte>& data)
{
	boost::asio::write(m_socket, boost::asio::buffer(data));
}

int TcpEthernetCommunication::ResponsePort() const
{
	return m_socket.local_endpoint().port();
}

std::wstring TcpEthernetCommunication::DeviceIPAddress() const
{
	return ToWString(m_deviceEndpoint.address().to_string());
}
