// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#include <IO/DeviceCommunication/Detail/Base64Serialization.h>

#include <boost/archive/iterators/base64_from_binary.hpp>
#include <boost/archive/iterators/binary_from_base64.hpp>
#include <boost/archive/iterators/insert_linebreaks.hpp>
#include <boost/archive/iterators/transform_width.hpp>
#include <boost/archive/iterators/ostream_iterator.hpp>
#include <sstream>

/// <summary>Converts binary data to a base 64 string.</summary>
/// <remarks>
/// Source: http://stackoverflow.com/questions/7053538/how-do-i-encode-a-string-to-base64-using-only-boost.
/// </remarks>
/// <typeparam name="TByte">Byte representation.</typeparam>
/// <param name="binary">The binary data.</param>
/// <returns>A base64 encoded string.</returns>
template<typename TByte>
std::string Polytec::IO::ToBase64String(const std::vector<TByte>& binary)
{
	// convert binary values to base64 characters
	// retrieve 6 bit integers from a sequence of 8 bit bytes
	// compose all the above operations in to a new iterator
	namespace bai = boost::archive::iterators;
	using Encoder = bai::base64_from_binary<bai::transform_width<const char *, 6, 8> >;

	std::string string;
	if (!binary.empty())
	{
#pragma warning(suppress: 26490) // Don't use reinterpret_cast (type.1).
		auto begin = reinterpret_cast<const char*>(binary.data());
#pragma warning(suppress: 26481) // Don't use pointer arithmetic. Use span instead (bounds.1).
#pragma warning(suppress: 26490) // Don't use reinterpret_cast (type.1).
		auto end = reinterpret_cast<const char*>(binary.data() + binary.size());
		string.assign(begin, end);
	}

	std::stringstream os;
	std::copy(Encoder(string.c_str()), Encoder(string.c_str() + string.size()),
		bai::ostream_iterator<char>(os));

	static const char* padding[] = {"", "==", "="};
#pragma warning(suppress: 26482) // Only index into arrays using constant expressions (bounds.2).
	os << padding[binary.size() % 3];
	return os.str().c_str();
}

/// <summary>Parse base64 encoded string.</summary>
/// <remarks>
/// Source: http://stackoverflow.com/questions/7053538/how-do-i-encode-a-string-to-base64-using-only-boost.
/// </remarks>
/// <typeparam name="TByte">Byte representation.</typeparam>
/// <param name="string">The base64 encoded string.</param>
/// <returns>The binary data.</returns>
template<typename TByte>
std::vector<TByte> Polytec::IO::ParseBase64String(const std::string& string)
{
	assert(string.length() % 4 == 0);

	// convert binary values to base64 characters
	// retrieve 6 bit integers from a sequence of 8 bit bytes
	// compose all the above operations in to a new iterator
	namespace bai = boost::archive::iterators;
	typedef bai::transform_width<bai::binary_from_base64<const char *>, 8, 6> Decoder;

	Decoder decoder(string.c_str());
	const auto count = string.find_last_not_of('=') + 1;

	std::vector<TByte> data;
	while (data.size() < count * 6 / 8)
		data.push_back(static_cast<TByte>(*decoder++));

	return data;
}

template std::string Polytec::IO::ToBase64String(const std::vector<std::byte>&);
template std::string Polytec::IO::ToBase64String(const std::vector<std::uint8_t>&);
template std::vector<std::byte> Polytec::IO::ParseBase64String(const std::string&);
template std::vector<std::uint8_t> Polytec::IO::ParseBase64String(const std::string&);
