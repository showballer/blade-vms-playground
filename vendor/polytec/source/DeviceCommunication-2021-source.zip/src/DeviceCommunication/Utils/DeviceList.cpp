// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#include <IO/DeviceCommunication/Utils/DeviceList.h>

#include <IO/DeviceCommunication/Device.h>
#include <IO/DeviceCommunication/DeviceCommunication.h>
#include <IO/DeviceCommunication/PTCDeviceCommand.h>
#include <IO/DeviceCommunication/PTCDeviceType.h>

#include <algorithm>
#include <map>
#include <gsl/gsl>

namespace Polytec::IO
{
	DeviceList::DeviceList(const IO::DeviceCommunication& communication)
		: m_deviceList(communication.SendGet<std::vector<std::int16_t>>(PTCDeviceType_Controller, PTCDeviceCommand_DeviceList))
	{}

	bool DeviceList::HasDevice(const IO::Device& device) const
	{
		return device.Number() < std::count(std::cbegin(m_deviceList), std::cend(m_deviceList), static_cast<std::int16_t>(device.Type()));
	}

	int DeviceList::Count(PTCDeviceType deviceType) const
	{
		return gsl::narrow_cast<int>(
			std::count(std::cbegin(m_deviceList), std::cend(m_deviceList), static_cast<std::int16_t>(deviceType)));
	}

	std::vector<Device> DeviceList::AllDevices() const
	{
		std::map<PTCDeviceType, int> count;
		std::vector<IO::Device> result;
		for (const auto& device : m_deviceList)
		{
			const auto deviceType = static_cast<PTCDeviceType>(device);
			const auto deviceNumber = count[deviceType]++;
			result.emplace_back(deviceType, deviceNumber);
		}
		return result;
	}
}
