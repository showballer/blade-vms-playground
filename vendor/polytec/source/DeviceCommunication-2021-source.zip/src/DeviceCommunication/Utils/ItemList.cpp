// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#include <IO/DeviceCommunication/Utils/ItemList.h>

#include <IO/DeviceCommunication/Detail/StringConverter.h>
#include <IO/DeviceCommunication/DeviceCommunication.h>

#include <gsl/gsl>

#include <algorithm>
#include <complex>

namespace
{
	using namespace Polytec::IO;

	std::vector<std::wstring> SendGetAllItems(const DeviceCommunication& communication, const Device& device, PTCDeviceCommand command)
	{
		std::wstringstream stream(communication.SendGetValueList<std::wstring>(device, command));
		std::vector<std::wstring> allItems;
		std::wstring element;
		while (std::getline(stream, element, L','))
		{
			allItems.push_back(element);
		}
		return allItems;
	}
}

namespace Polytec::IO
{
	ItemList::ItemList(DeviceCommunication& communication, const Device& device, PTCDeviceCommand command)
		: m_communication(communication)
		, m_device(device)
		, m_command(command)
		, m_allItems(SendGetAllItems(m_communication, m_device, m_command))
	{}

	std::vector<std::int16_t> ItemList::GetAvailableIndices() const
	{
		return m_communication.SendGetDevInfo<std::vector<std::int16_t>>(m_device, m_command);
	}

	std::vector<std::wstring> ItemList::GetAvailableItems() const
	{
		const auto availableIndices = GetAvailableIndices();
		std::vector<std::wstring> availableItems(availableIndices.size());

		std::transform(availableIndices.cbegin(), availableIndices.cend(), availableItems.begin(),
			[this](int16_t index) { return m_allItems.at(index); });

		return availableItems;
	}

	std::wstring ItemList::GetCurrentItem() const
	{
		return m_allItems.at(GetCurrentIndex());
	}

	std::int16_t ItemList::GetCurrentIndex() const
	{
		return m_communication.SendGet<std::int16_t>(m_device, m_command);
	}

	void ItemList::SetCurrentItem(const std::wstring& item)
	{
		const auto found = std::find(std::cbegin(m_allItems), std::cend(m_allItems), item);
		if (found == std::cend(m_allItems))
			throw std::logic_error(IO::ToString(L"Invalid item for item list: \"" + item + L"\" (Cmd: " + std::to_wstring(m_command) + L")"));
		SetCurrentIndex(gsl::narrow_cast<std::int16_t>(std::distance(std::cbegin(m_allItems), found)));
	}

	void ItemList::SetCurrentIndex(std::int16_t index)
	{
		m_communication.SendSet<std::int16_t>(m_device, m_command, index);
	}

	bool ItemList::HasItem(const std::wstring& item) const
	{
		return std::find(m_allItems.begin(), m_allItems.end(), item) != m_allItems.end();
	}

	bool ItemList::IsItemAvailable(const std::wstring& item) const
	{
		const auto availableItems = GetAvailableItems();
		return std::find(availableItems.begin(), availableItems.end(), item) != availableItems.end();
	}

	bool ItemList::IsIndexAvailable(std::int16_t index) const
	{
		const auto availableIndices = GetAvailableIndices();
		return std::find(availableIndices.begin(), availableIndices.end(), index) != availableIndices.end();
	}

	std::wstring ItemList::GetStartUpItem() const
	{
		const auto startUpIndex = m_communication.SendGet<int16_t>(m_device, m_command, PTCMiscellaneousTag_StartUpValue);
		return m_allItems.at(startUpIndex);
	}
}
