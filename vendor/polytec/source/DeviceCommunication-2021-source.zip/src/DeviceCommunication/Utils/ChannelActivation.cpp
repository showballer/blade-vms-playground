// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#include <IO/DeviceCommunication/Utils/ChannelActivation.h>

#include <IO/DataAcquisition/Detail/ProtocolType.h>
#include <IO/DeviceCommunication/CommunicationException.h>
#include <IO/DeviceCommunication/Detail/StringConverter.h>
#include <IO/DeviceCommunication/DeviceCommunication.h>
#include <IO/DeviceCommunication/Utils/CommandList.h>
#include <IO/DeviceCommunication/Utils/DeviceList.h>

#include <algorithm>
#include <iterator>
#include <sstream>

#include <gsl/gsl>

namespace
{
	constexpr PTCDeviceCommand c_command = PTCDeviceCommand_DaqActiveChannels;
	constexpr Polytec::IO::Device c_device{PTCDeviceType_SignalProcessing};

	using namespace Polytec::IO;

	Device SendGetActiveDecoder(const DeviceCommunication& communication)
	{
		if (!CommandList(communication, PTCDeviceType_VelocityDecoderDigital)
			.HasCommand(PTCDeviceCommand_OutputActive))
		{
			return PTCDeviceType_VelocityDecoderDigital;
		}
		for (auto device : {PTCDeviceType_VelocityDecoderDigital, PTCDeviceType_DisplacementDecoderDigital, PTCDeviceType_AccelerationDecoderDigital})
		{
			if (DeviceList(communication).HasDevice(device)
				&& communication.SendGet<int16_t>(device, PTCDeviceCommand_OutputActive) == 1)
			{
				return device;
			}
		}
		throw std::logic_error("Channel activation not able to find active output.");
	}

	std::vector<Channel> IvsActiveChannels(const DeviceCommunication& communication)
	{
		const std::map<Device, Channel> toChannel =
		{
			{PTCDeviceType_VelocityDecoderDigital, PTCChannelType_Velocity},
			{PTCDeviceType_DisplacementDecoderDigital, PTCChannelType_Displacement},
			{PTCDeviceType_AccelerationDecoderDigital, PTCChannelType_Acceleration}
		};

		const auto activeDecoder = toChannel.find(SendGetActiveDecoder(communication));
		if (activeDecoder == toChannel.cend())
			throw std::logic_error("No active decoder found.");

		return
		{
			activeDecoder->second,
			PTCChannelType_RSSI,
			PTCChannelType_DataValidity,
			PTCChannelType_Trigger
		};
	}
}

namespace Polytec::IO
{
	ChannelActivation::ChannelActivation(DeviceCommunication& communication)
		: m_communication{communication}
	{
		const auto allChannelTypes = m_communication.SendGet<std::vector<int16_t>>(c_device, c_command);
		std::transform(std::cbegin(allChannelTypes), std::cend(allChannelTypes), std::back_inserter(m_allChannelTypes), [](const int16_t& type) {
			return ToChannelType(static_cast<PTCMiscellaneousTag>(type));
		});
	}

	int	ChannelActivation::GetMaxChannelCount(PTCChannelType channelType) const
	{
		CheckChannelType(channelType);
		if (m_maxSupportedChannelCount.find(channelType) == std::cend(m_maxSupportedChannelCount))
		{
			m_maxSupportedChannelCount[channelType] =
				m_communication.SendGetValueList<int16_t>(c_device, c_command, ToMiscellaneousTag(channelType));
		}
		return m_maxSupportedChannelCount.at(channelType);
	}

	int	ChannelActivation::GetAvailableChannelCount(PTCChannelType channelType) const
	{
		CheckChannelType(channelType);
		return m_communication.SendGetDevInfo<int16_t>(c_device, c_command, ToMiscellaneousTag(channelType));
	}

	std::vector<int> ChannelActivation::GetActiveChannels(PTCChannelType channelType) const
	{
		CheckChannelType(channelType);
		auto activeChannelsVec = m_communication.SendGet<std::vector<int16_t>>(c_device, c_command, ToMiscellaneousTag(channelType));

		if (std::size(activeChannelsVec) == 1 && activeChannelsVec[0] == -1)
			return {};
		else
			return std::vector<int>(std::cbegin(activeChannelsVec), std::cend(activeChannelsVec));
	}

	void ChannelActivation::SetActiveChannels(PTCChannelType channelType, std::vector<int> activeChannels)
	{
		CheckChannelType(channelType);
		std::vector<int16_t> activeChannelsVec(std::cbegin(activeChannels), std::cend(activeChannels));
		m_communication.SendSet<std::vector<int16_t>>(c_device, c_command, activeChannelsVec, ToMiscellaneousTag(channelType));
	}

	void ChannelActivation::DisableAllChannels()
	{
		for (const auto& channelType : m_allChannelTypes)
			m_communication.SendSet<std::vector<int16_t>>(c_device, c_command, {}, ToMiscellaneousTag(channelType));
	}

	void ChannelActivation::CheckChannelType(PTCChannelType channelType) const
	{
		if (std::find(std::cbegin(m_allChannelTypes), std::cend(m_allChannelTypes), channelType) == std::cend(m_allChannelTypes))
			throw CommunicationException(PTCCommunicationStatusCode_InvalidArgument, "Channel type is not supported by the device");
	}

	PTCMiscellaneousTag ToMiscellaneousTag(PTCChannelType channelType)
	{
		switch (channelType)
		{
			case PTCChannelType_Trigger:
				return PTCMiscellaneousTag_ChannelTypeTrigger;
			case PTCChannelType_Velocity:
				return PTCMiscellaneousTag_ChannelTypeVelocity;
			case PTCChannelType_Displacement:
				return PTCMiscellaneousTag_ChannelTypeDisplacement;
			case PTCChannelType_Acceleration:
				return PTCMiscellaneousTag_ChannelTypeAcceleration;
			case PTCChannelType_RSSI:
				return PTCMiscellaneousTag_ChannelTypeRSSI;
			default:
				throw std::logic_error("Cannot convert unknown channel type to miscellaneous tag.");
		}
	}

	PTCChannelType ToChannelType(PTCMiscellaneousTag miscellaneousTag)
	{
		switch (miscellaneousTag)
		{
			case PTCMiscellaneousTag_ChannelTypeTrigger:
				return PTCChannelType_Trigger;
			case PTCMiscellaneousTag_ChannelTypeVelocity:
				return PTCChannelType_Velocity;
			case PTCMiscellaneousTag_ChannelTypeDisplacement:
				return PTCChannelType_Displacement;
			case PTCMiscellaneousTag_ChannelTypeAcceleration:
				return PTCChannelType_Acceleration;
			case PTCMiscellaneousTag_ChannelTypeRSSI:
				return PTCChannelType_RSSI;
			default:
				throw std::logic_error("Cannot convert unknown miscellaneous tag to channel type.");
		}
	}

	std::vector<Channel> ActiveChannels(DeviceCommunication& communication)
	{
		if (CommandList(communication, PTCDeviceType_SignalProcessing)
			.HasCommand(PTCDeviceCommand_DaqActiveChannels))
		{
			std::vector<Channel> activeChannels;
			const auto channelActivation = ChannelActivation(communication);
			for (const auto& channelType : channelActivation.GetAllSupportedChannelTypes())
				for (const auto& channelId : channelActivation.GetActiveChannels(channelType))
					activeChannels.push_back({channelType, channelId});
			return activeChannels;
		}

		const auto daqProtocolType = static_cast<ProtocolType>
			(communication.SendGet<int16_t>(PTCDeviceType_SignalProcessing, PTCDeviceCommand_DAQProtocolType));
		if (daqProtocolType == ProtocolType::IVS500
			|| daqProtocolType == ProtocolType::IVS500Hotfix
			|| daqProtocolType == ProtocolType::VGO200Pioneer)
		{
			return IvsActiveChannels(communication);
		}

		throw CommunicationException(PTCCommunicationStatusCode_RuntimeError,
			"Unable to determine active channels from unknown device type / protocol.");
	}
}
