// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#include <IO/DeviceCommunication/Utils/CommandList.h>

#include <IO/DeviceCommunication/Device.h>
#include <IO/DeviceCommunication/DeviceCommunication.h>

#include <algorithm>
#include <boost/cast.hpp>

namespace
{
	auto ToDeviceCommands(const std::vector<int16_t>& commands)
	{
		std::vector<PTCDeviceCommand> result(std::size(commands));
		std::transform(std::cbegin(commands), std::cend(commands), std::begin(result),
			[](const auto& command) { return static_cast<PTCDeviceCommand>(command); });
		return result;
	}
}

namespace Polytec::IO
{
	CommandList::CommandList(const IO::DeviceCommunication& communication, const IO::Device& device)
		: m_commandList(ToDeviceCommands(communication.SendGet<std::vector<std::int16_t>>(device, PTCDeviceCommand_CommandList)))
	{}

	bool CommandList::HasCommand(PTCDeviceCommand deviceCommand) const
	{
		return std::find(std::cbegin(m_commandList), std::cend(m_commandList), deviceCommand) != std::cend(m_commandList);
	}

	std::vector<PTCDeviceCommand> CommandList::AllCommands() const
	{
		return m_commandList;
	}
}
