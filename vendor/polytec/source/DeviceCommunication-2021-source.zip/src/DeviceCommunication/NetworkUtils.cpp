// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#include <IO/DeviceCommunication/Detail/NetworkUtils.h>

namespace
{
	constexpr std::pair<int, int> c_reservedPorts = {60'100, 60'200};
}

namespace Polytec::IO
{
	/// <summary>Checks if a port is reserved.</summary>
	/// <param name="port">The port to be checked.</param>
	/// <returns>True if reserved.</returns>
	bool IsReservedPort(int port)
	{
		return port >= c_reservedPorts.first && port < c_reservedPorts.second;
	}

	/// <summary>Get the number of reserved ports</summary>
	/// <returns>Number of reserved ports.</returns>
	int NumberOfReservedPorts()
	{
		return c_reservedPorts.second - c_reservedPorts.first;
	}
}
