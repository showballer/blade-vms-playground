// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#include <IO/DeviceCommunication/Detail/ServiceThread.h>

#include <IO/DeviceCommunication/Detail/IService.h>

#include <boost/asio.hpp>

namespace Polytec::IO
{
	struct ServiceThread::Implementation
	{
		static auto Create(ServiceThread::Callback run, ServiceThread::ErrorHandler errorHandler)
		{
			if (!run || !errorHandler)
			{
				throw std::invalid_argument("Service thread callbacks may not be null.");
			}
			return [run, errorHandler]
			{
				try
				{
					run();
				}
				catch (const std::exception& e)
				{
					errorHandler(e);
				}
			};
		}

		Implementation(ServiceThread::Callback run, ServiceThread::Callback shutdown, ServiceThread::ErrorHandler errorHandler)
			: Run(Create(std::move(run), std::move(errorHandler)))
			, Shutdown(std::move(shutdown))
		{
			if (!Shutdown)
			{
				throw std::invalid_argument("Service thread callbacks may not be null.");
			}
		}

		std::function<void()> Run;
		std::function<void()> Shutdown;
		std::thread Thread;
		std::mutex Mutex;
	};

	/// <summary>Constructor.</summary>
	/// <param name="service">[in,out] The service.</param>
	ServiceThread::ServiceThread(IService& service)
		: ServiceThread(
		[&service] { service.Run(); },
		[&service] { service.Shutdown(); },
		[&service] (const std::exception& e) { service.HandleError(e); })
	{}

	/// <summary>Constructor.</summary>
	/// <param name="runCallback">The run callback.</param>
	/// <param name="shutdownCallback">The shutdown callback.</param>
	ServiceThread::ServiceThread(Callback run, Callback shutdown, ErrorHandler errorHandler)
		: m_implementation(std::make_unique<Implementation>(std::move(run), std::move(shutdown), std::move(errorHandler)))
	{}

	ServiceThread::ServiceThread(ServiceThread&&) noexcept = default;

	#pragma warning (push)
	#pragma warning (disable: 26447) // The function is declared 'noexcept' but calls function 'Stop()' which may throw exceptions(f.6).
	/// <summary>Destructor. Stops the service thread.</summary>
	ServiceThread::~ServiceThread() noexcept
	{
		if (m_implementation)
			Stop();
	}
	#pragma warning (pop)

	/// <summary>Starts a thread running the service. If the thread is already running, this function has no effect.</summary>
	void ServiceThread::Start()
	{
		CheckValid();
		std::lock_guard lock(m_implementation->Mutex);
		if (!m_implementation->Thread.joinable())
			m_implementation->Thread = std::thread(m_implementation->Run);
	}

	/// <summary>Stops the service thread.</summary>
	void ServiceThread::Stop()
	{
		CheckValid();
		std::lock_guard lock(m_implementation->Mutex);
		if (m_implementation->Thread.joinable())
		{
			m_implementation->Shutdown();
			m_implementation->Thread.join();
		}
	}

	ServiceThread CreateContextThread(boost::asio::io_context& ioContext, ServiceThread::ErrorHandler errorHandler)
	{
		return ServiceThread([&ioContext] { ioContext.run(); }, [&ioContext] { ioContext.stop(); }, std::move(errorHandler));
	}

	void ServiceThread::CheckValid() const
	{
		if (!m_implementation)
		{
			throw std::logic_error("Use of invalid service thread object.");
		}
	}
}
