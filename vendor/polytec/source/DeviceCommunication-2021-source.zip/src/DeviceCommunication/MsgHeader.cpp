// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#include <IO/DeviceCommunication/Detail/MsgHeader.h>

#include <IO/DeviceCommunication/Detail/DataReader.h>
#include <IO/DeviceCommunication/Detail/DataWriter.h>

#include <gsl/gsl_util>

using namespace Polytec::IO;

namespace
{
	constexpr std::size_t c_headerSize = 14;
}

/// <summary>Loads the message header from the binary data reader.</summary>
/// <param name="reader">[in,out] The reader from which the message header will be read.</param>
void MsgHeader::Load(DataReader& reader)
{
	reader.Read(m_msgType);
	reader.Read(m_sequenceNumber);
	reader.Read(m_multiCmd);
	reader.Read(m_multiPackageCmd);
	reader.Read(m_multiPackageCount);

	uint8_t reservedByte;
	reader.Read(reservedByte);

	reader.Read(m_packetSize);
}

/// <summary>Saves this message header to the binary data.</summary>
/// <param name="writer">[in,out] The binary data writer that will save the message header.</param>
void MsgHeader::Save(DataWriter& writer) const
{
	writer.Write(m_msgType);
	writer.Write(m_sequenceNumber);
	writer.Write(m_multiCmd);
	writer.Write(m_multiPackageCmd);
	writer.Write(m_multiPackageCount);

	constexpr uint8_t reservedByte = 0;
	writer.Write(reservedByte);

	writer.Write(m_packetSize);
}

/// <summary>Gets the message type.</summary>
/// <returns>The message type.</returns>
Polytec::IO::MsgType MsgHeader::GetMsgType() const
{
	return static_cast<MsgType>(m_msgType);
}

/// <summary>Gets message size, i.e. the size of the header with all packets.</summary>
/// <returns>The message size.</returns>
std::size_t MsgHeader::GetMsgSize() const
{
	if (m_packetSize < c_headerSize)
		throw std::logic_error("Can't get message size.");
	return m_packetSize;
}

/// <summary>Sets the message type.</summary>
/// <param name="value">The message type value.</param>
void MsgHeader::SetMsgType(MsgType value)
{
	m_msgType = static_cast<uint8_t>(value);
}

/// <summary>
/// Sets the sequence number. This is an upcounting number for each message data packet.
/// </summary>
/// <param name="value">The sequence number value.</param>
void MsgHeader::SetSequenceNumber(int value)
{
	m_sequenceNumber = value;
}

/// <summary>Sets message size, i.e. the size of the header with all packets.</summary>
/// <param name="value">The value.</param>
void MsgHeader::SetMsgSize(std::size_t value)
{
	if (value > std::numeric_limits<std::uint32_t>::max())
		throw std::invalid_argument("Message size to large for message header.");
	m_packetSize = gsl::narrow_cast<std::uint32_t>(value);
}
