// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#include <IO/DeviceCommunication/CommunicationException.h>

#include <IO/DeviceCommunication/Detail/StringConverter.h>
#include <IO/DeviceCommunication/PTCCommunicationStatusCode.h>

#include <string>

using Polytec::IO::CommunicationException;

CommunicationException::CommunicationException(const PTCCommunicationStatusCode statusCode,
	const std::wstring& additionalInformation)
	: m_statusCode(statusCode),
	m_additionalInformation(additionalInformation)
{}

CommunicationException::CommunicationException(const PTCCommunicationStatusCode statusCode,
	const std::string& additionalInformation)
	: CommunicationException(statusCode, ToWString(additionalInformation))
{}

PTCCommunicationStatusCode CommunicationException::GetStatusCode() const noexcept
{
	return m_statusCode;
}

#pragma warning(push)
#pragma warning(disable: 26447) // The function is declared 'noexcept' but calls function '...' which may throw exceptions (f.6).
const char* CommunicationException::what() const noexcept
{
	m_message = StatusMessage();
	if (!m_additionalInformation.empty())
	{
		m_message += " (" + AdditionalInformation() + ")";
	}
	return m_message.c_str();
}
#pragma warning(pop)

std::string CommunicationException::AdditionalInformation() const
{
	try
	{
		return ToString(m_additionalInformation);
	}
	catch (const std::exception& e)
	{
		return std::string("Communication exception conversion failed: ") + e.what();
	}
}

std::string CommunicationException::StatusMessage() const
{
	switch (m_statusCode)
	{
		case PTCCommunicationStatusCode_Success:
			return "Success.";
		case PTCCommunicationStatusCode_UnknownDeviceError:
			return "Firmware error: Unknown device error: The device firmware encountered an unknown error.";
		case PTCCommunicationStatusCode_WrongCommandType:
			return "Firmware error: Wrong command type: The device firmware received a wrong command type.";
		case PTCCommunicationStatusCode_WrongDeviceType:
			return "Firmware error: Wrong device type: The device firmware received a command that can't be handled by the device type.";
		case PTCCommunicationStatusCode_WrongDeviceNumber:
			return "Firmware error: Wrong device number: The device firmware received a command to a device number which is not installed.";
		case PTCCommunicationStatusCode_WrongAttribute:
			return "Firmware error: Wrong attribute: The device firmware received a wrong device command.";
		case PTCCommunicationStatusCode_WrongPayloadType:
			return "Firmware error: Wrong payload type: The device firmware received a set-command with a wrong payload type.";
		case PTCCommunicationStatusCode_WrongPayloadData:
			return "Firmware error: Wrong payload data: The device firmware received a command with wrong payload data, i.e. with a value which is out of range.";
		case PTCCommunicationStatusCode_ScanArrayBufferUnderrun:
			return "Firmware error: Scan array buffer underrun";
		case PTCCommunicationStatusCode_ScanArrayBufferOverrun:
			return "Firmware error: Scan array buffer overrun";
		case PTCCommunicationStatusCode_WrongExtraTag:
			return "Firmware error: Wrong extra tag: The device firmware received a command with a wrong miscellaneous tag.";
		case PTCCommunicationStatusCode_NotInstalled:
			return "Firmware error: Not installed: The device firmware received a command to a device type which is not installed.";
		case PTCCommunicationStatusCode_WrongOperationMode:
			return "Firmware error: Wrong operation mode";
		case PTCCommunicationStatusCode_MemoryOverrun:
			return "Firmware error: Memory overrun";
		case PTCCommunicationStatusCode_DeviceNotReady:
			return "Firmware error: Device not ready";
		case PTCCommunicationStatusCode_DeviceNotResponding:
			return "Firmware error: Device not responding";
		case PTCCommunicationStatusCode_WrongI2CAnswer:
			return "Firmware error: Wrong I2C answer";
		case PTCCommunicationStatusCode_WrongCRCResult:
			return "Firmware error: Wrong CRC result attribute";
		case PTCCommunicationStatusCode_LaserDisabled:
			return "Firmware error: Laser disabled";
		case PTCCommunicationStatusCode_FlashDeviceMismatch:
			return "Firmware error: Flash device mismatch";
		case PTCCommunicationStatusCode_FlashWriteFailed:
			return "Firmware error: Flash write failed";
		case PTCCommunicationStatusCode_SensorLimitReached:
			return "Firmware error: Sensor limit reached";
		case PTCCommunicationStatusCode_NotEnoughMemory:
			return "Firmware error: Not enough memory";
		case PTCCommunicationStatusCode_ContentMismatch:
			return "Firmware error: Content mismatch";
		case PTCCommunicationStatusCode_ExecutionFailed:
			return "Firmware error: Execution failed";
		case PTCCommunicationStatusCode_WriteLockFailed:
			return "Write-Lock failed. A write lock is needed to perform set-commands on this device.";
		case PTCCommunicationStatusCode_NoPermission:
			return "No permission.";
		case PTCCommunicationStatusCode_InvalidConfiguration:
			return "Invalid configuration.";

		case PTCCommunicationStatusCode_UnknownError:
			return "Unknown software error: An unknown error occurred in the interface software.";
		case PTCCommunicationStatusCode_LogicError:
			return "Logic error.";
		case PTCCommunicationStatusCode_InvalidArgument:
			return "Invalid argument: A function was called with an invalid argument.";
		case PTCCommunicationStatusCode_RangeError:
			return "Range error.";
		case PTCCommunicationStatusCode_SystemError:
			return "System error.";
		case PTCCommunicationStatusCode_BadCast:
			return "Bad cast.";
		case PTCCommunicationStatusCode_BadAlloc:
			return "Bad alloc: Failed to allocate memory storage.";
		case PTCCommunicationStatusCode_BufferOverflow:
			return "Buffer overflow.";
		case PTCCommunicationStatusCode_Timeout:
			return "Timeout: The device is not responding within the timeout. A command was sent to the device but it is not responding.";
		case PTCCommunicationStatusCode_InvalidResponseFormat:
			return "Invalid response format: The device sent a response with an invalid format.";
		case PTCCommunicationStatusCode_ReceivedWrongPayloadType:
			return "Received wrong payload type: The received payload type from a Get/GetDevInfo/GetValueList-command does not match the expected payload type.";
		case PTCCommunicationStatusCode_RuntimeError:
			return "Runtime error.";
		default:
			return "Status code: " + std::to_string(m_statusCode);
	}
}
