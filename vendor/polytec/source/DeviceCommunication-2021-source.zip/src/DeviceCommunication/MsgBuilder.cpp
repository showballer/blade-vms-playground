// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#include <IO/DeviceCommunication/Detail/MsgBuilder.h>

#include <IO/DeviceCommunication/Detail/DataWriter.h>
#include <IO/DeviceCommunication/Detail/MsgHeader.h>
#include <IO/DeviceCommunication/Detail/MsgResponse.h>
#include <IO/DeviceCommunication/Detail/MsgRequest.h>
#include <IO/DeviceCommunication/Detail/MsgType.h>

using namespace Polytec::IO;

/// <summary>Builds the given message data packet. A header will be created. The header and the
/// 		 data packet will be returned as binary data.</summary>
/// <typeparam name="TPacket">Type of the packet.</typeparam>
/// <param name="packet">The message data packet.</param>
/// <returns>The message data packet with header as binary data.</returns>
template<typename TPacket>
std::vector<std::byte> MsgBuilder<TPacket>::Build(const TPacket& packet)
{
	const MsgType msgType = EvaluateMsgType(packet);
	MsgHeader header;
	header.SetMsgType(msgType);
	header.SetSequenceNumber(m_sequenceNumber++);
	header.SetMsgSize(Size(header) + Size(packet, msgType));

	std::vector<std::byte> data;
	DataWriter writer(data);
	header.Save(writer);
	packet.Save(writer, msgType);

	return data;
}

template std::vector<std::byte> MsgBuilder<MsgRequest>::Build(const MsgRequest&);
template std::vector<std::byte> MsgBuilder<MsgResponse>::Build(const MsgResponse&);
