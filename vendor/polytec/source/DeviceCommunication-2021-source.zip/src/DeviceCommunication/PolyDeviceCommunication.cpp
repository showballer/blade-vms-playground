// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.


#define BUILD_COMMAPI // This is needed to export symbols when creating a DLL. It is used in PolyDeviceCommunication.h.
#include <IO/DeviceCommunication/PolyDeviceCommunication.h>

#include <IO/DeviceCommunication/AllCommunication.h>
#include <IO/DeviceCommunication/Detail/CommandType.h>
#include <IO/Devicecommunication/Detail/CommunicationImplementation.h>
#include <IO/DeviceCommunication/Detail/CommunicationResource.h>
#include <IO/DeviceCommunication/Detail/DataReader.h>
#include <IO/DeviceCommunication/Detail/HandleManager.h>
#include <IO/DeviceCommunication/Detail/PayloadTypeTraits.h>
#include <IO/DeviceCommunication/Detail/StringConverter.h>

#include <boost/algorithm/string/join.hpp>
#include <map>
#include <utility>

#pragma warning(disable: 4996) // strcpy

using namespace Polytec::IO;

namespace
{
	/// <summary>A structure that can hold payload data. The payload data can be used to receive or send
	/// 		 information from or to the device.</summary>
	struct PTPayload
	{
		PayloadType type;
		void* data;
		size_t size;
	};

	template <typename T>
	void CheckValid(const T* value)
	{
		if (!value)
		{
			throw CommunicationException(PTCCommunicationStatusCode_InvalidArgument,
				"Argument may not be null.");
		}
	}

	int SizeOf(PayloadType payloadType)
	{
		switch (payloadType)
		{
			case PayloadType::Ascii:
				return 1;
			case PayloadType::Byte:
				return 1;
			case PayloadType::Int16:
				return 2;
			case PayloadType::UInt16:
				return 2;
			case PayloadType::Int32:
				return 4;
			case PayloadType::UInt32:
				return 4;
			case PayloadType::Float32:
				return 4;
			case PayloadType::Float64:
				return 8;
			case PayloadType::UTF8:
				return 1;
			case PayloadType::None:
				return 0;
			case PayloadType::Unknown:
			default:
				throw std::invalid_argument("unknown payload type");
		}
	}

	void CreatePayload(PayloadType payloadType, const std::vector<std::byte>& commandData,
		PTPayloadHandle& payloadHandle)
	{
		if (SizeOf(payloadType) == 0 || commandData.size() % SizeOf(payloadType) != 0)
		{
			throw CommunicationException(PTCCommunicationStatusCode_InvalidResponseFormat);
		}
		PTPayload payload;
		#pragma warning(suppress: 26408) // Avoid malloc() and free(), prefer the nothrow version of new with delete (r.10).
		payload.data = malloc(commandData.size());
		if (payload.data)
		{
			payload.type = payloadType;
			payload.size = commandData.size() / SizeOf(payloadType);
			std::memcpy(payload.data, commandData.data(), commandData.size());
			
			payloadHandle = GetHandleManager<PTPayload>().Create(payload);
		}
		else
		{
			throw CommunicationException(PTCCommunicationStatusCode_BadAlloc);
		}
	}

	std::vector<std::byte> ToNullTerminatedStringData(std::vector<std::byte> data)
	{
		DataWriter writer(data);
		writer.Write('\0');
		return data;
	}

	void DoSendGet(PTCommunicationHandle communicationHandle, PTCDeviceType deviceType,
		int deviceNumber, PTCDeviceCommand deviceCommand, CommandType commandType,
		PTCMiscellaneousTag tag, PTPayloadHandle& payloadHandle)
	{
		const auto [payloadType, commandData]
			= GetHandleManager<CommunicationResource>().Get(communicationHandle).DeviceCommunication().GetImpl()
			.SendGet(commandType, Device(deviceType, deviceNumber), deviceCommand, tag, PayloadType::None, {});

		if (payloadType == PayloadType::Ascii)
		{
			throw std::logic_error("SendGet is expected to convert ASCII to UTF8.");
		}

		CreatePayload(
			payloadType,
			(payloadType == PayloadType::UTF8) ? ToNullTerminatedStringData(commandData) : commandData,
			payloadHandle);
	}

	PTCCommunicationStatusCode SendGetPayloadHandle(PTCommunicationHandle communicationHandle, PTCDeviceType deviceType,
		int deviceNumber, PTCDeviceCommand deviceCommand, CommandType commandType,
		PTPayloadHandle* receivedPayload, PTCMiscellaneousTag tag)
	{
		return Try([communicationHandle, deviceType, deviceNumber, deviceCommand, commandType, receivedPayload, tag]
		{
			CheckValid(receivedPayload);
			*receivedPayload = 0;
			DoSendGet(communicationHandle, deviceType, deviceNumber, deviceCommand,
				commandType, tag, *receivedPayload);
		});
	}

	void DoSendSet(PTCommunicationHandle communicationHandle, PTCDeviceType deviceType, int deviceNumber,
		PTCDeviceCommand deviceCommand, PTPayloadHandle payloadHandle, PTCMiscellaneousTag tag)
	{
		const PTPayload& payload = GetHandleManager<PTPayload>().Get(payloadHandle);
		std::vector<std::byte> commandData;
		DataWriter writer(commandData);
		writer.Write(payload.data, payload.size * SizeOf(payload.type));

		GetHandleManager<CommunicationResource>().Get(communicationHandle)
			.DeviceCommunication().GetImpl().SendSet(
			CommandType::Set, Device(deviceType, deviceNumber), deviceCommand, tag, payload.type, commandData);
	}

	PTCCommunicationStatusCode SendSetPayloadHandle(PTCommunicationHandle communicationHandle, PTCDeviceType deviceType,
		int deviceNumber, PTCDeviceCommand deviceCommand, PTPayloadHandle handle, PTCMiscellaneousTag tag)
	{
		return Try([communicationHandle, deviceType, deviceNumber, deviceCommand, handle, tag]
		{
			DoSendSet(communicationHandle, deviceType, deviceNumber, deviceCommand, handle, tag);
		});
	}

	template<typename TPayload>
	PTCCommunicationStatusCode SendGet(PTCommunicationHandle communicationHandle,
		PTCDeviceType deviceType, int deviceNumber, PTCDeviceCommand deviceCommand, TPayload *payload)
	{
		return Try([communicationHandle, deviceType, deviceNumber, deviceCommand, payload]
		{
			CheckValid(payload);
			*payload = GetHandleManager<CommunicationResource>().Get(communicationHandle)
				.DeviceCommunication().SendGet<TPayload>({deviceType, deviceNumber}, deviceCommand);
		});
	}

	template<typename TPayload>
	PTCCommunicationStatusCode SendSet(PTCommunicationHandle communicationHandle,
		PTCDeviceType deviceType, int deviceNumber, PTCDeviceCommand deviceCommand, const TPayload& payload, PTCMiscellaneousTag tag = PTCMiscellaneousTag_None)
	{
		return Try([communicationHandle, deviceType, deviceNumber, deviceCommand, payload, tag]
		{
			GetHandleManager<CommunicationResource>().Get(communicationHandle)
				.DeviceCommunication().SendSet<TPayload>({deviceType, deviceNumber}, deviceCommand, payload, tag);
		});
	}

	template<typename TPayload>
	PTPayloadHandle CreatePayload(const TPayload* value, std::size_t size)
	{
		try
		{
			if (!value || !size)
			{
				return 0;
			}
			PTPayload payload;
			#pragma warning(suppress: 26408) // Avoid malloc() and free(), prefer the nothrow version of new with delete (r.10).
			payload.data = malloc(size * sizeof(TPayload));
			if (payload.data)
			{
				payload.type = c_payloadType<TPayload>;
				payload.size = size;
				std::memcpy(payload.data, value, size * sizeof(TPayload));
				return GetHandleManager<PTPayload>().Create(payload);
			}
			else
			{
				return 0;
			}
		}
		catch (const std::exception&)
		{
			return 0;
		}
	}

	template<typename TPayload>
	PTCCommunicationStatusCode GetPayload(PTPayloadHandle payloadHandle,
		TPayload* payloadBuffer, std::size_t* payloadSize, std::size_t bufferSize)
	{
		return Try([payloadHandle, payloadBuffer, payloadSize, bufferSize] () mutable
		{
			if (!payloadSize)
			{
				static std::size_t ignorePayloadSize{};
				payloadSize = &ignorePayloadSize;
			}
			*payloadSize = 0;
			if (!GetHandleManager<PTPayload>().IsValidHandle(payloadHandle) || !payloadBuffer)
			{
				throw CommunicationException(PTCCommunicationStatusCode_InvalidArgument);
			}
			const PTPayload& payload = GetHandleManager<PTPayload>().Get(payloadHandle);
			if (bufferSize < payload.size)
			{
				*payloadSize = payload.size;
				throw CommunicationException(PTCCommunicationStatusCode_RangeError,
					"The buffer size is to small for the received payload.");
			}
			if (c_payloadType<TPayload> != payload.type)
			{
				throw CommunicationException(PTCCommunicationStatusCode_ReceivedWrongPayloadType);
			}
			std::memcpy(payloadBuffer, payload.data, payload.size * sizeof(TPayload));
			*payloadSize = payload.size;
		});
	}
}

extern "C"
void PolyLastCommunicationStatus(char* message, size_t bufferSize)
{
	if (!message)
	{
		return;
	}
	std::strncpy(message, GetLastCommunicationError().c_str(), bufferSize);
	message[bufferSize - 1] = '\0';
}

extern "C"
PTCCommunicationStatusCode PolyOpenUdpEthernetCommunication(PTCommunicationHandle* communicationHandle,
	const char* ipAddress, int timeoutInMilliseconds)
{
	return Try([communicationHandle, ipAddress, timeoutInMilliseconds]
	{
		CheckValid(communicationHandle);
		*communicationHandle = 0;
		CheckValid(ipAddress);
		*communicationHandle = GetHandleManager<CommunicationResource>().Create(
			CreateUdpEthernetCommunication(ToWString(ipAddress), std::chrono::milliseconds(timeoutInMilliseconds)));
	});
}

extern "C"
PTCCommunicationStatusCode PolyOpenTcpEthernetCommunication(PTCommunicationHandle* communicationHandle,
	const char* ipAddress, int timeoutInMilliseconds)
{
	return Try([communicationHandle, ipAddress, timeoutInMilliseconds]
	{
		CheckValid(communicationHandle);
		*communicationHandle = 0;
		CheckValid(ipAddress);
		*communicationHandle = GetHandleManager<CommunicationResource>().Create(
			CreateTcpEthernetCommunication(ToWString(ipAddress), std::chrono::milliseconds(timeoutInMilliseconds)));
	});
}

extern "C"
PTCCommunicationStatusCode PolyOpenSerialCommunication(PTCommunicationHandle* communicationHandle,
	const char* comPort, int baudRate, int timeoutInMilliseconds)
{
	return Try([communicationHandle, comPort, baudRate, timeoutInMilliseconds]
	{
		CheckValid(communicationHandle);
		*communicationHandle = 0;
		CheckValid(comPort);
		*communicationHandle = GetHandleManager<CommunicationResource>().Create(
			CreateSerialCommunication(ToWString(comPort), baudRate, std::chrono::milliseconds(timeoutInMilliseconds)));
	});
}

extern "C"
void PolyCloseCommunication(PTCommunicationHandle communicationHandle)
{
	GetHandleManager<CommunicationResource>().Delete(communicationHandle);
}

// ----
// The following methods offer higher level control for the most common uses. For full control see the lower level methods section.
// ----

extern "C"
PTCCommunicationStatusCode PolyItemListGetAllItems(PTCommunicationHandle communicationHandle,
	PTCDeviceType deviceType, int deviceNumber, PTCDeviceCommand deviceCommand, char* buffer, size_t bufferSize)
{
	return Try([communicationHandle, deviceType, deviceNumber, deviceCommand, buffer, bufferSize]
	{
		CheckValid(buffer);

		const auto& itemList = GetHandleManager<CommunicationResource>().Get(communicationHandle)
			.ItemList(deviceType, deviceNumber, deviceCommand);
		const auto allItems = ToString(boost::algorithm::join(itemList.GetAllItems(), ","));

		if (allItems.size() > bufferSize)
			throw CommunicationException(PTCCommunicationStatusCode_RangeError, "The buffer is too small.");

		strncpy(buffer, allItems.c_str(), bufferSize);
	});
}

extern "C"
PTCCommunicationStatusCode PolyItemListGetAvailableItems(PTCommunicationHandle communicationHandle,
	PTCDeviceType deviceType, int deviceNumber, PTCDeviceCommand deviceCommand, char* buffer, size_t bufferSize)
{
	return Try([communicationHandle, deviceType, deviceNumber, deviceCommand, buffer, bufferSize]
	{
		CheckValid(buffer);

		const auto& itemList = GetHandleManager<CommunicationResource>().Get(communicationHandle)
			.ItemList(deviceType, deviceNumber, deviceCommand);
		const auto allItems = ToString(boost::algorithm::join(itemList.GetAvailableItems(), ","));

		if (allItems.size() > bufferSize)
			throw CommunicationException(PTCCommunicationStatusCode_RangeError, "The buffer is too small.");

		strncpy(buffer, allItems.c_str(), bufferSize);
	});
}

extern "C"
PTCCommunicationStatusCode PolyItemListGetCurrentItem(PTCommunicationHandle communicationHandle,
	PTCDeviceType deviceType, int deviceNumber, PTCDeviceCommand deviceCommand, char* buffer, size_t bufferSize)
{
	return Try([communicationHandle, deviceType, deviceNumber, deviceCommand, buffer, bufferSize]
	{
		CheckValid(buffer);

		const auto& itemList = GetHandleManager<CommunicationResource>().Get(communicationHandle)
			.ItemList(deviceType, deviceNumber, deviceCommand);
		const auto currentItem = ToString(itemList.GetCurrentItem());

		if (currentItem.size() > bufferSize)
			throw CommunicationException(PTCCommunicationStatusCode_RangeError, "The buffer is too small.");

		strncpy(buffer, currentItem.c_str(), bufferSize);
	});
}

extern "C"
PTCCommunicationStatusCode PolyItemListSetCurrentItem(PTCommunicationHandle communicationHandle,
	PTCDeviceType deviceType, int deviceNumber, PTCDeviceCommand deviceCommand, const char* item)
{
	return Try([communicationHandle, deviceType, deviceNumber, deviceCommand, item]
	{
		CheckValid(item);

		auto& itemList = GetHandleManager<CommunicationResource>().Get(communicationHandle)
			.ItemList(deviceType, deviceNumber, deviceCommand);
		const auto allItems = itemList.GetAllItems();
		const auto itemToSet = ToWString(item);

		if (std::find(allItems.begin(), allItems.end(), itemToSet) == allItems.end())
			throw CommunicationException(PTCCommunicationStatusCode_InvalidArgument);
		itemList.SetCurrentItem(itemToSet);
	});
}

extern "C"
PTCCommunicationStatusCode PolyItemListIsItemAvailable(PTCommunicationHandle communicationHandle,
	PTCDeviceType deviceType, int deviceNumber, PTCDeviceCommand deviceCommand, const char* item, bool* result)
{
	return Try([communicationHandle, deviceType, deviceNumber, deviceCommand, item, result]
	{
		CheckValid(result);
		*result = false;
		CheckValid(item);

		*result = GetHandleManager<CommunicationResource>().Get(communicationHandle)
			.ItemList(deviceType, deviceNumber, deviceCommand).IsItemAvailable(ToWString(item));
	});
}

extern "C"
PTCCommunicationStatusCode PolySendGetFloat(PTCommunicationHandle communicationHandle,
	PTCDeviceType deviceType, int deviceNumber, PTCDeviceCommand deviceCommand, float* payload)
{
	return SendGet(communicationHandle, deviceType, deviceNumber, deviceCommand, payload);
}

extern "C"
PTCCommunicationStatusCode PolySendSetFloat(PTCommunicationHandle communicationHandle,
	PTCDeviceType deviceType, int deviceNumber, PTCDeviceCommand deviceCommand, float payload)
{
	return SendSet<float>(communicationHandle, deviceType, deviceNumber, deviceCommand, payload);
}

extern "C"
PTCCommunicationStatusCode PolySendGetInt16(PTCommunicationHandle communicationHandle,
	PTCDeviceType deviceType, int deviceNumber, PTCDeviceCommand deviceCommand, int16_t* payload)
{
	return SendGet(communicationHandle, deviceType, deviceNumber, deviceCommand, payload);
}

extern "C"
PTCCommunicationStatusCode PolySendSetInt16(PTCommunicationHandle communicationHandle,
	PTCDeviceType deviceType, int deviceNumber, PTCDeviceCommand deviceCommand, int16_t payload)
{
	return SendSet<int16_t>(communicationHandle, deviceType, deviceNumber, deviceCommand, payload);
}

extern "C"
PTCCommunicationStatusCode PolySendGetInt32(PTCommunicationHandle communicationHandle,
	PTCDeviceType deviceType, int deviceNumber, PTCDeviceCommand deviceCommand, int32_t* payload)
{
	return SendGet(communicationHandle, deviceType, deviceNumber, deviceCommand, payload);
}

extern "C"
PTCCommunicationStatusCode PolySendSetInt32(PTCommunicationHandle communicationHandle,
	PTCDeviceType deviceType, int deviceNumber, PTCDeviceCommand deviceCommand, int32_t payload)
{
	return SendSet<int32_t>(communicationHandle, deviceType, deviceNumber, deviceCommand, payload);
}

extern "C"
PTCCommunicationStatusCode PolySendGetString(PTCommunicationHandle communicationHandle,
	PTCDeviceType deviceType, int deviceNumber, PTCDeviceCommand deviceCommand, char* payload, size_t bufferSize)
{
	return Try([communicationHandle, deviceType, deviceNumber, deviceCommand, payload, bufferSize]
	{
		CheckValid(payload);
		std::string payloadStr = GetHandleManager<CommunicationResource>().Get(communicationHandle)
			.DeviceCommunication().SendGet<std::string>({deviceType, deviceNumber}, deviceCommand);
		if (payloadStr.size() > bufferSize)
			throw CommunicationException(PTCCommunicationStatusCode_RangeError, "The buffer is too small.");
		strncpy(payload, payloadStr.c_str(), bufferSize);
	});
}

extern "C"
PTCCommunicationStatusCode PolySendSetString(PTCommunicationHandle communicationHandle,
	PTCDeviceType deviceType, int deviceNumber, PTCDeviceCommand deviceCommand, const char* payload)
{
	// use Try to assure LastError to be set correctly
	auto status = Try([payload] { CheckValid(payload); });
	if (status == PTCCommunicationStatusCode_Success)
		status = SendSet<std::string>(communicationHandle, deviceType, deviceNumber, deviceCommand, payload);
	return status;
}

extern "C"
PTCCommunicationStatusCode PolySendGetDevInfoRange(PTCommunicationHandle communicationHandle,
	PTCDeviceType deviceType, int deviceNumber, PTCDeviceCommand deviceCommand, int16_t* minimum, int16_t* maximum)
{
	return Try([communicationHandle, deviceType, deviceNumber, deviceCommand, minimum, maximum]
	{
		CheckValid(minimum);
		CheckValid(maximum);

		const auto rangeIndices = GetHandleManager<CommunicationResource>().Get(communicationHandle)
			.DeviceCommunication().SendGetDevInfo<std::vector<std::int16_t>>({deviceType, deviceNumber}, deviceCommand);

		if (rangeIndices.size() != 2)
			throw CommunicationException(PTCCommunicationStatusCode_InvalidResponseFormat);

		*minimum = rangeIndices[0];
		*maximum = rangeIndices[1];
	});
}

extern "C"
PTCCommunicationStatusCode PolyHasDevice(PTCommunicationHandle communicationHandle,
	PTCDeviceType deviceType, int deviceNumber, bool* result)
{
	return Try([communicationHandle, deviceType, deviceNumber, result]
	{
		CheckValid(result);
		*result = GetHandleManager<CommunicationResource>().Get(communicationHandle)
			.DeviceList().HasDevice({deviceType, deviceNumber});
	});
}

extern "C"
PTCCommunicationStatusCode PolyHasCommand(PTCommunicationHandle communicationHandle,
	PTCDeviceType deviceType, int deviceNumber, PTCDeviceCommand deviceCommand, bool* result)
{
	return Try([communicationHandle, deviceType, deviceNumber, deviceCommand, result]
	{
		CheckValid(result);
		*result = GetHandleManager<CommunicationResource>().Get(communicationHandle)
			.CommandList(deviceType, deviceNumber).HasCommand(deviceCommand);
	});
}

// ----
// The following methods offer lower level control. See the higher level methods section for an abstraction that may be sufficient for most uses.
// ----

extern "C"
PTCCommunicationStatusCode PolySendGet(PTCommunicationHandle communicationHandle, PTCDeviceType deviceType,
	int deviceNumber, PTCDeviceCommand deviceCommand, PTPayloadHandle* receivedPayload)
{
	return SendGetPayloadHandle(communicationHandle, deviceType, deviceNumber, deviceCommand,
		CommandType::Get, receivedPayload, PTCMiscellaneousTag_None);
}

extern "C"
PTCCommunicationStatusCode PolySendGetDevInfo(PTCommunicationHandle communicationHandle, PTCDeviceType deviceType,
	int deviceNumber, PTCDeviceCommand deviceCommand, PTPayloadHandle* receivedPayload)
{
	return SendGetPayloadHandle(communicationHandle, deviceType, deviceNumber, deviceCommand,
		CommandType::GetDevInfo, receivedPayload, PTCMiscellaneousTag_None);
}

extern "C"
PTCCommunicationStatusCode PolySendGetValueList(PTCommunicationHandle communicationHandle, PTCDeviceType deviceType,
	int deviceNumber, PTCDeviceCommand deviceCommand, PTPayloadHandle* receivedPayload)
{
	return SendGetPayloadHandle(communicationHandle, deviceType, deviceNumber, deviceCommand,
		CommandType::GetValueList, receivedPayload, PTCMiscellaneousTag_None);
}

extern "C"
PTCCommunicationStatusCode PolySendSet(PTCommunicationHandle communicationHandle, PTCDeviceType deviceType,
	int deviceNumber, PTCDeviceCommand deviceCommand, PTPayloadHandle payload)
{
	return SendSetPayloadHandle(communicationHandle, deviceType, deviceNumber,
		deviceCommand, payload, PTCMiscellaneousTag_None);
}

extern "C"
PTCCommunicationStatusCode PolySendGetWithTag(PTCommunicationHandle communicationHandle,
	PTCDeviceType deviceType, int deviceNumber, PTCDeviceCommand deviceCommand, PTCMiscellaneousTag tag,
	PTPayloadHandle* payload)
{
	return SendGetPayloadHandle(communicationHandle, deviceType,
		deviceNumber, deviceCommand, CommandType::Get, payload, tag);
}

extern "C"
PTCCommunicationStatusCode PolySendGetDevInfoWithTag(PTCommunicationHandle communicationHandle,
	PTCDeviceType deviceType, int deviceNumber, PTCDeviceCommand deviceCommand, PTCMiscellaneousTag tag,
	PTPayloadHandle* payload)
{
	return SendGetPayloadHandle(communicationHandle, deviceType,
		deviceNumber, deviceCommand, CommandType::GetDevInfo, payload, tag);
}

extern "C"
PTCCommunicationStatusCode PolySendGetValueListWithTag(PTCommunicationHandle communicationHandle,
	PTCDeviceType deviceType, int deviceNumber, PTCDeviceCommand deviceCommand, PTCMiscellaneousTag tag,
	PTPayloadHandle* payload)
{
	return SendGetPayloadHandle(communicationHandle, deviceType,
		deviceNumber, deviceCommand, CommandType::GetValueList, payload, tag);
}

extern "C"
PTCCommunicationStatusCode PolySendSetWithTag(PTCommunicationHandle communicationHandle, PTCDeviceType deviceType,
	int deviceNumber, PTCDeviceCommand deviceCommand, PTCMiscellaneousTag tag, PTPayloadHandle payload)
{
	return SendSetPayloadHandle(communicationHandle, deviceType, deviceNumber, deviceCommand, payload, tag);
}

extern "C"
void PolyFreePayload(PTPayloadHandle payloadHandle)
{
	auto& payloadInstance = GetHandleManager<PTPayload>();
	if (!payloadInstance.IsValidHandle(payloadHandle))
	{
		return;
	}
	std::free(payloadInstance.Get(payloadHandle).data);
	payloadInstance.Delete(payloadHandle);
}

extern "C"
PTPayloadHandle PolyCreatePayloadFromCStr(const char* value)
{
	return CreatePayload(value, std::strlen(value));
}

extern "C"
PTPayloadHandle PolyCreatePayloadFromUInt8(const uint8_t* value, std::size_t size)
{
	return CreatePayload(value, size);
}

extern "C"
PTPayloadHandle PolyCreatePayloadFromInt16(const int16_t* value, std::size_t size)
{
	return CreatePayload(value, size);
}

extern "C"
PTPayloadHandle PolyCreatePayloadFromUInt16(const uint16_t* value, std::size_t size)
{
	return CreatePayload(value, size);
}

extern "C"
PTPayloadHandle PolyCreatePayloadFromInt32(const int32_t* value, std::size_t size)
{
	return CreatePayload(value, size);
}

extern "C"
PTPayloadHandle PolyCreatePayloadFromUInt32(const uint32_t* value, std::size_t size)
{
	return CreatePayload(value, size);
}

extern "C"
PTPayloadHandle PolyCreatePayloadFromFloat(const float* value, std::size_t size)
{
	return CreatePayload(value, size);
}

extern "C"
PTPayloadHandle PolyCreatePayloadFromDouble(const double* value, std::size_t size)
{
	return CreatePayload(value, size);
}

extern "C"
PTCCommunicationStatusCode PolyGetCStrFromPayload(PTPayloadHandle payloadHandle,
	char* payloadBuffer, std::size_t bufferSize)
{
	std::size_t size;
	const auto status = GetPayload(payloadHandle, payloadBuffer, &size, bufferSize - 1);
	payloadBuffer[size] = '\0';
	return status;
}

extern "C"
PTCCommunicationStatusCode PolyGetUInt8FromPayload(PTPayloadHandle payloadHandle,
	uint8_t* payloadBuffer, std::size_t* payloadSize, std::size_t bufferSize)
{
	return GetPayload(payloadHandle, payloadBuffer, payloadSize, bufferSize);
}

extern "C"
PTCCommunicationStatusCode PolyGetInt16FromPayload(PTPayloadHandle payloadHandle,
	int16_t* payloadBuffer, std::size_t* payloadSize, std::size_t bufferSize)
{
	return GetPayload(payloadHandle, payloadBuffer, payloadSize, bufferSize);
}

extern "C"
PTCCommunicationStatusCode PolyGetUInt16FromPayload(PTPayloadHandle payloadHandle,
	uint16_t* payloadBuffer, std::size_t* payloadSize, std::size_t bufferSize)
{
	return GetPayload(payloadHandle, payloadBuffer, payloadSize, bufferSize);
}

extern "C"
PTCCommunicationStatusCode PolyGetInt32FromPayload(PTPayloadHandle payloadHandle,
	int32_t* payloadBuffer, std::size_t* payloadSize, std::size_t bufferSize)
{
	return GetPayload(payloadHandle, payloadBuffer, payloadSize, bufferSize);
}

extern "C"
PTCCommunicationStatusCode PolyGetUInt32FromPayload(PTPayloadHandle payloadHandle,
	uint32_t* payloadBuffer, std::size_t* payloadSize, std::size_t bufferSize)
{
	return GetPayload(payloadHandle, payloadBuffer, payloadSize, bufferSize);
}

extern "C"
PTCCommunicationStatusCode PolyGetFloatFromPayload(PTPayloadHandle payloadHandle,
	float* payloadBuffer, std::size_t* payloadSize, std::size_t bufferSize)
{
	return GetPayload(payloadHandle, payloadBuffer, payloadSize, bufferSize);
}

extern "C"
PTCCommunicationStatusCode PolyGetDoubleFromPayload(PTPayloadHandle payloadHandle,
	double* payloadBuffer, std::size_t* payloadSize, std::size_t bufferSize)
{
	return GetPayload(payloadHandle, payloadBuffer, payloadSize, bufferSize);
}

extern "C"
void PolyDeviceIPAddress(PTCommunicationHandle communicationHandle, char* ipAddress, std::size_t bufferSize)
{
	if (!ipAddress || bufferSize == 0)
	{
		return;
	}

	if (GetHandleManager<CommunicationResource>().IsValidHandle(communicationHandle))
	{
		const auto deviceAddress
			= GetHandleManager<CommunicationResource>().Get(communicationHandle)
			.DeviceCommunication().DeviceIPAddress();

		std::strncpy(ipAddress, ToString(deviceAddress).c_str(), bufferSize);
		ipAddress[bufferSize - 1] = '\0';
	}
	else
	{
		ipAddress[0] = '\0';
	}
}
