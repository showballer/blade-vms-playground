// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#include <IO/DeviceCommunication/Detail/StringConverter.h>

#include <IO/DeviceCommunication/Detail/DataReader.h>
#include <IO/DeviceCommunication/Detail/DataWriter.h>
#include <IO/DeviceCommunication/Detail/PhoenixSingleton.h>

#include <algorithm>
#pragma warning(disable: 4996) // codecvt deprecated in C++17, but will be available until a replacement is standardized: https://stackoverflow.com/questions/2573834/c-convert-string-or-char-to-wstring-or-wchar-t
#include <codecvt>
#include <cstddef>
#include <gsl/gsl>
#include <locale>
#include <sstream>

using StringConverter = std::wstring_convert<std::codecvt_utf8<wchar_t>, wchar_t>;
using namespace Polytec;

namespace
{
	/// <summary>
	/// Checks if the conversion from unicode to ISO8859_1 (with special characters) is possible.
	/// </summary>
	/// <exception cref="std::runtime_error">Raised when not possible.</exception>
	/// <param name="character">The character to convert.</param>
	void CheckLatin1FromUnicode(wchar_t character)
	{
		// defined ISO8859_1 characters are: https://en.wikipedia.org/wiki/ISO/IEC_8859-1
		if (character >= 0x100 || (character >= 0x7F && character < 0xA0))
		{
			std::stringstream stream;
#pragma warning(suppress: 26493) // Don't use C-style casts (type.4).
			stream << "Can't convert from unicode to ISO8859_1: 0x" << std::hex << int{character};
			throw std::runtime_error(stream.str());
		}
	}

	/// <summary>
	/// Checks if the conversion from ISO8859_1 (with special characters) to unicode is possible.
	/// </summary>
	/// <exception cref="std::runtime_error">Raised when not possible.</exception>
	/// <param name="byte">The character byte to convert.</param>
	void CheckUnicodeFromLatin1(std::byte byte)
	{
		// defined ISO8859_1 characters are: https://en.wikipedia.org/wiki/ISO/IEC_8859-1
#pragma warning(suppress: 26475) // Do not use function style C-casts (es.49).
		if ((byte >= std::byte(0x7F) && byte < std::byte(0xA0)))
		{
			std::stringstream stream;
			stream << "Can't convert from ISO8859_1 to unicode: 0x" << std::hex << static_cast<int>(byte);
			throw std::runtime_error(stream.str());
		}
	}

	/// <summary>
	/// Checks if the conversion from ISO8859_1 (with special characters) to unicode is possible.
	/// </summary>
	/// <param name="character">The character to convert.</param>
	void CheckUnicodeFromLatin1(char character)
	{
		CheckUnicodeFromLatin1(static_cast<std::byte>(character));
	}
}

namespace Polytec::IO
{
	/// <summary>Convert a wstring into a string.</summary>
	/// <param name="wstr">The wstring.</param>
	/// <returns>The converted string.</returns>
	std::string ToString(const std::wstring& wstr)
	{
		return PhoenixSingleton<StringConverter>::GetInstance().to_bytes(wstr);
	}

	/// <summary>Convert a string into a wstring.</summary>
	/// <param name="str">The string.</param>
	/// <returns>The converted wstring.</returns>
	std::wstring ToWString(const std::string& str)
	{
		return PhoenixSingleton<StringConverter>::GetInstance().from_bytes(str);
	}

	/// <summary>Converts an UTF-8 encoded string data to an ISO8859-1 encoded string data.</summary>
	/// <param name="data">The UTF-8 encoded data.</param>
	/// <returns>The converted string data.</returns>
	std::vector<std::byte> Latin1FromUTF8(const std::vector<std::byte>& data)
	{
		DataReader reader(data);
		std::wstring unicode;
		reader.Read(unicode);
		std::vector<std::byte> iso88591;
		iso88591.reserve(unicode.size());
		std::transform(std::cbegin(unicode), std::cend(unicode), std::back_inserter(iso88591), [](const auto character)
		{
			CheckLatin1FromUnicode(character);
			return gsl::narrow_cast<std::byte>(character);
		});
		return iso88591;
	}

	/// <summary>Converts an ISO8859-1 encoded string data to an UTF-8 encoded string data.</summary>
	/// <param name="data">The ISO8859-1 encoded data.</param>
	/// <returns>The converted string data.</returns>
	std::vector<std::byte> UTF8FromLatin1(const std::vector<std::byte>& data)
	{
		std::wstring unicode;
		unicode.reserve(data.size());
		std::transform(std::cbegin(data), std::cend(data), std::back_inserter(unicode), [](const auto byte)
		{
			CheckUnicodeFromLatin1(byte);
			return static_cast<wchar_t>(byte);
		});
		std::vector<std::byte> utf8Data;
		DataWriter writer(utf8Data);
		writer.Write(unicode);
		return utf8Data;
	}

	/// <summary>Converts a latin-1 (ISO8859-1) encoded string to unicode.</summary>
	/// <param name="latin">The latin string.</param>
	/// <returns>The unicode string.</returns>
	std::wstring UnicodeFromLatin1(const std::string& latin)
	{
		std::wstring unicode;
		unicode.reserve(latin.size());
		std::transform(std::cbegin(latin), std::cend(latin), std::back_inserter(unicode), [](const auto character)
		{
			CheckUnicodeFromLatin1(character);
			wchar_t wideCharacter{};
			std::mbtowc(&wideCharacter, &character, 1);
			return wideCharacter;
		});
		return unicode;
	}

	/// <summary>Converts a unicode string to a latin-1 (ISO8859-1) string.</summary>
	/// <param name="unicode">The unicode string.</param>
	/// <returns>The latin string.</returns>
	std::string Latin1FromUnicode(const std::wstring& unicode)
	{
		std::string latin;
		latin.reserve(unicode.size());
		std::transform(std::cbegin(unicode), std::cend(unicode), std::back_inserter(latin), [](const auto character)
		{
			CheckLatin1FromUnicode(character);
			return gsl::narrow_cast<char>(character);
		});
		return latin;
	}
}
