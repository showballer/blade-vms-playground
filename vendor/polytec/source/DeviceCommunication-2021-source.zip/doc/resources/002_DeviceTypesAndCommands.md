\page deviceAndCommands Device types and device commands

[TOC]

This Article describes how you can get lists of all logical [devices] and [commands] supported by your device.
You need to have this information in case you want to send any command to the device via the Device Communication API
(e.g. using \ref PolySendGetInt16()).


# Logical devices and device commands

## Logical devices
Internally your %Polytec device is divided up into logical [devices], some of which also have physical representations, e.g. the [Sensor Head](\ref PTCDeviceType_SensorHead).
The main logical [device] that is guaranteed to be available on all %Polytec devices is the [Controller].

## Device commands
Each logical [device] supports a range of [device commands](\ref PTCDeviceCommand) (e.g. [Name](\ref PTCDeviceCommand_Name)).
They define the communication interface of that [device] and can be used to read values from and write values to that [device].
There are four different methods to access a [command]:

Method			| Usage
----------------|------------
Get				| Used to get the current or static state of a [device command], e.g. the [current focus position of the laser](\ref PTCDeviceCommand_FocusPosition) or the [name of the device](\ref PTCDeviceCommand_Name).
GetDevInfo		| Used to get information about the possible values of a [device command], like the allowed range [min, max] of the [laser signal level](\ref PTCDeviceCommand_SignalLevel).
GetValueList	| Used to get information about the possible values of a [device command], like all available [velocity ranges](\ref PTCDeviceCommand_Range) as strings.
Set				| Used to set the current state of a given [device command] e.g. [turn on the laser](\ref PTCDeviceCommand_LaserOn).

\note Not all [device commands] support all of the access methods above.
\note The payload type of a command may differ based on the access method used.

\see \ref PTCDeviceCommand in the [device commands header](\ref IO/DeviceCommunication/PTCDeviceCommand.h) for an overview over all available [device commands], their supported access methods, their functionalities and their payload type (e.g. int16).


# How to get a list of all supported devices and/or commands
In order to communicate with a (physical) device you first need to know of what logical [devices] the physical device is made up of.
Also you then need to know what [commands] each of those logical [devices] supports.
For this each [Controller] device supports the [DeviceList] command, a command that returns a list of all available logical [devices].
Each of those logical [devices] itself then supports the [CommandList] command, returning a list of all commands available on that logical [device].
This process is always guaranteed to be supported by each %Polytec device.

For the C++ interface the [DeviceList] and [CommandList] commands have been wrapped in two classes, the [DeviceList class] and [CommandList class], making them very easy to use.
Take a look at the \ref cpp_examples for more information.

# Testing if a specific device or command is supported
If you are only interested in knowing if a specific logical [device] or [command] is supported by your device, use the API functions \ref PolyHasDevice() and \ref PolyHasCommand().
For the C++ interface use the [DeviceList class] or the [CommandList class] in this case.


\see \ref python_example_dcDevsAndCmds "Supported devices and commands example" for a Python implementation of the procedure described above
\see \ref examplesOverview for usage examples of the logical [devices] and [commands]
\see PTCDeviceType.h for a list of all possible device types.
\see PTCDeviceCommand.h for details about all commands, their uses and how they can be accessed.


[device]: \ref PTCDeviceType
[devices]: \ref PTCDeviceType
[command]: \ref PTCDeviceCommand
[commands]: \ref PTCDeviceCommand
[Controller]: \ref PTCDeviceType_Controller
[DeviceList]: \ref PTCDeviceCommand_DeviceList
[CommandList]: \ref PTCDeviceCommand_CommandList
[DeviceList class]: \ref Polytec::IO::DeviceList
[CommandList class]: \ref Polytec::IO::CommandList


\copyright (c) 2020-2021 %Polytec GmbH, Waldbronn Released under the terms of the GNU Lesser General Public License version 3.
