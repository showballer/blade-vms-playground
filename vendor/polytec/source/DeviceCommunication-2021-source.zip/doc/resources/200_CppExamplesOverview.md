\page cpp_examples C++ examples

[TOC]

The Device Communication Software includes two C++ examples detailing the use of the Device Communication and Data Acquisition Interface in C++.

Example														| Level			| Description
------------------------------------------------------------|---------------|--------------
\subpage cpp_example_communication "Device Communication"	| Basic			| A C++ example showing the use of the Device Communication C++ interface
\subpage cpp_example_acquisition "Data Acquisition"			| Intermediate	| A C++ example detailing the configuration and implementation of a Data Acquisition using the Data Acquisition C++ interface
\subpage cpp_example_devicePanel "Device Panel"				| Advanced		| A C++ example implementing a feature rich Qt application able to remotely control a device, acquire data and display said data in signal plots.


\copyright (c) 2021 %Polytec GmbH, Waldbronn Released under the terms of the GNU Lesser General Public License version 3.
