\page python_examples Python examples

[TOC]

The Python examples are divided in two categories: communication examples and acquisition examples.

\note In order to be able to run the included Python examples you first need to install the `polytec` package to your Python installation or [virtual environment](https://docs.python.org/3/tutorial/venv.html).
Follow the instructions below.


# Communication examples
The communication example scripts show how the Device Communciation interface can be used to communicate with a device in Python.
They can be found in the `examples/Python/communication examples` directory.

Example																	| Level	| Description
------------------------------------------------------------------------|-------|--------------
\subpage python_example_dcDevsAndCmds "Supported devices and commands"	| Basic	| A simple example script showing how to get the device types and commands supported by a device using polytec Python package, also providing details about the use of the C interface in the `polytec` package
\subpage python_example_dcSetGet "Get and Set commands"					| Basic	| Two simple example scripts showing how to get values from and set values on a device using the polytec Python package
\subpage python_example_dcItemList "Item list commands"					| Basic	| A simple example script showing how to work with item list commands using polytec Python package

# Acquisition examples
The acquisition example scripts show how the Data Acquisition interface can be used to configure and perform a data acquisition in Python.
Besides scripts, the acquisition examples also include a simple data acquisition package, providing common functionalities to configure a data acquisition, acquire data from a device and write the acquired data to a CSV file.
The acquisition examples can be found in the `examples/Python/acquisition examples` directory.

Example																				| Level			| Description
------------------------------------------------------------------------------------|---------------|--------------
\subpage python_example_daqConfigOptions "Get configuration options"				| Basic			| A simple example script using the polytec Python package to show all data acquisition configuration options using polytec Python package
\subpage python_example_daqChannelSelection "Channel selection"						| Basic			| A simple example script allowing the user to interactively select the active channels on a device using polytec Python package
\subpage python_example_daqBandwidthAndRange "Bandwidth and range selection"		| Basic			| A simple example script allowing the user to interactively selet the bandwidth and ranges configured on a device using polytec Python package
\subpage python_example_daqStreamingAndBlock "Streaming and block mode acquisition"	| Intermediate	| Two detailed example projects showing how to acquire data from a %Polytec device to a CSV file using polytec Python package

# The polytec package  {#polytecPackage}

The Python examples include a Python package called `polytec` providing all nescessary modules for the interaction with the Device Communication interface.
The polytec package contains all resources needed to use the package standalone (without any other part of the Device Communication Software) on Windows systems.
You can find the `polytec` package and all Python example scripts in `build32/examples/Python` and `build64/examples/Python`.

## Installation
In order to install the `polytec` package to your Python installation you need to run the following command from within the `examples/Python/polytec` directory (the directory containing `setup.py`)

	pip install .

## Usage
After the package has been installed, you can access it from anywhere on your system.
Take a look at the included examples files (e.g. `get_commands.py`) for more information about the usage of this package and its modules.


\copyright (c) 2021 %Polytec GmbH, Waldbronn Released under the terms of the GNU Lesser General Public License version 3.
