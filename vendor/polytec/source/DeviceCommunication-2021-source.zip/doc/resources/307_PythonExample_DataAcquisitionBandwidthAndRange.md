\page python_example_daqBandwidthAndRange Acquisition / Bandwidth and range selection

[TOC]

# Description
This example shows how the bandwidth and signal channel ranges can be configured on a device.
The bandwidth may influence the sample rate and thus the amount of samples acquired in a fixed period of time, whereas the range determines what range of physical value can be acquired.
Using this example lets the user interactively select the bandwidth and the range for each individual signal channel on the connected device.

This example is located in **examples/Python/acquisition examples**

\see [Device Communication example in C](\ref c_example_communication) for further information about the Device Communication C Interface and its usage
\see [Data acquisition example in C](\ref c_example_acquisition) for further information about the Data Acquisition C Interface and its usage

\note The Python examples rely on the `polytec` package to be installed.
Take a look at the section [the polytec package](\ref polytecPackage) of the [Python examples overview](\ref python_examples) for further information.


# Example overview

File											| Description
------------------------------------------------|-------------------------
interactive_bandwidth_and_range_selection.py	| The script containing this example
polytec											| The general `polytec` Python package
polytec/io										| The `polytec.io` subpackage providing a range of modules used for the device communication and data acquisition in Python


This exmaple uses the `ItemList` class which is part of the `polytec.io` package.
Take a look at the \ref python_example_dcItemList for more information about this class, item lists and their usage.

The following code snippet shows the main functionality of this example defined in *interactive_bandwidth_and_range_selection.py*:

\snippet{lineno} "Examples/Python/acquisition examples/interactive_bandwidth_and_range_selection.py" run

As the code snippet shows, the `run()` function is fairly simple maily consists of three function calls:

1.  DeviceCommunication creation
2.  Interactive bandwidth selection
3.	Interactive range selection

*Step 1* opens a Device Communication with a device (see [Supported devices and commands example in Python](\ref python_example_dcDevsAndCmds) for more information).
This instances is then used in *Step 2* and *3* to perform the interactive selections.

## Bandwidth selection
The following code snippet shows the implementation of the interactive bandwidth selection using the `ItemList` class:

\snippet{lineno} "Examples/Python/acquisition examples/interactive_bandwidth_and_range_selection.py" bandwidth_selection

First a `ItemList` instance is created, wrapping the [Bandwidth](\ref PTCDeviceCommand_Bandwidth) command of the [VelocityDecoderDigital](\ref PTCDeviceType_VelocityDecoderDigital) device.
This instance is then used to print out all available bandwidths to the user.
The user is then prompted for his selection, which will then be set.

## Range selection
The following code snippet shows the implementation of the interactive range selection using the `ItemList` class:

\snippet{lineno} "Examples/Python/acquisition examples/interactive_bandwidth_and_range_selection.py" bandwidth_selection

For each available signal [channel type](\ref PTCChannelType) (Velocity, Displacement and Acceleration) an `ItemList` instance is created, wrapping that signal channels decoder devices [Range](\ref PTCDeviceCommand_Range) command.
This instance is then used to print out all available ranges to the user.
The user is then prompted for his selection, which will then be set.


# Using this example
This example is very useful to quickly and easily configure the bandwidth and ranges of a device.

## Usage examples

```.sh
> python .\interactive_bandwidth_and_range_selection.py 192.168.123.103
Available bandwidths: 100 kHz, 50 kHz, 25 kHz, 10 kHz, 5 kHz, 1 kHz
New bandwidth [100 kHz]: 50 kHz
Available Velocity ranges: 2 m/s, 1 m/s, 500 mm/s, 200 mm/s, 100 mm/s, 50 mm/s, 20 mm/s, 10 mm/s
New Velocity range [2 m/s]: 1 m/s
Available Displacement ranges: 50 mm, 20 mm, 10 mm, 5 mm, 2 mm, 1 mm, 500 µm, 200 µm, 100 µm, 50 µm, 20 µm, 10 µm, 5 µm, 2 µm, 1 µm, 500 nm
New Displacement range [50 mm]: 20 mm
Available Acceleration ranges: 50 km/s², 20 km/s², 10 km/s², 5 km/s², 2 km/s², 1 km/s², 500 m/s², 200 m/s²
New Acceleration range [50 km/s²]: 20 km/s²
```

\see \ref gettingStarted
\see \ref examplesOverview


\copyright (c) 2021 %Polytec GmbH, Waldbronn Released under the terms of the GNU Lesser General Public License version 3.
