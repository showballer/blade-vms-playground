\page python_example_dcSetGet Communication / Get and Set device commands

[TOC]

# Description
These two example scripts show how the [polytec package](\ref polytecPackage) can be used to get and set the value of a [device command] in Python.
Using these examples gets/sets a [device command] \(e.g. [LaserOn](\ref PTCDeviceCommand_LaserOn)) of a [logical device] \(e.g. [SensorHead](\ref PTCDeviceType_SensorHead)) specified through the command line interface.

These examples are located in **examples/Python/communication examples**

\see \ref deviceAndCommands for further information about [logical devices], [device commands] and their access methods
\see [Device Communication example in C] for further information about the C Interface and its usage
\see [Supported devices and commands example in Python] for a glimpse into the inner workings of the `polytec` Python package and the use of the C interface in Python

\note The Python examples rely on the `polytec` package to be installed.
Take a look at the section [the polytec package](\ref polytecPackage) of the [Python examples overview](\ref python_examples) for further information.


# Examples overview

File			| Description
----------------|-------------------------
get_command.py	| The script containing the get command example
set_command.py	| The script containing the set command example
polytec			| The general `polytec` Python package
polytec/io		| The `polytec.io` subpackage providing a range of modules used for the device communication and data acquisition in Python

Here you can see the main function of the get example script defined in *get_command.py*:

\snippet{lineno} "Examples/Python/communication examples/get_command.py" main

The process implemented in these examples is fairly simple, as the code snippet above shows.
They consist of only two major steps:

1.  Establishing a device communication
2.  Sending a get or set-command via the device communication and printing the result to the command line

Detailed information about *step 1* can be found in the [Supported devices and commands example in Python].
*Step 2* basically consists of a single call to a method of the `DeviceCommunication` class (which method is being used, depends on the [device command]'s payload type, specified through the command line interface).

\see [Supported devices and commands example in Python] for further information about the inner workings of the `DeviceCommunication` class and the use of the C interface in Python

# Using these examples
These examples can be very useful if you want to get/set the value of a [device command] on a %Polytec device.
Use the following commands to print the scripts help and get more information about their command line interface:

```.sh
python .\get_command.py -h
```

```.sh
python .\set_command.py -h
```

\note Setting the logging level to "DEBUG" (`-l DEBUG`) will expose every Device Communication API call with its argument values to the log.
This might be interesting to understand all the inner workings of the `polytec` Python package.

\note These examples currently only support single values to be fetched from or set on the device, but can easily be adapted to support a list of values using the same methods of the `DeviceCommunication` class.
For set, simply call the set-methods using a list of values instead of a single value.
Fro get, take a look the the [Supported devices and commands example in Python] to get more information.

\see \ref deviceAndCommands for more information about [logical devices] and [device commands]


## Usage examples

### Get the current value of the laser (0=off, 1=on)

```.sh
> python get_command.py 192.168.123.103 SensorHead LaserOn int16
Command value: 1
```

### Turn off the laser

```.sh
> python set_command.py 192.168.123.103 Sensorhead LaserOn int16 0
Command value successfully set to "0"
```

\see \ref deviceAndCommands
\see \ref gettingStarted
\see \ref examplesOverview


[Device Communication example in C]: \ref c_example_communication
[Supported devices and commands example in Python]: \ref python_example_dcDevsAndCmds
[device commands]: \ref PTCDeviceCommand
[device command]: \ref PTCDeviceCommand
[logical devices]: \ref PTCDeviceType
[logical device]: \ref PTCDeviceType


\copyright (c) 2020-2021 %Polytec GmbH, Waldbronn Released under the terms of the GNU Lesser General Public License version 3.
