\page c_examples C examples

[TOC]

The Device Communication Software includes two C examples detailing the use of the Device Communication and Data Acquisition Interface in C.

Example													| Level			| Description
--------------------------------------------------------|---------------|--------------
\subpage c_example_communication "Device Communication"	| Basic			| A C example showing the use of the Device Communication C interface
\subpage c_example_acquisition "Data Acquisition"		| Intermediate	| A C example detailing the configuration and implementation of a Data Acquisition using the Data Acquisition C interface


\copyright (c) 2021 %Polytec GmbH, Waldbronn Released under the terms of the GNU Lesser General Public License version 3.
