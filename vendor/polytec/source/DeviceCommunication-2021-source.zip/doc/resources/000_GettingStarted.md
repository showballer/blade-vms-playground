﻿\page gettingStarted Getting Started

[TOC]

# Using the API

## C interface / DLLs
The C interface can be used by linking the dynamic library to your project.
Prebuilt 32 and 64 bit DLLs for Windows can be found in the respective build directories (e.g. `build64/DeviceCommunication/Release/DeviceCommunication.dll`).
If required you can also build the DLL from source (see \ref bfs below).
An import library (`.lib`) is located next to the DLL.
Header files are located in `include/IO/*`.
`PolyDeviceCommunication.h` and `PolyDataAcquisition.h` together define the interface of the library while the `PTC*.h` files provide additional definitions for the use of the Device Communication and Data Acquisition C interface (e.g. \ref PTCDeviceCommand).

Take a look at the \ref c_examples, \ref python_examples and \ref labView_examples for further information on usage and additional functionalities of the C interface.

## C++ interface
The C++ interface is not available as a dynamic library and needs to be build from source (see \ref bfs).
Take a look at the \ref cpp_examples for information on usage and additional functionalities of the C++ interface.

## Python
For Python the whole C interface has been wrapped in multiple Python classes packed up (including the windows DLLs) in a Python package called `polytec`.
Take a look at the \ref python_examples for further information.


# Building the library from source  {#bfs}
\note Building the libraries from source is only needed if you cannot use the prebuilt DLLs provided (e.g. using the C++ interface).

Tested using following configurations:
 -	Windows 10 1809, CMake 3.20.2, MS Visual Studio 2019 16.9.4, Boost 1.74
 -	Ubuntu 20.04, CMake 3.16.3, GCC 9.3.0, Boost 1.74

## Requirements
 -	C++17 Compiler
 -	[Boost] header-only libraries
 -	[Boost] DateTime & Serialization libraries (Windows only)

\note	For a quick start you can use the [Boost prebuilt binaries for Windows](https://www.boost.org/users/download/#alternative)
\note	Make sure to have the latest CMake version if you are using a later Boost version than tested

## How to build
1.	Open a command prompt
2.	Navigate to "Device Communication Software" root directory (directory containing the folders `build32`, `build64`, `examples`, ...)
3.	Create/Navigate to a subdirectory where you want to build the project, e.g.:

		cd build64

4.	Use CMake to generate a Visual Studio Solution for your target platform:

		cmake -G "Visual Studio 16 2019" -A x64 -DBOOST_LIBRARYDIR=C:\boost\boost_1_71_0\stage\lib -DBOOST_INCLUDEDIR=C:\boost\boost_1_71_0 ..
	
	\note Adjust Visual Studio version, architecture and [Boost] paths to your configuration (see [cmake(1)](https://cmake.org/cmake/help/v3.13/manual/cmake.1.html) for more information).
	\note [Boost] options can be omitted if respective system environment variables have been set.

	The generated Solution contains separate projects for Device Communication and Data Acquisition shared and static libraries (e.g. DeviceCommunication, DataAcquisitionStatic, ...).


# Examples

In addition to the source code, this release includes multiple [example projects](\ref examplesOverview) illustrating the usage of the C and C++ interfaces in C, C++, Python and LabVIEW.
Further, there is an extensive C++ example called [Device Panel] consisting of a Qt application with a graphical user interface to control a %Polytec device and to visualize the acquired data.

## Running examples
Prebuilt executables for all examples can be found in the build directories, e.g. `build64/examples/C++/DeviceCommunication/Release`.
\note Most C, C++ and Python examples (except [Device Panel]) are console applications without a graphical user interface.
\warning If an examples fails to start with an error stating that `msvcp142.dll` is missing, run `vcredist_x86.exe` or `vcredist_x64.exe` to install the missing DLLs on your system.

## Building the examples from source

### Basic examples
To add the projects for the basic C and C++ examples to your Visual Studio Solution you need to rerun CMake with the following option:

	-DBUILD_EXAMPLES=ON

### Device Panel
For the [Device Panel] you need to have Qt 5.7 (or higher) available on your system.
The most convenient way to get Qt is to download the installers from the [Qt website](https://www.qt.io/).
If you want to build Qt 5.7 from source, you can download the sources from our server: [qt-everywhere-opensource-src-5.7.0.zip](http://swdownload.polytec.com/public/qt-everywhere-opensource-src-5.7.0.zip)

To add the [Device Panel] example to your solution run CMake with the following options (adjust Qt path to your configuration):

	-DCMAKE_PREFIX_PATH=C:/Qt/Qt5.7.0/5.7/msvc2015_64
	-DBUILD_DEVICE_PANEL=ON

\note `-DCMAKE_PREFIX_PATH` can be omitted if you add the respective directory to your system PATH variable.
\warning This executable is dynamically linked to the Qt DLLs. If the application fails to start because its dependencies can’t be found, the easiest solution is to copy the required DLLs Qt5Core.dll, Qt5Gui.dll, Qt5Widgets.dll and platforms\qwindows.dll to the same folder as the executable (e.g. `build64\examples\DevicePanel\Release`). Another solution would be to add Qt's `bin` directory containing these DLLs to your systems PATH variable.
\note Qt is free software. Its use in the [Device Panel] is covered by the LGPL v.3 (see [LGPL](\ref lgpl) and [GPL](\ref gpl)).

# What to read next
 -	\ref examplesOverview
 -	\ref networkInfo

[Boost]: https://www.boost.org
[Device Panel]: \ref cpp_example_devicePanel


\copyright (c) 2016-2021 %Polytec GmbH, Waldbronn Released under the terms of the GNU Lesser General Public License version 3.
