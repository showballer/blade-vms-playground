\page cpp_example_communication Device Communication

[TOC]


# Description
This simple example shows how the Device Communication C++ interface can be used.
Depending on the command line parameters, this example will establish a device communication via a serial interface (COM port) or Ethernet connection.
The connection is used to fetch a list of all available velocity ranges which gets printed out to the user.
The user then has to pick one of the velocity ranges from the list which will be set.
Subsequently the example program will turn on the laser and perform an autofocus (if available with the connected device).

Visual Studio Project Name: **Device-Communication-Example-C++**

\see \ref gettingStarted for details on how to generate this project using CMake.
\see [Device Communication example in C] for an implementation of the same functionalities using the C interface


# What am I going to learn?
 -	Using the Device Communication C interface
 -	Establishing a connection with a device
 -	Communicating with the device
 	 -	Getting information from the device (e.g. current range)
 	 -	Setting values on the device (e.g. turn laser on)


# Example overview
File							| Description
--------------------------------|-------------------------
DeviceCommunicationExample.cpp	| Example program implementation (main)


The program flow of this example can be broken down into four steps:
1. 	Opening a communication with the device
2. 	Letting the user pick a velocity range
3. 	Turning the laser on (if a sensor head is installed)
4. 	Autofocusing the laser (if available)

All four steps can be seen in the following as part of the programs `main()` function (defined in `DeviceCommunicationExample.cpp`):

\snippet{lineno} examples/C++/DeviceCommunication/DeviceCommunicationExample.cpp main


# How to establish a communication with a device
In order to open a connection with a device you need to use either \ref CreateSerialCommunication(), \ref CreateUdpEthernetCommunication() or CreateTcpEthernetCommunication().
All of those functions return an instance of the [DeviceCommunication] class, managing the newly opened device communication and providing a list of methods to directly communicate with the connected device.

\note Not all devices support a device communication connection via TCP (e.g. IVS-500)

The following snippet shows the implementation of the `OpenCommunication()` function, called in *Step 1* of the `main()` function above:

\snippet{lineno} examples/C++/DeviceCommunication/DeviceCommunicationExample.cpp OpenCommunication

Based on the command line arguments, the `OpenCommunication()` function opens either a serial or an Ethernet (UDP) device communication with the device.
The resources allocated through the creation of the connection are automatically freed with the destruction of the [DeviceCommunication] instance.


# How to communicate with a connected device
The device communication is based on [device commands] sent to [logical devices] which the physical device is logically divided into.
Common [logical devices] are the [controller](\ref PTCDeviceType_Controller), the [sensor head](\ref PTCDeviceType_SensorHead) or the [velocity decoder](\ref PTCDeviceType_VelocityDecoderDigital).
Take a look at the [Device types and device commands] page for more information about [logical device], [device commands] and their access methods.

## Basic device communication
The [DeviceCommunication] instance provides all functionalities for a basic device communication through its public methods.
In order to access a [device command] all acces methods have been made available as template functions:

 -	[DeviceCommunication::SendGet](\ref Polytec::IO::DeviceCommunication::SendGet())
 -	[DeviceCommunication::SendGetDevInfo](\ref Polytec::IO::DeviceCommunication::SendGetDevInfo())
 -	[DeviceCommunication::SendGetValueList](\ref Polytec::IO::DeviceCommunication::SendGetValueList())
 -	[DeviceCommunication::SendSet](\ref Polytec::IO::DeviceCommunication::SendSet())

You can see the use of the [DeviceCommunication::SendSet<int16_t>()](\ref Polytec::IO::DeviceCommunication::SendSet()) method in *step 3* of the `main()` function above. Further examples can be found in the code snippets below.

## Item list commands
An item list models a [device command] that returns a comma separated list of Strings for the GetValueList access method, all available indices for the GetDevInfo access method and reads/writes the current index for the Get/Set access methods.
An example for this is the [Range](\ref PTCDeviceCommand_Range) command.
You can use the [ItemList] class to communicate with an item list command.
Among other things, it provides functionalities to get all available items and indices, set/get the current item and test if an item is available.

A usage example of the [ItemList] class can be seen in the following code snippet of the `SelectVelocityRange()` function:
\snippet{lineno} examples/C++/DeviceCommunication/DeviceCommunicationExample.cpp SelectVelocityRange

## Device and command list commands
In order to quickly and easily determine the [logical devices] and [device commands] supported by a %Polytec device (e.g. is the [sensor head](\ref PTCDeviceType_SensorHead) installed), the C++ interafce provides the [DeviceList] and [CommandList] classes.
Both have a fairly simple interface to get all available devices and commands or evaluate if a specific [logical device] or [device command] is available to be used.

You can see the use of those classes in the following code snippet:
\snippet{lineno} examples/C++/DeviceCommunication/DeviceCommunicationExample.cpp HasDeviceAndCommand

## Channel activation  {#cppChannelActivation}
There are two ways to control the active acquisition channels on a device:
Through the [active channels] command and through the [output active] command.
A device supports either one of the commands mentioned or none, but never both.

The following table shows a list of some %Polytec devices and the command they support:

Device      | Supported command to manipulate active channels
------------|--------------------------
IVS-500     | none (all available channels are always active)
VGO-200     | [output active]
VFX-F-110   | [active channels]
VIO-130     | [active channels]

\note If your device supportes the command [OutputActive](\ref PTCDeviceCommand_OutputActive) on the [VelocityDecoderDigital](\ref PTCDeviceType_VelocityDecoderDigital) device it uses the [output active] command.
\note If your device supports the [DaqActiveChannels](\ref PTCDeviceCommand_DaqActiveChannels) command on the [SignalProcessing](\ref PTCDeviceType_SignalProcessing) device it uses the [active channels] command.
\note Only one or none of the above is true for your device. Use the [CommandList] class to find out what your device supports.

On devices supporting the [output active] command you can only select the active signal channel (Velocity, Displacement or Acceleration) but never disable any channel completely.
The active signal channel can be selected by setting the [output active] command of the respective decoder device (e.g. [VelocityDecoderDigital](\ref PTCDeviceType_VelocityDecoderDigital)) to *1* (this automatically sets all other decoders active outputs to 0 on the device).

\note Based on your devices hardware and license not all decoder devices and thus signal channels may be available to be enabled.
Use \ref PolyHasDevice() to find out what decoder device are available on your device.

For devices using the [active channels] command, the command has been wrapped by the [ChannelActivation] class.
This class provides a range of methods to manipulate the active channels of a device (e.g. set all active channels or get all available channel types).

To increase user comfort an additional free function has been added to \ref ChannelActivation.h retrieve all channels active from any device (no matter what channel activation command it supports) using a single function call: \ref ActiveChannels()

You can find a usage example of the above mentioned class and functions in the `ChannelList.cpp`, `GetConfig.cpp` and `InteractiveConfig.cpp` files of the [Data acquisition example in C++].

## Error handling
If an error occures during a call to a C++ Interface function or method a [CommunicationException] is being thrown.
A [CommunicationException] indicates an error during the device communication either in the C++ interface or on the device itself.
Use [CommunicationException::what()](\ref Polytec::IO::CommunicationException::what) to get additional information about the error.

In this example those exceptions are being caught at the highest level in the `main()` function you can see above.
At this level it is recommended to catch all exceptions that could happen during the runtime of your application.
This is why a single catch block is used to catch all exceptions derived from `std::exception` (as is the [CommunicationException] class).


# What headers need to be included
To be able to communicate with a device using the Device Communication C++ interface it is sufficient to only include a single header file:

~~~{.cpp}
#include <IO/DeviceCommunication/AllCommunication.h>	// Device Communication C++ interface to start the data acquisition stream
~~~ 

\note Take care that the device communication software's `include` directory is on your projects include path.


# Key takeaways
 -	A device communication connection can be **established over a serial or an Ethernet connection**
 -	A device communication connection opened using the C++ interface is **managed through an instance of the [DeviceCommunication] class**
 -	To get/set data **you need to know what [device types] and [device commands] are supported by your device** (see [Device types and device commands])
 -	Each [device command] uses a different **payload type**. Make sure to check the [command documentation](\ref PTCDeviceCommand) before using it.
 
\see \ref gettingStarted
\see \ref examplesOverview
\see [Device types and device commands]


[Device Communication example in C]: \ref c_example_communication
[Data acquisition example in C++]: \ref cpp_example_acquisition
[Device types and device commands]: \ref deviceAndCommands
[DeviceCommunication]: \ref Polytec::IO::DeviceCommunication
[device commands]: \ref PTCDeviceCommand
[device command]: \ref PTCDeviceCommand
[logical devices]: \ref PTCDeviceType
[logical device]: \ref PTCDeviceType
[device types]: \ref PTCDeviceType
[active channels]: \ref PTCDeviceCommand_DaqActiveChannels
[output active]: \ref PTCDeviceCommand_OutputActive
[CommunicationException]: \ref Polytec::IO::CommunicationException
[ItemList]: \ref Polytec::IO::ItemList
[DeviceList]: \ref Polytec::IO::DeviceList
[CommandList]: \ref Polytec::IO::CommandList
[ChannelActivation]: \ref Polytec::IO::ChannelActivation


\copyright (c) 2020-2021 %Polytec GmbH, Waldbronn Released under the terms of the GNU Lesser General Public License version 3.
