\page python_example_dcDevsAndCmds Communication / Supported devices and commands

[TOC]

# Description
This example shows how the Device Communication C interface can be used with Python.
In this example the Device Communication Interface is used to extract all supported [logical devices] and their respective [device commands] from a %Polytec device (see \ref deviceAndCommands for further information about this topic).
In order to simplify the usage of the Device Communication C interface, a wrapper class has been implemented as part of the `polytec` Python package.
This class wraps all functions needed to perform a device communication over a TCP connection with a device.
The extracted [logical devices] and [device commands] with their corresponding enum values are printed to the command line as Markdown tables.

This example is located in **examples/Python/communication examples**

\note The Python examples rely on the `polytec` package to be installed.
Take a look at the section [the polytec package](\ref polytecPackage) of the [Python examples overview](\ref python_examples) for further information.

\see \ref deviceAndCommands for further information about [logical devices], [device commands] and their access methods
\see [Device Communication example in C] for further information about the C Interface and the device communication interface

# What am I going to learn?
 -  How to use the Device Communication C Interface in Python
 -  Connecting to a device via TCP
 -  Fetching information from a device

# Example overview
File						| Description
----------------------------|-------------------------
device_and_command_lists.py	| The script containing this examples
polytec						| The general `polytec` Python package
polytec/io  				| The `polytec.io` subpackage providing a range of modules used for the device communication and data acquisition in Python

Here you can see this examples main function defined in *device_and_command_lists.py*:

\snippet{lineno} "Examples/Python/communication examples/device_and_command_lists.py" main

As we look at the code above, we see that the execution can be divided into four major sections:

1.  Initialization of a Device Communication object which also establishes a connection to a device
2.  Fetching and printing of the list of all [logical devices] supported by the %Polytec device
3.  Fetching and printing of the list of all [device commands] supported for each [logical device]

# Connecting to a device / using the C Interface in Python
In order to load and interface with a DLL in Python you need to use the built-in [ctypes] module.
In our example we use the function `ctypes.cdll.LoadLibrary()` to load the Device Communication DLL into a class variable of our wrapper class called `__device_communication_dll`.
This operation is part of the `DeviceCommunication` constructor called in *Step 1* of the `main()` function above (take a look at the `__load_dll()` method implemented in *polytec/io/device_communication.py* for more details).

The following paragraphs will describe how the now loaded library is then used to establish a connection with a device via TCP, which is also part of the `DeviceCommunication` constructor called in `Step 1` of the main function above.
To outline this process, code snippets from the `DeviceCommunication.__open_connection()` function defined in *polytec/io/device_communication.py* are used.

In order to call a library function you first need to define its signature.
For this we copy the API function \ref PolyOpenTcpEthernetCommunication() from the DLL-object to a local variable called `poly_open_tcp_ethernet_communication `.
Then we define its argument and result types based on the arguments and return types of the \ref PolyOpenTcpEthernetCommunication() API function.

\snippet{lineno} Examples/Python/polytec/polytec/io/device_communication.py define_signature

Now that the function is ready to be used, we need to prepare the arguments we want to call it with.
Each argument needs to be initialized with its respective ctype (e.g. `c_int`, `c_uint16`, ...).
If you look at the signature of \ref PolyOpenTcpEthernetCommunication(), you can see that the first argument is a connection handle, which needs to be passed as a pointer to an integer variable.
This variable is then set by the library function.
To pass the handle variable by reference (as a pointer) we initialize our local variable (here the attribute called `__communication_handle`) with a normal `c_int`.
When calling the function, we then use the function `byref()` to pass that argument by reference and not by value.

\snippet{lineno} Examples/Python/polytec/polytec/io/device_communication.py prepare_arguments

The function call itself, is now as simple as every other function call in Python.
The only thing you need to keep in mind, is to use `byref()` for the first argument.

\snippet{lineno} Examples/Python/polytec/polytec/io/device_communication.py library_function_call

As usual for C, this function and most of the other library functions return a status code indicating the success or failure of the execution.
This status code needs to be checked after each library call.

\snippet{lineno} Examples/Python/polytec/polytec/io/device_communication.py check_status_code

A similar process is used for most of the other methods provided by the `DeviceCommunication` class.

\see \ref PTCCommunicationStatusCode.h or `polytec/io/communication_status_code.py` for a list of all status codes

# Communicating with a device
The basics of the communication with a %Polytec device can be read in the section [How to communicate with a connected device](\ref howtocommunicate) of the [Device Communication example in C].

In order to get all [logical devices] and [device commands] available on a device, the [DeviceList](\ref PTCDeviceCommand_DeviceList) and [CommandList](\ref PTCDeviceCommand_CommandList) commands are being used.
As those commands return multiple items the high level API functions cannot be used for this task.
Instead three low level API functions need to be called in order to retrieve those multiple values.
Details about the high and low level API can be found in the [How to communicate with a connected device](\ref howtocommunicate) section of the [Device Communication example in C].

The three calls to the low level API functions are wrapped in the `get_int16()` or rather the `__get_low_level()` method of the `DeviceCommunication` class in *polytec/io/device_communication.py*.
The low level API functions being used are
 -  PolySendGet()
 -  PolyGetInt16FromPayload()
 -  PolyFreePayload()

\note The `DeviceCommunication` Python class mostly uses low level API functions for Get and Set operations as they enable more flexibility (getting/setting of multiple values, using [extra tags](\ref PTCMiscellaneousTag)).

\note If you take a close look at the `get_int16()` method calls in the `main()` function above, you will see that they specify a `max_value_count` of 100.
This value defauls to 1 and it is nescessary to provide a value greater than 1 in order to fetch multiple values from the device.
This value is used to size the recieve buffer for the low level C API call and only defines an upper edge of values to be received, hence the name `max_value_count`.
The actual amount of values received may be less or equal to the value of `max_value_count`.

# Using this example
This example can be very useful when you are starting to write software for a %Polytec device, as it provides you with a list of all [logical devices] and their [device commands] in a human readable Markdown format.
Use the following command to print the scripts help and get more information about its fairly simple command line interface:

```.sh
python .\device_and_command_lists.py -h
```

\note Setting the logging level to "DEBUG" (`-l DEBUG`) will expose every Device Communication API call with its argument values to the log.
This might be interesting to understand all the inner workings of the `polytec` Python package.

# Key takeaways
 -  The `polytec` Python package uses the built-in **python [ctypes] module** to load and interact with the **C interface**
 -  The `DeviceCommunication` class and the other parts of the `polytec` Package provide the **most common C API functions direcly in native Python**
 -  Take a look at the **[Device Communication example in C] for further information** about the C interface and its usage
 -	Run this example script to get more information about the [logical devices] and [device commands] supported by your device


\see \ref gettingStarted
\see \ref examplesOverview
\see \ref deviceAndCommands


[ctypes]: https://docs.python.org/library/ctypes.html
[Device Communication example in C]: \ref c_example_communication
[device commands]: \ref PTCDeviceCommand
[device command]: \ref PTCDeviceCommand
[logical devices]: \ref PTCDeviceType
[logical device]: \ref PTCDeviceType


\copyright (c) 2020-2021 %Polytec GmbH, Waldbronn Released under the terms of the GNU Lesser General Public License version 3.
