\page license License

This software was released under the terms of the GNU Lesser General Public License version 3:

 -	\subpage gpl
 -	\subpage lgpl

\copyright (c) 2021 %Polytec GmbH, Waldbronn Released under the terms of the GNU Lesser General Public License version 3.
