\page c_example_communication Device Communication

[TOC]


# Description
This simple example shows how the Device Communication C interface can be used in C.
The Device Communication C interface is part of the interface exported by the Device Communication DLL (see \ref gettingStarted).
Depending on the command line parameters, this example will establish a device communication via a serial interface (COM port) or Ethernet connection.
The connection is used to fetch a list of all available velocity ranges which gets printed out to the user.
The user then has to pick one of the velocity ranges from the list which will be set.
Subsequently the example program will turn on the laser and perform an autofocus (if available with the connected device).

\note The knowledge gained through this example can easily be transfered to other languages using the C interface (e.g. [Python](\ref python_examples)).

Visual Studio Project Name: **Device-Communication-Example-C**

\see \ref gettingStarted for details on how to generate this project using CMake.
\see [Device Communication example in C++] for an implementation of the same functionalities using the C++ interface
\see \ref python_examples for usage examples of the Device Communication C interface in Python
\see \ref labView_examples for usage examples of the Device Communication C interface in LabVIEW


# What am I going to learn?
 -	Using the Device Communication C interface
 -	Establishing a connection with a device
 -	Communicating with the device
 	 -	Getting information from the device (e.g. current range)
 	 -	Setting values on the device (e.g. turn laser on)


# Example overview
File							| Description
--------------------------------|-------------------------
DeviceCommunicationExample.c	| Example program implementation (main)
Utils.h							| Utility function definitions


The program flow of this example can be broken down into five steps:
1. 	Opening a communication with the device
2. 	Letting the user pick a velocity range
3. 	Turning the laser on (if a sensor head is installed)
4. 	Autofocusing the laser (if available)
5. 	Closing the communication

All five steps can be seen in the following as part of the programs `main()` function (defined in `DeviceCommunicationExample.c`):

\snippet{lineno} examples/C/DeviceCommunication/DeviceCommunicationExample.c main


# How to establish a communication with a device
In order to open a connection with a device using the C interface you need to either call \ref PolyOpenSerialCommunication() or \ref PolyOpenUdpEthernetCommunication().
Both take a pointer to a \ref PTCommunicationHandle as their first argument, which will be initialized as the communication handle by either function.
The following snippet shows the implementation of the `OpenCommunication()` function, called in *Step 1* of the `main()` function above:

\snippet{lineno} examples/C/DeviceCommunication/DeviceCommunicationExample.c OpenCommunication

Based on the command line arguments, the `OpenCommunication()` function opens either a serial or an Ethernet device communication with the device.
In order to free all resources allocated during the opening of the communication, it is important to close all communications established over the C interface when they are no longer needed.
This is taken care of through *Step 5* of the `main()` function above by calling the \ref PolyCloseCommunication() API function.
\ref PolyCloseCommunication() is able to close both serial and Ethernet connection based on the communication handle provided.


# How to communicate with a connected device  {#howtocommunicate}
The device communication is based on [device commands] sent to [logical devices] which the physical device is logically divided into.
Common [logical devices] are the [controller](\ref PTCDeviceType_Controller), the [sensor head](\ref PTCDeviceType_SensorHead) or the [velocity decoder](\ref PTCDeviceType_VelocityDecoderDigital).
Take a look at the [Device types and device commands] page for more information about [logical device], [device commands] and their access methods.

## High level Get/Set API functions
Most often you will use the Get and Set access methods to read and write values on a device.
To simplify the use of those commonly used access methods, the Device Communication API provides a set of high level SendGet/SendSet commands supporting the most common payload types (e.g. int16):

 -	\ref PolySendGetFloat()
 -	\ref PolySendSetFloat()
 -	\ref PolySendGetInt16()
 -	\ref PolySendSetInt16()
 -	\ref PolySendGetInt32()
 -	\ref PolySendSetInt32()
 -	\ref PolySendGetString()
 -	\ref PolySendSetString()

You can see the use of the \ref PolySendSetInt16() function in *step 3* of the `main()` function above.
Further examples can be found in the code snippets below.

## Low level API  {#cLowLevelApi}
Some [device commands] use a payload type that is not supported by those high level functions, return multiple values (e.g. [CommandList](\ref PTCDeviceCommand_CommandList)) or expect an [MiscellaneousTag](\ref PTCMiscellaneousTag) to be provided (e.g. [FanSpeed](\ref PTCDeviceCommand_FanSpeed)).
For those or when accessing a [device command] using GetDevInfo or GetValueList, a combination of three low level API calls is needed instead of the single high levelA API call used above:

1.	\ref PolySendGet() (or \ref PolySendSet(), \ref PolySendGetDevInfo(), \ref PolySendGetValueList())
2.	PolyGet`<payloadType>`FromPayload() (e.g. \ref PolyGetInt16FromPayload())
3.	\ref PolyFreePayload()

\see The function `SetBlockSize` of the [Data acquisition example in C] for a low level API usage example

For most applications you won't be needing those low level API functions as very common [device commands] and access methods that would need this special process have been wrapped in some other high level API functions defined in PolyDeviceCommunication.h.
Take a look at the following sections for those high level functions.

## High level value range API functions
The Device communication API provides a special function to get the value range of a [device command] \(e.g. [DaqBlockCount](\ref PTCDeviceCommand_DaqBlockCount)):

 -	\ref PolySendGetDevInfoRange()

\note This function can only be used with [device commands] using the payload type `int16`.
To get the range of [device command] using another payload type, use the low level API described above.

## High level item list API functions  {#cItemListFunctions}
An item list models a [device command] that returns a comma separated list of Strings for the GetValueList access method, all available indices for the GetDevInfo access method and reads/writes the current index for the Get/Set access methods.
An example for this is the [Range](\ref PTCDeviceCommand_Range) command.
You can use the following functions to communicate with an item list command:

 -	\ref PolyItemListGetAllItems()
 -	\ref PolyItemListGetAvailableItems()
 -	\ref PolyItemListGetCurrentItem()
 -	\ref PolyItemListSetCurrentItem()
 -	\ref PolyItemListIsItemAvailable()

Using these functions enables you to read and manipulate the item list [device command] without any knowledge about the mapping of the string values to their item list indices.
A usage example of these functions can be seen in the following code snippet of the `SelectVelocityRange()` function, called in *Step 2* of the `main()` function above:
\snippet{lineno} examples/C/DeviceCommunication/DeviceCommunicationExample.c SelectVelocityRange

## High level device and command list API functions
In order to quickly and easily determine if a [logical device] or a [device command] is installed and currently available (e.g is the [sensor head](\ref PTCDeviceType_SensorHead) installed or does this device support the [data acquisition mode command](\ref PTCDeviceCommand_DaqMode)), the following two high level functions have added to the Device Communication C Interface:

 -	\ref PolyHasDevice()
 -	\ref PolyHasCommand()

You can see the use of those functions in the following code snippet:
\snippet{lineno} examples/C/DeviceCommunication/DeviceCommunicationExample.c HasDeviceAndCommand

## High level channel activation  {#cChannelActivation}
There are two ways to control the active acquisition channels on a device:
Through the [active channels] command and through the [output active] command.
A device supports either one of the commands mentioned or none, but never both.

The following table shows a list of some %Polytec devices and the command they support:

Device      | Supported command to manipulate active channels
------------|--------------------------
IVS-500     | none (all available channels are always active)
VGO-200     | [output active]
VFX-F-110   | [active channels]
VIO-130     | [active channels]

\note If your device supportes the command [OutputActive](\ref PTCDeviceCommand_OutputActive) on the [VelocityDecoderDigital](\ref PTCDeviceType_VelocityDecoderDigital) device it uses the [output active] command.
\note If your device supports the [DaqActiveChannels](\ref PTCDeviceCommand_DaqActiveChannels) command on the [SignalProcessing](\ref PTCDeviceType_SignalProcessing) device it uses the [active channels] command.
\note Only one or none of the above is true for your device. Use \ref PolyHasCommand() to find out what your device supports.

On devices supporting the [output active] command you can only select the active signal channel (Velocity, Displacement or Acceleration) but never disable any channel completely.
The active signal channel can be selected by setting the [output active] command of the respective decoder device (e.g. [VelocityDecoderDigital](\ref PTCDeviceType_VelocityDecoderDigital)) to *1* (this automatically sets all other decoders active outputs to 0 on the device).

\note Based on your devices hardware and license not all decoder devices and thus signal channels may be available to be enabled.
Use \ref PolyHasDevice() to find out what decoder device are available on your device.

For devices using the [active channels] command, the command has been wrapped in the following `PolyChannelActivation` functions defined in [PolyDataAcquisition.h](\ref IO/DataAcquisition/PolyDataAcquisition.h):

 -	\ref PolyChannelActivationMaxChannelCount()
 -	\ref PolyChannelActivationIsChannelTypeSupported()
 -	\ref PolyChannelActivationIsChannelAvailable()
 -	\ref PolyChannelActivationEnableChannel()
 -	\ref PolyChannelActivationDisableChannel()
 -	\ref PolyChannelActivationDisableAllChannels()
 -	\ref PolyChannelActivationIsChannelEnabled()

To increase user comfort all non modifying functions of the functions listed above (e.g. \ref PolyChannelActivationIsChannelAvailable()) are also implemented for devices using the [output active] command.

You can find a usage example of the above mentioned functionalities ([output active] and [active channles]) in the `ChannelList.c`, `GetConfig.c` and `InteractiveConfig.c` files of the [Data acquisition example in C].

## Error handling
Most API functions return a [status code](\ref PTCCommunicationStatusCode).
It is important to check the outcome of each call to the API.
If this status code has a different value than [success](\ref PTCCommunicationStatusCode_Success) an error has occurred on the device or in the Device Communication library.
A message providing additional information about the last error can be fetched through the \ref PolyLastCommunicationStatus() function.
In this example the outcome of each API call is checked through the `CheckSuccess()` function, the implementation of which you can see in the following code snippet:

\snippet{lineno} examples/C/DeviceCommunication/DeviceCommunicationExample.c CheckSuccess


# What headers need to be included
To be able to communicate with a device using the Device Communication C interface it is sufficient to only include a single header file:

~~~{.c}
#include <IO/DeviceCommunication/PolyDeviceCommunication.h>		// Device Communication C interface definition
~~~ 

\note Take care that the device communication software's `include` directory is on your projects include path.


# Key takeaways
 -	A device communication connection can be **established over a serial or an Ethernet connection**
 -	A device communication connection opened using the C interface is managed through a \ref PTCommunicationHandle instance which **has to be closed** before exiting a program
 -	To get/set data **you need to know what [device types] and [device commands] are supported by your device** (see [Device types and device commands])
 -	Each [device command] uses a different **payload type**. Make sure to check the [command documentation](\ref PTCDeviceCommand) before using it.
 -	Commonly performed procedures have been wrapped in **high level functions** to simplify their use.
 
\see \ref gettingStarted
\see \ref examplesOverview
\see [Device types and device commands]


[Device Communication example in C++]: \ref cpp_example_communication
[Data acquisition example in C]: \ref c_example_acquisition
[Device types and device commands]: \ref deviceAndCommands
[device commands]: \ref PTCDeviceCommand
[device command]: \ref PTCDeviceCommand
[logical devices]: \ref PTCDeviceType
[logical device]: \ref PTCDeviceType
[device types]: \ref PTCDeviceType
[PolyDeviceCommunication.h]: \ref IO/DeviceCommunication/PolyDeviceCommunication.h
[active channels]: \ref PTCDeviceCommand_DaqActiveChannels
[output active]: \ref PTCDeviceCommand_OutputActive


\copyright (c) 2020-2021 %Polytec GmbH, Waldbronn Released under the terms of the GNU Lesser General Public License version 3.
