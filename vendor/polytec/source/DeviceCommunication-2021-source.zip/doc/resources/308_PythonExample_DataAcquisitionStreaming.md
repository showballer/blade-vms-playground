\page python_example_daqStreamingAndBlock Acquisition / Streaming and block acquisition

[TOC]

# Description
These examples show how to acquire data from a device in Python using either the streaming or the block mode acquisition.
Using these examples configures and performs an acquisition based on the cvonfiguration specified in each of those example scripts.
The acquired data is converted and written to CSV files.

These examples are located in **examples/Python/acquisition examples**

\see [Device Communication example in C](\ref c_example_communication) for further information about the Device Communication C Interface and its usage
\see [Data acquisition example in C](\ref c_example_acquisition) for further information about the Data Acquisition C Interface and its usage

\note The Python examples rely on the `polytec` package to be installed.
Take a look at the section [the polytec package](\ref polytecPackage) of the [Python examples overview](\ref python_examples) for further information.


# Examples overview

File					| Description
------------------------|-------------------------
acquire_streaming.py	| The script containing the streaming acquisition example
acquire_block_mode.py	| The script containing the block mode acquisition example
acquisition_control		| the `acquisiution_control` package providing acquisiton configuration and data acquisition functionalities
polytec					| The general `polytec` Python package
polytec/io				| The `polytec.io` subpackage providing a range of modules used for the device communication and data acquisition in Python


For the data acquisition examples an additional `acquisition_control` package is provided.
This package is located next to the acquisiton examples in the **examples/Python/acquisition examples** directory.
The examples detailed here use both the the `config` and the `acquire_to_csv` modules of the `acquisition_control` package.

The following code snippets shows the main functionalities of these examples defined in *acquire_streaming.py* and *acquire_block_mode.py*:

## Streaming

\snippet{lineno} "Examples/Python/acquisition examples/acquire_streaming.py" run

## Block mode

\snippet{lineno} "Examples/Python/acquisition examples/acquire_block_mode.py" run

The `run()` function of both of those examples can be broken down into two sections:

1.  Data acquisition configuration using the DaqConfig class
2.  Data acquisition to CSV using the aquire_to_csv module

The following sections will examine these steps in detail.


# Acquisition configuration

In order to simplify the configuration process the `DaqConfig` class is provided as part of the `acquisition_control` package, wrapping the most common data acquisiton configuration [commands](\ref PTCDeviceCommand) (e.g. [BlockSize](\ref PTCDeviceCommand_DaqBlockSize)).
As the code snippets above show, the interface of that class is very simple.
In order to get or set a configuration value, simply access it as if it was a member variable (e.g. `daq_config.block_count = 3`).
The `DaqConfig` class also provides additional methods to access the ranges or value lists of all of the configuration options.
Take a look at the [Configuration Options example in Python](\ref python_example_daqConfigOptions) for more information about this topic.


# Data acquisition implementation

The actual data acquisition is completely encapsulated by the `acquire_to_csv` module of the `acquisition_control` package.
You can see the `acquire_data()` function of that module beeing called in *Step 2* of the `run()` functions above.
`acquire_data()` is the only function exposed by the `acquire_to_csv` module.
Let's take a deeper look into that module and its components.

Here you can see a code snippet of the `acquire_data()` function:

\snippet{lineno} "Examples/Python/acquisition examples/acquisition_control/acquire_to_csv.py" acquire_data

As you can see it performs some preparatory steps, like the buffer capacity calculation and the creation of an `DataAcquisition` instance and then calls an other member function called `__acquire_data_to_csv()`.
The `__acquire_data_to_csv()` contains the actual data acquisition process implementation.

The following code snippet shows the implementation of the `__acquire_data_to_csv()` function:

\snippet{lineno} "Examples/Python/acquisition examples/acquisition_control/acquire_to_csv.py" acquire_data_to_csv

In the beginning of the `__acquire_data_to_csv()` function the current configuration is retrieved using a `DaqConfig` instance.
The `__get_active_channels()` subroutine is then used to get a list of all active channels, including additional inforamation used for the acuqision and unit conversion process.
The current date and time is saved to be used for the naming of the CSV files created.

Now the data acquisition is started on the device.
For each block (single block when streaming) the following acquisiton process is beeing performed individually.

## Data block acquisition process

1.	*Block mode only*: **Wait for the trigger** signal if configured using the `__wait_for_trigger()` subroutine
2.	**Generate the filename** for that block and open the file (each blcok gets written to an individual file)
3.	**Write the CSV headers** to the CSV file (including the Name, ID and Unit for each channel) usingh the `__write_csv_headers()` subroutine
4.	Now **for each data chunk** the following steps are executed
	1.	**Perform a blocking read**: The chunk samples are internally extracted from the ring buffer to another internal buffer making them available to be read using the `get_*_data()` functions
	2.	**Copy the signal and overrange data for each active channel** to its respective buffer in the active channels list
	3.	**Calculate the timestamp** of the first sample of that chunk
	4.	Convert the acquired samples to their base units and **write them the CSV file** using the `__write_chunk_data_to_csv()` subroutine
5.	*Block mode only*: Call the `next_data_acquisition_block()` method of the `DataAcquisition` instance to **start the acquisiton for the next data block**

After all blocks have been acquired the data acquisition ist stopped on the device and the process is completed.
Take a look at the `acquire_to_csv` module directly for more details about the acquisition process in Python and the subroutines mentioned above.


# Using these examples

These examples can be very useful to quickly and easily acquire any kind of data with any configuration from any %Polytec device.
Both examples can easily adapted to your needs to perform a quick and easy data acquisition to CSV.
You can also use the example scripts together with the `acquisition_control` package as a base to write your own data acquisition projects in Python, maybe also integrating the [channel selection](\ref python_example_daqChannelSelection) and [bandwidth and range configuration](\ref python_example_daqBandwidthAndRange) as well.


## Usage examples

### Streaming

```.sh
> python .\acquire_streaming.py 192.168.123.103
2021-04-28 15:23:06,680 [INFO] Successfully connected to the device: 192.168.123.103
2021-04-28 15:23:06,686 [INFO] ----------------------------------------
2021-04-28 15:23:06,686 [INFO] Data acquisition mode:   Streaming
2021-04-28 15:23:06,686 [INFO] ----------------------------------------
2021-04-28 15:23:06,737 [INFO] Writing 10000 samples to "2021-04-28_152306_AcquisitionData_0.csv"
2021-04-28 15:23:06,907 [INFO] Acquisition complete
2021-04-28 15:23:06,908 [INFO] Connection to the device closed
```

### Block acquisition

```.sh
> python .\acquire_block_mode.py 192.168.123.103
2021-04-28 15:20:06,818 [INFO] Successfully connected to the device: 192.168.123.103
2021-04-28 15:20:06,827 [INFO] ----------------------------------------
2021-04-28 15:20:06,827 [INFO] Data acquisition mode:   Block
2021-04-28 15:20:06,828 [INFO] Block count:             3
2021-04-28 15:20:06,828 [INFO] Block size:              200
2021-04-28 15:20:06,828 [INFO] Trigger mode:            Analog
2021-04-28 15:20:06,829 [INFO] Trigger edge:            Rising
2021-04-28 15:20:06,829 [INFO] Analog trigger source:   Velocity
2021-04-28 15:20:06,829 [INFO] Analog trigger level:    0.5
2021-04-28 15:20:06,830 [INFO] Gated trigger:           False
2021-04-28 15:20:06,830 [INFO] Pre-/Post-trigger:       2000
2021-04-28 15:20:06,830 [INFO] ----------------------------------------
2021-04-28 15:20:06,838 [INFO] Waiting for Analog trigger...
2021-04-28 15:20:06,859 [INFO] Writing 200 samples to "2021-04-28_152006_AcquisitionData_0.csv"
2021-04-28 15:20:06,865 [INFO] Waiting for Analog trigger...
2021-04-28 15:20:06,865 [INFO] Writing 200 samples to "2021-04-28_152006_AcquisitionData_1.csv"
2021-04-28 15:20:06,870 [INFO] Waiting for Analog trigger...
2021-04-28 15:20:06,881 [INFO] Writing 200 samples to "2021-04-28_152006_AcquisitionData_2.csv"
2021-04-28 15:20:06,885 [INFO] Acquisition complete
2021-04-28 15:20:06,887 [INFO] Connection to the device closed
```

\see \ref gettingStarted
\see \ref examplesOverview



\copyright (c) 2021 %Polytec GmbH, Waldbronn Released under the terms of the GNU Lesser General Public License version 3.
