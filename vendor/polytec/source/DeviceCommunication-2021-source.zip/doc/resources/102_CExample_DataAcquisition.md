\page c_example_acquisition Data Acquisition

[TOC]

# Description
This example shows how to use the Data Acquisition C interface in C.
The data will be acquired from the device through an Ethernet UDP stream.
For this, the user has to provide the devices IP address as a command line argument.
Additional command line arguments define whether the user wants to configure the device or acquire data from it.
Two Acquisition modes are supported: Streaming and Block acquisition.

\note Not all devices support the block acquisition (e.g. IVS-500 or VGO-200).

Running this example will either perform an interactive configuration of the device or acquire the specified amount of samples in streaming or block mode.
Acquired samples will be written to files with the following naming scheme: "<timestamp> AcquisitionData<blockId>.csv" (blockId is always 0 for streaming).
These files will be created in the directory the example has been executed in.
The data is written as CSV where each row represents a single sample and each column represents a data channel (e.g. Velocity, RSSI).
The active channels depend on the configuration of the device.

\note The knowledge gained through this example can easily be transfered to other languages using the C interface (e.g. [Python](\ref python_examples)).

Visual Studio Project Name: **Data-Acquisition-Example-C**

\see \ref gettingStarted for details on how to generate this project using CMake.


# What am I going to learn?
 -	Using the Data Acquisition C interface
 -	Configuring a data acquisition
 -	Starting a data acquisition
 -	Reading and interpreting the data acquired from a device


# Example overview
File						| Description
----------------------------|-------------------------
DataAcquisitionExample.c	| Example program implementation (main)
InteractiveUserConfig.h		| Defines functions used to perform an interactive configuration of the device
InteractiveUserConfig.c		| Interactive configuration implementation.
ChannelList.h				| Defines functions and structures to create a linked list of all active channels with additional information
ChannelList.c				| Channel list implementation.
GetConfig.h					| Defines functions to read the current configuration of a device
GetConfig.c					| Get config implementation.
WriteDataToCsv.h			| Defines functions to convert the raw data received from a device to physical values and output them to a CSV file
WriteDataToCsv.c			| Write data to CSV implementation.
Utils.h						| Utility function definitions


The program flow of this example can be broken down into five steps:
1. 	Handle the command line parameters and calculate the data acquisition ring buffer size
2.	Open a network communication and data acquisition connection with the device
3.	Stop any possibly running acquisition
4.	Depending on operation mode selected:
	- a) Perform an interactive configuration of the device
	- b) Setup and perform a data acquisition
5.	Close all connection handles

*Step 4b* can be further broken down into four substeps:

1.	Setup the acquisition and print the current configuration
2.	Start the acquisition stream on the device
3.	Read the available data and write it to a file
4.	Stop the acquisition stream on the device

All steps can be seen in the following as part of the programs `main()` function (defined in `DataAcquisitionExample.c`):

\snippet{lineno} examples/C/DataAcquisition/DataAcquisitionExample.c main

# How to configure a data acquisition  {#cConfigureDaq}
To acquire data it is always important to make sure that the device is configured to your needs.
Configuration options include settings like [bandwidth], [acquisition mode], [trigger mode](\ref PTCDeviceCommand_DaqTriggerMode) and [block count].
The device configuration is set and retrieved through the Device Communication API.
The following code snippet shows how the data [acquisition mode] and the [block size] are being configured for this example:

\snippet{lineno} examples/C/DataAcquisition/DataAcquisitionExample.c SetupDataAcquisition

\note `SetBlockSize()` uses the [low level API](\ref cLowLevelApi) to retrieve the range of the [block size] command from the device as the type of the command is `int32`.
This requires three API calls in total (\ref PolySendGetDevInfo(), \ref PolyGetInt32FromPayload(), \ref PolyFreePayload()).
For commands with type `int16` this operation is way simpler, as the range can be retrieved by a single higher level API call: \ref PolySendGetDevInfoRange() (usage example in `UserSelectBlockCount()` located in `InteractiveUserConfig.c`).

\note Some settings cannot be configured if a data acquisition is in progress.
Due to this fact any possibly running data acquisition is stopped on the device in *Step 3* of the `main()` function above.

\see [Device Communication example in C](\ref c_example_communication) for more information about the Device Communication
\see `InteractiveUserConfig.c` for more example code of how to configure a data acquisition on a device.
\see `GetConfig.c` for example code on how to read the data acquisition configuration from a device.

# Streaming vs. Block mode

## Streaming
In this [acquisition mode] data is streamed directly from the device without any trigger handling or pre-processing.
It is important to note that data streaming over a slow connection or with a high [bandwidth] and/or a large number of [active channels](\ref cChannelActivation) can result in a buffer overflow on the device as the throughput might be limited by the bandwidth of your network connection.

## Block
In block mode data is acquired and delivered in blocks.
Block mode enables further options to setup and configure a triggered data acquisition on the device.
If a trigger is enabled, the trigger will be used for each block individually.
Block acquisition can be especially useful if the bandwidth of your connection to the device is lower than the [bandwidth] of the acquired signal, as the complete data block is guaranteed to be able to be buffered on the device, while being delivered over the slower connection.
Block mode data acquisition is only limited by the buffer space available on the device (see [block size]).

\note Block mode is not available on all devices (e.g. IVS-500 and VGO-200).

# How the data acquisition works
The acquisition data is gathered by the device internally where it may be buffered before being transmitted over the Ethernet connection.
Not all devices support internal buffering (e.g. VGO-200 and IVS-500), but it is guaranteed that all devices supporting the block mode (e.g. VFX-F-110 and VIO-130) also support internal buffering as it is mandatory for the block acquisition.
The data transmitted by the device gets received and stored to a ring buffer by the Data Acquisition library in the background.
From there it can be extracted using the Data Acquisition API.

In order to start / stop a data acquisition stream you first need to open a data acquisition connection with a device.
This is achieved by calling \ref PolyOpenDataAcquisition() which initialized the \ref PTAcquisitionHandle provided.
\ref PTAcquisitionHandle is a reference to the now opened data acquisition connection with the device.
From this point on the Data Acquisition library silently fetches all incoming data into a ring buffer in the background.
In order to enable the transmission on the device you need to start the data acquisition stream using the \ref PolyStartDataAcquisition() API call.
The data acquisition stream is not enabled by default.

In order to be able to configure the next data acquisition, you need to stop any active data acquisition stream from the device (see \ref cConfigureDaq above).
Otherwise some of the settings are locked and cannot be manipulated.
You can do this using the \ref PolyStopDataAcquisition() API call.
In order to prevent any memory leaks, you also need to close the connections established through \ref PolyOpenDataAcquisition() by calling PolyCloseDataAcquisition() in the end.

You can see the usage of the above mentioned API calls as part of the code snippet of the `main()` function above.

# How to access the acquired data
The `AcquireData()` function (defined in `DataAcquisitionExample.c`), called from the `main()` function above, handles the acquisition and processing of the available data.
The following snippet shows the implementation of this and the `WaitForTrigger()` function (also defined in `DataAcquisitionExample.c`):

\snippet{lineno} examples/C/DataAcquisition/DataAcquisitionExample.c AcquireData

First some of previously configured the settings (see \ref cppConfigureDaq above) are being fetched from the device.
This information (e.g. the [block count]) is needed to acquire and interpret the data from the device properly.

Then a linked list of all active channels is created by calling `CreateChannelList()` (defined in `ChannelList.h`), providing additional information for data conversion and most importantly the necessary data buffers for each channel.
The active channels are determined through the `PolyChannelActivation*()` functions (e.g. \ref PolyChannelActivationIsChannelEnabled()).
See `CreateChannelList()` implementation in `ChannelList.c` for further information.

A date time string is created, used to prefix each CSV file created during the acquisition.

Now the actual acquisition and output to a CSV file is performed for each data block (single block for streaming) individually by the `AcquireAndWriteBlockToCsv()` function.
If block mode is enabled, the function awaits a possibly configured trigger before the acquisition is performed by calling the `WaitforTrigger()` function for each block.
Also in block mode the API function \ref PolyNextDataAcquisitionBlock() has to be called after each block, in order to inform the data acquisition that the current block has been completely processed and a new block can be received.

The following snippet shows the inner workings of the `AcquireAndWriteBlockToCsv()` function (defined in `DataAcquisitionExample.c`) performing the actual data acquisition.

\snippet{lineno} examples/C/DataAcquisition/DataAcquisitionExample.c AcquireAndWriteBlockToCsv

First the CSV file is opened and the header row is printed to the file using the `WriteCsvHeaders()` function (defined in `WriteDataToCsv.h`).
Then the already in the background acquired data is copied from each channel in chunks.
The chunk size is specified through the base buffer size of the buffers contained in the channels linked list.

For each chunk \ref PolyReadData() is being called.
\ref PolyReadData() is a blocking call, ensuring that the specified amount of base samples (chunk size) has been received bei the API in the background and is ready to be extracted.

Nowthe number of samples to be extracted is determined for each individual channel by calling the \ref PolyExtractedSampleCount() API function.
The samples are then copied to their respective buffers (within the linked list) using the \ref PolyGetInt32Data() API call.
All samples are copied as 32 bit integers as it simplifies the handling of the channels later.

In addition to the raw signal data the overrange data is copied to an additional 8 bit buffer for each available signal channels (Velocity, Displacement and Acceleration) using the \ref PolyGetOverrange() API call.

Finally the now acquired chunk samples are converted to physical values and written to a CSV file using the `WriteDataToCsv()` function (defined in `WriteDataToCsv.h`).

After all chunks have been processed the acquisition of that data block is complete and the CSV file is being closed.

\see \ref PTCChannelType for a list of all available channel types

# How to convert raw data samples to physical values
In order to retrieve the physical value (e.g. in m/s for velocity) from raw data samples, the raw value needs to be normalized using the maximum raw value of the channel and then multiplied with the channel headroom and a factor representing the range of the channel in its base unit:

	physicalValue = rawValue * headroom * rangeFactor / max

In our example the max. value, headroom and range factor are combined into a single multiplicable factor, called the ScaleFactor.

	ScaleFactor = headroom * rangeFactor / max

This factor is calculated for each active channel and stored within the channel linked list during the call to `CreateChannelList()` (defined in `ChannelList.h`).
The scale factor for each channel is calculated by the `ChannelScaleFactor()` function (defined in `GetConfig.h`).
The following snippet shows the source code of that function.

\snippet{lineno} examples/C/DataAcquisition/GetConfig.c ChannelScalefactor

First the max value for the channel is retrieved using the \ref PolyChannelMaxValue() API call.
Then, depending on the channel type, the unit and headroom factor is calculated through the `UnitAndHeadRoomFactor()` function (defined in `GetConfig.c`).
For the RSSI channel this factor is fixed to 100 in order to convert the raw samples into a percentage value.

# What headers need to be included
In order to be able to perform a simple data acquisition you need to include at least these two headers to your project:

~~~{.c}
#include <IO/DeviceCommunication/PolyDeviceCommunication.h>	// defines the Device Communication C interface
#include <IO/DataAcquisition/PolyDataAcquisition.h>			// defines the Data Acquisition C interface
~~~

\note Take care that the device communication software's `include` directory is on your projects include path.


# Good to know: Bandwidths and available channels
Higher [bandwidths] can lead to significantly more data needed to be buffered on the device (if supported) and transmitted over the Ethernet connection.
Selecting a higher [bandwidth] may restrict how many acquisition channels can be active at the same time.
Also some channel types may not be available at all with some [bandwidths] \(e.g. acceleration is not available on VFX-F-110 devices for [bandwidths] above 3 MHz).

\see System requirements defined on the \ref networkInfo page


# Key takeaways
 -	You need to **start the data acquisition stream through the Data Acquisition API** otherwise no data will be transmitted from the device
 -	A data acquisition connection opened using the C interface is managed through a \ref PTAcquisitionHandle instance which **has to be closed** before exiting a program
 -	The data acquisition (receiving of any incoming data) **starts as soon as a data acquisition connection has been opened** (data will be stored in a ring buffer managed by an object in the background)
 -	Depending on your device there are **many options to configure the data acquisition**
 -	**Raw data samples** received from a device **need to be converted to get physical values** (e.g. in m/s)
 
\see \ref gettingStarted
\see \ref examplesOverview


[block count]: \ref PTCDeviceCommand_DaqBlockCount
[block size]: \ref PTCDeviceCommand_DaqBlockSize
[acquisition mode]: \ref PTCDeviceCommand_DaqMode
[bandwidth]: \ref PTCDeviceCommand_Bandwidth
[bandwidths]: \ref PTCDeviceCommand_Bandwidth


\copyright (c) 2020-2021 %Polytec GmbH, Waldbronn Released under the terms of the GNU Lesser General Public License version 3.
