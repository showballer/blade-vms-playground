\page python_example_daqChannelSelection Acquisition / Channel selection

[TOC]

# Description
This example shows how the active acquisition channels can be configured on a device.
Which channels can be configured depends on the %Polytec device used.
Using this example lets the user interactively select the active acquisition channels on the connected device.

This example is located in **examples/Python/acquisition examples**

\see [Device Communication example in C] for further information about the Device Communication C Interface and its usage
\see [Data acquisition example in C](\ref c_example_acquisition) for further information about the Data Acquisition C Interface and its usage

\note The Python examples rely on the `polytec` package to be installed.
Take a look at the section [the polytec package](\ref polytecPackage) of the [Python examples overview](\ref python_examples) for further information.


# Example overview

File								| Description
------------------------------------|-------------------------
interactive_channel_selection.py	| The script containing this example
acquisition_control					| the `acquisiution_control` package providing acquisiton configuration and data acquisition functionalities
polytec								| The general `polytec` Python package
polytec/io							| The `polytec.io` subpackage providing a range of modules used for the device communication and data acquisition in Python


This example uses the `config` module which is part of the `acquisition_control` package, developed for the Python data acquisition examples.
This module is designed to simplify the configuration of a data acquisition.

\see [Data acquisition examples in Python](\ref python_example_daqStreamingAndBlock) for more information about the `acquisition_control package`.

Also the `ChannelActivation` class is beeing used as part of the `polytec.io` package.
This class can be used to read and manipulate the active channels of a device.
The manipulation capabilities are only enabled if the device supports the [DaqActiveChannels] command.
Take a look at the \ref cChannelActivation section of the [Device Communication example in C] for more information about this topic.

The following code snippet shows the main functionality of this example defined in *interactive_channel_selection.py*:

\snippet{lineno} "Examples/Python/acquisition examples/interactive_channel_selection.py" run

As the code snippet shows, the `run()` function can be devided in two logical sections:

1.  Communication preparation
2.  Interactive channel selection

*Step 1* opens a Device Communication with a device (see [Supported devices and commands example in Python](\ref python_example_dcDevsAndCmds) for more information) and creates a DaqConfig instance instance.
Those instances are then used in *Step 2* to determine the channel selection command supported by the device.
Based on the result of this query, one of the following functions is called, enabling the user to interactively select the active channels.

## ChannelActivation
The following code snippet shows the implementation of the interactive channel activation using the `ChannelActivation` class.
This channel selection method is used for Devices supporting the [DaqActiveChannels] command.
The [DaqActiveChannels] gives you full control over all acquisition channels of a device.

\snippet{lineno} "Examples/Python/acquisition examples/interactive_channel_selection.py" channel_activation

In the beginning a `ChannelActivation` instance is created and all channels are beeing disabled.
The function then iterates over all [ChannelTypes](\ref PTCChannelType) and tests how many channels of each [ChannelType](\ref PTCChannelType) are supported by the device.
For each availble channel the user gets prompted whether he wants that channel top be enabled or not.

## OutputActive selection
The code snippet below shows the implementation of the intearctive output active selection.
This channel selection method is used for devices supporting the [OutputActive] command.
The [OutputActive] command lets you select the active signal channel between Velocity, Displacement and Acceleration, only one of which can be active at the same time.
Signal channel availablity depends on your %Polytec device.

\snippet{lineno} "Examples/Python/acquisition examples/interactive_channel_selection.py" output_active_selection

As you can see, the [OutputActive] command has been wrapped by the `DaqConfig` class (part of the `acquisition_control` package).
This simplifies the channel selection dramatically.

\see The \ref cChannelActivation section of the [Device Communication example in C] for more information about the [DaqActiveChannels] and [OutputActive] commands.
\see \ref python_example_daqConfigOptions for more information about the available channels of your device.


# Using this example
This example is very useful to quickly and easily configure the active channels of a device based on the devices capabilities.

## Usage examples

### ChannelActivation (VFX-F-110)

```.sh
> python .\interactive_channel_selection.py 192.168.123.103
Enable Velocity channel 0 [Y/n]:
Enable RSSI channel 0 [Y/n]: n
Enable Trigger channel 0 [Y/n]:
Enable Displacement channel 0 [Y/n]:
Enable Acceleration channel 0 [Y/n]: n
```

### OutputActive selection (VGO-200)

```.sh
> python .\interactive_channel_selection.py 192.168.123.103
Currently active output: Velocity
Available active output channels: Velocity, Displacement, Acceleration
New active output: Displacement
```

\see \ref gettingStarted
\see \ref examplesOverview


[Device Communication example in C]: \ref c_example_communication
[DaqActiveChannels]: \ref PTCDeviceCommand_DaqActiveChannels
[OutputActive]: \ref PTCDeviceCommand_OutputActive

\copyright (c) 2021 %Polytec GmbH, Waldbronn Released under the terms of the GNU Lesser General Public License version 3.
