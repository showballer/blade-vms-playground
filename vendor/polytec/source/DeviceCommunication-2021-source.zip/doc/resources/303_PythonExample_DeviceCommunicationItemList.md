\page python_example_dcItemList Communication / Item list commands

[TOC]

# Description
This example shows how the [polytec package](\ref polytecPackage) can be used to interact with an item list command.
Using this example reads the currently selected and all available items from an item list [device command] \(e.g. [Range]) and allows the user to select a new current value.

This example is located in **examples/Python/communication examples**

\see \ref cItemListFunctions for further information about item lists and the C API used in this example
\see [Device Communication example in C] for further information about the C Interface and its usage
\see \ref deviceAndCommands for further information about [logical devices], [device commands] and their access methods
\see [Supported devices and commands example in Python] for a glimpse into the inner workings of the `polytec` Python package and the use of the C interface in Python

\note The Python examples rely on the `polytec` package to be installed.
Take a look at the section [the polytec package](\ref polytecPackage) of the [Python examples overview](\ref python_examples) for further information.


# Example overview

File			| Description
----------------|-------------------------
item_list.py	| The script containing this example
polytec			| The general `polytec` Python package
polytec/io		| The `polytec.io` subpackage providing a range of modules used for the device communication and data acquisition in Python

Here you can see this examples main function defined in *item_list.py*:

\snippet{lineno} "Examples/Python/communication examples/item_list.py" main

The process implemented in this example is fairly simple, as the code snippet above shows.
It consists of two major steps:

1.  Establishing a device communication
2.  A item list command demonstration

Detailed information about *step 1* can be found in the [Supported devices and commands example in Python].
*Step 2* demonstrates how an instance of the `ItemList` class is created and how it can be interacted with.
The `ItemList` class provides a set of methods to get the current, supported and available items, set the current item and check if a specific item is currently avaibale.
Three of those methods are used in the code snippet above: `available_items()`, `get_current_item()` and `set_current_item()`
Take a look at the implementations of the `ItemList` class, implemented in `polytec/io/item_list.py`, to get more informations about all available methods and their parameters.

\see \ref cItemListFunctions for further information about item lists and the C API functions wrapped by the `ItemList` class
\see [Supported devices and commands example in Python] for further information about the inner workings of the `DeviceCommunication` class and the use of the C interface in Python

# Using this example
This example can be useful to quickly manipulate an item list [device command] \(e.g. the Velocity [Range]) on a %Polytec device.
Use the following commands to print the scripts help and get more information about their command line interface:

```.sh
python .\item_list.py -h
```

\note Setting the logging level to "DEBUG" (`-l DEBUG`) will expose every Device Communication API call with its argument values to the log.
This might be interesting to understand all the inner workings of the `polytec` Python package.

## Usage example

```.sh
> python .\item_list.py 192.168.123.103 VelocityDecoderDigital Range
Available items: 2 m/s, 1 m/s, 500 mm/s, 200 mm/s, 100 mm/s, 50 mm/s, 20 mm/s, 10 mm/s
Current item: 2 m/s
--------------------------------------------------------------------------------
Specify new item to be set: 50 mm/s
Successfully set current item to "50 mm/s"
```

\see \ref deviceAndCommands
\see \ref gettingStarted
\see \ref examplesOverview


[Device Communication example in C]: \ref c_example_communication
[Supported devices and commands example in Python]: \ref python_example_dcDevsAndCmds
[device commands]: \ref PTCDeviceCommand
[device command]: \ref PTCDeviceCommand
[logical devices]: \ref PTCDeviceType
[logical device]: \ref PTCDeviceType
[Range]: \ref PTCDeviceCommand_Range


\copyright (c) 2021 %Polytec GmbH, Waldbronn Released under the terms of the GNU Lesser General Public License version 3.
