\page labView_examples LabVIEW examples

[TOC]

The Device Communication Software project includes two LabVIEW examples detailing the use of the Device Communication and Data Acquisition Interface in LabVIEW.

Example															| Level	| Description
----------------------------------------------------------------|-------|--------------
\subpage labView_example_communication "Device Communication"	| Basic	| A simple example project showing how to use the Device Communication LabVIEW VIs
\subpage labView_example_acquisition "Data Acquisition"			| Basic	| A simple example project showing how to use the Data Acquisition LabVIEW VIs


# Running examples
Open the example project in your LabVIEW environment and run the desired VIs.


# Importing the shared library in LabVIEW  {#importLibToLabView}

\note Tested using following configurations:
 -	Windows 10, NI LabVIEW 2014 SP1 (32 Bit)

## How to import the Device Communication functions  {#importDeviceComm}
1.	Open LabVIEW
2.	Select "Tools/Import/Shared Library (.dll)..."

	\image{inline} html doc/resources/img/LabView_Using_0_Import_SharedLibrary.png "Import Shared Library"

3.	Specify Create Mode

	\image{inline} html doc/resources/img/LabView_Using_1_Specify_Create_Mode.png "Specify Create Mode"

4.	Select Shared Library and Header File

	For "Shared Library (.dll) File" navigate to "Device Communication Software" root directory (directory containing the folders `build32`, `build64`, `examples`, ...) and select `build32/DeviceCommunication/Release/DeviceCommunication.dll` or `build64/DeviceCommunication/Release/DeviceCommunication.dll` (depending on your LabVIEW build architecture).

	For "Header (.h) File" navigate to "Device Communication Software" root directory (directory containing the folders `build32`, `build64`, `examples`, ...) and select `/Include/IO/DeviceCommunication/PolyDeviceCommunication.h`.

	\note The Device Communication Interface depends on `stdlib.h` and `stdint.h` which are not provided with this project.
	In order to be able to use the API in LabVIEW you need to provide those headers by yourself.
	You can either download these headers or use the once included with your Visual Studio installation (if available).
	Simply add those headers to the directory of your library header (e.g. PolyDeviceCommunication.h) is being loaded from (e.g. include/IO/DeviceCommunication).

	\image{inline} html doc/resources/img/LabView_Using_2_Select_Library_Header.png "Select Shared Library and Header File"

5.	Configure Include Paths

	\image{inline} html doc/resources/img/LabView_Using_3_Configure_Include_Paths.png "Configure Include Paths"

6.	Select the functions to import (select all)

	\image{inline} html doc/resources/img/LabView_Using_4_Select_Functions.png "Select Functions to Convert"

7.	Configure Project Library Settings

	Specify "Project Library Name (.lvlib)" and "Project Library Path" at your discretion and check "Copy the shared library file to the destination directory.".

	\note If you accept the default path to your LabVIEW development software `user.lib` you can use the resulting VIs via the functions palette of the block diagram when writing your own VIs.

	\note If you do not check "Copy the shared library file to the destination directory." you will not be able to use the functions of the shared library later.

	\image{inline} html doc/resources/img/LabView_Using_5_Configure_Project_Settings.png "Configure Project Library Settings"

8.	Select the Error Handling Mode

	\note It is recommended to select "Function Returns Error Code/Status" which adds an Error Converter VI after each function call.
	Selecting this you have to remove the Error Converter call from all functions which do not return the PTCCommunicationStatusCode (e.g. \ref PolyCloseCommunication).
 
	\image{inline} html doc/resources/img/LabView_Using_6_Select_Error_Handling.png "Select Error Handling Mode"

	\note Due to the fact that the API uses error codes greater than zero, it is necessary to later replace the error code check from lower than zero to greater than zero in the imported "Error Converter (ErrCode or Status).vi" VI.

	\note It is recommended to place the "Poly Last Communication Status.vi" VI into the TRUE case of the error code check.
	This will get you the latest error message in case of an error has occurred.
	Make sure to remove the call to the Error Converter VI inside the "Poly Last Communication Status.vi" VI in order to prevent a recursive loop.

	\image{inline} html doc/resources/img/LabView_Using_6_1_Error_Converter.png "Recommended block diagram of ErrorConverter (ErrCode or Status).vi"

9.	Configure VIs and Controls

	Here you can see and configure the VI properties for each of the imported functions.
	The values should be set correctly by default.

	\image{inline} html doc/resources/img/LabView_Using_7_Configure_VIs.png "Configure VIs and Controls"

10.	After finishing the import wizard you should be able to use the resulting LabVIEW library and its VIs in your LabVIEW projects.

	\image{inline} html doc/resources/img/LabView_Using_8_DeviceCommunication_lvlib.png "Device Communication LabVIEW Library"

## How to import the Data Acquisition functions

Importing the Data Acquisition functions requires the same steps as the [Device Communication functions](\ref importDeviceComm) above.
You just need to replace the reference to the Header file with `/Include/IO/DataAcquisition/PolyDataAcquisition.h`.

\note During *Step 9* "Configure VIs and Controls" you need to change definition of the `dataBuffer` parameter for the `PolyGetInt16Data`, `PolyGetUInt16Data` and `PolyGetUInt8Data` functions as shown in the images below:

\image{inline} html doc/resources/img/LabView_Using_Configure_GetInt16Data.png "Configuration of the dataBuffer for PolyGetIntData(U)Int16Data)"

\image{inline} html doc/resources/img/LabView_Using_Configure_GetUInt8Data.png "Configuration of the dataBuffer for PolyGetUInt8Data"

\see \ref gettingStarted
\see \ref examplesOverview
\see [Ethernet Settings](\ref networkInfo)


\copyright (c) 2020-2021 %Polytec GmbH, Waldbronn Released under the terms of the GNU Lesser General Public License version 3.
