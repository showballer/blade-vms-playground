\page labView_example_acquisition LabVIEW example: Data Acquisition

[TOC]

# Description
This simple example shows how to use the Data Acquisition C interface in LabVIEW.
The data will be acquired from the device through an Ethernet UDP stream.
For this, the user has to provide the devices IP address over the user interface.
Running this example will acquire 10,000 samples from a device.
These samples are then displayed in waveform graphs on the user interface.

LabVIEW Project: **DataAcquisitionExample.lvproj**

\see \ref importLibToLabView for details on how to import the Device Communication library using an import wizard.
\see [Data Acquisition C example] implements similar but more advanced functionality using the same interface in C.
\see [Data Acquisition C++ example] implements similar but more advanced functionality using the C++ interface.

# What am I going to learn?
 -	Using the Data Acquisition library in LabVIEW
 -	Starting the data acquisition
 -	Reading and interpreting the data acquired from the device

# Example files
File							| Description
--------------------------------|-------------------------
DataAcquisitionExample.lvproj	| Example program project
DataAcquisition.lvlib			| Imported Data Acquisition C interface wrapper VIs

# Taking a look at the code
This example program consists of five major parts:
1. 	Open an Ethernet communication with the device based on the IP address specified through the user interface
2. 	Open a data acquisition connection with the device
3. 	Configure and start the acquisition stream on the device
4. 	Receive data from the UDP stream and write it to a waveform graph
5.	Close all connection handles

For information on step 1 see [Device Communication LabVIEW Example](\ref labView_example_communication).
*Steps 2* to *5* can be seen in the following as part of the DevicePanel.vi (defined in `DataAcquisitionExample.lvproj`):

\image html doc/resources/img/LabView_Example_DataAcquisition.png "Block diagram of DevicePanel.vi showing the data acquisition event case."

\note In order to prevent memory leaks, it is important to **close the connections you established** when they are no longer needed (see *step 5* above).
To do this do not connect the error cluster to `Poly Close Communication.vi` or `Poly Close Data Acquisition.vi**` in order to prevent the functions from not being called in case of an error.

## How to get the data acquisition stream started
The data acquisition stream is not enabled by default.
A specific command needs to be sent to the device via the Device Communication API in order to enable it.
This is achieved by *step 1* and *3* of the steps above.
*Step 1* opens a connection to communicate with the device using an Ethernet connection.
*Step 3* configures this example for the use with a device (e.g. VGO-200, VFX-F-110) and then calls `Poly Start Data Acquisition.vi`, a VI provided by the Data Acquisition LabVIEW library which uses the connection opened in *step 2* to enable the data acquisition stream.
You can see the implementation of the `Configure.vi` below:

\image html doc/resources/img/LabView_Example_Configure.png "Block diagram of Configure.vi used to set some acquisition properties for different devices."

## How to access the acquired data
*Step 2* and *4* of the steps above are responsible for the actual data acquisition process.
*Step 2* opens an Ethernet connection for the data acquisition which immediately starts to listen to the IP address of the given connection.
All incoming data is stored in a ring buffer of the provided capacity.

The following image shows the call of the `Poly Open Data Acquisition.vi` called in *step 2* to open the connection:

\image html doc/resources/img/LabView_Example_OpenAcqConnection.png "Open data acquisition connection."

*Step 4* then reads 10,000 samples from the ring buffer, checks their validity and shows the converted physical values for each sample in a waveform graph on the UI.
The implementation of *step 4* is contained in `ReadIncomingMeasurementData.vi` whose source code can be seen in the following:

\image html doc/resources/img/LabView_Example_ReadIncomingMeasurementData.png "Block diagram of ReadIncomingMeasurementData.vi."

## How to convert raw data samples to physical values
Looking at `ReadIncomingMeasurementData.vi` above, we see two VIs being called to convert the raw data to physical values.
Let's take a look at their implementation:

\image html doc/resources/img/LabView_Example_ConvertVelocityRawData.png "Block diagram of ConvertVelocityRawData.vi."
\image html doc/resources/img/LabView_Example_ConvertRSSIRawData.png "Block diagram of ConvertRSSIRawData.vi."

As you can see, the conversion is rather simple.
To convert the raw velocity data to m/s first the headroom is fetched from the device.
Then each sample is normalized with the maximum value of the Velocity channel (`rawSample / max`) and scaled with the velocity range setting and headroom.
For the signal level, it is even simpler.
First, the maximum value of the RSSI channel is fetched from the device, then each sample is normalized with that value and scaled with 100.
This converts each signal level sample to a percent value.

# Key takeaways
 -	You need to **start the data acquisition stream using the Data Acquisition LabVIEW library** otherwise no data will be transmitted from the device
 -	The data acquisition (receiving of any incoming data) **starts as soon as a data acquisition connection has been opened** (data will be stored in a ring buffer managed by an object in the background)
 -	**Raw data samples** received from a device **need to be converted to get physical values** (e.g. in m/s)
 
\see \ref gettingStarted
\see \ref examplesOverview
\see \ref importLibToLabView


[Data Acquisition C example]: \ref c_example_acquisition
[Data Acquisition C++ example]: \ref cpp_example_acquisition


\copyright (c) 2020-2021 %Polytec GmbH, Waldbronn Released under the terms of the GNU Lesser General Public License version 3.
