\page python_example_daqConfigOptions Acquisition / Get available configuration options

[TOC]

# Description
This simple example shows how the available data acquisition configuration options and supported acquisition channels of your device can be determined (e.g. block mode support).
Using this example prints all available configuration options and acquisition channels of your device to the command line.

This example is located in **examples/Python/acquisition examples**

\see [Device Communication example in C] for further information about the Device Communication C Interface and its usage
\see [Data acquisition example in C](\ref c_example_acquisition) for further information about the Data Acquisition C Interface and its usage

\note The Python examples rely on the `polytec` package to be installed.
Take a look at the section [the polytec package](\ref polytecPackage) of the [Python examples overview](\ref python_examples) for further information.


# Example overview

File				| Description
--------------------|-------------------------
config_options.py	| The script containing this example
acquisition_control	| the `acquisiution_control` package providing acquisiton configuration and data acquisition functionalities
polytec				| The general `polytec` Python package
polytec/io			| The `polytec.io` subpackage providing a range of modules used for the device communication and data acquisition in Python


This example uses the `config` module which is part of the `acquisition_control` package, developed for the Python data acquisition examples.
This module is designed to simplify the configuration of a data acquisition.

\see [Data acquisition examples in Python](\ref python_example_daqStreamingAndBlock) for more information about the `acquisition_control package`.

The following code snippet shows the main functionality of this example defined in *config_options.py*:

\snippet{lineno} "Examples/Python/acquisition examples/config_options.py" run

As the code snippet shows, the `run()` function can be devided in two logical sections:

1.  Communication preparation
2.  Reading and printing of the configuration options and aquisition channels 

*Step 1* opens a Device Communication with a device (see [Supported devices and commands example in Python](\ref python_example_dcDevsAndCmds) for more information), creates a DaqConfig instance and a ChannelActivation instance.
Those instances are then used in *Step 2* to read and print out the available configuration options and channels from the connected %Polytec device.


# Using this example
This example can be useful to find out the configuration options of your device (e.g. the range of the [Pre/Post-Trigger](\ref PTCDeviceCommand_DaqPreTrigger)).
It also tells you whether your device uses the [channel activation](\ref PTCDeviceCommand_DaqActiveChannels) or [output active](\ref PTCDeviceCommand_OutputActive) command and what channels are supported by your device.
Take a look at the \ref cChannelActivation section of the [Device Communication example in C] for more information about this topic.

## Usage example

```.sh
> python .\config_options.py 192.168.123.103
Data acquisition modes:         Streaming, Block
Block count range:              (0, 32767)
Block size range:               (1, 22369621)
Trigger modes:                  None, Extern, Analog
Trigger edges:                  Falling, Rising
Analog trigger sources:         Velocity, Displacement, Acceleration
Analog trigger level range:     (-1.0, 1.0)
Pre-/Post-trigger range:        (-2147483648, 22369621)
Active output supported:        False
Channel activation supported:   True
Supported channels:
        Velocity 0
        RSSI 0
        Trigger 0
        Displacement 0
        Acceleration 0
```

\see \ref gettingStarted
\see \ref examplesOverview


[Device Communication example in C]: \ref c_example_communication

\copyright (c) 2021 %Polytec GmbH, Waldbronn Released under the terms of the GNU Lesser General Public License version 3.
