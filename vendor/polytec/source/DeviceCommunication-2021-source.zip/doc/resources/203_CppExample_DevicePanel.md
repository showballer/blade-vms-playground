\page cpp_example_devicePanel Device Panel

[TOC]


# Description
This comprehensive example project contains a feature-rich Qt application.
This application gives control over a range of device commands (e.g. [laser on/off](\ref PTCDeviceCommand_LaserOn), [bandwidth](\ref PTCDeviceCommand_Bandwidth), [velocity range](\ref PTCDeviceCommand_Range)) and can also perform a data acquisition, plotting incoming data streams to the UI.
The connection can be established via an Ethernet or serial communication.

This document will *not* attempt to explain all the details of the extensive source code involved, but rather give an overview over the application and its features.
See some of the [other examples](\ref examplesOverview) to get detailed information about the basics of the Device Communication and Data Acquisition Interface including explanations of the code involved.

Visual Studio Project Name: **PolytecDevicePanel**

# Main Window

\image{inline} html doc/resources/img/DevicePanel_0_ConnectionWindow.png "Connection Window"


Upon opening the application you are presented with a window consisting of two sections, the connection view and the side bar (see image above).
The side bar is persistent throughout the whole application, whereas the connection view will be replaced by a tabbed view as soon as a connection has been established.

## Side bar

\image{inline} html doc/resources/img/DevicePanel_1_SideBar.png "Side Bar"


The side bar consists of three buttons:
 -	**Connect**: When pressed, the application will try to connect to a device using the parameters set through the connection view (disabled when a connection has already been established).
 -	**Disconnect**: If a connection has been established, this button can be used to disconnect a device (disabled when a connection has not been established yet).
 -	**License**: Displays an dialog providing information about licensing of this software.

## Connection view

\image{inline} html doc/resources/img/DevicePanel_2_ConnectionSerial.png "Connection view (serial)"
\image{inline} html doc/resources/img/DevicePanel_2_ConnectionUDP.png "Connection view (UDP)"


The connection view is used to setup a connection to be established.
You can choose from three communication types using the drop down menu labeled "Communication Protocol".
The combo boxes below this drop down menu will adapt to your selection.
For a serial connection, you have to set a COM-Port and the Baud Rate, where for an Ethernet connection (UDP and TCP) you have to provide the devices IP address.

## Configuration tab

\image{inline} html doc/resources/img/DevicePanel_3_Configuration.png "Configuration tab"


Using the configuration tab, you can read information and settings from and set settings on a device connected.
This example user interface features similar settings and information as the user interfaces of our other Polytec products do.
Here are some of the things you can do with this interface:
 -	Set the velocity range
 -	Perform an autofocus with the limits of your choice
 -	Set the focus distance manually
 -	Control the laser (on / off)
 -	Read the current signal level
 -	Saving the current settings as *User 1* Settings using the [SaveUserSettings](\ref PTCDeviceCommand_SaveUserSettings) command
 -	Selecting the Power-Up User Settings to be loaded

## Data Acquisition tab

\image{inline} html doc/resources/img/DevicePanel_4_DataAcquisition.png "Data Acquisition tab (active)"


The Data Acquisition tab provides a simple user interface featuring some data plots each plotting the data of a single data acquisition channel.
On the top, you can start and stop the data acquisition using the respective buttons.
Additionally the drop down list below those buttons can be used to set the amount of data to be displayed in the plots (only enabled if a data acquisition is not running).
What data plots are being shown depends on what data channels are active during the start of a data acquisition.
Before starting the first data acquisition, this tab shows no data plots.
Start a data acquisition to display the data plots of the currently active channels.

\note Orange lines indicate overrange.

\see \ref examplesOverview


\copyright (c) 2020-2021 %Polytec GmbH, Waldbronn Released under the terms of the GNU Lesser General Public License version 3.
