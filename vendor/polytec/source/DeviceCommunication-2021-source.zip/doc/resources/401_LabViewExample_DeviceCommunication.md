\page labView_example_communication LabVIEW example: Device Communication

[TOC]

# Description
This simple example shows how to use the Device Communication C interface in LabVIEW.
The C interface is equivalent to the interface exported by the Device Communication DLL (see \ref gettingStarted).
The device communication in this example will be established via a UDP Ethernet connection.
When the example has been started, a list of all available velocity ranges is fetched from the device and set to a selection list.
The user then has to pick one of the velocity ranges from the list.
Subsequently the example program will turn on the laser and perform an autofocus (if available with the connected device).

LabVIEW Project: **DeviceCommunicationExample.lvproj**

\see \ref importLibToLabView for details on how to import the Device Communication library using an import wizard.
\see [Device Communication C example] implements the same functionality using the same interface in C.
\see [Device Communication C++ example] implements the same functionality using the C++ interface.

# What am I going to learn?
 -	Using the Device Communication library in LabVIEW
 -	Establishing a connection with a device
 -	Communication with the device
 	 -	Getting information from the device (e.g. a current setting)
 	 -	Setting data on the device (e.g. turn laser on)

# Example files
File								| Description
------------------------------------|-------------------------
DeviceCommunicationExample.lvproj	| Example program implementation (DevicePanel)
DeviceCommunication.lvlib			| Imported Device communication C interface wrapper VIs

# Taking a look at the code
This example program consists of five major parts:
1. 	Open an Ethernet communication with the device based on the IP address provided
2. 	Let the user pick a velocity range
3. 	Turn on the laser
4. 	Autofocus the laser (if available)
5. 	Close the Ethernet communication

## How to connect with a device
In order to open a connection with a device you need to call either `Poly Open Serial Communication.vi` or `Poly Open UDP Ethernet Communication.vi`.
Both take a pointer to a \ref PTCommunicationHandle as their first argument, which will be initialized as the communication handle by either function.
`Connect.vi`, which is part of this example, contains the implementation for opening an Ethernet connection:

\image html doc/resources/img/LabView_Example_Connect.png "Block diagram of Connect.vi"

\note In order to prevent memory leaks, it is important to **close the connections you established** when they are no longer needed.
To do this do not connect the error cluster to the `Poly Close Communication.vi` in order to prevent the function from not being called in case of an error.

## How to communicate with a connected device
In order to communicate with the device you have to use the VIs located in `DeviceCommunication.lvlib`.
Not all of those VIs are necessary for a simple communication (Set/Get values).
You will mostly use a small subset of those VIs:

Method									| Usage
----------------------------------------|------------
Poly Send Get \<DataType>.vi			| Sends a Get-command to the device to fetch a command of the data type specified (e.g. Int16). A Get-command is used to get information about a current or static state of the device, e.g. the current focus position or the name of the device.
Poly Send Set \<DataType>.vi			| Sends a Set-command to the device with a value of the specified data type (e.g. Int16). A Set-command is used to control the state of a given device e.g. set the laser on.
Poly Item List Get Available Items.vi	| Sends a Get-command to the device to retrieve all available items of an item list command (e.g. Bandwidth).
Poly Item List Get Current Item.vi		| Sends a Get-command to the device to get the current item of an item list command (e.g. Bandwidth).
Poly Item List Set Current Item.vi		| Sends a Set-command to the device to set the current item of an item list command (e.g. Bandwidth).
Poly Has Command.vi						| Sends a command to check whether the device has the given device command (e.g. Data acquisition mode).
Poly Has Device.vi						| Sends a command to check whether the device has the given logical device (e.g. Sensor Head).

The following shows an example of one of those VIs:

\image html doc/resources/img/LabView_Example_GetInt16.png "Poly Send Get Int16.vi"

Most of the VIs expect the following four input parameters:

Type						| Description
----------------------------|------------
\ref PTCommunicationHandle	| The communication handle created when opening a connection
\ref PTCDeviceType			| The device type of the part of the device you want to communicate with (e.g. sensor head)
`int`						| The device number of the part of the device you want to communicate with (used if there are multiple devices e.g. multiple sensor heads in a device)
\ref PTCDeviceCommand		| The device command you want to send to the device (e.g. laser on)

The output/input parameter of the get/set VIs depends on the VI and its data type.

See [Device types and device commands] to find out what devices and commands are supported by your device.

\see deviceCommand enum terminal for further information about all commands available.
\see deviceType enum terminal for further information about all device types available.

### SetVelocityRangeItem.vi
This VI enables the user to set the velocity range to his needs.
To achieve this, the user first puts in the item of the velocity range he wants to be set.
This item is then set on the device by calling `Poly Item List Set Current Item.vi` using the \ref PTCDeviceType_VelocityDecoderDigital device and the \ref PTCDeviceCommand_Range command.

\image html doc/resources/img/LabView_Example_SetVelocityRangeItem.png "SetVelocityRangeItem.vi block diagram"

### AutofocusIfAvailable()
This function performs an autofocus if supported by the device.
First, a VI is being called to check if the device supports the autofocus command.
If autofocus is supported, the \ref PTCDeviceCommand_Autofocus command is sent to the sensor head of the device.
Then the function waits until the autofocus has finished.

\image html doc/resources/img/LabView_Example_AutofocusIfAvailable.png "AutofocusIfAvailable.vi block diagram"

# Key takeaways
 -	A connection to a device can be **established over a serial or an Ethernet connection**
 -	A connection opened using the C interface is managed through a \ref PTCommunicationHandle instance which **has to be closed** before exiting a program
 -	To get/set data **you need to know what *device types* and *commands* are supported by your device** (see [Device types and device commands])
 
\see \ref gettingStarted
\see \ref examplesOverview
\see [Device types and device commands]
\see \ref importLibToLabView


[Device Communication C example]: \ref c_example_communication
[Device Communication C++ example]: \ref cpp_example_communication
[Device types and device commands]: \ref deviceAndCommands


\copyright (c) 2020-2021 %Polytec GmbH, Waldbronn Released under the terms of the GNU Lesser General Public License version 3.
