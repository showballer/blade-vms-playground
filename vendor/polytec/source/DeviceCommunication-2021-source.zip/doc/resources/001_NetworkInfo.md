\page networkInfo Network Connection

[TOC]

Here you can find some information about how to setup your network configuration for using the Device Communication Software.

# Setting up a peer-to-peer connection
1.	Connect your device with a peer-to-peer Ethernet connection to your computer.
2.	Assign a static unique IP-address in the same subnet to your computer and your %Polytec device.

# Recommended system settings
If your network adapter has a property to set the receive and transmission buffer sizes, you may want to set them to maximum.
On Windows set your Power Options to "High performance".

# Firewall settings
Take care that your Firewall does not block the network data acquisition.
If you start a data acquisition on Windows for the first time and your Windows Firewall informs you about blocking the network communication, allow access to private and public networks for your executable.

# System requirements

## UDP Streaming (e.g. IVS-500)
Devices using a UDP connection for the data acquisition have to be connected over a direct peer-to-peer Ethernet connection in order to guarantee that the packets are received in the correct order.
A modern desktop computer and Ethernet cables of high quality are recommended.
The use of a laptop for this use case is discouraged as the power management might interfere with the data transmissions, which can lead to packet loss.

## TCP streaming (e.g. VGO-200)
To avoid any buffer overflows, make sure that the connection between your computer and your %Polytec device can handle the amount of data being transmitted.
When in doubt, use block mode acquisition (if supported by your device).

## Block acquisition
Block mode acquisitions can be performed over any kind of network connection and with any computer.
During block acquisition it is guaranteed that the whole data block can be buffered on your %Polytec device until it has been completely transmitted to your computer.

\note Not all devices support block mode acquisition.


\copyright (c) 2016-2021 %Polytec GmbH, Waldbronn Released under the terms of the GNU Lesser General Public License version 3.
