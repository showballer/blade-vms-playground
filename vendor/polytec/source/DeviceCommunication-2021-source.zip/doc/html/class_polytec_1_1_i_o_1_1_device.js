var class_polytec_1_1_i_o_1_1_device =
[
    [ "Device", "class_polytec_1_1_i_o_1_1_device.html#a2bf80be87cf3d0dd61119c19df9b7b25", null ],
    [ "Number", "class_polytec_1_1_i_o_1_1_device.html#a83dc76cfefedc20d2b7576110aebe8a1", null ],
    [ "Type", "class_polytec_1_1_i_o_1_1_device.html#aa007432cdc114edb742a5493168641a4", null ]
];