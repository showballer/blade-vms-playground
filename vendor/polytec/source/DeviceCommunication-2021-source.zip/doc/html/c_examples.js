var c_examples =
[
    [ "Device Communication", "c_example_communication.html", [
      [ "Description", "c_example_communication.html#autotoc_md27", null ],
      [ "What am I going to learn?", "c_example_communication.html#autotoc_md28", null ],
      [ "Example overview", "c_example_communication.html#autotoc_md29", null ],
      [ "How to establish a communication with a device", "c_example_communication.html#autotoc_md30", null ],
      [ "How to communicate with a connected device", "c_example_communication.html#howtocommunicate", [
        [ "High level Get/Set API functions", "c_example_communication.html#autotoc_md31", null ],
        [ "Low level API", "c_example_communication.html#cLowLevelApi", null ],
        [ "High level value range API functions", "c_example_communication.html#autotoc_md32", null ],
        [ "High level item list API functions", "c_example_communication.html#cItemListFunctions", null ],
        [ "High level device and command list API functions", "c_example_communication.html#autotoc_md33", null ],
        [ "High level channel activation", "c_example_communication.html#cChannelActivation", null ],
        [ "Error handling", "c_example_communication.html#autotoc_md34", null ]
      ] ],
      [ "What headers need to be included", "c_example_communication.html#autotoc_md35", null ],
      [ "Key takeaways", "c_example_communication.html#autotoc_md36", null ]
    ] ],
    [ "Data Acquisition", "c_example_acquisition.html", [
      [ "Description", "c_example_acquisition.html#autotoc_md37", null ],
      [ "What am I going to learn?", "c_example_acquisition.html#autotoc_md38", null ],
      [ "Example overview", "c_example_acquisition.html#autotoc_md39", null ],
      [ "How to configure a data acquisition", "c_example_acquisition.html#cConfigureDaq", null ],
      [ "Streaming vs. Block mode", "c_example_acquisition.html#autotoc_md40", [
        [ "Streaming", "c_example_acquisition.html#autotoc_md41", null ],
        [ "Block", "c_example_acquisition.html#autotoc_md42", null ]
      ] ],
      [ "How the data acquisition works", "c_example_acquisition.html#autotoc_md43", null ],
      [ "How to access the acquired data", "c_example_acquisition.html#autotoc_md44", null ],
      [ "How to convert raw data samples to physical values", "c_example_acquisition.html#autotoc_md45", null ],
      [ "What headers need to be included", "c_example_acquisition.html#autotoc_md46", null ],
      [ "Good to know: Bandwidths and available channels", "c_example_acquisition.html#autotoc_md47", null ],
      [ "Key takeaways", "c_example_acquisition.html#autotoc_md48", null ]
    ] ]
];