var _p_t_c_channel_type_8h =
[
    [ "PTCChannelType", "_p_t_c_channel_type_8h.html#a7773ec088e64f7c55d1e12bd7cc420d3", null ],
    [ "PTCChannelType", "_p_t_c_channel_type_8h.html#afa57fab7efaa6f8f89f02419d4339e2f", [
      [ "PTCChannelType_Unknown", "_p_t_c_channel_type_8h.html#afa57fab7efaa6f8f89f02419d4339e2fa4c1d34087cb74aac66ce0d35f57015c3", null ],
      [ "PTCChannelType_DataValidity", "_p_t_c_channel_type_8h.html#afa57fab7efaa6f8f89f02419d4339e2faa7d3035291abaab8b829ef2a03eaba0e", null ],
      [ "PTCChannelType_Velocity", "_p_t_c_channel_type_8h.html#afa57fab7efaa6f8f89f02419d4339e2fa36f28c15b1e5cf3b1614afacd7954c2d", null ],
      [ "PTCChannelType_RSSI", "_p_t_c_channel_type_8h.html#afa57fab7efaa6f8f89f02419d4339e2fa6c111ac521132bdd16d28c3f36feb736", null ],
      [ "PTCChannelType_Trigger", "_p_t_c_channel_type_8h.html#afa57fab7efaa6f8f89f02419d4339e2fa23cf76bec36b2b3d70d33c5545d28531", null ],
      [ "PTCChannelType_Displacement", "_p_t_c_channel_type_8h.html#afa57fab7efaa6f8f89f02419d4339e2fa58c39bc0c0e0b78e5b4fff865673c638", null ],
      [ "PTCChannelType_Acceleration", "_p_t_c_channel_type_8h.html#afa57fab7efaa6f8f89f02419d4339e2fa288f9182b3f98b2700336a689aeff5c3", null ]
    ] ]
];