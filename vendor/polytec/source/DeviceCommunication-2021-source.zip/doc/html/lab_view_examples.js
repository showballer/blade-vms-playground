var lab_view_examples =
[
    [ "Running examples", "lab_view_examples.html#autotoc_md122", null ],
    [ "Importing the shared library in LabVIEW", "lab_view_examples.html#importLibToLabView", [
      [ "How to import the Device Communication functions", "lab_view_examples.html#importDeviceComm", null ],
      [ "How to import the Data Acquisition functions", "lab_view_examples.html#autotoc_md123", null ]
    ] ],
    [ "LabVIEW example: Device Communication", "lab_view_example_communication.html", [
      [ "Description", "lab_view_example_communication.html#autotoc_md124", null ],
      [ "What am I going to learn?", "lab_view_example_communication.html#autotoc_md125", null ],
      [ "Example files", "lab_view_example_communication.html#autotoc_md126", null ],
      [ "Taking a look at the code", "lab_view_example_communication.html#autotoc_md127", [
        [ "How to connect with a device", "lab_view_example_communication.html#autotoc_md128", null ],
        [ "How to communicate with a connected device", "lab_view_example_communication.html#autotoc_md129", null ]
      ] ],
      [ "Key takeaways", "lab_view_example_communication.html#autotoc_md130", null ]
    ] ],
    [ "LabVIEW example: Data Acquisition", "lab_view_example_acquisition.html", [
      [ "Description", "lab_view_example_acquisition.html#autotoc_md131", null ],
      [ "What am I going to learn?", "lab_view_example_acquisition.html#autotoc_md132", null ],
      [ "Example files", "lab_view_example_acquisition.html#autotoc_md133", null ],
      [ "Taking a look at the code", "lab_view_example_acquisition.html#autotoc_md134", [
        [ "How to get the data acquisition stream started", "lab_view_example_acquisition.html#autotoc_md135", null ],
        [ "How to access the acquired data", "lab_view_example_acquisition.html#autotoc_md136", null ],
        [ "How to convert raw data samples to physical values", "lab_view_example_acquisition.html#autotoc_md137", null ]
      ] ],
      [ "Key takeaways", "lab_view_example_acquisition.html#autotoc_md138", null ]
    ] ]
];