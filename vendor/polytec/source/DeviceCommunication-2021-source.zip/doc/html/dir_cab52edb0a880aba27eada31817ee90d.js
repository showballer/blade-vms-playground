var dir_cab52edb0a880aba27eada31817ee90d =
[
    [ "DataAcquisition", "dir_73ad9c604f64eebb47efdcec7d9ac076.html", "dir_73ad9c604f64eebb47efdcec7d9ac076" ],
    [ "DeviceCommunication", "dir_f758fc2c5264db17fa6e544d4bf3dd06.html", "dir_f758fc2c5264db17fa6e544d4bf3dd06" ]
];