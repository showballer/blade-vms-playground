var class_polytec_1_1_i_o_1_1_measurement_data =
[
    [ "MeasurementData", "class_polytec_1_1_i_o_1_1_measurement_data.html#a550d05ea4314e132a36a59b01c4e5be1", null ],
    [ "MeasurementData", "class_polytec_1_1_i_o_1_1_measurement_data.html#a0f60438d9a2b8412e5e244640ea6e9c2", null ],
    [ "BaseSampleCount", "class_polytec_1_1_i_o_1_1_measurement_data.html#ae05432ff07fba8c6ee2776fabd0d24c8", null ],
    [ "Get", "class_polytec_1_1_i_o_1_1_measurement_data.html#aa9fcffdf5e449eb46721de4573dbe3f5", null ],
    [ "GetOverrange", "class_polytec_1_1_i_o_1_1_measurement_data.html#adde0409aa1c03d69512820705470b17d", null ],
    [ "GetRawSamples", "class_polytec_1_1_i_o_1_1_measurement_data.html#a5d4ec59b90629215b4309c6e632589fb", null ],
    [ "SampleCount", "class_polytec_1_1_i_o_1_1_measurement_data.html#a17795ccab13e363a8f879aa86eebaf9c", null ]
];