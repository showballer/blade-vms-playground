var python_examples =
[
    [ "Communication examples", "python_examples.html#autotoc_md78", null ],
    [ "Acquisition examples", "python_examples.html#autotoc_md79", null ],
    [ "The polytec package", "python_examples.html#polytecPackage", [
      [ "Installation", "python_examples.html#autotoc_md80", null ],
      [ "Usage", "python_examples.html#autotoc_md81", null ]
    ] ],
    [ "Communication / Supported devices and commands", "python_example_dc_devs_and_cmds.html", [
      [ "Description", "python_example_dc_devs_and_cmds.html#autotoc_md82", null ],
      [ "What am I going to learn?", "python_example_dc_devs_and_cmds.html#autotoc_md83", null ],
      [ "Example overview", "python_example_dc_devs_and_cmds.html#autotoc_md84", null ],
      [ "Connecting to a device / using the C Interface in Python", "python_example_dc_devs_and_cmds.html#autotoc_md85", null ],
      [ "Communicating with a device", "python_example_dc_devs_and_cmds.html#autotoc_md86", null ],
      [ "Using this example", "python_example_dc_devs_and_cmds.html#autotoc_md87", null ],
      [ "Key takeaways", "python_example_dc_devs_and_cmds.html#autotoc_md88", null ]
    ] ],
    [ "Communication / Get and Set device commands", "python_example_dc_set_get.html", [
      [ "Description", "python_example_dc_set_get.html#autotoc_md89", null ],
      [ "Examples overview", "python_example_dc_set_get.html#autotoc_md90", null ],
      [ "Using these examples", "python_example_dc_set_get.html#autotoc_md91", [
        [ "Usage examples", "python_example_dc_set_get.html#autotoc_md92", null ]
      ] ]
    ] ],
    [ "Communication / Item list commands", "python_example_dc_item_list.html", [
      [ "Description", "python_example_dc_item_list.html#autotoc_md93", null ],
      [ "Example overview", "python_example_dc_item_list.html#autotoc_md94", null ],
      [ "Using this example", "python_example_dc_item_list.html#autotoc_md95", [
        [ "Usage example", "python_example_dc_item_list.html#autotoc_md96", null ]
      ] ]
    ] ],
    [ "Acquisition / Get available configuration options", "python_example_daq_config_options.html", [
      [ "Description", "python_example_daq_config_options.html#autotoc_md97", null ],
      [ "Example overview", "python_example_daq_config_options.html#autotoc_md98", null ],
      [ "Using this example", "python_example_daq_config_options.html#autotoc_md99", [
        [ "Usage example", "python_example_daq_config_options.html#autotoc_md100", null ]
      ] ]
    ] ],
    [ "Acquisition / Channel selection", "python_example_daq_channel_selection.html", [
      [ "Description", "python_example_daq_channel_selection.html#autotoc_md101", null ],
      [ "Example overview", "python_example_daq_channel_selection.html#autotoc_md102", [
        [ "ChannelActivation", "python_example_daq_channel_selection.html#autotoc_md103", null ],
        [ "OutputActive selection", "python_example_daq_channel_selection.html#autotoc_md104", null ]
      ] ],
      [ "Using this example", "python_example_daq_channel_selection.html#autotoc_md105", [
        [ "Usage examples", "python_example_daq_channel_selection.html#autotoc_md106", null ]
      ] ]
    ] ],
    [ "Acquisition / Bandwidth and range selection", "python_example_daq_bandwidth_and_range.html", [
      [ "Description", "python_example_daq_bandwidth_and_range.html#autotoc_md107", null ],
      [ "Example overview", "python_example_daq_bandwidth_and_range.html#autotoc_md108", [
        [ "Bandwidth selection", "python_example_daq_bandwidth_and_range.html#autotoc_md109", null ],
        [ "Range selection", "python_example_daq_bandwidth_and_range.html#autotoc_md110", null ]
      ] ],
      [ "Using this example", "python_example_daq_bandwidth_and_range.html#autotoc_md111", [
        [ "Usage examples", "python_example_daq_bandwidth_and_range.html#autotoc_md112", null ]
      ] ]
    ] ],
    [ "Acquisition / Streaming and block acquisition", "python_example_daq_streaming_and_block.html", [
      [ "Description", "python_example_daq_streaming_and_block.html#autotoc_md113", null ],
      [ "Examples overview", "python_example_daq_streaming_and_block.html#autotoc_md114", [
        [ "Streaming", "python_example_daq_streaming_and_block.html#autotoc_md115", null ],
        [ "Block mode", "python_example_daq_streaming_and_block.html#autotoc_md116", null ]
      ] ],
      [ "Acquisition configuration", "python_example_daq_streaming_and_block.html#autotoc_md117", null ],
      [ "Data acquisition implementation", "python_example_daq_streaming_and_block.html#autotoc_md118", [
        [ "Data block acquisition process", "python_example_daq_streaming_and_block.html#autotoc_md119", null ]
      ] ],
      [ "Using these examples", "python_example_daq_streaming_and_block.html#autotoc_md120", [
        [ "Usage examples", "python_example_daq_streaming_and_block.html#autotoc_md121", null ]
      ] ]
    ] ]
];