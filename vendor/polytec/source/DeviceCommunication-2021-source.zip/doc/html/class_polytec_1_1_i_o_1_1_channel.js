var class_polytec_1_1_i_o_1_1_channel =
[
    [ "Channel", "class_polytec_1_1_i_o_1_1_channel.html#a04a07df56ee270306639fcaa19f2b4e8", null ],
    [ "Number", "class_polytec_1_1_i_o_1_1_channel.html#a0d590f6a8f65d3a00de03749e854f2b3", null ],
    [ "Type", "class_polytec_1_1_i_o_1_1_channel.html#a6ea1350885a067bb15605448dbe1dc94", null ]
];