var namespaces_dup =
[
    [ "Polytec", "namespace_polytec.html", "namespace_polytec" ]
];