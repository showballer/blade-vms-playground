var cpp_examples =
[
    [ "Device Communication", "cpp_example_communication.html", [
      [ "Description", "cpp_example_communication.html#autotoc_md49", null ],
      [ "What am I going to learn?", "cpp_example_communication.html#autotoc_md50", null ],
      [ "Example overview", "cpp_example_communication.html#autotoc_md51", null ],
      [ "How to establish a communication with a device", "cpp_example_communication.html#autotoc_md52", null ],
      [ "How to communicate with a connected device", "cpp_example_communication.html#autotoc_md53", [
        [ "Basic device communication", "cpp_example_communication.html#autotoc_md54", null ],
        [ "Item list commands", "cpp_example_communication.html#autotoc_md55", null ],
        [ "Device and command list commands", "cpp_example_communication.html#autotoc_md56", null ],
        [ "Channel activation", "cpp_example_communication.html#cppChannelActivation", null ],
        [ "Error handling", "cpp_example_communication.html#autotoc_md57", null ]
      ] ],
      [ "What headers need to be included", "cpp_example_communication.html#autotoc_md58", null ],
      [ "Key takeaways", "cpp_example_communication.html#autotoc_md59", null ]
    ] ],
    [ "Data Acquisition", "cpp_example_acquisition.html", [
      [ "Description", "cpp_example_acquisition.html#autotoc_md60", null ],
      [ "What am I going to learn?", "cpp_example_acquisition.html#autotoc_md61", null ],
      [ "Example overview", "cpp_example_acquisition.html#autotoc_md62", null ],
      [ "How to configure a data acquisition", "cpp_example_acquisition.html#cppConfigureDaq", null ],
      [ "Streaming vs. Block mode", "cpp_example_acquisition.html#autotoc_md63", [
        [ "Streaming", "cpp_example_acquisition.html#autotoc_md64", null ],
        [ "Block", "cpp_example_acquisition.html#autotoc_md65", null ]
      ] ],
      [ "How the data acquisition works", "cpp_example_acquisition.html#autotoc_md66", null ],
      [ "How to access the acquired data", "cpp_example_acquisition.html#autotoc_md67", null ],
      [ "How to convert raw data samples to physical values", "cpp_example_acquisition.html#autotoc_md68", null ],
      [ "What headers need to be included", "cpp_example_acquisition.html#autotoc_md69", null ],
      [ "Good to know: Bandwidths and available channels", "cpp_example_acquisition.html#autotoc_md70", null ],
      [ "Key takeaways", "cpp_example_acquisition.html#autotoc_md71", null ]
    ] ],
    [ "Device Panel", "cpp_example_device_panel.html", [
      [ "Description", "cpp_example_device_panel.html#autotoc_md72", null ],
      [ "Main Window", "cpp_example_device_panel.html#autotoc_md73", [
        [ "Side bar", "cpp_example_device_panel.html#autotoc_md74", null ],
        [ "Connection view", "cpp_example_device_panel.html#autotoc_md75", null ],
        [ "Configuration tab", "cpp_example_device_panel.html#autotoc_md76", null ],
        [ "Data Acquisition tab", "cpp_example_device_panel.html#autotoc_md77", null ]
      ] ]
    ] ]
];