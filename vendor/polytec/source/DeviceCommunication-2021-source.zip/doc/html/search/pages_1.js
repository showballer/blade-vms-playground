var searchData=
[
  ['c_20examples',['C examples',['../c_examples.html',1,'examplesOverview']]],
  ['c_2b_2b_20examples',['C++ examples',['../cpp_examples.html',1,'examplesOverview']]],
  ['communication_20_2f_20supported_20devices_20and_20commands',['Communication / Supported devices and commands',['../python_example_dc_devs_and_cmds.html',1,'python_examples']]],
  ['communication_20_2f_20item_20list_20commands',['Communication / Item list commands',['../python_example_dc_item_list.html',1,'python_examples']]],
  ['communication_20_2f_20get_20and_20set_20device_20commands',['Communication / Get and Set device commands',['../python_example_dc_set_get.html',1,'python_examples']]]
];
