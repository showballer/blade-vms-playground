var searchData=
[
  ['nextdataacquisitionblock',['NextDataAcquisitionBlock',['../class_polytec_1_1_i_o_1_1_data_acquisition.html#af0045fe2578985c3a6a936d3c38c0929',1,'Polytec::IO::DataAcquisition']]],
  ['number',['Number',['../class_polytec_1_1_i_o_1_1_channel.html#a0d590f6a8f65d3a00de03749e854f2b3',1,'Polytec::IO::Channel::Number()'],['../class_polytec_1_1_i_o_1_1_device.html#a83dc76cfefedc20d2b7576110aebe8a1',1,'Polytec::IO::Device::Number()']]]
];
