var searchData=
[
  ['what',['what',['../class_polytec_1_1_i_o_1_1_communication_exception.html#ac8b157c799241b48ece9a6d8990933c2',1,'Polytec::IO::CommunicationException']]]
];
