var searchData=
[
  ['getting_20started',['Getting Started',['../getting_started.html',1,'']]],
  ['gnu_20general_20public_20license',['GNU General Public License',['../gpl.html',1,'license']]],
  ['gnu_20lesser_20general_20public_20license',['GNU Lesser General Public License',['../lgpl.html',1,'license']]]
];
