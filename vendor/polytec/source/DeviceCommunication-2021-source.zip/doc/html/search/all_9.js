var searchData=
[
  ['measurementdata',['MeasurementData',['../class_polytec_1_1_i_o_1_1_measurement_data.html',1,'Polytec::IO::MeasurementData'],['../class_polytec_1_1_i_o_1_1_measurement_data.html#a550d05ea4314e132a36a59b01c4e5be1',1,'Polytec::IO::MeasurementData::MeasurementData()=default'],['../class_polytec_1_1_i_o_1_1_measurement_data.html#a0f60438d9a2b8412e5e244640ea6e9c2',1,'Polytec::IO::MeasurementData::MeasurementData(std::vector&lt; std::byte &gt; &amp;&amp;data, std::unique_ptr&lt; IDeinterlacer &gt; deinterlacer)']]],
  ['measurementdata_2eh',['MeasurementData.h',['../_measurement_data_8h.html',1,'']]]
];
