var searchData=
[
  ['basesamplecount',['BaseSampleCount',['../class_polytec_1_1_i_o_1_1_measurement_data.html#ae05432ff07fba8c6ee2776fabd0d24c8',1,'Polytec::IO::MeasurementData']]],
  ['basesamplerateinhz',['BaseSampleRateInHz',['../class_polytec_1_1_i_o_1_1_data_acquisition.html#a54b1d23a558dedcd1c64dd168f1df83f',1,'Polytec::IO::DataAcquisition']]]
];
