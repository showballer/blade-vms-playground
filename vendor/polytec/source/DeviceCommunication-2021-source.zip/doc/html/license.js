var license =
[
    [ "GNU General Public License", "gpl.html", [
      [ "Preamble", "gpl.html#autotoc_md146", null ],
      [ "TERMS AND CONDITIONS", "gpl.html#autotoc_md147", [
        [ "0. Definitions", "gpl.html#autotoc_md148", null ],
        [ "1. Source Code", "gpl.html#autotoc_md149", null ],
        [ "2. Basic Permissions", "gpl.html#autotoc_md150", null ],
        [ "3. Protecting Users' Legal Rights From Anti-Circumvention Law", "gpl.html#autotoc_md151", null ],
        [ "4. Conveying Verbatim Copies", "gpl.html#autotoc_md152", null ],
        [ "5. Conveying Modified Source Versions", "gpl.html#autotoc_md153", null ],
        [ "6. Conveying Non-Source Forms", "gpl.html#autotoc_md154", null ],
        [ "7. Additional Terms", "gpl.html#autotoc_md155", null ],
        [ "8. Termination", "gpl.html#autotoc_md156", null ],
        [ "9. Acceptance Not Required for Having Copies", "gpl.html#autotoc_md157", null ],
        [ "10. Automatic Licensing of Downstream Recipients", "gpl.html#autotoc_md158", null ],
        [ "11. Patents", "gpl.html#autotoc_md159", null ],
        [ "12. No Surrender of Others' Freedom", "gpl.html#autotoc_md160", null ],
        [ "13. Use with the GNU Affero General Public License", "gpl.html#autotoc_md161", null ],
        [ "14. Revised Versions of this License", "gpl.html#autotoc_md162", null ],
        [ "15. Disclaimer of Warranty", "gpl.html#autotoc_md163", null ],
        [ "16. Limitation of Liability", "gpl.html#autotoc_md164", null ],
        [ "17. Interpretation of Sections 15 and 16", "gpl.html#autotoc_md165", null ]
      ] ],
      [ "How to Apply These Terms to Your New Programs", "gpl.html#autotoc_md166", null ]
    ] ],
    [ "GNU Lesser General Public License", "lgpl.html", [
      [ "0. Additional Definitions", "lgpl.html#autotoc_md139", null ],
      [ "1. Exception to Section 3 of the GNU GPL", "lgpl.html#autotoc_md140", null ],
      [ "2. Conveying Modified Versions", "lgpl.html#autotoc_md141", null ],
      [ "3. Object Code Incorporating Material from Library Header Files", "lgpl.html#autotoc_md142", null ],
      [ "4. Combined Works", "lgpl.html#autotoc_md143", null ],
      [ "5. Combined Libraries", "lgpl.html#autotoc_md144", null ],
      [ "6. Revised Versions of the GNU Lesser General Public License", "lgpl.html#autotoc_md145", null ]
    ] ]
];