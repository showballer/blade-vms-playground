var class_polytec_1_1_i_o_1_1_data_acquisition =
[
    [ "DataAcquisition", "class_polytec_1_1_i_o_1_1_data_acquisition.html#a0bbe5ae580d334992a1b653c18cde124", null ],
    [ "DataAcquisition", "class_polytec_1_1_i_o_1_1_data_acquisition.html#af4c7e2768665dc13a6c295f6f23439b8", null ],
    [ "DataAcquisition", "class_polytec_1_1_i_o_1_1_data_acquisition.html#a0f9a86ccfd00fc4f74e02f2fde940617", null ],
    [ "~DataAcquisition", "class_polytec_1_1_i_o_1_1_data_acquisition.html#a16440b6a0d1368b8f78ce2be83de318e", null ],
    [ "DataAcquisition", "class_polytec_1_1_i_o_1_1_data_acquisition.html#ac4c7c8ebd6482eeba45e9b038a5a9d89", null ],
    [ "ActiveChannels", "class_polytec_1_1_i_o_1_1_data_acquisition.html#a187906a67e276b99b5a5c747e5a501c1", null ],
    [ "AvailableSamples", "class_polytec_1_1_i_o_1_1_data_acquisition.html#a498ce8ee61a03fae5c00392469da9b07", null ],
    [ "BaseSampleRateInHz", "class_polytec_1_1_i_o_1_1_data_acquisition.html#a54b1d23a558dedcd1c64dd168f1df83f", null ],
    [ "ChannelMaxValue", "class_polytec_1_1_i_o_1_1_data_acquisition.html#aa8adc63298967e9e55e3892435af856d", null ],
    [ "ChannelMinValue", "class_polytec_1_1_i_o_1_1_data_acquisition.html#a1606718771a7df909f8bf89a2ca0aa9e", null ],
    [ "Close", "class_polytec_1_1_i_o_1_1_data_acquisition.html#a0f1eaa1a40e670743622206f8840bfe4", null ],
    [ "IsAcquisitionStarted", "class_polytec_1_1_i_o_1_1_data_acquisition.html#a67b8ab6c8c4d567bc77fd1d026e364a8", null ],
    [ "NextDataAcquisitionBlock", "class_polytec_1_1_i_o_1_1_data_acquisition.html#af0045fe2578985c3a6a936d3c38c0929", null ],
    [ "operator=", "class_polytec_1_1_i_o_1_1_data_acquisition.html#a1bda73c8e4f23c641994c8d41f82bb6c", null ],
    [ "operator=", "class_polytec_1_1_i_o_1_1_data_acquisition.html#a58105899950fa896e8d31f91f7c67b2b", null ],
    [ "ReadAvailableData", "class_polytec_1_1_i_o_1_1_data_acquisition.html#a87a9300a3d1653b2848d684375e10046", null ],
    [ "ReadData", "class_polytec_1_1_i_o_1_1_data_acquisition.html#a5dc87bac94d1d1a6263af76e531a8217", null ],
    [ "StartAcquisition", "class_polytec_1_1_i_o_1_1_data_acquisition.html#ad5f60987306d1d3597a7410662e47fdd", null ],
    [ "StopAcquisition", "class_polytec_1_1_i_o_1_1_data_acquisition.html#aed71a362c1d9327fc89ded25eb5131e2", null ]
];