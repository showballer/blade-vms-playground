/*
@ @licstart  The following is the entire license notice for the
JavaScript code in this file.

Copyright (C) 1997-2017 by Dimitri van Heesch

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

@licend  The above is the entire license notice
for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "Device Communication Software", "index.html", [
    [ "Overview", "index.html", [
      [ "Folder structure", "index.html#autotoc_md0", null ],
      [ "API structure", "index.html#autotoc_md1", [
        [ "Device Communication", "index.html#autotoc_md2", null ],
        [ "Data Acquisition", "index.html#autotoc_md3", null ]
      ] ],
      [ "What to read next", "index.html#autotoc_md4", null ]
    ] ],
    [ "Getting Started", "getting_started.html", [
      [ "Using the API", "getting_started.html#autotoc_md5", [
        [ "C interface / DLLs", "getting_started.html#autotoc_md6", null ],
        [ "C++ interface", "getting_started.html#autotoc_md7", null ],
        [ "Python", "getting_started.html#autotoc_md8", null ]
      ] ],
      [ "Building the library from source", "getting_started.html#bfs", [
        [ "Requirements", "getting_started.html#autotoc_md9", null ],
        [ "How to build", "getting_started.html#autotoc_md10", null ]
      ] ],
      [ "Examples", "getting_started.html#autotoc_md11", [
        [ "Running examples", "getting_started.html#autotoc_md12", null ],
        [ "Building the examples from source", "getting_started.html#autotoc_md13", null ]
      ] ],
      [ "What to read next", "getting_started.html#autotoc_md14", null ]
    ] ],
    [ "Network Connection", "network_info.html", [
      [ "Setting up a peer-to-peer connection", "network_info.html#autotoc_md15", null ],
      [ "Recommended system settings", "network_info.html#autotoc_md16", null ],
      [ "Firewall settings", "network_info.html#autotoc_md17", null ],
      [ "System requirements", "network_info.html#autotoc_md18", [
        [ "UDP Streaming (e.g. IVS-500)", "network_info.html#autotoc_md19", null ],
        [ "TCP streaming (e.g. VGO-200)", "network_info.html#autotoc_md20", null ],
        [ "Block acquisition", "network_info.html#autotoc_md21", null ]
      ] ]
    ] ],
    [ "Device types and device commands", "device_and_commands.html", [
      [ "Logical devices and device commands", "device_and_commands.html#autotoc_md22", [
        [ "Logical devices", "device_and_commands.html#autotoc_md23", null ],
        [ "Device commands", "device_and_commands.html#autotoc_md24", null ]
      ] ],
      [ "How to get a list of all supported devices and/or commands", "device_and_commands.html#autotoc_md25", null ],
      [ "Testing if a specific device or command is supported", "device_and_commands.html#autotoc_md26", null ]
    ] ],
    [ "Examples overview", "examples_overview.html", "examples_overview" ],
    [ "License", "license.html", "license" ],
    [ "Namespaces", "namespaces.html", [
      [ "Namespace List", "namespaces.html", "namespaces_dup" ],
      [ "Namespace Members", "namespacemembers.html", [
        [ "All", "namespacemembers.html", null ],
        [ "Functions", "namespacemembers_func.html", null ]
      ] ]
    ] ],
    [ "Classes", "annotated.html", [
      [ "Class List", "annotated.html", "annotated_dup" ],
      [ "Class Index", "classes.html", null ],
      [ "Class Hierarchy", "hierarchy.html", "hierarchy" ],
      [ "Class Members", "functions.html", [
        [ "All", "functions.html", null ],
        [ "Functions", "functions_func.html", null ]
      ] ]
    ] ],
    [ "Files", "files.html", [
      [ "File List", "files.html", "files_dup" ],
      [ "File Members", "globals.html", [
        [ "All", "globals.html", "globals_dup" ],
        [ "Functions", "globals_func.html", null ],
        [ "Typedefs", "globals_type.html", null ],
        [ "Enumerations", "globals_enum.html", null ],
        [ "Enumerator", "globals_eval.html", "globals_eval" ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"_all_acquisition_8h.html",
"_p_t_c_device_command_8h.html#a74dc0c1c333a6704e59c812b9a1a5bfdad832546a37e1c5452a8fc3b0b3258660",
"class_polytec_1_1_i_o_1_1_data_acquisition.html#a16440b6a0d1368b8f78ce2be83de318e",
"python_example_dc_devs_and_cmds.html#autotoc_md86"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';