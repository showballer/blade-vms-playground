var _device_communication_8h =
[
    [ "DeviceCommunication", "class_polytec_1_1_i_o_1_1_device_communication.html", "class_polytec_1_1_i_o_1_1_device_communication" ],
    [ "CreateSerialCommunication", "_device_communication_8h.html#a6e69b52a9ae2ffdc73b29dc76eaaf49c", null ],
    [ "CreateTcpEthernetCommunication", "_device_communication_8h.html#a96e9a807d832608f123cdbdadfe53e86", null ],
    [ "CreateUdpEthernetCommunication", "_device_communication_8h.html#aeb979259331d72dd4e93028150540524", null ]
];