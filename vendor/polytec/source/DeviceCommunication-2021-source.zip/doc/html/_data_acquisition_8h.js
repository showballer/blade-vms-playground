var _data_acquisition_8h =
[
    [ "DataAcquisition", "class_polytec_1_1_i_o_1_1_data_acquisition.html", "class_polytec_1_1_i_o_1_1_data_acquisition" ],
    [ "CreateDigitalDataAcquisition", "_data_acquisition_8h.html#a019bb8095302cc5bd9c394b30684f1d7", null ]
];