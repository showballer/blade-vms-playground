var class_polytec_1_1_i_o_1_1_communication_exception =
[
    [ "CommunicationException", "class_polytec_1_1_i_o_1_1_communication_exception.html#a6883c76861ce02a058e109f3796ce6b7", null ],
    [ "CommunicationException", "class_polytec_1_1_i_o_1_1_communication_exception.html#a272de6357e47126aae64cbfec4dc29fd", null ],
    [ "AdditionalInformation", "class_polytec_1_1_i_o_1_1_communication_exception.html#aab0e1c2e8584b9d5c5d4e06935cefa50", null ],
    [ "GetStatusCode", "class_polytec_1_1_i_o_1_1_communication_exception.html#a7afe66d8214fee03485a0ff9dd0c38e1", null ],
    [ "StatusMessage", "class_polytec_1_1_i_o_1_1_communication_exception.html#a0e53e6864d0ce54009dc29d50f0b5a3b", null ],
    [ "what", "class_polytec_1_1_i_o_1_1_communication_exception.html#ac8b157c799241b48ece9a6d8990933c2", null ]
];