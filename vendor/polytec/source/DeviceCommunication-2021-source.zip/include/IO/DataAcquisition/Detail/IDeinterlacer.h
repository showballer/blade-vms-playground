// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#pragma once

#include <IO/DataAcquisition/Detail/DataAcquisitionPayloadType.h>
#include <IO/DataAcquisition/Detail/ProtocolType.h>
#include <IO/DataAcquisition/Detail/IDataLossControl.h>
#include <IO/DataAcquisition/PTCChannelType.h>

#include <gsl/gsl>

#include <cstddef>
#include <memory>
#include <optional>

namespace Polytec::IO
{
	class Channel;

	/// <summary>
	/// This class represents functionality for extracting samples from a digital data stream.
	/// </summary>
	class IDeinterlacer
	{
	public:
		using SourceData = gsl::span<const std::byte>;
		using DestinationData = gsl::span<std::byte>;
		enum class SignalProperty { Data, Overrange };

		IDeinterlacer() = default;
		IDeinterlacer(const IDeinterlacer&) = default;
		IDeinterlacer(IDeinterlacer&&) = default;
		IDeinterlacer& operator=(const IDeinterlacer&) = default;
		IDeinterlacer& operator=(IDeinterlacer&&) = default;
		virtual ~IDeinterlacer() = default;

		/// <summary>
		/// Updates the data format configuration, e.g. the sample rate, active channels.
		/// </summary>
		virtual void UpdateConfiguration() = 0;
		
		/// <summary>The payload type of the given channel.</summary>
		/// <param name="channel">The channel.</param>
		/// <returns>The payload type as enum.</returns>
		virtual DataAcquisitionPayloadType PayloadType(const IO::Channel& channel) const = 0;

		/// <summary>Sample count in the data source for the given channel.</summary>
		/// <param name="channel">The channel.</param>
		/// <param name="source">The data source.</param>
		/// <returns>The sample count.</returns>
		virtual std::size_t ChannelSampleCount(const IO::Channel& channel, const SourceData& source) const = 0;

		/// <summary>
		/// Base sample size in bytes. Different channels may have different sample rates. A base sample
		/// consists of all active channels in the base sample rate.
		/// </summary>
		/// <returns>The base sample size.</returns>
		virtual std::size_t BaseSampleSize() const = 0;

		/// <summary>Copies the samples for the given channel to the destination.</summary>
		/// <param name="channel">The channel.</param>
		/// <param name="signalProperty">The signal property, differentiating data and overrange.</param>
		/// <param name="source">The data source.</param>
		/// <param name="destination">The data destination.</param>
		virtual void CopySamplesForChannel(const IO::Channel& channel, SignalProperty signalProperty,
			const SourceData& source, const DestinationData& destination) const = 0;

		/// <summary>Gets the channel minimum value.</summary>
		/// <remarks>
		/// Some channels may have a head room. In this case the returned value is including
		/// the head room. For example if the velocity range of 2 m/s is selected and the head room for
		/// the digital velocity channel is 10%, the minimum value would indicate a velocity of -2.2 m/s.
		/// </remarks>
		/// <param name="channelType">Type of the channel.</param>
		/// <returns>The minimum value.</returns>
		virtual int64_t ChannelMinValue(PTCChannelType channelType) const = 0;

		/// <summary>Gets the channel maximum value.</summary>
		/// <remarks>
		/// Some channels may have a head room. In this case the returned value is including
		/// the head room. For example if the velocity range of 2 m/s is selected and the head room for
		/// the digital velocity channel is 10%, the maximum value would indicate a velocity of +2.2 m/s.
		/// </remarks>
		/// <param name="channelType">Type of the channel.</param>
		/// <returns>The maximum value.</returns>
		virtual int64_t ChannelMaxValue(PTCChannelType channelType) const = 0;

		/// <summary>Gets all active channels of the currently updated configuration.</summary>
		/// <returns>All active channels.</returns>
		virtual std::vector<Channel> ActiveChannels() const = 0;

		/// <summary>Makes a deep copy of this object.</summary>
		/// <returns>A copy of this object.</returns>
		virtual std::unique_ptr<IDeinterlacer> Clone() const = 0;

		/// <summary>Protocol type of the data acquisition according to DataFormat, e.g. IVS500, VFXF110.</summary>
		/// <returns>The Protocol type.</returns>
		virtual IO::ProtocolType ProtocolType() const = 0;

		/// <summary>
		/// Measurement number is used to distinguish data from different measurements.
		/// </summary>
		/// <returns>The measurement number.</returns>
		virtual int MeasurementNumber() const = 0;

		/// <summary>The data acquisition block size.</summary>
		/// <returns>The block size as optional value if block mode is activated.</returns>
		virtual std::optional<int> BlockSize() const = 0;

		/// <summary>Base sample rate in hertz.</summary>
		/// <returns>The base sample rate.</returns>
		virtual double BaseSampleRateHertz() const = 0;

		/// <summary>
		/// Data loss control for systems that may lose data packets, e.g. UDP transmission.
		/// </summary>
		/// <returns>The data loss control may be null if there may be no data loss.</returns>
		virtual const IDataLossControl* DataLossControl() const = 0;
	};
}
