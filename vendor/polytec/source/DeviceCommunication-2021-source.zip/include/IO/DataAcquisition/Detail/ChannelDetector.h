// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#pragma once

#include <IO/DataAcquisition/PTCChannelType.h>

namespace Polytec::IO
{
	/// <summary>Channel selector implements the member detector idiom. It enables to verify if a channel exists and to access the channel data.</summary>
	/// <typeparam name="TSampleFormat">The sample format.</typeparam>
	/// <typeparam name="channelType">The channel type.</typeparam>
	template <typename TSampleFormat, PTCChannelType channelType>
	struct ChannelDetector;

	#pragma warning(push)
	#pragma warning(disable: 4702) // unreachable code
	template <typename TSampleFormat>
	struct ChannelDetector <TSampleFormat, PTCChannelType_Velocity>
	{
		static constexpr bool HasChannel() { return HasMemberImpl<TSampleFormat>(int{}); }
		static constexpr auto GetChannelData(const TSampleFormat& sample) { return sample.VibrometerSignal; }
		static constexpr auto GetChannelOverrange(const TSampleFormat& sample) { return sample.VelocityOverrange; }
	private:
		template <typename U>
		static constexpr decltype(std::declval<U>().VibrometerSignal, bool()) HasMemberImpl(int) { return true; }
		template <typename U>
		static constexpr bool HasMemberImpl(...) { return false; }
	};

	template <typename TSampleFormat>
	struct ChannelDetector <TSampleFormat, PTCChannelType_Displacement>
	{
		static constexpr bool HasChannel() { return HasMemberImpl<TSampleFormat>(int{}); }
		static constexpr auto GetChannelData(const TSampleFormat& sample) { return sample.VibrometerSignal; }
		static constexpr auto GetChannelOverrange(const TSampleFormat& sample)
		{ 
			return sample.VelocityOverrange || sample.DisplacementOverrange;
		}
	private:
		template <typename U>
		static constexpr decltype(std::declval<U>().VibrometerSignal, bool()) HasMemberImpl(int) { return true; }
		template <typename U>
		static constexpr bool HasMemberImpl(...) { return false; }
	};

	template <typename TSampleFormat>
	struct ChannelDetector <TSampleFormat, PTCChannelType_Acceleration>
	{
		static constexpr bool HasChannel() { return HasMemberImpl<TSampleFormat>(int{}); }
		static constexpr auto GetChannelData(const TSampleFormat& sample) { return sample.VibrometerSignal; }
		static constexpr auto GetChannelOverrange(const TSampleFormat& sample)
		{ 
			return sample.VelocityOverrange || sample.AccelerationOverrange;
		}
	private:
		template <typename U>
		static constexpr decltype(std::declval<U>().VibrometerSignal, bool()) HasMemberImpl(int) { return true; }
		template <typename U>
		static constexpr bool HasMemberImpl(...) { return false; }
	};

	template <typename TSampleFormat>
	struct ChannelDetector <TSampleFormat, PTCChannelType_RSSI>
	{
		static constexpr bool HasChannel() { return HasMemberImpl<TSampleFormat>(int{}); }
		static constexpr auto GetChannelData(const TSampleFormat& sample) { return sample.RSSI; }
		static constexpr int GetChannelOverrange(const TSampleFormat&) { throw std::logic_error("No overrange for non-signal channel"); }
	private:
		template <typename U>
		static constexpr decltype(std::declval<U>().RSSI, bool()) HasMemberImpl(int) { return true; }
		template <typename U>
		static constexpr bool HasMemberImpl(...) { return false; }
	};

	template <typename TSampleFormat>
	struct ChannelDetector <TSampleFormat, PTCChannelType_Trigger>
	{
		static constexpr bool HasChannel() { return HasMemberImpl<TSampleFormat>(int{}); }
		static constexpr auto GetChannelData(const TSampleFormat& sample) { return sample.Trigger; }
		static constexpr int GetChannelOverrange(const TSampleFormat&) { throw std::logic_error("No overrange for non-signal channel"); }
	private:
		template <typename U>
		static constexpr decltype(std::declval<U>().Trigger, bool()) HasMemberImpl(int) { return true; }
		template <typename U>
		static constexpr bool HasMemberImpl(...) { return false; }
	};

	template <typename TSampleFormat>
	struct ChannelDetector <TSampleFormat, PTCChannelType_DataValidity>
	{
		static constexpr bool HasChannel() { return HasMemberImpl<TSampleFormat>(int{}); }
		static constexpr auto GetChannelData(const TSampleFormat& sample) { return sample.DataValidity; }
		static constexpr int GetChannelOverrange(const TSampleFormat&) { throw std::logic_error("No overrange for non-signal channel"); }
	private:
		template <typename U>
		static constexpr decltype(std::declval<U>().DataValidity, bool()) HasMemberImpl(int) { return true; }
		template <typename U>
		static constexpr bool HasMemberImpl(...) { return false; }
	};
	#pragma warning(pop)
}
