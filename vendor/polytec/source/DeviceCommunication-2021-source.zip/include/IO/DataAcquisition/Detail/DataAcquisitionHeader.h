// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#pragma once

#include "DataUse.h"
#include "DataAcquisitionPayloadType.h"
#include "ProtocolType.h"


#include <cstddef>
#include <cstdint>

namespace Polytec::IO
{
	constexpr int c_startOfMeasurement = 0b1;
	constexpr int c_endOfMeasurement = 0b10;
	constexpr int c_startOfBlock = 0b100;
	constexpr int c_endOfBlock = 0b1000;

	class DataReader;
	class DataWriter;

	struct DataAcquisitionHeader
	{
		IO::ProtocolType ProtocolType{};
		std::size_t PayloadLength{};
		DataAcquisitionPayloadType PayloadType{};
		Polytec::IO::DataUse DataUse{};
		uint64_t SequenceNumber{};
		int SequenceFlags{};
		int32_t MeasurementNumber{};
		uint64_t DacSequence{};
	};

	void SaveDataAcquisitionHeader(DataWriter& writer, const DataAcquisitionHeader& header);
	DataAcquisitionHeader LoadDataAcquisitionHeader(DataReader& reader);
	std::size_t LoadDataAcquisitionPacketLength(DataReader& reader);
}
