// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#pragma once

#include <IO/DataAcquisition/Channel.h>
#include <IO/DataAcquisition/Detail/DataAcquisitionPayloadType.h>
#include <IO/DeviceCommunication/CommunicationException.h>

#include <gsl/gsl>

namespace Polytec::IO
{
	namespace Detail
	{
		#pragma warning(push)
		#pragma warning(disable: 26490) // Don't use reinterpret_cast (type.1).
		template <typename T>
		auto AsBytes(std::vector<T>& v)
		{
			return gsl::span(
				reinterpret_cast<std::byte*>(v.data()),
				v.size() * sizeof(T));
		}
		#pragma warning(pop)
	}

	template<typename TResult>
	std::vector<TResult> MeasurementData::Get(const Channel& channel) const
	{
		return GetDataImplementation<TResult>(channel, IDeinterlacer::SignalProperty::Data);
	}

	template<typename TResult>
	std::vector<TResult> MeasurementData::GetOverrange(const Channel& channel) const
	{
		return GetDataImplementation<TResult>(channel, IDeinterlacer::SignalProperty::Overrange);
	}

	template<typename TSampleFormat>
	std::vector<TSampleFormat> MeasurementData::GetRawSamples() const
	{
		CheckValid();
		std::vector<TSampleFormat> samples(BaseSampleCount());
		if (samples.size() * sizeof(TSampleFormat) != m_data.size())
		{
			throw std::logic_error("Failed to get raw samples. Sample data size does not match.");
		}
		std::memcpy(samples.data(), m_data.data(), m_data.size());
		return samples;
	}

	template<typename TResult>
	std::vector<TResult> MeasurementData::GetDataImplementation(const Channel& channel, IDeinterlacer::SignalProperty signalProperty) const
	{
		CheckValid();
		if (!IsSignalChannel(channel)
			&& signalProperty == IDeinterlacer::SignalProperty::Overrange)
		{
			throw IO::CommunicationException(PTCCommunicationStatusCode_LogicError, "Can't get overrange for non-signal channel.");
		}
		switch (m_deinterlacer->PayloadType(channel))
		{
			case DataAcquisitionPayloadType::UInt8:
				return Deinterlace<TResult, uint8_t>(channel, signalProperty);
			case DataAcquisitionPayloadType::Int16:
				return Deinterlace<TResult, int16_t>(channel, signalProperty);
			case DataAcquisitionPayloadType::UInt16:
				return Deinterlace<TResult, uint16_t>(channel, signalProperty);
			case DataAcquisitionPayloadType::Int32:
				return Deinterlace<TResult, int32_t>(channel, signalProperty);
			default:
				throw std::logic_error("Data acquisition payload type not supported: "
					+ std::to_string(static_cast<int>(m_deinterlacer->PayloadType(channel))));
		}
	}

	template<typename TResult, typename TSample>
	std::vector<TResult> MeasurementData::Deinterlace(const Channel& channel, IDeinterlacer::SignalProperty signalProperty) const
	{
		std::vector<TSample> result(m_deinterlacer->ChannelSampleCount(channel, m_data));
		m_deinterlacer->CopySamplesForChannel(channel, signalProperty, m_data, Detail::AsBytes(result));
		if constexpr (std::is_same_v<TResult, TSample>)
		{
			return result;
		}
		else
		{
			CheckConvertible<TResult>(channel.Type(), signalProperty);
			std::vector<TResult> transformed(result.size());
			std::transform(result.cbegin(), result.cend(), transformed.begin(), [](auto element)
			{
				return gsl::narrow_cast<TResult>(element);
			});
			return transformed;
		}
	}

	template<typename TResult>
	void MeasurementData::CheckConvertible(PTCChannelType channelType, IDeinterlacer::SignalProperty signalProperty) const
	{
		if (signalProperty == IDeinterlacer::SignalProperty::Overrange)
		{
			return;
		}
		if (m_deinterlacer->ChannelMaxValue(channelType) > std::numeric_limits<TResult>::max()
			|| m_deinterlacer->ChannelMinValue(channelType) < std::numeric_limits<TResult>::lowest())
		{
			throw IO::CommunicationException(PTCCommunicationStatusCode_BadCast, "Measurement data conversion failed");
		}
	}
}
