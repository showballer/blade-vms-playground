// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#pragma once

#include <IO/DataAcquisition/Channel.h>
#include <IO/DataAcquisition/Detail/ChannelDetector.h>
#include <IO/DataAcquisition/Detail/Samples.h>

namespace Polytec::IO
{
	namespace Detail
	{
        template<typename TResult, typename TChannel>
        void CopySamples(std::vector<TResult>& result, const TChannel& channelData);
        template<typename TResult, typename TChannel, int SamplesCount>
        void CopySamples(std::vector<TResult>& result, const Samples<TChannel, SamplesCount>& channelData);
        template<PTCChannelType channelType, typename TResult, typename TSampleFormat>
        void Copy(std::vector<TResult>& result, const TSampleFormat& sample, IO::IDeinterlacer::SignalProperty signalProperty);

		/// <summary>Helper function to use channel type templates. The function takes a
		/// 		 PTCChannelType value which is available at runtime and applies it as a constexpr
		/// 		 value to the visitor.</summary>
		/// <exception cref="CommunicationException">Thrown when the channel type is unknown.</exception>
		/// <typeparam name="TReturn">Type of the return. Has to match the visitor return type.</typeparam>
		/// <typeparam name="TVisitor">Type of the visitor. The visitor has to overload Visit() as
		/// 						   a template for all PTCChannelType values.</typeparam>
		/// <param name="channelType">The channel type.</param>
		/// <param name="visitor">The visitor.</param>
		/// <returns>The return value of the visitor.</returns>
		template<typename TVisitor>
		auto VisitChannelType(PTCChannelType channelType, const TVisitor& visitor)
		{
			switch (channelType)
			{
				case PTCChannelType_Velocity:
					return visitor.template Visit<PTCChannelType_Velocity>();
				case PTCChannelType_Displacement:
					return visitor.template Visit<PTCChannelType_Displacement>();
				case PTCChannelType_Acceleration:
					return visitor.template Visit<PTCChannelType_Acceleration>();
				case PTCChannelType_RSSI:
					return visitor.template Visit<PTCChannelType_RSSI>();
				case PTCChannelType_Trigger:
					return visitor.template Visit<PTCChannelType_Trigger>();
				case PTCChannelType_DataValidity:
					return visitor.template Visit<PTCChannelType_DataValidity>();
				default:
					throw CommunicationException(PTCCommunicationStatusCode_InvalidArgument,
						"Channel type not supported for static deinterlacing.");
			}
		}

		template <typename TDataFormat>
		struct SampleCountVisitor
		{
			const IDeinterlacer::SourceData& Source;

			template<PTCChannelType t_channelType>
			std::size_t Visit() const
			{
				using selector = ChannelDetector<typename TDataFormat::SampleFormat, t_channelType>;
				if constexpr (selector::HasChannel())
				{
#ifndef DEBUG
					typename TDataFormat::SampleFormat sample{};
#else // DEBUG
					// In debug build with 16.7.2 we get:
					// error C4789: buffer 'sample' of size 4 bytes will be overrun; 6 bytes will be written starting at offset 0
					// https://developercommunity.visualstudio.com/content/problem/1158290/compiler-error-c4789-on-bitfield-aggregate-initial.html
					// Workaround:
					typename TDataFormat::SampleFormat sample;
					std::memset(&sample, 0, sizeof(sample));
#endif // DEBUG

					return FrequencyFactor(selector::GetChannelData(sample)) * Source.size() / sizeof(sample);
				}
				else
				{
					throw std::runtime_error("Channel type not available for data acquisition:" + std::to_string(t_channelType));
				}
			}

		private:
			/// <summary>
			/// Frequency factor for single samples per base sample, e.g. RSSI:
			/// struct SampleFormat
			/// {
			///   Samples&lt;int32_t, FrequencyFactor&gt; Velocity;
			///   int16_t RSSI;
			/// };
			/// </summary>
			template<typename TChannelSamples>
			static std::size_t FrequencyFactor(const TChannelSamples&)
			{
				return 1;
			}

			/// <summary>
			/// Frequency factor for multiple samples per base sample, e.g. Velocity:
			/// struct SampleFormat
			/// {
			///   Samples&lt;int32_t, FrequencyFactor&gt; Velocity;
			///   int16_t RSSI;
			/// };
			/// </summary>
			template<typename TChannelSamples, int SampleCount>
			static std::size_t FrequencyFactor(const Samples<TChannelSamples, SampleCount>&)
			{
				return SampleCount;
			}
		};

		template <typename TDataFormat>
		struct CopySamplesVisitor
		{
			const IDeinterlacer::SignalProperty SignalProperty{};
			const IDeinterlacer::SourceData& Source;
			const IDeinterlacer::DestinationData& Destination;

			template<PTCChannelType t_channelType>
			void Visit() const
			{
				switch (TDataFormat::PayloadType(t_channelType))
		{
					case DataAcquisitionPayloadType::UInt8:
						return CopySamples<uint8_t, t_channelType>();
					case DataAcquisitionPayloadType::UInt16:
						return CopySamples<uint16_t, t_channelType>();
					case DataAcquisitionPayloadType::Int16:
						return CopySamples<int16_t, t_channelType>();
					case DataAcquisitionPayloadType::Int32:
						return CopySamples<int32_t, t_channelType>();
					default:
						throw std::logic_error("Payload type not supported for copying: "
							+ std::to_string(static_cast<int>(TDataFormat::PayloadType(t_channelType))));
				}
			}

		private:
			template<typename TResult, PTCChannelType t_channelType>
			void CopySamples() const
			{
				if (Source.size() % sizeof(typename TDataFormat::SampleFormat) != 0)
				{
					throw std::logic_error("Static deinterlacer failed. The data source does not have the expected sample format.");
				}

				const auto sourceSamples = gsl::span(
					reinterpret_cast<const typename TDataFormat::SampleFormat*>(Source.data()),
					Source.size() / sizeof(typename TDataFormat::SampleFormat));

				std::vector<TResult> result;
                result.reserve(SampleCountVisitor<TDataFormat>{Source}.template Visit<t_channelType>());
				for (const auto& sample : sourceSamples)
				{
					Copy<t_channelType>(result, sample, SignalProperty);
				}
				if (Destination.size() != result.size() * sizeof(TResult))
				{
					throw std::logic_error("Static deinterlacer copying failed. Buffer sizes don't match.");
				}
				std::memcpy(Destination.data(), result.data(), Destination.size());
			}
		};

		template<typename TResult, typename TChannel>
		void CopySamples(std::vector<TResult>& result, const TChannel& channelData)
		{
			result.push_back(gsl::narrow_cast<TResult>(channelData));
		}

		template<typename TResult, typename TChannel, int SamplesCount>
		void CopySamples(std::vector<TResult>& result, const Samples<TChannel, SamplesCount>& channelData)
		{
			std::transform(channelData.Values.cbegin(), channelData.Values.cend(), std::back_inserter(result), [](const auto value)
			{
				return gsl::narrow_cast<TResult>(value);
			});
		}

        #pragma warning (push)
        #pragma warning (disable: 4100) // 'sample': unreferenced formal parameter
        template<PTCChannelType channelType, typename TResult, typename TSampleFormat>
        void Copy(std::vector<TResult>& result, const TSampleFormat& sample, IO::IDeinterlacer::SignalProperty signalProperty)
        {
            using selector = ChannelDetector<TSampleFormat, channelType>;
            if constexpr (selector::HasChannel())
            {
				signalProperty == IDeinterlacer::SignalProperty::Data
					? CopySamples(result, selector::GetChannelData(sample))
					: CopySamples(result, selector::GetChannelOverrange(sample));
            }
            else
            {
                throw std::runtime_error("Channel type not available for data acquisition:" + std::to_string(channelType));
            }
        }
        #pragma warning (pop)
	}

	template<typename TDataFormat>
	DataAcquisitionPayloadType StaticDeinterlacer<TDataFormat>::PayloadType(const IO::Channel& channel) const
	{
		return TDataFormat::PayloadType(channel.Type());
	}

	template<typename TDataFormat>
	std::size_t StaticDeinterlacer<TDataFormat>::ChannelSampleCount(const IO::Channel& channel, const SourceData& source) const
	{
		return Detail::VisitChannelType(channel.Type(), Detail::SampleCountVisitor<TDataFormat>({source}));
	}

	template<typename TDataFormat>
	std::size_t StaticDeinterlacer<TDataFormat>::BaseSampleSize() const
	{
		return sizeof(typename TDataFormat::SampleFormat);
	}

	template<typename TDataFormat>
	void StaticDeinterlacer<TDataFormat>::CopySamplesForChannel(const IO::Channel& channel, SignalProperty signalProperty,
		const SourceData& source, const DestinationData& destination) const
	{
		if (channel.Number() != 0)
		{
			throw CommunicationException(PTCCommunicationStatusCode_InvalidArgument,
				"Not implemented for multiple channel numbers.");
		}
		Detail::VisitChannelType(channel.Type(), Detail::CopySamplesVisitor<TDataFormat>({signalProperty, source, destination}));
	}

	template<typename TDataFormat>
	int64_t StaticDeinterlacer<TDataFormat>::ChannelMinValue(PTCChannelType channelType) const
	{
		return TDataFormat::ChannelMinValue(channelType);
	}

	template<typename TDataFormat>
	int64_t StaticDeinterlacer<TDataFormat>::ChannelMaxValue(PTCChannelType channelType) const
	{
		return TDataFormat::ChannelMaxValue(channelType);
	}

	template<typename TDataFormat>
	std::shared_ptr<IDataLossControl> StaticDeinterlacer<TDataFormat>::CreateDataLossControl()
	{
		if constexpr (ChannelDetector<typename TDataFormat::SampleFormat, PTCChannelType_DataValidity>::HasChannel())
		{
			return std::make_unique<StaticDataLossControl<TDataFormat>>();
		}
		else
		{
			return nullptr;
		}
	}
}
