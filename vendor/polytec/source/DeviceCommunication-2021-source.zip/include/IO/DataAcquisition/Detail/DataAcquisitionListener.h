// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#pragma once

#include <IO/DataAcquisition/Detail/IDeinterlacer.h>
#include <IO/DataAcquisition/Detail/MeasurementDataBuffer.h>
#include <IO/DeviceCommunication/Detail/ServiceThread.h>

#include <chrono>
#include <cstddef>
#include <map>
#include <memory>
#include <mutex>
#include <string>

namespace Polytec::IO
{
	class DataAcquisitionListener;
	class IDataAcquisitionClient;
	class IMeasurementDataBuffer;
	class MeasurementData;

	std::shared_ptr<DataAcquisitionListener> GetUdpListener();
	std::unique_ptr<DataAcquisitionListener> GetTcpListener(const std::wstring& address);

	/// <summary>A listener for a data acquisition stream writing all data to an IMeasurementDataBuffer</summary>
	/// <remarks>On construction a service thread will be started in order to handle the data acquisition asynchronously</remarks>
	class DataAcquisitionListener
	{
	public:
		explicit DataAcquisitionListener(std::unique_ptr<IDataAcquisitionClient> client);
		DataAcquisitionListener(const DataAcquisitionListener&) = delete;
		DataAcquisitionListener& operator=(const DataAcquisitionListener&) = delete;
		DataAcquisitionListener(DataAcquisitionListener&&) = delete;
		DataAcquisitionListener& operator=(DataAcquisitionListener&&) = delete;
		~DataAcquisitionListener() noexcept;

		void Open(const std::wstring& ipAddress, std::size_t capacity, std::unique_ptr<IDeinterlacer> deinterlacer);
		void ClearBuffer(const std::wstring& ipAddress);
		void NextBlock(const std::wstring& ipAddress);
		void ShutdownBuffer(const std::wstring& ipAddress);
		void Close(const std::wstring& ipAddress) noexcept;
		void Write(const std::wstring& ipAddress, const gsl::span<const std::byte>& data);
		MeasurementData ReadAvailableData(const std::wstring& ipAddress, std::size_t sampleCount);

		MeasurementData ReadData(const std::wstring& ipAddress,
			std::size_t sampleCount, const std::chrono::duration<double>& timeout);

		std::size_t Size(const std::wstring& ipAddress) const;
		const IDeinterlacer& Deinterlacer(const std::wstring& ipAddress) const { return m_buffers.at(ipAddress).Deinterlacer(); }

	private:
		void EraseBuffer(const std::wstring& ipAddress);

		std::map<std::wstring, MeasurementDataBuffer> m_buffers;
		std::mutex m_bufferMutex;
		std::unique_ptr<IDataAcquisitionClient> m_client;
		ServiceThread m_clientThread;
	};
}
