// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#pragma once

#include <IO/DataAcquisition/Detail/ChannelDetector.h>
#include <IO/DataAcquisition/Detail/IDataLossControl.h>

namespace Polytec::IO
{
	/// <summary>Static data loss control for data formats with a DataValidity flag.</summary>
	/// <typeparam name="TChannelPolicy">Type of the channel policy.</typeparam>
	template <typename TChannelPolicy>
	class StaticDataLossControl : public IDataLossControl
	{
		using SampleFormat = typename TChannelPolicy::SampleFormat;

	public:
		std::vector<std::byte> CreateDataForInvalidPacket() const override
		{
			return std::vector<std::byte>(TChannelPolicy::PacketSampleCount * sizeof(SampleFormat));
		}

		std::vector<std::byte> MakeValidSamples(std::vector<std::byte> data) const override
		{
			if (data.size() != TChannelPolicy::PacketSampleCount * sizeof(SampleFormat))
			{
				throw std::logic_error(
					"The received payload does not match the specified length defined in the channel policy.");
			}
			const auto samples = gsl::span(
				reinterpret_cast<SampleFormat*>(data.data()),
				data.size() / sizeof(SampleFormat));
			for (auto& sample : samples)
				sample.DataValidity = 1;
			return data;
		}
	};
}
