// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

/// \file
/// \brief	Defines all supported data formats for the data acquisition of measurement data

#pragma once

namespace Polytec
{
	namespace IO // Workaround: "namespace Polytec::IO" results in DCS build error: <Parse error at "Polytec">
	{
		/// <summary>Data format for data acquisition of measurement data.</summary>
		enum class ProtocolType
		{
			/// <summary>
			/// Unknown format. Always an error if this occurs.
			/// </summary>
			Unknown,
			/// <summary>
			/// IVS-500 and VGO-200 (except VGO-200 pioneer) data format.
			/// </summary>
			IVS500 = 3,
			/// <summary>
			/// VFX-F-110 data format.
			/// </summary>
			VFXF110 = 4,
			/// <summary>
			/// VGO-200 pioneer data format.
			/// </summary>
			VGO200Pioneer = 5,
			/// <summary>
			/// Hotfix: IVS-500 and VGO-200 devices have been released with incorrect PTCDeviceCommand_DAQProtocolType command response 30 instead of 3.
			/// </summary>
			IVS500Hotfix = 30
		};
	}
}
