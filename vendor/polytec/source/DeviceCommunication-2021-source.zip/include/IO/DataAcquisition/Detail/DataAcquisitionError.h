// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

/// \file
/// \brief	Defines the data acquisition error codes used as payload for error packets

#pragma once


#include <cstdint>

namespace Polytec::IO {
	/// <summary>Data acquisition error codes.</summary>
	/// <remarks>Used as payload for data acquisition packets with the data use Error</remarks>
	enum class DataAcquisitionError : uint8_t {
		UnknownError = 0, ///< An unknown error has occurred
		GeneratorBufferUnderflow = 1, ///< Generator buffer overflow
		GeneratorSequenceError = 2, ///< Generator sequence error
		GeneratorSequenceErrorOutputData = 3, ///< Generator sequence error output data
		GeneratorSequenceErrorFillFiFo = 4, ///< Generator sequence error fill FiFo
		DataAcquisitionBufferOverflow = 5, ///< the internal buffer of the device has overflown
		DataAcquisitionDataLoss = 6, ///< data has been lost in the device
		NoError = 255 ///< only for implementation purposes
	};
}
