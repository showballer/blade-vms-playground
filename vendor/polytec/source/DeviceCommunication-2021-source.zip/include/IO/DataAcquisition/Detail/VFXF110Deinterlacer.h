// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#pragma once

#include <IO/DataAcquisition/Detail/IDeinterlacer.h>
#include <IO/DeviceCommunication/Device.h>
#include <IO/DeviceCommunication/PTCMiscellaneousTag.h>
#include <IO/DeviceCommunication/Utils/DeviceList.h>
#include <IO/DeviceCommunication/Utils/ItemList.h>

#include <map>
#include <vector>

namespace Polytec::IO
{
	struct OffsetSpan
	{
		int Offset{};
		int Size{};
	};

	using BaseSampleDataFormat = std::map<IO::Channel, OffsetSpan>;
}

namespace Polytec::CM::VFX
{
	using SignalType = int32_t;
	using RssiType = int16_t;
	using TriggerType = uint8_t;

	static constexpr SignalType c_signalMask = 0xFFFF'FF00;
	static constexpr SignalType c_overrangeMask = 0b1;

	IO::BaseSampleDataFormat GetBaseSampleDataFormat(int frequencyFactor, const std::function<bool(const IO::Channel&)>& isChannelActive);
}

namespace Polytec::IO
{
	class DeviceCommunication;

	/// <summary>
	/// This class provides deinterlacing for VFX-F-110.
	/// </summary>
	class VFXF110Deinterlacer : public IDeinterlacer
	{
	public:
		explicit VFXF110Deinterlacer(DeviceCommunication& communication);

		void UpdateConfiguration() override;
		DataAcquisitionPayloadType PayloadType(const Channel& channel) const override;
		std::size_t ChannelSampleCount(const Channel& channel, const SourceData& source) const override;
		std::size_t BaseSampleSize() const override;
		void CopySamplesForChannel(const IO::Channel& channel, SignalProperty signalProperty,
			const SourceData& source, const DestinationData& destination) const override;
		int64_t ChannelMinValue(PTCChannelType channelType) const override;
		int64_t ChannelMaxValue(PTCChannelType channelType) const override;
		std::vector<Channel> ActiveChannels() const override;
		std::unique_ptr<IDeinterlacer> Clone() const override { return std::make_unique<VFXF110Deinterlacer>(*this); }
		IO::ProtocolType ProtocolType() const override { return ProtocolType::VFXF110; }
		int MeasurementNumber() const override { return m_measurementNumber; }
		std::optional<int> BlockSize() const override { return m_blockSize; }
		double BaseSampleRateHertz() const override { return m_baseSampleRate; }
		const IDataLossControl* DataLossControl() const override { return nullptr; }

	private:
		std::vector<Channel> EvaluateActiveChannels() const;
		bool IsActive(const Channel& channel) const;
		std::size_t BaseSampleCount(const SourceData& source) const;
		void CheckAllBaseSampleOffsetsDefined() const;

		DeviceCommunication& m_communication;
		const int m_baseSampleRate{};
		const ItemList m_daqMode{m_communication, PTCDeviceType_SignalProcessing, PTCDeviceCommand_DaqMode};
		int m_measurementFrequencyFactor{};
		int m_measurementNumber{};
		std::optional<int> m_blockSize{};
		std::vector<Channel> m_activeChannels;
		BaseSampleDataFormat m_baseSampleOffsets;
	};
}
