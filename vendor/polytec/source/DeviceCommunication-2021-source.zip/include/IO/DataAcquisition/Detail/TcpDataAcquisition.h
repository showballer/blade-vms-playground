// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#pragma once

#include <IO/DataAcquisition/Detail/IDataAcquisitionClient.h>
#include <IO/DeviceCommunication/Detail/INetworkPacketFormat.h>

#include <boost/asio.hpp>

namespace boost::system { class error_code; }

namespace Polytec::IO
{
	/// <summary>A TCP data acquisition client used to receive measurement data from a network.</summary>
	class TcpDataAcquisition : public IDataAcquisitionClient
	{
	public:
		TcpDataAcquisition(const std::wstring& address, std::unique_ptr<INetworkPacketFormat>&& packetFormat);
		TcpDataAcquisition(const TcpDataAcquisition&) = delete;
		TcpDataAcquisition& operator=(const TcpDataAcquisition&) = delete;
		TcpDataAcquisition(TcpDataAcquisition&&) = default;
		TcpDataAcquisition& operator=(TcpDataAcquisition&&) = default;

		void Run() override;

		/// <summary>Shutdown the data acquisition service</summary>
		void Shutdown() override { m_ioService.stop(); }

		void HandleError(const std::exception& e) const override;

		/// <summary>If data has been received the given callback function is called.</summary>
		/// <param name="callback">The callback function.</param>
		void ConnectOnDataAvailable(const DataAvailableSignal::slot_function_type& callback) override { m_dataAvailableSignal.connect(callback); }

	private:
		void ResolveHostname(const std::string& hostname);
		void ReceiveHeaderAsync();
		void HandleReceiveHeader(std::size_t bytesReceived, boost::system::error_code errorCode);
		void ReceiveBodyAsync();
		void HandleReceiveBody(std::size_t bytesReceived, boost::system::error_code errorCode);
		void ConnectAsync();
		void HandleConnectAsync(boost::system::error_code errorCode);

	private:
		std::vector<std::byte> m_buffer;
		std::unique_ptr<INetworkPacketFormat> m_packetFormat;
		std::wstring m_address;
		boost::asio::io_service m_ioService;
		boost::asio::ip::tcp::socket m_socket;
		boost::asio::ip::tcp::endpoint m_deviceEndpoint;
		DataAvailableSignal m_dataAvailableSignal;
	};
}
