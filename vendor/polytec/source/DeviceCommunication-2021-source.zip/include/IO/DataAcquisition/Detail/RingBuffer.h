// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#pragma once


#include <boost/numeric/conversion/cast.hpp>
#include <atomic>
#include <gsl/span>
#include <memory_resource>
#include <mutex>

namespace Polytec::IO
{
	/// <summary>
	/// A thread-safe ring buffer of fixed capacity for at most one consumer thread and one acquisition thread.
	/// </summary>
	/// <remarks>
	/// The ring buffer checks for data over- and underflow.
	/// </remarks>
	/// <typeparam name="T">Type of the buffer elements.</typeparam>
	template<typename T>
	class RingBuffer
	{
		using AtomicIndex = std::atomic<std::size_t>;

	public:
		RingBuffer(std::size_t capacity, std::pmr::polymorphic_allocator<T> allocator = std::pmr::new_delete_resource());
		RingBuffer(const RingBuffer&) = delete;
		RingBuffer& operator=(const RingBuffer&) = delete;
		RingBuffer(RingBuffer&&) = delete; // can be implemented if needed, take care of buffer deallocation
		RingBuffer& operator=(RingBuffer&&) = delete; // can be implemented if needed, take care of buffer deallocation
		~RingBuffer();

		/// <summary>
		/// Writes the elements from the given span into the buffer. The function checks for a buffer overflow.
		/// </summary>
		/// <typeparam name="T">Type of the buffer elements.</typeparam>
		/// <param name="src">Source span providing the elements to be written to the ring buffer.</param>
		void Write(const gsl::span<const T>& src) { WriteToBuffer(src); };

		/// <summary>
		/// Writes the volatile elements from the given span into the buffer. The function checks for a buffer overflow.
		/// </summary>
		/// <typeparam name="T">Type of the buffer elements.</typeparam>
		/// <param name="src">Source span providing the elements to be written to the ring buffer.</param>
		void WriteFromVolatile(const gsl::span<const volatile T>& src) { WriteToBuffer(src); };

		void Read(const gsl::span<T>& dest);
		void DiscardElements(std::size_t sizeToDiscard);
		void Clear();

		/// <summary>Get the buffer capacity</summary>
		/// <returns>The buffer capacity</returns>
		std::size_t Capacity() const noexcept { return std::size(m_data); }
		std::size_t Size() const { return SizeImpl(std::memory_order_relaxed); };
		std::size_t SizeToRead() const { return SizeImpl(std::memory_order_relaxed); }
		std::size_t SizeToWrite() const
		{
			const auto capacity = Capacity();
			return capacity - std::min(SizeToRead(), capacity);
		};

	private:
		std::size_t SizeImpl(std::memory_order memoryOrder) const;
		std::size_t IndexWrapBound() const { return 2 * Capacity(); };
		void Advance(AtomicIndex& index, std::size_t advance, std::memory_order memoryOrder);
		void CheckOverflow(std::size_t sizeToWrite) const;
		void CheckUnderflow(std::size_t sizeToRead, std::memory_order memoryOrder) const;

		template<typename U>
		void WriteToBuffer(const gsl::span<const U>& src);
		template<typename U>
		void DoWrite(const gsl::span<const U>& src, std::size_t offset = 0);

		std::pmr::polymorphic_allocator<T> m_allocator;
		gsl::span<T> m_data;
		AtomicIndex m_readIndex{0};
		AtomicIndex m_writeIndex{0};
	};
}

#include "RingBuffer.inl"
