// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#pragma once

#include <vector>

namespace Polytec::IO
{
	/// <summary>
	/// Data loss control provides functionality to handle valid or invalid samples for data
	/// transmission that may lose data packets, e.g. UDP transmission.
	/// </summary>
	class IDataLossControl
	{
	public:
		IDataLossControl() = default;
		IDataLossControl(const IDataLossControl&) = default;
		IDataLossControl(IDataLossControl&&) = default;
		IDataLossControl& operator=(const IDataLossControl&) = default;
		IDataLossControl& operator=(IDataLossControl&&) = default;
		virtual ~IDataLossControl() = default;

		/// <summary>
		/// Makes valid samples by marking the DataValidity channel valid for each sample.
		/// </summary>
		/// <param name="data">The data.</param>
		/// <returns>A std::vector<std::byte></returns>
		virtual std::vector<std::byte> MakeValidSamples(std::vector<std::byte> data) const = 0;

		/// <summary>Creates invalid data for one lost packet.</summary>
		/// <returns>The data for invalid packet.</returns>
		virtual std::vector<std::byte> CreateDataForInvalidPacket() const = 0;
	};
}
