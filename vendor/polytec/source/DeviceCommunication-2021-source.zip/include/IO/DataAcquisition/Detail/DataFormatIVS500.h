// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

/// \file
/// \brief	Declaration of a class defining the IVS-500 data format

#pragma once

#include <IO/DataAcquisition/Channel.h>
#include <IO/DataAcquisition/Detail/DataAcquisitionPayloadType.h>
#include <IO/DataAcquisition/Detail/ProtocolType.h>
#include <IO/DataAcquisition/PTCChannelType.h>
#include <IO/DeviceCommunication/CommunicationException.h>

#include <gsl/gsl>

#include <cstdint>
#include <limits>
#include <vector>

#pragma warning(push)
#pragma warning(disable: 6326) // Potential comparison of a constant with another constant.

namespace Polytec
{
	namespace IO
	{
		/// <summary>The IVS-500 sample format</summary>
		/// <remarks>
		/// It has a vibrometer velocity channel, a signal level channel, a data validity channel,
		/// an overrange channel and a channel for the digital trigger input signal. All channels 
		/// are set by the IVS-500 except the data validity channel which indicates invalid samples
		/// caused e.g. by a UDP packet loss. The data validity channel is set by the software.
		/// The channels are ordered according to the bitfield.
		/// </remarks>
		struct IVS500SampleFormat
		{
			int16_t VibrometerSignal: 16;		///< <summary>16 bit vibrometer channel, i.e. VEL, DISPL or ACC.</summary>
			uint16_t RSSI : 9;					///< <summary>9 bit signal level channel</summary>
			uint16_t : 2;						///< <summary>2 bit padding</summary>
			uint16_t DataValidity : 1;			///< <summary>Data validity flag</summary>
			uint16_t AccelerationOverrange : 1;	///< <summary>Acceleration overrange flag</summary>
			uint16_t DisplacementOverrange : 1;	///< <summary>Displacement overrange flag</summary>
			uint16_t VelocityOverrange : 1;		///< <summary>Velocity overrange flag</summary>
			uint16_t Trigger : 1;				///< <summary>Trigger flag</summary>
		};


		/// <summary>
		/// The IVS-500 data format.
		/// </summary>
		/// <remarks>
		/// Defines the bitwise sample format and offers information about available channels and their limits.
		/// </remarks>
		template <IO::ProtocolType t_protocolType>
		struct DataFormatIVS500
		{
			using SampleFormat = IVS500SampleFormat;

			/// <summary>Gets a vector of all IVS-500 channels.</summary>
			/// <returns>The channels.</returns>
			static std::vector<Channel> Channels();

			static constexpr DataAcquisitionPayloadType PayloadType(PTCChannelType channelType);

			/// <summary>Gets the channel minimum value.</summary>
			/// <remarks>
			/// The IVS-500 velocity channel has a head room. In this case the returned value is including
			/// the head room. For example if the velocity range of 2 m/s is selected and the head room for
			/// the digital velocity channel is 10%, the minimum value would indicate a velocity of -2.2 m/s.
			/// </remarks>
			/// <param name="channelType">Type of the channel.</param>
			/// <returns>The minimum value.</returns>
			static constexpr auto ChannelMinValue(PTCChannelType channelType);

			/// <summary>Gets the channel maximum value.</summary>
			/// <remarks>
			/// The IVS-500 velocity channel has a head room. In this case the returned value is including
			/// the head room. For example if the velocity range of 2 m/s is selected and the head room for
			/// the digital velocity channel is 10%, the maximum value would indicate a velocity of +2.2 m/s.
			/// </remarks>
			/// <param name="channelType">Type of the channel.</param>
			/// <returns>The maximum value.</returns>
			static constexpr auto ChannelMaxValue(PTCChannelType channelType);

		public:
			///< <summary>Sample count in an Ethernet packet</summary>
			static constexpr std::size_t PacketSampleCount = 357;

			///< <summary>Size of a single sample in Bytes</summary>
			static constexpr const std::size_t SampleSize = 4;

			///< <summary>Protocol type identifier</summary>
			static constexpr IO::ProtocolType ProtocolType = []()
			{
				switch (t_protocolType)
				{
					case ProtocolType::IVS500:
					case ProtocolType::IVS500Hotfix:
						return ProtocolType::IVS500;
					case ProtocolType::VGO200Pioneer:
						return ProtocolType::VGO200Pioneer;
					default:
						throw std::logic_error("Unknown IVS-500/VGO-200 protocol type " + std::to_string(static_cast<int>(t_protocolType)) + ".");
				}
			}();

			///< <summary>Sample rate in Hz</summary>
			static constexpr double SampleRateHertz = (ProtocolType == ProtocolType::IVS500)
				? 218'750
				: 218'750 * 10. / 3.;	// 729'167 Hz
		};

		/// <summary>Gets all IVS-500 channels.</summary>
		/// <returns>All channels.</returns>
		template <ProtocolType t_protocolType>
		inline std::vector<Channel> DataFormatIVS500<t_protocolType>::Channels()
		{
			return
			{
				PTCChannelType_Velocity,
				PTCChannelType_RSSI,
				PTCChannelType_DataValidity,
				PTCChannelType_Trigger
			};
		}

		template <ProtocolType t_protocolType>
		inline constexpr DataAcquisitionPayloadType DataFormatIVS500<t_protocolType>::PayloadType(PTCChannelType channelType)
		{
			switch (channelType)
			{
				case PTCChannelType_Velocity:
				case PTCChannelType_Displacement:
				case PTCChannelType_Acceleration:
					return DataAcquisitionPayloadType::Int16;
				case PTCChannelType_RSSI:
					return DataAcquisitionPayloadType::Int16;
				case PTCChannelType_Trigger:
					return DataAcquisitionPayloadType::UInt8;
				case PTCChannelType_DataValidity:
					return DataAcquisitionPayloadType::UInt8;
				default:
					throw CommunicationException(PTCCommunicationStatusCode_InvalidArgument, "Channel not supported by IVS-500.");
			}
		}

		template <ProtocolType t_protocolType>
		inline constexpr auto DataFormatIVS500<t_protocolType>::ChannelMinValue(PTCChannelType channelType)
		{
			switch (channelType)
			{
				case PTCChannelType_Velocity:
				case PTCChannelType_Displacement:
				case PTCChannelType_Acceleration:
					return std::numeric_limits<int16_t>::min();
				case PTCChannelType_RSSI:
					return gsl::narrow_cast<int16_t>(0);
				case PTCChannelType_Trigger:
					return gsl::narrow_cast<int16_t>(0);
				case PTCChannelType_DataValidity:
					return gsl::narrow_cast<int16_t>(0);
				default:
					throw CommunicationException(PTCCommunicationStatusCode_InvalidArgument, "Channel not supported by IVS-500.");
			}
		}

		template <ProtocolType t_protocolType>
		inline constexpr auto DataFormatIVS500<t_protocolType>::ChannelMaxValue(PTCChannelType channelType)
		{
			switch (channelType)
			{
				case PTCChannelType_Velocity:
				case PTCChannelType_Displacement:
				case PTCChannelType_Acceleration:
					return std::numeric_limits<int16_t>::max();
				case PTCChannelType_RSSI:
					return gsl::narrow_cast<int16_t>(511);
				case PTCChannelType_Trigger:
					return gsl::narrow_cast<int16_t>(1);
				case PTCChannelType_DataValidity:
					return gsl::narrow_cast<int16_t>(1);
				default:
					throw CommunicationException(PTCCommunicationStatusCode_InvalidArgument, "Channel not supported by IVS-500.");
			}
		}
	}
}

#pragma warning(pop)
