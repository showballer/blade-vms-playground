// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#pragma once

#include <IO/DataAcquisition/Detail/IDataAcquisitionClient.h>

namespace boost::system { class error_code; }

namespace Polytec::IO
{
	struct ReceiveBufferSize { int Value{}; };
	
	/// <summary>A UDP data acquisition client used to receive measurement data from a network.</summary>
	class UdpDataAcquisition : public IDataAcquisitionClient
	{
	public:
		UdpDataAcquisition(int port, ReceiveBufferSize receiveBufferSize = {10'000'000});
		UdpDataAcquisition(const UdpDataAcquisition&) = delete;
		UdpDataAcquisition& operator=(const UdpDataAcquisition&) = delete;
		UdpDataAcquisition(UdpDataAcquisition&&) = default;
		UdpDataAcquisition& operator=(UdpDataAcquisition&&) = default;

		void Run() override;

		/// <summary>Shutdown the data acquisition service</summary>
		void Shutdown() override { m_ioService.stop(); }

		void HandleError(const std::exception& e) const override;

		/// <summary>If data has been received the given callback function is called.</summary>
		/// <param name="callback">The callback function.</param>
		void ConnectOnDataAvailable(const DataAvailableSignal::slot_function_type& callback) override { m_dataAvailableSignal.connect(callback); }

	private:
		void ReceiveAsync();
		void HandleReceive(std::size_t bytesReceived, boost::system::error_code errorCode);

	private:
		std::vector<std::byte> m_buffer;
		boost::asio::io_service m_ioService;
		boost::asio::ip::udp::socket m_socket;
		boost::asio::ip::udp::endpoint m_deviceEndpoint;
		DataAvailableSignal m_dataAvailableSignal;
	};
}
