// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#pragma once

#include <IO/DataAcquisition/Detail/IDeinterlacer.h>
#include <IO/DataAcquisition/Detail/StaticDataLossControl.h>

namespace Polytec::IO
{
	/// <summary>A deinterlacer implemented by static data representation.</summary>
	/// <typeparam name="TDataFormat">Type of the data format.</typeparam>
	template <typename TDataFormat>
	class StaticDeinterlacer : public IDeinterlacer
	{
	public:
		void UpdateConfiguration() override {}
		DataAcquisitionPayloadType PayloadType(const IO::Channel& channel) const override;
		std::size_t ChannelSampleCount(const IO::Channel& channel, const SourceData& source) const override;
		std::size_t BaseSampleSize() const override;
		void CopySamplesForChannel(const IO::Channel& channel, SignalProperty signalProperty,
			const SourceData& source, const DestinationData& destination) const override;
		int64_t ChannelMinValue(PTCChannelType channelType) const override;
		int64_t ChannelMaxValue(PTCChannelType channelType) const override;
		std::vector<Channel> ActiveChannels() const override { return TDataFormat::Channels(); }
		std::unique_ptr<IDeinterlacer> Clone() const override { return std::make_unique<StaticDeinterlacer>(*this); }
		IO::ProtocolType ProtocolType() const override { return TDataFormat::ProtocolType; }
		int MeasurementNumber() const override { return 0; }
		std::optional<int> BlockSize() const override { return std::nullopt; }
		double BaseSampleRateHertz() const override { return TDataFormat::SampleRateHertz; }
		const IDataLossControl* DataLossControl() const override { return m_dataLossControl.get(); }

	private:
		static_assert(std::is_trivially_copyable<typename TDataFormat::SampleFormat>::value, "sample format should be POD");
		static_assert(sizeof(typename TDataFormat::SampleFormat) == TDataFormat::SampleSize, "sample size doesn't match");

		static std::shared_ptr<IDataLossControl> CreateDataLossControl();

		const std::shared_ptr<IDataLossControl> m_dataLossControl = CreateDataLossControl();
	};
}

#include "StaticDeinterlacer.inl"
