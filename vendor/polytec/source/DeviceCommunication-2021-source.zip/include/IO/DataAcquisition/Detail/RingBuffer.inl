// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#pragma once

#include <cassert>

namespace Polytec
{
	namespace IO
	{
		/// <summary>Constructor.</summary>
		/// <remarks>
		/// The buffer m_data is created with a size of (capacity + 1). This is needed to distinguish an
		/// empty buffer from a full buffer.
		/// </remarks>
		/// <typeparam name="T">Type of the buffer elements.</typeparam>
		/// <param name="capacity">The capacity.</param>
		/// <param name="allocator">The memory allocator.</param>
		template<typename T>
		RingBuffer<T>::RingBuffer(std::size_t capacity, std::pmr::polymorphic_allocator<T> allocator)
			: m_allocator(std::move(allocator))
			, m_data(m_allocator.allocate(capacity), capacity)
		{}

		/// <summary>Destructor.</summary>
		/// <typeparam name="T">Type of the buffer elements.</typeparam>
		template<typename T>
		RingBuffer<T>::~RingBuffer()
		{
			m_allocator.deallocate(std::data(m_data), Capacity());
		}

		/// <summary>
		/// Writes the elements from the given span into the buffer. The function checks for a buffer overflow.
		/// </summary>
		/// <remarks>
		/// The written elements are released to memory by the Advance function. This guarantees the
		/// thread safety.
		/// </remarks>
		/// <typeparam name="T">Type of the buffer elements.</typeparam>
		/// <typeparam name="U">Type of the elements to be buffered.</typeparam>
		/// <param name="src">Source span providing the elements to be written to the ring buffer.</param>
		template<typename T>
		template<typename U>
		void RingBuffer<T>::WriteToBuffer(const gsl::span<const U>& src)
		{
			CheckOverflow(std::size(src));
			const std::size_t writeIndex = m_writeIndex.load(std::memory_order_relaxed) % Capacity();
			DoWrite(src, writeIndex);
			Advance(m_writeIndex, std::size(src), std::memory_order_release);
		}

		/// <summary>
		/// Reads the given count of elements from the buffer. This decreases the buffer size by the
		/// number of readout elements. The function checks for a buffer underflow.
		/// </summary>
		/// <remarks>
		/// The read elements are acquired from memory by the CheckUnderflow function. This guarantees
		/// the thread safety.
		/// </remarks>
		/// <typeparam name="T">Type of the buffer elements.</typeparam>
		/// <param name="dest">Destination span providing the information how many elements to read from the buffer to what location in memory.</param>
		/// <returns>The read elements.</returns>
		template<typename T>
		void RingBuffer<T>::Read(const gsl::span<T>& dest)
		{
			const std::size_t sizeToRead = std::size(dest);
			CheckUnderflow(sizeToRead, std::memory_order_acquire);
			const std::size_t readIndex = m_readIndex.load(std::memory_order_relaxed) % Capacity();
			const std::size_t sizeToEnd = Capacity() - readIndex;
			if (sizeToRead <= sizeToEnd)
			{
				std::copy_n(std::begin(m_data) + readIndex, sizeToRead, std::begin(dest));
			}
			else
			{
				std::copy(std::begin(m_data) + readIndex,std::end(m_data), std::begin(dest));
				const std::size_t rest = sizeToRead - sizeToEnd;
				std::copy_n(std::begin(m_data), rest, std::begin(dest) + sizeToEnd);
			}
			Advance(m_readIndex, sizeToRead, std::memory_order_relaxed);
		}

		/// <summary>Discard buffered samples.</summary>
		/// <typeparam name="T">Type of the buffer elements.</typeparam>
		/// <param name="count">The amount of elements to be discarded.</param>
		template<typename T>
		void RingBuffer<T>::DiscardElements(std::size_t count) {
			CheckUnderflow(count, std::memory_order_relaxed);
			Advance(m_readIndex, count, std::memory_order_relaxed);
		}

		/// <summary>Clears the content of the ring buffer.</summary>
		/// <typeparam name="T">Type of the buffer elements.</typeparam>
		template<typename T>
		void RingBuffer<T>::Clear()
		{
			const std::size_t writeIndex = m_writeIndex.load(std::memory_order_relaxed);
			m_readIndex.store(writeIndex, std::memory_order_relaxed);
		}

		/// <summary>
		/// Gets the size of the buffer. This is the number of elements which are available for reading.
		/// The maximal size is the capacity of the buffer.
		/// </summary>
		/// <typeparam name="T">Type of the buffer elements.</typeparam>
		/// <param name="memoryOrder">The memory order.</param>
		/// <returns>The number of elements available for reading.</returns>
		template<typename T>
		std::size_t RingBuffer<T>::SizeImpl(std::memory_order memoryOrder) const
		{
			const std::size_t writeIndex = m_writeIndex.load(memoryOrder);
			const std::size_t readIndex = m_readIndex.load(std::memory_order_relaxed);
			return writeIndex >= readIndex
				? writeIndex - readIndex
				: writeIndex + IndexWrapBound() - readIndex;
		}

		/// <summary>
		/// Advances the given index by the given distance. If the index would exceed the end of the
		/// buffer, it goes back to the beginning.
		/// </summary>
		/// <typeparam name="T">Type of the buffer buffer elements.</typeparam>
		/// <param name="index">[in,out] The index.</param>
		/// <param name="distance">The distance to advance. It must be smaller than the data buffer size
		/// (ring buffer capacity + 1).</param>
		/// <param name="memoryOrder">The memory order.</param>
		template<typename T>
		void RingBuffer<T>::Advance(AtomicIndex& index, std::size_t distance, std::memory_order memoryOrder)
		{
			const std::size_t distanceToEnd = IndexWrapBound() - index.load(std::memory_order_relaxed);
			if (distance < distanceToEnd)
			{
				index.fetch_add(distance, memoryOrder);
			}
			else
			{
				if (distance > Capacity())
					throw std::runtime_error("The distance to advance cannot be greater than the ring buffer capacity.");
				index.store(distance - distanceToEnd, memoryOrder);
			}
		}

		/// <summary>
		/// Throws an exception if the elements to be written wouldn't fit into the buffer.
		/// </summary>
		/// <exception cref="std::overflow_error">Raised if a buffer overflow occurs.</exception>
		/// <typeparam name="T">Type of the buffer elements.</typeparam>
		/// <param name="sizeToWrite">The number of samples to be written.</param>
		template<typename T>
		void RingBuffer<T>::CheckOverflow(std::size_t sizeToWrite) const
		{
			const auto freeSamples = Capacity() - SizeImpl(std::memory_order_relaxed);
			if (sizeToWrite > freeSamples)
				throw std::overflow_error("buffer overflow");
		}

		/// <summary>Throws an exception if the elements to be read are not available.</summary>
		/// <exception cref="std::underflow_error">Raised if a buffer underflow occurs.</exception>
		/// <typeparam name="T">Type of the buffer elements.</typeparam>
		/// <param name="sizeToRead">The number of samples to be read.</param>
		/// <param name="memoryOrder">The memory order.</param>
		template<typename T>
		void RingBuffer<T>::CheckUnderflow(std::size_t sizeToRead, std::memory_order memoryOrder) const
		{
			if (sizeToRead > SizeImpl(memoryOrder))
				throw std::underflow_error("buffer underflow");
		}

		/// <summary>Executes the write operation.</summary>
		/// <typeparam name="T">Type of the buffer elements.</typeparam>
		/// <typeparam name="U">Type of the elements to be buffered.</typeparam>
		/// <param name="src">Source span providing the elements to be written to the ring buffer.</param>
		/// <param name="writeIndex">The position in the buffer where the data will be written.</param>
		template<typename T>
		template<typename U>
		void RingBuffer<T>::DoWrite(const gsl::span<const U>& src, std::size_t writeIndex)
		{
			const std::size_t sizeToEnd = Capacity() - writeIndex;
			if (std::size(src) > sizeToEnd)
			{
				std::copy_n(std::begin(src), sizeToEnd, std::begin(m_data) + writeIndex);
				std::copy_n(std::begin(src) + sizeToEnd, std::size(src) - sizeToEnd, std::begin(m_data));
			} else
			{
				std::copy(std::begin(src), std::end(src), std::begin(m_data) + writeIndex);
			}
		}
	}
}
