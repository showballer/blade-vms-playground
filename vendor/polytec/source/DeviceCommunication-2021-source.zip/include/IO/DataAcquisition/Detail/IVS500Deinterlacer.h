// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#pragma once

#include <IO/DataAcquisition/Detail/DataFormatIVS500.h>
#include <IO/DataAcquisition/Detail/IDeinterlacer.h>
#include <IO/DataAcquisition/Detail/StaticDeinterlacer.h>
#include <IO/DeviceCommunication/Device.h>
#include <IO/DeviceCommunication/Utils/DeviceList.h>

namespace Polytec::IO
{
	class DeviceCommunication;

	/// <summary>
	/// This class provides deinterlacing for IVS-500+ and VGO-200. Channel activation of different
	/// decoders is provided in addition to the static IVS-500 data format.
	/// </summary>
	class IVS500Deinterlacer : public IDeinterlacer
	{
	public:
		explicit IVS500Deinterlacer(DeviceCommunication& communication);

		void UpdateConfiguration() override;
		DataAcquisitionPayloadType PayloadType(const Channel& channel) const override;
		std::size_t ChannelSampleCount(const Channel& channel, const SourceData& source) const override;
		std::size_t BaseSampleSize() const override;
		void CopySamplesForChannel(const IO::Channel& channel, SignalProperty signalProperty,
			const SourceData& source, const DestinationData& destination) const override;
		int64_t ChannelMinValue(PTCChannelType channelType) const override;
		int64_t ChannelMaxValue(PTCChannelType channelType) const override;
		std::vector<Channel> ActiveChannels() const override { return m_activechannels; };
		std::unique_ptr<IDeinterlacer> Clone() const override { return std::make_unique<IVS500Deinterlacer>(*this); }
		IO::ProtocolType ProtocolType() const override { return m_staticDeinterlacer->ProtocolType(); }
		int MeasurementNumber() const override { return m_staticDeinterlacer->MeasurementNumber(); }
		std::optional<int> BlockSize() const override { return m_staticDeinterlacer->BlockSize(); }
		double BaseSampleRateHertz() const override { return m_staticDeinterlacer->BaseSampleRateHertz(); }
		const IDataLossControl* DataLossControl() const override { return m_staticDeinterlacer->DataLossControl(); }

	private:
		bool IsActiveDecoder(const Channel& channel) const;

		DeviceCommunication& m_communication;
		const std::shared_ptr<IDeinterlacer> m_staticDeinterlacer;
		const DeviceList m_devices;
		const bool m_hasChannelActivation{};
		std::vector<Channel> m_activechannels{};
	};
}
