// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#pragma once

namespace Polytec::IO
{
	/// <summary>The Samples class represents an array of samples.</summary>
	/// <typeparam name="T">The array type.</typeparam>
	/// <typeparam name="N">The array size.</typeparam>
	template <typename T, int N>
	struct Samples
	{
		using SampleType = T;
		std::array<T, N> Values;
	};
}
