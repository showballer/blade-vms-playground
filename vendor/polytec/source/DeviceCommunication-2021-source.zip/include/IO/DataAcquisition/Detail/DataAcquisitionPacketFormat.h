// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#pragma once

#include <IO/DeviceCommunication/Detail/INetworkPacketFormat.h>

namespace Polytec::IO
{
	/// <summary>
	/// The data acquisition packet format
	/// </summary>
	/// <remarks>
	/// This class can be used for sending data acquisition packets with protocols that don't support packaging, like e.g. TCP.
	/// </remarks>
	class DataAcquisitionPacketFormat : public INetworkPacketFormat
	{
		std::size_t GetBaseHeaderSize() const override { return 8; }
		std::size_t GetBodySize(const std::vector<std::byte>& header) const override;
	};
}
