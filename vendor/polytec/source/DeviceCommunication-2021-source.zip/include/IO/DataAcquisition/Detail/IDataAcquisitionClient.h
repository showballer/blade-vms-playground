// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#pragma once

#include <IO/DeviceCommunication/Detail/DataWriter.h>
#include <IO/DeviceCommunication/Detail/IService.h>

#include <boost/asio.hpp>
#include <boost/signals2.hpp>
#include <gsl/span>

#include <string>

namespace Polytec::IO
{
	/// <summary>Interface for data acquisition clients used to receive measurement data from a network.</summary>
	class IDataAcquisitionClient : public IService
	{
	public:
		/// <summary>Data available signal</summary>
		using DataAvailableSignal = boost::signals2::signal<void(const std::wstring&, const gsl::span<const std::byte>&)>;

		/// <summary>The given callback function is called if data has been received.</summary>
		/// <param name="callback">The callback function.</param>
		virtual void ConnectOnDataAvailable(const DataAvailableSignal::slot_function_type& callback) = 0;
	};

	using DataAcquisitionClientPtr = std::unique_ptr<IDataAcquisitionClient>;
}
