// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#pragma once


#include <mutex>

namespace Polytec::IO
{
	/// <summary>A guard making sure that a thread is running on real time priority</summary>
	/// <remarks>
	/// Also sets the process priority to high.
	/// Thread and process priority are being set on construction and reset on destruction.
	/// </remarks>
	class RealTimePriorityGuard
	{
	public:
		RealTimePriorityGuard();
		RealTimePriorityGuard(const RealTimePriorityGuard&) = delete;
		RealTimePriorityGuard& operator=(const RealTimePriorityGuard&) = delete;
		RealTimePriorityGuard(RealTimePriorityGuard&&) = default;
		RealTimePriorityGuard& operator=(RealTimePriorityGuard&&) = delete;
		~RealTimePriorityGuard();

	private:
		using NativePriorityValue = int;

		static NativePriorityValue GetProcessPriority();
		static NativePriorityValue GetThreadPriority();
		static void SetProcessPriority(NativePriorityValue priority);
		static void SetThreadPriority(NativePriorityValue priority);
		static NativePriorityValue HighProcessPriority();
		static NativePriorityValue RealTimeThreadPriority();

		const NativePriorityValue m_initialThreadPriority{};
		const static NativePriorityValue s_initialProcessPriority;
		static std::size_t s_instanceCount;
		static std::mutex s_mutex;
	};
}
