// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#pragma once

#include "IDeinterlacer.h"
#include "RingBuffer.h"

#include <IO/DeviceCommunication/PTCCommunicationStatusCode.h>

#include <mutex>

namespace Polytec
{
	namespace IO
	{
		struct DataAcquisitionHeader;
		class MeasurementData;

		/// <summary>
		/// A data buffer using a RingBuffer to store acquired measurement data in the appropriate format
		/// </summary>
		class MeasurementDataBuffer
		{
		public:
			MeasurementDataBuffer(std::size_t capacity, std::unique_ptr<IDeinterlacer> deinterlacer);

		public:
			void Write(const gsl::span<const std::byte>& data);
		private:
			void DoWrite(const DataAcquisitionHeader& header, const gsl::span<const std::byte>& data);
			void CheckHeaderConsistency(const DataAcquisitionHeader& header, std::size_t dataSizeBytes) const;
			void CheckNoError(const DataAcquisitionHeader& header, const gsl::span<const std::byte>& data) const;
			void WriteOneSampleAtATime(const gsl::span<const std::byte>& samples);
			void WaitForBytesAvailableToWrite(std::size_t size) const;
			gsl::span<const std::byte> CreateValidSamples(const gsl::span<const std::byte>& source);

		public:
			void Reset();
			void NextBlock();
			MeasurementData ReadAvailableData(std::size_t sampleCount);
			MeasurementData ReadData(std::size_t sampleCount, const std::chrono::duration<double>& timeout);
			std::size_t AvailableSamples() const;
			void CheckReadOutOfRange(std::size_t sampleCount) const;
			const IDeinterlacer& Deinterlacer() const { return *m_deinterlacer; }
			void Shutdown() { m_isShuttingDown.store(true, std::memory_order_relaxed); }
		private:
			void Initialize();
			void ResetRingBuffer(std::size_t capacity);

		private:
			class ErrorState
			{
			public:
				std::pair<PTCCommunicationStatusCode, std::wstring> Get() const;
				bool IsErrorState() const;
				void Set(PTCCommunicationStatusCode statusCode, std::wstring errorMessage);
				void Clear();
			private:
				PTCCommunicationStatusCode m_statucCode;
				std::wstring m_errorMessage;
				mutable std::mutex m_mutex;
			};

			const std::size_t m_capacity{};
			std::unique_ptr<RingBuffer<std::byte>> m_ringBuffer;
			std::unique_ptr<IDeinterlacer> m_deinterlacer;
			std::uint64_t m_sequenceNumber = 0;
			ErrorState m_errorState;
			bool m_hasStarted = false;
			std::size_t m_readCounter{};
			std::vector<std::byte> m_validSamplesBuffer;
			std::atomic<bool> m_isShuttingDown{false};
			std::mutex m_mutex;
		};
	}
}
