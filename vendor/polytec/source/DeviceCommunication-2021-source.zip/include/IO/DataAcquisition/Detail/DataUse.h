// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#pragma once


#include <cstdint>

namespace Polytec::IO
{
	/// <summary>Enum to define the use of a data packet from a data acquisition stream.</summary>
	enum class DataUse : uint8_t
	{
		/// <summary>Unknown data use.</summary>
		Unknown = 0,
		/// <summary>Measurement data.</summary>
		Data = 1,
		/// <summary>Information.</summary>
		Info = 2,
		/// <summary>Response.</summary>
		Response = 3,
		/// <summary>Request.</summary>
		Request = 4,
		/// <summary>Error.</summary>
		Error = 5,
		/// <summary>Redundancy data, i.e. measurement data sent repeatedly.</summary>
		Redundancy = 6,
		/// <summary>Payload carries no information.</summary>
		Void = 7
	};
}
