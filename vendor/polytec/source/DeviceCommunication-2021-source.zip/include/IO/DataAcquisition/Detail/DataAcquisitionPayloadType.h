// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#pragma once


#include <cstdint>

namespace Polytec::IO
{
	/// <summary>Enum to define the payload type of a data packet from a data acquisition stream.</summary>
	enum class DataAcquisitionPayloadType : uint8_t
	{
		Unknown = 0,
		Ascii = 1,
		Int8 = 2,
		UInt8 = 3,
		Int16 = 4,
		UInt16 = 5,
		Int24 = 6,
		UInt24 = 7,
		Int32 = 8,
		UInt32 = 9,
		Float = 10
	};
}
