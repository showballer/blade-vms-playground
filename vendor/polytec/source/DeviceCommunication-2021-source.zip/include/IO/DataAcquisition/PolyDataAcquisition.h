// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

/// \file
/// \brief	Main header for the Data Acquisition C interface

#pragma once

#include "PTCChannelType.h"

#include <IO/DeviceCommunication/PTCCommunicationStatusCode.h>

#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>

// The macro DAQAPI is used on Windows to export symbols when a DLL is build and to import symbols
// when the DLL is used. In order to build the DLL on Windows, EXPORT_DAQAPI needs to be defined.
#ifdef _WIN32
#	ifdef BUILD_DAQAPI
#		define DAQAPI __declspec(dllexport)
#	else
#		define DAQAPI __declspec(dllimport)
#	endif
#else
#	define DAQAPI
#endif

#ifdef __cplusplus
extern "C" {
	#endif

	/// <summary>
	/// An acquisition handle is created by opening a data acquisition. It can be used to read from a
	/// continuous measurement data stream.
	/// </summary>
	typedef int PTAcquisitionHandle;

	/// <summary>A communication handle is created by opening a communication to a device.
	/// 		 It can be used to send commands to the device.</summary>
	/// <remarks>Valid handles are positive numbers. Null is an invalid handle</remarks>
	typedef int PTCommunicationHandle;

	/// <summary>
	/// Opens a data acquisition listener. The instance starts listening for data from the given IP
	/// address of the specified data format when PolyStartDataAcquisition is called. The data is
	/// saved into an internal ring buffer of size bufferCapacity until the data is read by the
	/// PolyReadData or PolyReadAvailableData.
	/// </summary>
	/// <param name="acquisitionHandle">[out] The created acquisition handle.</param>
	/// <param name="communicationHandle">The communication handle.</param>
	/// <param name="bufferCapacity">The buffer capacity of the internal ring buffer in base samples.</param>
	/// <returns>Returns a status code, that indicates if the listener could be opened.</returns>
	DAQAPI PTCCommunicationStatusCode PolyOpenDataAcquisition(PTAcquisitionHandle* acquisitionHandle,
		PTCommunicationHandle communicationHandle, size_t bufferCapacity);

	/// <summary>
	/// Closes the data acquisition instance.
	/// </summary>
	/// <param name="acquisitionHandle">The acquisition handle that will be destroyed.</param>
	DAQAPI void PolyCloseDataAcquisition(PTAcquisitionHandle acquisitionHandle);

	/// <summary>Starts acquiring data to the internal ring buffer.</summary>
	/// <param name="acquisitionHandle">The data acquisition handle.</param>
	/// <returns>A status code which indicates if the function succeeded.</returns>
	DAQAPI PTCCommunicationStatusCode PolyStartDataAcquisition(PTAcquisitionHandle acquisitionHandle);

	/// <summary>Stops acquiring data to the internal ring buffer.</summary>
	/// <param name="acquisitionHandle">The data acquisition handle.</param>
	/// <returns>A status code which indicates if the function succeeded.</returns>
	DAQAPI PTCCommunicationStatusCode PolyStopDataAcquisition(PTAcquisitionHandle acquisitionHandle);

	/// <summary>
	/// This method ensures that data from different blocks are read seperately. The use of this
	/// method is only needed if multiple block acquisition is activated
	/// (PTCDeviceCommand_DaqBlockCount != 1). This method has to be called after all data from one
	/// block has been read and before data from the next block is read.
	/// </summary>
	/// <param name="acquisitionHandle">The data acquisition handle.</param>
	/// <returns>A status code which indicates if the function succeeded.</returns>
	DAQAPI PTCCommunicationStatusCode PolyNextDataAcquisitionBlock(PTAcquisitionHandle acquisitionHandle);

	/// <summary>
	/// Reads data from the ring buffer of the data acquisition into the measurement data buffer
	/// from which the samples then can be extracted using the PolyGet[Type]Data() functions
	/// (e.g. PolyGetInt32Data()). If the requested samples are not available in the given time,
	/// the function unblocks and returns the status code PTCCommunicationStatusCode_Timeout.
	/// </summary>
	/// <remarks>
	/// If data is acquired in block mode (PTCDeviceCommand_DaqMode is supported and is set to "Block"), the
	/// requested sample count may not exceed the number of remaining samples in the block.
	/// </remarks>
	/// <param name="acquisitionHandle">The data acquisition handle to the listener from which data
	/// will be extracted.</param>
	/// <param name="requestedSamples">The number of requested samples.</param>
	/// <param name="timeoutInMilliseconds">The timeout in milliseconds. When the data is not
	/// available within the given time. The function returns an error.</param>
	/// <returns>A status code which indicates if the function succeeded.</returns>
	DAQAPI PTCCommunicationStatusCode PolyReadData(PTAcquisitionHandle acquisitionHandle,
		size_t requestedSamples, int timeoutInMilliseconds);

	/// <summary>
	/// Reads data from the ring buffer of the data acquisition into the measurement data buffer
	/// from which the samples then can be extracted using the PolyGet[Type]Data() functions
	/// (e.g. PolyGetInt32Data()). If the requested samples are not available, the function only
	/// reads the currently available samples.
	/// </summary>
	/// <param name="acquisitionHandle">The data acquisition handle to the listener from which data
	/// will be extracted.</param>
	/// <param name="requestedSamples">The number of requested base samples.</param>
	/// <param name="extractedSamples">[out] The number of base samples which are actually extracted.</param>
	/// <returns>A status code which indicates if the function succeeded.</returns>
	DAQAPI PTCCommunicationStatusCode PolyReadAvailableData(PTAcquisitionHandle acquisitionHandle,
		size_t requestedSamples, size_t* extractedSamples);

	/// <summary>
	/// Get base sample count available to be extracted from all channels.
	/// </summary>
	/// <param name="acquisitionHandle">The data acquisition handle.</param>
	/// <param name="availableBaseSamples">[out] Number of base samples available.</param>
	/// <returns>
	/// Returns a status code which indicates if the function copied the measurement data
	/// successfully.
	/// </returns>
	DAQAPI PTCCommunicationStatusCode PolyAvailableSamples(PTAcquisitionHandle acquisitionHandle,
		size_t* availableBaseSamples);

	/// <summary>
	/// Get sample count extracted / available to be copied from the specified channel.
	/// </summary>
	/// <param name="acquisitionHandle">The data acquisition handle.</param>
	/// <param name="channelType">The channel type, e.g. Velocity</param>
	/// <param name="channelId">Channel identifier, e.g. 0</param>
	/// <param name="extractedSamples">[out] Number of samples available to be copied.</param>
	/// <returns>
	/// Returns a status code which indicates if the function copied the measurement data
	/// successfully.
	/// </returns>
	DAQAPI PTCCommunicationStatusCode PolyExtractedSampleCount(PTAcquisitionHandle acquisitionHandle,
		PTCChannelType channelType, int channelId, size_t* extractedSamples);

	/// <summary>
	/// Copies the samples for the given channel from the measurement data to the given data buffer.
	/// </summary>
	/// <param name="acquisitionHandle">The data acquisition handle.</param>
	/// <param name="channelType">The channel type, e.g. Velocity</param>
	/// <param name="channelId">Channel identifier, e.g. 0</param>
	/// <param name="dataBuffer">[out] The data buffer to which the measurement data will be copied.</param>
	/// <param name="bufferSize">The buffer size in samples. If the buffer size does not match the
	/// number of samples of the measurement data, the function fails.</param>
	/// <returns>
	/// Returns a status code which indicates if the function copied the measurement data
	/// successfully.
	/// </returns>
	DAQAPI PTCCommunicationStatusCode PolyGetUInt8Data(PTAcquisitionHandle acquisitionHandle,
		PTCChannelType channelType, int channelId, uint8_t* dataBuffer, size_t bufferSize);

	/// <summary>
	/// Copies the samples for the given channel from the measurement data to the given data buffer.
	/// </summary>
	/// <param name="acquisitionHandle">The data acquisition handle.</param>
	/// <param name="channelType">The channel type, e.g. Velocity</param>
	/// <param name="channelId">Channel identifier, e.g. 0</param>
	/// <param name="dataBuffer">[out] The data buffer to which the measurement data will be copied.</param>
	/// <param name="bufferSize">The buffer size in samples. If the buffer size does not match the
	/// number of samples of the measurement data, the function fails.</param>
	/// <returns>
	/// Returns a status code which indicates if the function copied the measurement data
	/// successfully.
	/// </returns>
	DAQAPI PTCCommunicationStatusCode PolyGetInt16Data(PTAcquisitionHandle acquisitionHandle,
		PTCChannelType channelType, int channelId, int16_t* dataBuffer, size_t bufferSize);

	/// <summary>
	/// Copies the samples for the given channel from the measurement data to the given data buffer.
	/// </summary>
	/// <param name="acquisitionHandle">The data acquisition handle.</param>
	/// <param name="channelType">The channel type, e.g. Velocity</param>
	/// <param name="channelId">Channel identifier, e.g. 0</param>
	/// <param name="dataBuffer">[out] The data buffer to which the measurement data will be copied.</param>
	/// <param name="bufferSize">The buffer size in samples. If the buffer size does not match the
	/// number of samples of the measurement data, the function fails.</param>
	/// <returns>
	/// Returns a status code which indicates if the function copied the measurement data
	/// successfully.
	/// </returns>
	DAQAPI PTCCommunicationStatusCode PolyGetUInt16Data(PTAcquisitionHandle acquisitionHandle,
		PTCChannelType channelType, int channelId, uint16_t* dataBuffer, size_t bufferSize);

	/// <summary>
	/// Copies the samples for the given channel from the measurement data to the given data buffer.
	/// </summary>
	/// <param name="acquisitionHandle">The data acquisition handle.</param>
	/// <param name="channelType">The channel type, e.g. Velocity</param>
	/// <param name="channelId">Channel identifier, e.g. 0</param>
	/// <param name="dataBuffer">[out] The data buffer to which the measurement data will be copied.</param>
	/// <param name="bufferSize">The buffer size in samples. If the buffer size does not match the
	/// number of samples of the measurement data, the function fails.</param>
	/// <returns>
	/// Returns a status code which indicates if the function copied the measurement data
	/// successfully.
	/// </returns>
	DAQAPI PTCCommunicationStatusCode PolyGetInt32Data(PTAcquisitionHandle acquisitionHandle,
		PTCChannelType channelType, int channelId, int32_t* dataBuffer, size_t bufferSize);

	/// <summary>
	/// Copies the overrange samples for the given channel from the measurement data to the given data buffer.
	/// </summary>
	/// <param name="acquisitionHandle">The data acquisition handle.</param>
	/// <param name="channelType">The channel type, e.g. Velocity</param>
	/// <param name="channelId">Channel identifier, e.g. 0</param>
	/// <param name="dataBuffer">[out] The data buffer to which the measurement data will be copied.</param>
	/// <param name="bufferSize">The buffer size in samples. If the buffer size does not match the
	/// number of samples of the measurement data, the function fails.</param>
	/// <returns>
	/// Returns a status code which indicates if the function copied the measurement data
	/// successfully.
	/// </returns>
	DAQAPI PTCCommunicationStatusCode PolyGetOverrange(PTAcquisitionHandle acquisitionHandle,
		PTCChannelType channelType, int channelId, uint8_t* dataBuffer, size_t bufferSize);

	/// <summary>Evaluates the regular minimum value for the channel type.</summary>
	/// <remarks>
	/// Some channels have a head room. In this case the returned value is including the head room.
	/// For example if a velocity range of 2 m/s is selected and the head room for the digital
	/// velocity channel is 10%, the minimum value would indicate a velocity of -2.2 m/s.
	/// </remarks>
	/// <param name="acquisitionHandle">The acquisition handle.</param>
	/// <param name="channelType">The channel type, e.g. Velocity</param>
	/// <param name="minValue">[in,out] The minimum value.</param>
	/// <returns>Returns a status code which indicates if the function succeeded.</returns>
	DAQAPI PTCCommunicationStatusCode PolyChannelMinValue(PTAcquisitionHandle acquisitionHandle,
		PTCChannelType channelType, int32_t* minValue);

	/// <summary>Evaluates the regular maximum value for the channel type.</summary>
	/// <remarks>
	/// Some channels have a head room. In this case the returned value is including the head room.
	/// For example if a velocity range of 2 m/s is selected and the head room for the digital
	/// velocity channel is 10%, the maximum value would indicate a velocity of +2.2 m/s.
	/// </remarks>
	/// <param name="acquisitionHandle">The acquisition handle.</param>
	/// <param name="channelType">The channel type, e.g. Velocity</param>
	/// <param name="maxValue">The maximum value.</param>
	/// <returns>Returns a status code which indicates if the function succeeded.</returns>
	DAQAPI PTCCommunicationStatusCode PolyChannelMaxValue(PTAcquisitionHandle acquisitionHandle,
		PTCChannelType channelType, int32_t* maxValue);

	/// <summary>Get the maximum amount of channels supported on a device (available or not).</summary>
	/// <remarks>See PolyChannelActivationIsChannelTypeSupported and PolyChannelActivationIsChannelAvailable
	/// 		 for further information on supported and available channels.</remarks>
	/// <param name="communicationHandle">The communication handle.</param>
	/// <param name="channelType">The channel type, e.g. Velocity</param>
	/// <param name="count">[out] Number of channels supported.</param>
	/// <returns>Returns a status code, e.g. PTCCommunicationStatusCode_Success on success.</returns>
	DAQAPI PTCCommunicationStatusCode PolyChannelActivationMaxChannelCount(
		PTCommunicationHandle communicationHandle, PTCChannelType channelType, int* count);

	/// <summary>Check if a channel type is supported by a device.</summary>
	/// <param name="communicationHandle">Handle of the communication.</param>
	/// <param name="channelType">The channel type, e.g. Velocity</param>
	/// <param name="result">[out] The result, true if channel type is available.</param>
	/// <returns>Returns a status code, e.g. PTCCommunicationStatusCode_Success on success.</returns>
	DAQAPI PTCCommunicationStatusCode PolyChannelActivationIsChannelTypeSupported(
		PTCommunicationHandle communicationHandle, PTCChannelType channelType, bool* result);

	/// <summary>Check if a channel is currently available to be enabled on a device.</summary>
	/// <remarks>Already enabled channels also return true.</remarks>
	/// <param name="communicationHandle">Handle of the communication.</param>
	/// <param name="channelType">The channel type, e.g. Velocity</param>
	/// <param name="channelId">Channel identifier, e.g. 0</param>
	/// <param name="result">[out] The result, true if channel is available.</param>
	/// <returns>Returns a status code, e.g. PTCCommunicationStatusCode_Success on success.</returns>
	DAQAPI PTCCommunicationStatusCode PolyChannelActivationIsChannelAvailable(
		PTCommunicationHandle communicationHandle, PTCChannelType channelType, int channelId, bool* result);

	/// <summary>Enable the specified channel.</summary>
	/// <param name="communicationHandle">Handle of the communication.</param>
	/// <param name="channelType">The channel type, e.g. Velocity</param>
	/// <param name="channelId">Channel identifier, e.g. 0</param>
	/// <returns>Returns a status code, e.g. PTCCommunicationStatusCode_Success on success.</returns>
	DAQAPI PTCCommunicationStatusCode PolyChannelActivationEnableChannel(
		PTCommunicationHandle communicationHandle, PTCChannelType channelType, int channelId);

	/// <summary>Disable the specified channel.</summary>
	/// <param name="communicationHandle">Handle of the communication.</param>
	/// <param name="channelType">The channel type, e.g. Velocity</param>
	/// <param name="channelId">Channel identifier, e.g. 0</param>
	/// <returns>Returns a status code, e.g. PTCCommunicationStatusCode_Success on success.</returns>
	DAQAPI PTCCommunicationStatusCode PolyChannelActivationDisableChannel(
		PTCommunicationHandle communicationHandle, PTCChannelType channelType, int channelId);

	/// <summary>Disable all channels on the device.</summary>
	/// <param name="communicationHandle">Handle of the communication.</param>
	/// <returns>Returns a status code, e.g. PTCCommunicationStatusCode_Success on success.</returns>
	DAQAPI PTCCommunicationStatusCode PolyChannelActivationDisableAllChannels(PTCommunicationHandle communicationHandle);

	/// <summary>Check if the specified channel is enabled.</summary>
	/// <param name="communicationHandle">Handle of the communication.</param>
	/// <param name="channelType">The channel type, e.g. Velocity</param>
	/// <param name="channelId">Channel identifier, e.g. 0</param>
	/// <param name="result">[out] The result, true if channel is enabled.</param>
	/// <returns>Returns a status code, e.g. PTCCommunicationStatusCode_Success on success.</returns>
	DAQAPI PTCCommunicationStatusCode PolyChannelActivationIsChannelEnabled(
		PTCommunicationHandle communicationHandle, PTCChannelType channelType, int channelId, bool* result);

	/// <summary>Retrieve the base sample rate of a device.</summary>
	/// <param name="acquisitionHandle">The data acquisition handle.</param>
	/// <param name="baseSampleRate">[out] The base sample rate in Hz.</param>
	/// <returns>Returns a status code, e.g. PTCCommunicationStatusCode_Success on success.</returns>
	DAQAPI PTCCommunicationStatusCode PolyBaseSampleRateInHz(PTAcquisitionHandle acquisitionHandle, double* baseSampleRate);

	#ifdef __cplusplus
}
#endif
