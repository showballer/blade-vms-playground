// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

/// \file
/// \brief	Declaration of a class defining a type of acquired measurement data

#pragma once

#include "PTCChannelType.h"

#include <IO/DataAcquisition/Detail/IDeinterlacer.h>

#include <vector>
#include <gsl/gsl>

namespace Polytec::IO
{
	class Channel;

	/// <summary>Defines a type for acquired measurement data.</summary>
	class MeasurementData
	{
	public:
		/// <summary>Constructs an empty measurement data object.</summary>
		MeasurementData() = default;

		/// <summary>Constructs a measurement data object from the given samples.</summary>
		/// <param name="data">[in] The samples.</param>
		/// <param name="deinterlacer">The deinterlacer.</param>
		MeasurementData(std::vector<std::byte>&& data, std::unique_ptr<IDeinterlacer> deinterlacer);

		/// <summary>Gets the measurement data samples for the given channel.</summary>
		/// <typeparam name="TResult">The type of the returned samples. The type has to be able to
		/// represent the channel minimum and maximum value. If not, the function call fails with an
		/// exception.</typeparam>
		/// <param name="channel">The channel.</param>
		/// <returns>Returns the samples.</returns>
		template<typename TResult>
		std::vector<TResult> Get(const Channel& channel) const;

		/// <summary>Gets the overrange data samples for the given channel.</summary>
		/// <typeparam name="TResult">The type of the returned samples. The type has to be able to
		/// represent the channel minimum and maximum value. If not the function call fails with an
		/// exception.</typeparam>
		/// <param name="channel">The channel.</param>
		/// <returns>Returns the samples.</returns>
		template<typename TResult>
		std::vector<TResult> GetOverrange(const Channel& channel) const;

		/// <summary>Get the measurement data samples in raw format for all channels.</summary>
		/// <typeparam name="TSampleFormat">The sample format.</typeparam>
		/// <returns>Returns the samples.</returns>
		template <typename TSampleFormat>
		std::vector<TSampleFormat> GetRawSamples() const;

		/// <summary>Gets the base sample count of the acquired data.</summary>
		/// <returns>The number of base samples.</returns>
		std::size_t BaseSampleCount() const;

		/// <summary>Sample count read from the specified channel.</summary>
		/// <param name="channel">The channel.</param>
		/// <returns>Number of samples.</returns>
		std::size_t SampleCount(const Channel& channel) const;

	private:
		template<typename TResult>
		std::vector<TResult> GetDataImplementation(const Channel& channel, IDeinterlacer::SignalProperty signalProperty) const;
		
		template<typename TResult, typename TChannelSample>
		std::vector<TResult> Deinterlace(const Channel& channel, IDeinterlacer::SignalProperty signalProperty) const;

		template<typename TResult>
		void CheckConvertible(PTCChannelType channelType, IDeinterlacer::SignalProperty signalProperty) const;

		void CheckValid() const;

	private:
		std::vector<std::byte> m_data;
		std::shared_ptr<IDeinterlacer> m_deinterlacer;
	};
}

#include "Detail/MeasurementData.inl"
