// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

/// \file
/// \brief	Definition of a class defining a type of data acquisition channel

#pragma once

#include "PTCChannelType.h"


#include <tuple>

namespace Polytec
{
	namespace IO
	{
		/// <summary>Defines a type of data acquisition channels.</summary>
		class Channel
		{
		public:
			/// <summary>Constructs a channel object.</summary>
			/// <param name="channelType">Type of the channel, e.g. PTCChannelType_Velocity.</param>
			/// <param name="channelNumber">The channel number.</param>
			constexpr Channel(PTCChannelType channelType = PTCChannelType_Unknown, int channelNumber = 0) noexcept
				: m_type(channelType),
				m_number(channelNumber)
			{}

			/// <summary>Gets the channel type.</summary>
			/// <returns>Returns the channel type.</returns>
			constexpr PTCChannelType Type() const noexcept
			{
				return m_type;
			}

			/// <summary>Gets the channel number.</summary>
			/// <returns>Returns the channel number.</returns>
			constexpr int Number() const noexcept
			{
				return m_number;
			}

		private:
			PTCChannelType m_type;
			int m_number;
		};

		/// <summary>Equality operator</summary>
		constexpr bool operator==(const Channel& lhs, const Channel& rhs) noexcept
		{
			return lhs.Type() == rhs.Type() && lhs.Number() == rhs.Number();
		}

		/// <summary>Inequality operator</summary>
		constexpr bool operator!=(const Channel& lhs, const Channel& rhs) noexcept
		{
			return !(lhs == rhs);
		}

		/// <summary>Less-than comparison operator.</summary>
		constexpr bool operator<(const Channel& lhs, const Channel& rhs) noexcept
		{
			return std::make_tuple(lhs.Type(), lhs.Number())
				< std::make_tuple(rhs.Type(), rhs.Number());
		}

		/// <summary>
		/// A signal channel is a channel with measurement data, as e.g. velocity signal. Non-signal
		/// channels are e.g. Trigger, RSSI.
		/// </summary>
		/// <param name="channel">The channel.</param>
		/// <returns>True if signal channel, false if not.</returns>
		constexpr bool IsSignalChannel(const Channel& channel)
		{
			return channel.Type() == PTCChannelType_Velocity
				|| channel.Type() == PTCChannelType_Displacement
				|| channel.Type() == PTCChannelType_Acceleration;
		}
	}
}
