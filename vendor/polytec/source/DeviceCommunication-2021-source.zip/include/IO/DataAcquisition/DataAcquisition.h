// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

/// \file
/// \brief	Declaration of a class defining the data acquisition type

#pragma once

#include <IO/DataAcquisition/PTCChannelType.h>

#include <chrono>
#include <functional>
#include <memory>
#include <string>

namespace Polytec::IO
{
	class Channel;
	class DataAcquisition;
	class DataAcquisitionListener;
	class DataAcquisitionImplementation;
	class DeviceCommunication;
	class IDeinterlacer;
	class MeasurementData;

	/// <summary>
	/// Creates a data acquisition object. The object receives data from the given device IP address
	/// and stores incoming data in a ring buffer of given capacity until the data is read out.
	/// </summary>
	/// <param name="communication">[in,out] The device communication.</param>
	/// <param name="capacity">The capacity of the ringbuffer in samples.</param>
	/// <returns>The constructed TCP data acquisition object.</returns>
	DataAcquisition CreateDigitalDataAcquisition(DeviceCommunication& communication, std::size_t capacity);

	/// <summary>High level data acquisition type</summary>
	/// <remarks>Multiple instances of this type may listen to different devices.</remarks>
	class DataAcquisition
	{
	public:
		/// <summary>Default constructor. Creates an empty object.</summary>
		DataAcquisition();

		DataAcquisition(const DataAcquisition&) = delete;
		DataAcquisition& operator=(const DataAcquisition&) = delete;

		/// <summary>Move constructor..</summary>
		/// <param name="rhs">[in] The object to be moved from.</param>/
		DataAcquisition(DataAcquisition&& rhs) noexcept;

		/// <summary>Move assignment constructor.</summary>
		/// <param name="rhs">[in] The object to be moved from.</param>/
		/// <returns>A shallow copy of this object.</returns>
		DataAcquisition& operator=(DataAcquisition&& rhs) noexcept;

		~DataAcquisition() noexcept;

		/// <summary>
		/// A helper function for dependency injection of the data acquisition listener implementation.
		/// The conventional way to create a data acquisition instance is to use the factory functions,
		/// e.g. CreateUdpAcquisition.
		/// </summary>
		/// <param name="communication">The device communication instance.</param>
		/// <param name="capacity">The capacity of the ring buffer.</param>
		/// <param name="listener">The data acquisition listener implementation.</param>
		explicit DataAcquisition(DeviceCommunication& communication, std::size_t capacity,
			std::shared_ptr<DataAcquisitionListener> listener);

		/// <summary>
		/// Starts a data acquisition. Data can be read from the buffer until StopDataAcquisition is
		/// called.
		/// </summary>
		void StartAcquisition();
		
		/// <summary>Stops a data acquisition. Data can no longer be read from the buffer.</summary>
		void StopAcquisition();

		/// <summary>Evaluates if a data acquisition has been started by calling StartAcquisition and not stopped by calling StopAcquisition.</summary>
		/// <returns>True if acquisition started, false if not.</returns>
		bool IsAcquisitionStarted() const;

		/// <summary>Gets all active channels of the currently started acquisition.</summary>
		/// <returns>All active channels.</returns>
		std::vector<Channel> ActiveChannels() const;

		/// <summary>
		/// This method ensures that data from different blocks are read seperately. The use of this
		/// method is only needed if multiple block acquisition is activated
		/// (PTCDeviceCommand_DaqBlockCount != 1). This method has to be called after all data from one
		/// block has been read and before data from the next block is read.
		/// </summary>
		void NextDataAcquisitionBlock();

		/// <summary>
		/// Reads available data from the ring buffer. This function is not blocking. If the requested
		/// number of samples is not available, the returned data contains only the currently available
		/// samples. This method fails if no data acquisition is started.
		/// </summary>
		/// <param name="sampleCount">Number of samples to be read if available.</param>
		/// <returns>Returns the available data.</returns>
		MeasurementData ReadAvailableData(
			std::size_t sampleCount = std::numeric_limits<std::size_t>::max());

		/// <summary>
		/// Reads data from the ring buffer. This function is blocking until the requested samples are
		/// available or the timeout is reached. If the timeout is reached an CommunicationException is
		/// thrown. This method fails if no data acquisition is started.
		/// </summary>
		/// <remarks>
		/// If data is acquired in block mode (PTCDeviceCommand_DaqMode is supported and is set to
		/// "Block"), the requested sample count may not exceed the number of remaining samples in the
		/// block.
		/// </remarks>
		/// <param name="sampleCount">Number of samples to be read.</param>
		/// <param name="timeout">The timeout.</param>
		/// <returns>Returns the data.</returns>
		MeasurementData ReadData(std::size_t sampleCount, const std::chrono::duration<double>& timeout);

		/// <summary>Closes the data acquisition listener and destroys the ring buffer.</summary>
		void Close();

		/// <summary>Gets the available samples to read in the ring buffer.</summary>
		/// <returns>The available samples in the ring buffer.</returns>
		std::size_t AvailableSamples() const;

		/// <summary>Gets the channel minimum value.</summary>
		/// <remarks>
		/// Some channels may have a head room. In this case the returned value is including
		/// the head room. For example if the velocity range of 2 m/s is selected and the head room for
		/// the digital velocity channel is 10%, the minimum value would indicate a velocity of -2.2 m/s.
		/// </remarks>
		/// <param name="channelType">Type of the channel.</param>
		/// <returns>The minimum value.</returns>
		int32_t ChannelMinValue(PTCChannelType channelType) const;

		/// <summary>Gets the channel maximum value.</summary>
		/// <remarks>
		/// Some channels may have a head room. In this case the returned value is including
		/// the head room. For example if the velocity range of 2 m/s is selected and the head room for
		/// the digital velocity channel is 10%, the maximum value would indicate a velocity of +2.2 m/s.
		/// </remarks>
		/// <param name="channelType">Type of the channel.</param>
		/// <returns>The maximum value.</returns>
		int32_t ChannelMaxValue(PTCChannelType channelType) const;

		/// <summary>Gets the base sample rate.</summary>
		/// <returns>The base sample rate in Hz.</returns>
		double BaseSampleRateInHz() const;

	private:
		void CheckImplementation() const;
		void CheckStarted() const;

		std::unique_ptr<DataAcquisitionImplementation> m_implementation;
	};
}
