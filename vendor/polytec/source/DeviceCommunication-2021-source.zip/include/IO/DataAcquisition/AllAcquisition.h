// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

/// \file

#pragma once

#include "Channel.h"
#include "DataAcquisition.h"
#include "MeasurementData.h"
#include "PTCChannelType.h"
