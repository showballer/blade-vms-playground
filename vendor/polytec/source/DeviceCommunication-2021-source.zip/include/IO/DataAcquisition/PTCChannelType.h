// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

/// \file
/// \brief	Definition of all Channel types of data acquisition channels

#pragma once

/// <summary>Channel types of data acquisition channels</summary>
typedef enum PTCChannelType
{
	/// <summary>
	/// Unknown channel type. Always an error if this occurs.
	/// </summary>
	PTCChannelType_Unknown = 0,
	/// <summary>
	/// The data validity channel indicates if the data is valid. Invalid data may be caused by
	/// a lost UDP packet or a buffer overflow. (0 == invalid, 1 == valid).
	/// </summary>
	PTCChannelType_DataValidity = 1,
	/// <summary>
	/// The velocity channel contains the measured velocity.
	/// </summary>
	PTCChannelType_Velocity = 2,
	/// <summary>
	/// The RSSI channel is a measure for the quality of the measurement data.
	/// </summary>
	PTCChannelType_RSSI = 3,
	/// <summary>
	/// The trigger channel indicates if the trigger was pulled. (0 == trigger off, 1 == trigger on).
	/// </summary>
	PTCChannelType_Trigger = 4,

	// Removed: PTCChannelType_Overrange = 5, use PolyGetOverrange and MeasurementData::GetOverrange instead

	/// <summary>
	/// The displacement channel contains the measured displacement.
	/// </summary>
	PTCChannelType_Displacement = 6,
	/// <summary>
	/// The acceleration channel contains the measured acceleration.
	/// </summary>
	PTCChannelType_Acceleration = 7
} PTCChannelType;


static const PTCChannelType PTCChannelType_SignalLevel = PTCChannelType_RSSI; // PTCChannelType_SignalLevel is deprecated but provided for compatibility
