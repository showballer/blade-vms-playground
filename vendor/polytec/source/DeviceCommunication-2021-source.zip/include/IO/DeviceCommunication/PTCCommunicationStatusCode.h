// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

/// \file
/// \brief	Definition of all status codes used by the device communication

#pragma once

/// <summary>Status codes for the device communication.</summary>
/// <remarks>
/// The status codes starting from 1 are errors encountered by the device firmware,
/// i.e. when the firmware received an invalid command. The status codes starting
/// from 2000 are errors from the software interface, e.g. when a function was used
/// with an invalid argument or when the device is not responding within a given timeout.
/// </remarks>
typedef enum PTCCommunicationStatusCode
{
	/// <summary>
	/// Success status code.
	/// </summary>
	PTCCommunicationStatusCode_Success = 0,

	/// <summary>
	/// Unknown device error: The device firmware encountered an unknown error. May be a
	/// device command was used in an inappropriate way.
	/// </summary>
	PTCCommunicationStatusCode_UnknownDeviceError = 1,

	/// <summary>
	/// Wrong command type: The device firmware received a wrong command type. Command
	/// types are Get, GetDevInfo, GetValueList, Set.
	/// </summary>
	PTCCommunicationStatusCode_WrongCommandType = 2,

	/// <summary>
	/// Wrong device type: The device firmware received a wrong device type. A command was sent to
	/// a device which cannot handle it.
	/// </summary>
	PTCCommunicationStatusCode_WrongDeviceType = 3,

	/// <summary>
	/// Wrong device number: The device firmware received a command to a device number which is not installed.
	/// </summary>
	PTCCommunicationStatusCode_WrongDeviceNumber = 4,

	/// <summary>
	/// Wrong attribute: The device firmware received a wrong device command, i.e. the command is not supported
	/// by the firmware. Device commands are e.g. Autofocus, LaserOn...
	/// </summary>
	PTCCommunicationStatusCode_WrongAttribute = 5,

	/// <summary>
	/// Wrong payload type: The device firmware received a Set-command with a wrong payload type.
	/// </summary>
	PTCCommunicationStatusCode_WrongPayloadType = 6,

	/// <summary>
	/// Wrong payload data: The device firmware received a command with wrong payload data, i.e. with a
	/// value which is out of range.
	/// </summary>
	PTCCommunicationStatusCode_WrongPayloadData = 7,

	/// <summary>
	/// Scan array buffer underrun.
	/// </summary>
	PTCCommunicationStatusCode_ScanArrayBufferUnderrun = 8,

	/// <summary>
	/// Scan array buffer overrun.
	/// </summary>
	PTCCommunicationStatusCode_ScanArrayBufferOverrun = 9,

	/// <summary>
	/// Wrong extra tag: The device firmware received a command with a wrong miscellaneous tag.
	/// </summary>
	PTCCommunicationStatusCode_WrongExtraTag = 10,

	/// <summary>
	/// Not installed: The device firmware received a command to a device type which is not installed.
	/// </summary>
	PTCCommunicationStatusCode_NotInstalled = 11,

	/// <summary>
	/// Wrong operation mode.
	/// </summary>
	PTCCommunicationStatusCode_WrongOperationMode = 12,

	/// <summary>
	/// Memory overrun.
	/// </summary>
	PTCCommunicationStatusCode_MemoryOverrun = 13,

	/// <summary>
	/// Device not ready.
	/// </summary>
	PTCCommunicationStatusCode_DeviceNotReady = 14,

	/// <summary>
	/// Device not responding.
	/// </summary>
	PTCCommunicationStatusCode_DeviceNotResponding = 15,

	/// <summary>
	/// Wrong I2C answer.
	/// </summary>
	PTCCommunicationStatusCode_WrongI2CAnswer = 16,

	/// <summary>
	/// Wrong CRC result.
	/// </summary>
	PTCCommunicationStatusCode_WrongCRCResult = 17,

	/// <summary>
	/// Laser disabled.
	/// </summary>
	PTCCommunicationStatusCode_LaserDisabled = 18,

	/// <summary>
	/// Flash device mismatch.
	/// </summary>
	PTCCommunicationStatusCode_FlashDeviceMismatch = 19,

	/// <summary>
	/// Flash write failed.
	/// </summary>
	PTCCommunicationStatusCode_FlashWriteFailed = 20,

	/// <summary>
	/// Sensor limit reached.
	/// </summary>
	PTCCommunicationStatusCode_SensorLimitReached = 21,

	/// <summary>
	/// Not enough memory.
	/// </summary>
	PTCCommunicationStatusCode_NotEnoughMemory = 22,

	/// <summary>
	/// Content mismatch.
	/// </summary>
	PTCCommunicationStatusCode_ContentMismatch = 23,

	/// <summary>
	/// Execution failed.
	/// </summary>
	PTCCommunicationStatusCode_ExecutionFailed = 24,

	/// <summary>
	/// Write-Lock failed. A write lock is needed to perform set commands on this device.
	/// </summary>
	PTCCommunicationStatusCode_WriteLockFailed = 25,

	/// <summary>
	/// No permission.
	/// </summary>
	PTCCommunicationStatusCode_NoPermission = 26,

	/// <summary>
	/// Invalid configuration.
	/// </summary>
	PTCCommunicationStatusCode_InvalidConfiguration = 27,



	/// <summary>
	/// Unknown software error: An unknown error occurred in the interface software.
	/// </summary>
	PTCCommunicationStatusCode_UnknownError = 2000,
	/// <summary>
	/// Logic error.
	/// </summary>
	PTCCommunicationStatusCode_LogicError = 2001,
	/// <summary>
	/// Invalid argument.
	/// </summary>
	PTCCommunicationStatusCode_InvalidArgument = 2002,
	/// <summary>
	/// Range error.
	/// </summary>
	PTCCommunicationStatusCode_RangeError = 2003,
	/// <summary>
	/// System error.
	/// </summary>
	PTCCommunicationStatusCode_SystemError = 2004,
	/// <summary>
	/// Bad cast.
	/// </summary>
	PTCCommunicationStatusCode_BadCast = 2005,
	/// <summary>
	/// Bad alloc: Failed to allocate memory storage.
	/// </summary>
	PTCCommunicationStatusCode_BadAlloc = 2006,
	/// <summary>
	/// Buffer overflow.
	/// </summary>
	PTCCommunicationStatusCode_BufferOverflow = 2007,
	/// <summary>
	/// Timeout: The device is not responding within the timeout. A command was sent to the device but
	/// it is not responding.
	/// </summary>
	PTCCommunicationStatusCode_Timeout = 2008,
	/// <summary>
	/// Invalid response format: The device sent a response with an invalid format.
	/// </summary>
	PTCCommunicationStatusCode_InvalidResponseFormat = 2009,
	/// <summary>
	/// Received wrong payload type: The received payload type from a Get/GetDevInfo/GetValueList-command
	/// does not match the expected payload type.
	/// </summary>
	PTCCommunicationStatusCode_ReceivedWrongPayloadType = 2010,
	/// <summary>
	/// Runtime error.
	/// </summary>
	PTCCommunicationStatusCode_RuntimeError = 2011

} PTCCommunicationStatusCode;

