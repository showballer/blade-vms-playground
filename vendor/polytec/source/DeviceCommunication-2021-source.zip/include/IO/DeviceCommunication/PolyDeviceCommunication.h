// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

/// \file
/// \brief	Main header for the Device Communication C interface

#pragma once

#include "PTCDeviceCommand.h"
#include "PTCDeviceType.h"
#include "PTCMiscellaneousTag.h"
#include "PTCCommunicationStatusCode.h"


#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>

// The macro COMMAPI is used on Windows to export symbols when a DLL is build and to import symbols
// when the DLL is used. In order to build the DLL on Windows, EXPORT_COMMAPI needs to be defined.
#ifdef _WIN32
#	ifdef BUILD_COMMAPI
#		define COMMAPI __declspec(dllexport)
#	else
#		define COMMAPI __declspec(dllimport)
#	endif
#else
#	define COMMAPI
#endif

#ifdef __cplusplus
extern "C" {
	#endif

	/// <summary>A communication handle is created by opening a communication to a device.
	/// 		 It can be used to send commands to the device.</summary>
	/// <remarks>Valid handles are positive numbers. Null is an invalid handle</remarks>
	typedef int PTCommunicationHandle;

	/// <summary>A payload handle is a reference to a data array. It can be used to send data
	/// 		 to a device or to receive data from a device.</summary>
	/// <remarks>Valid handles are positive numbers. Null is an invalid handle</remarks>
	typedef int PTPayloadHandle;
	
	/// <summary>
	/// Gets the status message from the last API call. It may contain further information in case of
	/// a failure.
	/// </summary>
	/// <param name="message">[out] The status message.</param>
	/// <param name="bufferSize">The size of the message string buffer.</param>
	COMMAPI void PolyLastCommunicationStatus(char* message, size_t bufferSize);

	/// <summary>Opens a UDP ethernet communication. A command is sent to the device to verify that the
	/// 		 communication is established. If this was successful the handle is set to a value greater than null.
	/// 		 This handle can be used to send commands to the device, e.g. with PolySendGet. To free resources
	/// 		 call PolyCloseCommunication when the communication is no longer needed.</summary>
	/// <param name="communicationHandle">[out] The communication handle. It is set to null on failure.</param>
	/// <param name="ipAddress">The hostname or the IP of the device, e.g. 192.168.104.xx.</param>
	/// <param name="timeoutInMilliseconds">The timeout in milliseconds. It specifies the duration in which
	/// 									a response of the device is expected. The timeout is used for both
	/// 									the creation of the communication as for the later use of
	/// 									the communication.</param>
	/// <returns>Returns a status code, e.g. PTCCommunicationStatusCode_Success on succes.</returns>
	COMMAPI PTCCommunicationStatusCode PolyOpenUdpEthernetCommunication(PTCommunicationHandle* communicationHandle,
		const char* ipAddress, int timeoutInMilliseconds);

	/// <summary>Opens a TCP ethernet communication. A command is sent to the device to verify that the
	/// 		 communication is established. If this was successful the handle is set to a value greater than null.
	/// 		 This handle can be used to send commands to the device, e.g. with PolySendGet. To free resources
	/// 		 call PolyCloseCommunication when the communication is no longer needed.</summary>
	/// <param name="communicationHandle">[out] The communication handle. It is set to null on failure.</param>
	/// <param name="ipAddress">The hostname or the IP of the device, e.g. 192.168.104.xx.</param>
	/// <param name="timeoutInMilliseconds">The timeout in milliseconds. It specifies the duration in which
	/// 									a response of the device is expected. The timeout is used for both
	/// 									the creation of the communication as for the later use of
	/// 									the communication.</param>
	/// <returns>Returns a status code, e.g. PTCCommunicationStatusCode_Success on succes.</returns>
	COMMAPI PTCCommunicationStatusCode PolyOpenTcpEthernetCommunication(PTCommunicationHandle* communicationHandle,
		const char* ipAddress, int timeoutInMilliseconds);

	/// <summary>Opens a serial communication. A command is sent to the device to verify that the
	/// 		 communication is established. If this is successful the handle is set to a value greater than null.
	/// 		 This handle can be used to send commands to the device, with e.g. PolySendGet. To free resources
	/// 		 call PolyCloseCommunication when the communication is no longer needed.</summary>
	/// <param name="communicationHandle">[out] The communication handle. It is set to null on failure.</param>
	/// <param name="comPort">The COM port of the serial communication, e.g. COM1 on Windows or /dev/tty0 on Unix</param>
	/// <param name="baudRate">The baud rate of the serial communication, e.g. 115200 or 9600.</param>
	/// <param name="timeoutInMilliseconds">The timeout in milliseconds. It specifies the duration in which
	/// 									a response of the device is expected. The timeout is used for both
	/// 									the creation of the communication as for the later use of
	/// 									the communication.</param>
	/// <returns>Returns a status code, e.g. PTCCommunicationStatusCode_Success on succes.</returns>
	COMMAPI PTCCommunicationStatusCode PolyOpenSerialCommunication(PTCommunicationHandle* communicationHandle,
		const char* comPort, int baudRate, int timeoutInMilliseconds);

	/// <summary>Closes the communication to the corresponding handle. This releases the resources used
	/// 		 by the communication.</summary>
	/// <param name="communicationHandle">The communication handle. The handle is no longer valid and could
	/// 								  be reused by an other communication.</param>
	COMMAPI void PolyCloseCommunication(PTCommunicationHandle communicationHandle);

	// ----
	// The following methods offer higher level control for the most common uses. For full control see the lower level methods section.
	// ----

	/// <summary>Sends a GetValueList-command to the device to get all items of an item list (e.g. range for velocity and displacement decoder).
	/// 		 Returns all valid values (currently available and not). Use PolyItemListIsItemAvailable or PolyItemListGetAvailableItems
	/// 		 to find out if a value is currently available or not.
	/// 		 See the documentation in PTCDeviceCommand.h for further information.</summary>
	/// <remarks>An item list models a command like Range, that returns a comma separated list ("2 m/s,1 m/s,...") for GetValueList,
	/// 		 all available indices for GetDevInfo and reads/writes the current index for Get/Set commands.</remarks>
	/// <param name="communicationHandle">The communication handle.</param>
	/// <param name="deviceType">The device type, e.g. PTCDeviceType_VelocityDecoderDigital.</param>
	/// <param name="deviceNumber">The device number, e.g. 0.</param>
	/// <param name="deviceCommand">The device command, e.g. PTCDeviceCommand_Range.</param>
	/// <param name="buffer">[out] Char buffer to be filled with the item list items as comma separated list.</param>
	/// <param name="bufferSize">Size of the char buffer in bytes.</param>
	/// <returns>Returns a status code, e.g. PTCCommunicationStatusCode_Success on success.</returns>
	COMMAPI PTCCommunicationStatusCode PolyItemListGetAllItems(PTCommunicationHandle communicationHandle,
		PTCDeviceType deviceType, int deviceNumber, PTCDeviceCommand deviceCommand, char* buffer, size_t bufferSize);

	/// <summary>Sends a GetDevInfo-command to the device to get all available items of an item list (e.g. range for velocity and displacement decoder).
	/// 		 See the documentation in PTCDeviceCommand.h for further information.</summary>
	/// <remarks>An item list models a command like Range, that returns a comma separated list ("2 m/s,1 m/s,...") for GetValueList,
	/// 		 all available indices for GetDevInfo and reads/writes the current index for Get/Set commands.</remarks>
	/// <param name="communicationHandle">The communication handle.</param>
	/// <param name="deviceType">The device type, e.g. PTCDeviceType_VelocityDecoderDigital.</param>
	/// <param name="deviceNumber">The device number, e.g. 0.</param>
	/// <param name="deviceCommand">The device command, e.g. PTCDeviceCommand_Range.</param>
	/// <param name="buffer">[out] Char buffer to be filled with the item list items as comma separated list.</param>
	/// <param name="bufferSize">Size of the char buffer in bytes.</param>
	/// <returns>Returns a status code, e.g. PTCCommunicationStatusCode_Success on success.</returns>
	COMMAPI PTCCommunicationStatusCode PolyItemListGetAvailableItems(PTCommunicationHandle communicationHandle,
		PTCDeviceType deviceType, int deviceNumber, PTCDeviceCommand deviceCommand, char* buffer, size_t bufferSize);

	/// <summary>Sends a Get-command to the device to get the current item from an item list (e.g. range for velocity and displacement decoder)
	/// 		 See the documentation in PTCDeviceCommand.h for further information.</summary>
	/// <remarks>An item list models a command like Range, that returns a comma separated list ("2 m/s,1 m/s,...") for GetValueList,
	/// 		 all available indices for GetDevInfo and reads/writes the current index for Get/Set commands.</remarks>
	/// <param name="communicationHandle">The communication handle.</param>
	/// <param name="deviceType">The device type, e.g. PTCDeviceType_VelocityDecoderDigital.</param>
	/// <param name="deviceNumber">The device number, e.g. 0.</param>
	/// <param name="deviceCommand">The device command, e.g. PTCDeviceCommand_Range.</param>
	/// <param name="buffer">[out] Char buffer to be filled with the current item of the item list.</param>
	/// <param name="bufferSize">Size of the char buffer in bytes.</param>
	/// <returns>Returns a status code, e.g. PTCCommunicationStatusCode_Success on success.</returns>
	COMMAPI PTCCommunicationStatusCode PolyItemListGetCurrentItem(PTCommunicationHandle communicationHandle,
		PTCDeviceType deviceType, int deviceNumber, PTCDeviceCommand deviceCommand, char* buffer, size_t bufferSize);

	/// <summary>Sends a Set-command to set the current item of an item list (e.g. range for velocity and displacement decoder)
	/// 		 See the documentation in PTCDeviceCommand.h for further information.</summary>
	/// <remarks>An item list models a command like Range, that returns a comma separated list ("2 m/s,1 m/s,...") for GetValueList,
	/// 		 all available indices for GetDevInfo and reads/writes the current index for Get/Set commands.</remarks>
	/// <param name="communicationHandle">The communication handle.</param>
	/// <param name="deviceType">The device type, e.g. PTCDeviceType_VelocityDecoderDigital.</param>
	/// <param name="deviceNumber">The device number, e.g. 0.</param>
	/// <param name="deviceCommand">The device command, e.g. PTCDeviceCommand_Range.</param>
	/// <param name="item">The item list item to be set.</param>
	/// <returns>Returns a status code, e.g. PTCCommunicationStatusCode_Success on success.</returns>
	COMMAPI PTCCommunicationStatusCode PolyItemListSetCurrentItem(PTCommunicationHandle communicationHandle,
		PTCDeviceType deviceType, int deviceNumber, PTCDeviceCommand deviceCommand, const char* item);

	/// <summary>Checks if an item list item is currently available to be set.
	/// 		 See the documentation in PTCDeviceCommand.h for further information.</summary>
	/// <remarks>An item list models a command like Range, that returns a comma separated list ("2 m/s,1 m/s,...") for GetValueList,
	/// 		 all available indices for GetDevInfo and reads/writes the current index for Get/Set commands.</remarks>
	/// <param name="communicationHandle">The communication handle.</param>
	/// <param name="deviceType">The device type, e.g. PTCDeviceType_VelocityDecoderDigital.</param>
	/// <param name="deviceNumber">The device number, e.g. 0.</param>
	/// <param name="deviceCommand">The device command, e.g. PTCDeviceCommand_Range.</param>
	/// <param name="item">The item list item to check.</param>
	/// <param name="result">[out] The result, true if available.</param>
	/// <returns>Returns a status code, e.g. PTCCommunicationStatusCode_Success on success.</returns>
	COMMAPI PTCCommunicationStatusCode PolyItemListIsItemAvailable(PTCommunicationHandle communicationHandle,
		PTCDeviceType deviceType, int deviceNumber, PTCDeviceCommand deviceCommand, const char* item, bool* result);

	/// <summary>Sends a Get-command to get a float value from a device (e.g. temperature).
	/// 		 See the documentation in PTCDeviceCommand.h for further information.</summary>
	/// <param name="communicationHandle">The communication handle.</param>
	/// <param name="deviceType">The device type, e.g. PTCDeviceType_Controller.</param>
	/// <param name="deviceNumber">The device number, e.g. 0.</param>
	/// <param name="deviceCommand">The device command, e.g. PTCDeviceCommand_Temperature.</param>
	/// <param name="payload">[out] The value received from the device.</param>
	/// <returns>Returns a status code, e.g. PTCCommunicationStatusCode_Success on success.</returns>
	COMMAPI PTCCommunicationStatusCode PolySendGetFloat(PTCommunicationHandle communicationHandle,
		PTCDeviceType deviceType, int deviceNumber, PTCDeviceCommand deviceCommand, float* payload);

	/// <summary>Sends a Set-command to set a float value on a device (e.g. data acquisition analog trigger level).
	/// 		 See the documentation in PTCDeviceCommand.h for further information.</summary>
	/// <param name="communicationHandle">The communication handle.</param>
	/// <param name="deviceType">The device type, e.g. PTCDeviceType_SignalProcessing.</param>
	/// <param name="deviceNumber">The device number, e.g. 0.</param>
	/// <param name="deviceCommand">The device command, e.g. PTCDeviceCommand_DaqAnalogTriggerLevel.</param>
	/// <param name="payload">The value to be set on the device.</param>
	/// <returns>Returns a status code, e.g. PTCCommunicationStatusCode_Success on success.</returns>
	COMMAPI PTCCommunicationStatusCode PolySendSetFloat(PTCommunicationHandle communicationHandle,
		PTCDeviceType deviceType, int deviceNumber, PTCDeviceCommand deviceCommand, float payload);

	/// <summary>Sends a Get-command to get a 16 bit int value from a device (e.g. laser on).
	/// 		 See the documentation in PTCDeviceCommand.h for further information.</summary>
	/// <param name="communicationHandle">The communication handle.</param>
	/// <param name="deviceType">The device type, e.g. PTCDeviceType_SensorHead.</param>
	/// <param name="deviceNumber">The device number, e.g. 0.</param>
	/// <param name="deviceCommand">The device command, e.g. PTCDeviceCommand_LaserOn.</param>
	/// <param name="payload">[out] The value received from the device.</param>
	/// <returns>Returns a status code, e.g. PTCCommunicationStatusCode_Success on success.</returns>
	COMMAPI PTCCommunicationStatusCode PolySendGetInt16(PTCommunicationHandle communicationHandle,
		PTCDeviceType deviceType, int deviceNumber, PTCDeviceCommand deviceCommand, int16_t* payload);

	/// <summary>Sends a Set-command to set a 16 bit int value on a device (e.g. laser on).
	/// 		 See the documentation in PTCDeviceCommand.h for further information.</summary>
	/// <param name="communicationHandle">The communication handle.</param>
	/// <param name="deviceType">The device type, e.g. PTCDeviceType_SensorHead.</param>
	/// <param name="deviceNumber">The device number, e.g. 0.</param>
	/// <param name="deviceCommand">The device command, e.g. PTCDeviceCommand_LaserOn.</param>
	/// <param name="payload">The value to be set on the device.</param>
	/// <returns>Returns a status code, e.g. PTCCommunicationStatusCode_Success on success.</returns>
	COMMAPI PTCCommunicationStatusCode PolySendSetInt16(PTCommunicationHandle communicationHandle,
		PTCDeviceType deviceType, int deviceNumber, PTCDeviceCommand deviceCommand, int16_t payload);

	/// <summary>Sends a Get-command to get a 32 bit int value from a device (e.g. data acquisition pre/post trigger).
	/// 		 See the documentation in PTCDeviceCommand.h for further information.</summary>
	/// <param name="communicationHandle">The communication handle.</param>
	/// <param name="deviceType">The device type, e.g. PTCDeviceType_SignalProcessing.</param>
	/// <param name="deviceNumber">The device number, e.g. 0.</param>
	/// <param name="deviceCommand">The device command, e.g. PTCDeviceCommand_DaqPreTrigger.</param>
	/// <param name="payload">[out] The value received from the device.</param>
	/// <returns>Returns a status code, e.g. PTCCommunicationStatusCode_Success on success.</returns>
	COMMAPI PTCCommunicationStatusCode PolySendGetInt32(PTCommunicationHandle communicationHandle,
		PTCDeviceType deviceType, int deviceNumber, PTCDeviceCommand deviceCommand, int32_t* payload);

	/// <summary>Sends a Set-command to set a 32 bit int value on a device (e.g. data acquisition pre/post trigger).
	/// 		 See the documentation in PTCDeviceCommand.h for further information.</summary>
	/// <param name="communicationHandle">The communication handle.</param>
	/// <param name="deviceType">The device type, e.g. PTCDeviceType_SignalProcessing.</param>
	/// <param name="deviceNumber">The device number, e.g. 0.</param>
	/// <param name="deviceCommand">The device command, e.g. PTCDeviceCommand_DaqPreTrigger.</param>
	/// <param name="payload">The value to be set on the device.</param>
	/// <returns>Returns a status code, e.g. PTCCommunicationStatusCode_Success on success.</returns>
	COMMAPI PTCCommunicationStatusCode PolySendSetInt32(PTCommunicationHandle communicationHandle,
		PTCDeviceType deviceType, int deviceNumber, PTCDeviceCommand deviceCommand, int32_t payload);

	/// <summary>Sends a Get-command to get a string value from a device (e.g. access point password).
	/// 		 See the documentation in PTCDeviceCommand.h for further information.</summary>
	/// <param name="communicationHandle">The communication handle.</param>
	/// <param name="deviceType">The device type, e.g. PTCDeviceType_Controller.</param>
	/// <param name="deviceNumber">The device number, e.g. 0.</param>
	/// <param name="deviceCommand">The device command, e.g. PTCDeviceCommand_AccessPointPassword.</param>
	/// <param name="payload">[out] The value received from the device.</param>
	/// <param name="bufferSize">Size of the payload output buffer.</param>
	/// <returns>Returns a status code, e.g. PTCCommunicationStatusCode_Success on success.</returns>
	COMMAPI PTCCommunicationStatusCode PolySendGetString(PTCommunicationHandle communicationHandle,
		PTCDeviceType deviceType, int deviceNumber, PTCDeviceCommand deviceCommand, char* payload, size_t bufferSize);

	/// <summary>Sends a Set-command to set a string value on a device (e.g. access point password).
	/// 		 See the documentation in PTCDeviceCommand.h for further information.</summary>
	/// <param name="communicationHandle">The communication handle.</param>
	/// <param name="deviceType">The device type, e.g. PTCDeviceType_Controller.</param>
	/// <param name="deviceNumber">The device number, e.g. 0.</param>
	/// <param name="deviceCommand">The device command, e.g. PTCDeviceCommand_AccessPointPassword.</param>
	/// <param name="payload">The value to be set on the device.</param>
	/// <returns>Returns a status code, e.g. PTCCommunicationStatusCode_Success on success.</returns>
	COMMAPI PTCCommunicationStatusCode PolySendSetString(PTCommunicationHandle communicationHandle,
		PTCDeviceType deviceType, int deviceNumber, PTCDeviceCommand deviceCommand, const char* payload);

	/// <summary>Sends a GetDevInfo-command to get the range of a 16 bit int value from a device
	/// 		 (e.g. sensor head focus position).
	/// 		 See the documentation in PTCDeviceCommand.h for further information.</summary>
	/// <param name="communicationHandle">The communication handle.</param>
	/// <param name="deviceType">The device type, e.g. PTCDeviceType_SensorHead.</param>
	/// <param name="deviceNumber">The device number, e.g. 0.</param>
	/// <param name="deviceCommand">The device command, e.g. PTCDeviceCommand_FocusPosition.</param>
	/// <param name="minimum">[out] The minimum value.</param>
	/// <param name="maximum">[out] The maximum value.</param>
	/// <returns>Returns a status code, e.g. PTCCommunicationStatusCode_Success on success.</returns>
	COMMAPI PTCCommunicationStatusCode PolySendGetDevInfoRange(PTCommunicationHandle communicationHandle,
		PTCDeviceType deviceType, int deviceNumber, PTCDeviceCommand deviceCommand, int16_t* minimum, int16_t* maximum);

	/// <summary>Check if a device is available (e.g. sensor head nr. 0).</summary>
	/// <param name="communicationHandle">The communication handle.</param>
	/// <param name="deviceType">The device type, e.g. PTCDeviceType_SensorHead.</param>
	/// <param name="deviceNumber">The device number, e.g. 0.</param>
	/// <param name="result">[out] The result, true if available.</param>
	/// <returns>Returns a status code, e.g. PTCCommunicationStatusCode_Success on success.</returns>
	COMMAPI PTCCommunicationStatusCode PolyHasDevice(PTCommunicationHandle communicationHandle,
		PTCDeviceType deviceType, int deviceNumber, bool* result);

	/// <summary>Check if a device command is available (e.g. data acquisition block count).</summary>
	/// <param name="communicationHandle">The communication handle.</param>
	/// <param name="deviceType">The device type, e.g. PTCDeviceType_Controller.</param>
	/// <param name="deviceNumber">The device number, e.g. 0.</param>
	/// <param name="deviceCommand">The device command, e.g. PTCDeviceCommand_DaqBlockCount.</param>
	/// <param name="result">[out] The result, true if available.</param>
	/// <returns>Returns a status code, e.g. PTCCommunicationStatusCode_Success on success.</returns>
	COMMAPI PTCCommunicationStatusCode PolyHasCommand(PTCommunicationHandle communicationHandle,
		PTCDeviceType deviceType, int deviceNumber, PTCDeviceCommand deviceCommand, bool* result);

	// ----
	// The following methods offer lower level control. See the higher level methods section for an abstraction that may be sufficient for most uses.
	// ----

	/// <summary>Sends a Get-command to the device. A Get-command is used to get information about a current
	/// 		 or static state of the device, e.g. the current focus position or the name of the device.
	/// 		 See the documentation in PTCDeviceCommand.h for further information.</summary>
	/// <param name="communicationHandle">The communication handle.</param>
	/// <param name="deviceType">The device type, e.g. PTCDeviceType_VelocityDecoderDigital.</param>
	/// <param name="deviceNumber">The device number, e.g. 0.</param>
	/// <param name="deviceCommand">The device command, e.g. PTCDeviceCommand_Range.</param>
	/// <param name="receivedPayload">[out] The handle for the received payload. The payload handle is created
	/// 							  when this function is called. To get the actual payload data use the
	/// 							  PolyGetXXXFromPayload functions.
	/// 							  The received payload may be e.g. the index of the current velocity range.</param>
	/// <returns>Returns a status code, e.g. PTCCommunicationStatusCode_Success on success.</returns>
	/// <remarks>This function creates a payload handle. Call PolyFreePayload when this handle is not longer used.</remarks>
	COMMAPI PTCCommunicationStatusCode PolySendGet(PTCommunicationHandle communicationHandle,
		PTCDeviceType deviceType, int deviceNumber, PTCDeviceCommand deviceCommand, PTPayloadHandle* receivedPayload);

	/// <summary>Sends a GetDevInfo-command to the device. A GetDevInfo-command is used to get certain additional
	/// 		 information for a given device command e.g. the currently available velocity ranges
	/// 		 See the documentation in PTCDeviceCommand.h for further information.</summary>
	/// <param name="communicationHandle">The communication handle.</param>
	/// <param name="deviceType">The device type, e.g. PTCDeviceType_VelocityDecoderDigital.</param>
	/// <param name="deviceNumber">The device number, e.g. 0.</param>
	/// <param name="deviceCommand">The device command, e.g. PTCDeviceCommand_Range.</param>
	/// <param name="receivedPayload">[out] The handle for the received payload. The payload handle is created
	/// 							  when this function is called. To get the actual payload data use the
	/// 							  PolyGetXXXFromPayload functions.
	/// 							  The received payload may be e.g. the currently available velocity
	/// 							  ranges as list.</param>
	/// <returns>Returns a status code, e.g. PTCCommunicationStatusCode_Success on success.</returns>
	/// <remarks>This function creates a payload handle. Call PolyFreePayload when this handle is not longer used.</remarks>
	COMMAPI PTCCommunicationStatusCode PolySendGetDevInfo(PTCommunicationHandle communicationHandle,
		PTCDeviceType deviceType, int deviceNumber, PTCDeviceCommand deviceCommand, PTPayloadHandle* receivedPayload);

	/// <summary>Sends a GetValueList-command to the device. A GetValueList-command is used to get certain additional
	/// 		 information for a given device command e.g. all available velocity ranges as string
	/// 		 See the documentation in PTCDeviceCommand.h for further information.</summary>
	/// <param name="communicationHandle">The communication handle.</param>
	/// <param name="deviceType">The device type, e.g. PTCDeviceType_VelocityDecoderDigital.</param>
	/// <param name="deviceNumber">The device number, e.g. 0.</param>
	/// <param name="deviceCommand">The device command, e.g. PTCDeviceCommand_Range.</param>
	/// <param name="receivedPayload">[out] The handle for the received payload. The payload handle is created
	/// 							  when this function is called. To get the actual payload data use the
	/// 							  PolyGetXXXFromPayload functions.
	/// 							  The received payload may be e.g. all available velocity ranges as string.</param>
	/// <returns>Returns a status code, e.g. PTCCommunicationStatusCode_Success on success.</returns>
	/// <remarks>This function creates a payload handle. Call PolyFreePayload when this handle is not longer used.</remarks>
	COMMAPI PTCCommunicationStatusCode PolySendGetValueList(PTCommunicationHandle communicationHandle,
		PTCDeviceType deviceType, int deviceNumber, PTCDeviceCommand deviceCommand, PTPayloadHandle* receivedPayload);

	/// <summary>Sends a Set-command to the device. A Set-command is used to control the state
	/// 		 of a given device e.g. set the velocity range
	/// 		 See the documentation in PTCDeviceCommand.h for further information.</summary>
	/// <param name="communicationHandle">The communication handle.</param>
	/// <param name="deviceType">The device type, e.g. PTCDeviceType_VelocityDecoderDigital.</param>
	/// <param name="deviceNumber">The device number, e.g. 0.</param>
	/// <param name="deviceCommand">The device command, e.g. PTCDeviceCommand_Range.</param>
	/// <param name="sentPayload">The handle to the sent payload. The handle has to be created before this
	/// 						  function is called. The sent payload may be e.g. the index of the velocity range</param>
	/// <returns>Returns a status code, e.g. PTCCommunicationStatusCode_Success on success.</returns>
	COMMAPI PTCCommunicationStatusCode PolySendSet(PTCommunicationHandle communicationHandle,
		PTCDeviceType deviceType, int deviceNumber, PTCDeviceCommand deviceCommand, PTPayloadHandle sentPayload);

	/// <summary>Sends a Get-command to the device. A Get-command is used to get information about a current
	/// 		 or static state of the device.
	/// 		 See the documentation in PTCDeviceCommand.h for further information.</summary>
	/// <param name="communicationHandle">The communication handle.</param>
	/// <param name="deviceType">The device type.</param>
	/// <param name="deviceNumber">The device number.</param>
	/// <param name="deviceCommand">The device command.</param>
	/// <param name="tag">The tag, e.g. PTCMiscellaneousTag_Param0.</param>
	/// <param name="receivedPayload">[out] The handle for the received payload. The payload handle is created
	/// 							  when this function is called. To get the actual payload data use the
	/// 							  PolyGetXXXFromPayload functions.</param>
	/// <returns>Returns a status code, e.g. PTCCommunicationStatusCode_Success on success.</returns>
	/// <remarks>This function creates a payload handle. Call PolyFreePayload when this handle is not longer used.</remarks>
	COMMAPI PTCCommunicationStatusCode PolySendGetWithTag(PTCommunicationHandle communicationHandle,
		PTCDeviceType deviceType, int deviceNumber, PTCDeviceCommand deviceCommand, PTCMiscellaneousTag tag,
		PTPayloadHandle* receivedPayload);

	/// <summary>Sends a GetDevInfo-command to the device. A GetDevInfo-command is used to get certain additional
	/// 		 information for a given device command.
	/// 		 See the documentation in PTCDeviceCommand.h for further information.</summary>
	/// <param name="communicationHandle">The communication handle.</param>
	/// <param name="deviceType">The device type.</param>
	/// <param name="deviceNumber">The device number.</param>
	/// <param name="deviceCommand">The device command.</param>
	/// <param name="tag">The tag, e.g. PTCMiscellaneousTag_Param0.</param>
	/// <param name="receivedPayload">[out] The handle for the received payload. The payload handle is created
	/// 							  when this function is called. To get the actual payload data use the
	/// 							  PolyGetXXXFromPayload functions.</param>
	/// <returns>Returns a status code, e.g. PTCCommunicationStatusCode_Success on success.</returns>
	/// <remarks>This function creates a payload handle. Call PolyFreePayload when this handle is not longer used.</remarks>
	COMMAPI PTCCommunicationStatusCode PolySendGetDevInfoWithTag(PTCommunicationHandle communicationHandle,
		PTCDeviceType deviceType, int deviceNumber, PTCDeviceCommand deviceCommand, PTCMiscellaneousTag tag,
		PTPayloadHandle* receivedPayload);

	/// <summary>Sends a GetValueList-command to the device. A GetValueList-command is used to get certain additional
	/// 		 information for a given device command.
	/// 		 See the documentation in PTCDeviceCommand.h for further information.</summary>
	/// <param name="communicationHandle">The communication handle.</param>
	/// <param name="deviceType">The device type.</param>
	/// <param name="deviceNumber">The device number.</param>
	/// <param name="deviceCommand">The device command.</param>
	/// <param name="receivedPayload">[out] The handle for the received payload. The payload handle is created
	/// 							  when this function is called. To get the actual payload data use the
	/// 							  PolyGetXXXFromPayload functions.</param>
	/// <param name="tag">The tag, e.g. PTCMiscellaneousTag_Param0.</param>
	/// <returns>Returns a status code, e.g. PTCCommunicationStatusCode_Success on success.</returns>
	/// <remarks>This function creates a payload handle. Call PolyFreePayload when this handle is not longer used.</remarks>
	COMMAPI PTCCommunicationStatusCode PolySendGetValueListWithTag(PTCommunicationHandle communicationHandle,
		PTCDeviceType deviceType, int deviceNumber, PTCDeviceCommand deviceCommand, PTCMiscellaneousTag tag,
		PTPayloadHandle* receivedPayload);

	/// <summary>Sends a Set-command to the device. A Set-command is used to control the state
	/// 		 of a given device.
	/// 		 See the documentation in PTCDeviceCommand.h for further information.</summary>
	/// <param name="communicationHandle">The communication handle.</param>
	/// <param name="deviceType">The device type.</param>
	/// <param name="deviceNumber">The device number.</param>
	/// <param name="deviceCommand">The device command.</param>
	/// <param name="sentPayload">The handle to the sent payload. The handle has to be created before this
	/// 						  function is called.</param>
	/// <param name="tag">The tag, e.g. PTCMiscellaneousTag_Param0.</param>
	/// <returns>Returns a status code, e.g. PTCCommunicationStatusCode_Success on success.</returns>
	COMMAPI PTCCommunicationStatusCode PolySendSetWithTag(PTCommunicationHandle communicationHandle,
		PTCDeviceType deviceType, int deviceNumber, PTCDeviceCommand deviceCommand, PTCMiscellaneousTag tag,
		PTPayloadHandle sentPayload);

	/// <summary>Frees the given payload handle. Use this function when a handle is no longer needed.
	/// 		 Payloads are created by the PolyCreatePayloadFromXXX functions and from the PolySendGetXXX
	/// 		 functions.</summary>
	/// <param name="payloadHandle">The payload handle.</param>
	COMMAPI void PolyFreePayload(PTPayloadHandle payloadHandle);

	/// <summary>Creates a payload handle for a string. The payload can be used to send data</summary>
	/// <param name="payloadData">The payload data as a null-terminated string</param>
	/// <returns>The payload handle. Use PolyFreePayloadHandle to free the handle when it is no longer used.</returns>
	COMMAPI PTPayloadHandle PolyCreatePayloadFromCStr(const char* payloadData);

	/// <summary>Creates a payload handle for an uint8_t. The payload can be used to send data</summary>
	/// <param name="payloadData">The payload data</param>
	/// <param name="size">The payload size</param>
	/// <returns>The payload handle. Use PolyFreePayload to free the handle when it is no longer used.</returns>
	COMMAPI PTPayloadHandle PolyCreatePayloadFromUInt8(const uint8_t* payloadData, size_t size);

	/// <summary>Creates a payload handle for an int16_t. The payload can be used to send data</summary>
	/// <param name="payloadData">The payload data</param>
	/// <param name="size">The payload size</param>
	/// <returns>The payload handle. Use PolyFreePayload to free the handle when it is no longer used.</returns>
	COMMAPI PTPayloadHandle PolyCreatePayloadFromInt16(const int16_t* payloadData, size_t size);

	/// <summary>Creates a payload handle for an uint16_t. The payload can be used to send data</summary>
	/// <param name="payloadData">The payload data</param>
	/// <param name="size">The payload size</param>
	/// <returns>The payload handle. Use PolyFreePayload to free the handle when it is no longer used.</returns>
	COMMAPI PTPayloadHandle PolyCreatePayloadFromUInt16(const uint16_t* payloadData, size_t size);

	/// <summary>Creates a payload handle for an int32_t. The payload can be used to send data</summary>
	/// <param name="payloadData">The payload data</param>
	/// <param name="size">The payload size</param>
	/// <returns>The payload handle. Use PolyFreePayload to free the handle when it is no longer used.</returns>
	COMMAPI PTPayloadHandle PolyCreatePayloadFromInt32(const int32_t* payloadData, size_t size);

	/// <summary>Creates a payload handle for an uint32_t. The payload can be used to send data</summary>
	/// <param name="payloadData">The payload data</param>
	/// <param name="size">The payload size</param>
	/// <returns>The payload handle. Use PolyFreePayload to free the handle when it is no longer used.</returns>
	COMMAPI PTPayloadHandle PolyCreatePayloadFromUInt32(const uint32_t* payloadData, size_t size);

	/// <summary>Creates a payload handle for a float. The payload can be used to send data</summary>
	/// <param name="payloadData">The payload data</param>
	/// <param name="size">The payload size</param>
	/// <returns>The payload handle. Use PolyFreePayload to free the handle when it is no longer used.</returns>
	COMMAPI PTPayloadHandle PolyCreatePayloadFromFloat(const float* payloadData, size_t size);

	/// <summary>Creates a payload handle for a double. The payload can be used to send data</summary>
	/// <param name="payloadData">The payload data</param>
	/// <param name="size">The payload size</param>
	/// <returns>The payload handle. Use PolyFreePayload to free the handle when it is no longer used.</returns>
	COMMAPI PTPayloadHandle PolyCreatePayloadFromDouble(const double* payloadData, size_t size);

	/// <summary>Gets a string from a payload handle.</summary>
	/// <param name="payloadHandle">The payload handle.</param>
	/// <param name="payloadBuffer">[out] The payload buffer. The string is copied to this buffer. If
	/// 							the payload types of the payload handle and the buffer don't match,
	/// 							the function fails.</param>
	/// <param name="bufferSize">Size of the buffer. If the payload size exceeds the buffer size, the
	/// 						 function fails.</param>
	/// <returns>The status code. Indicates if the function was successful or if an error occurred.</returns>
	COMMAPI PTCCommunicationStatusCode PolyGetCStrFromPayload(PTPayloadHandle payloadHandle,
		char* payloadBuffer, size_t bufferSize);

	/// <summary>Gets uint8_t data from a payload handle.</summary>
	/// <param name="payloadHandle">The payload handle.</param>
	/// <param name="payloadBuffer">[out] The payload buffer. The payload data is copied to this buffer. If
	/// 							the payload types of the payload and the buffer don't match,
	/// 							the function fails.</param>
	/// <param name="payloadSize">[out] Size of the payload data. If the payload size exceeds the buffer size
	/// 						  the function fails, i.e. no data is copied and the return status code
	/// 						  is payload buffer overflow. The payload size is in any case set
	/// 						  to the payload size.</param>
	/// <param name="bufferSize">Size of the payload buffer.</param>
	/// <returns>The status code. Indicates if the function was successful or if an error occurred.</returns>
	COMMAPI PTCCommunicationStatusCode PolyGetUInt8FromPayload(PTPayloadHandle payloadHandle,
		uint8_t* payloadBuffer, size_t* payloadSize, size_t bufferSize);

	/// <summary>Gets int16_t data from a payload handle.</summary>
	/// <param name="payloadHandle">The payload handle.</param>
	/// <param name="payloadBuffer">[out] The payload buffer. The payload data is copied to this buffer. If
	/// 							the payload types of the payload and the buffer don't match,
	/// 							the function fails.</param>
	/// <param name="payloadSize">[out] Size of the payload data. If the payload size exceeds the buffer size
	/// 						  the function fails, i.e. no data is copied and the return status code
	/// 						  is payload buffer overflow. The payload size is in any case set
	/// 						  to the payload size.</param>
	/// <param name="bufferSize">Size of the payload buffer.</param>
	/// <returns>The status code. Indicates if the function was successful or if an error occurred.</returns>
	COMMAPI PTCCommunicationStatusCode PolyGetInt16FromPayload(PTPayloadHandle payloadHandle,
		int16_t* payloadBuffer, size_t* payloadSize, size_t bufferSize);

	/// <summary>Gets uint16_t data from a payload handle.</summary>
	/// <param name="payloadHandle">The payload handle.</param>
	/// <param name="payloadBuffer">[out] The payload buffer. The payload data is copied to this buffer. If
	/// 							the payload types of the payload and the buffer don't match,
	/// 							the function fails.</param>
	/// <param name="payloadSize">[out] Size of the payload data. If the payload size exceeds the buffer size
	/// 						  the function fails, i.e. no data is copied and the return status code
	/// 						  is payload buffer overflow. The payload size is in any case set
	/// 						  to the payload size.</param>
	/// <param name="bufferSize">Size of the payload buffer.</param>
	/// <returns>The status code. Indicates if the function was successful or if an error occurred.</returns>
	COMMAPI PTCCommunicationStatusCode PolyGetUInt16FromPayload(PTPayloadHandle payloadHandle,
		uint16_t* payloadBuffer, size_t* payloadSize, size_t bufferSize);

	/// <summary>Gets int32_t data from a payload handle.</summary>
	/// <param name="payloadHandle">The payload handle.</param>
	/// <param name="payloadBuffer">[out] The payload buffer. The payload data is copied to this buffer. If
	/// 							the payload types of the payload and the buffer don't match,
	/// 							the function fails.</param>
	/// <param name="payloadSize">[out] Size of the payload data. If the payload size exceeds the buffer size
	/// 						  the function fails, i.e. no data is copied and the return status code
	/// 						  is payload buffer overflow. The payload size is in any case set
	/// 						  to the payload size.</param>
	/// <param name="bufferSize">Size of the payload buffer.</param>
	/// <returns>The status code. Indicates if the function was successful or if an error occurred.</returns>
	COMMAPI PTCCommunicationStatusCode PolyGetInt32FromPayload(PTPayloadHandle payloadHandle,
		int32_t* payloadBuffer, size_t* payloadSize, size_t bufferSize);

	/// <summary>Gets uint32_t data from a payload handle.</summary>
	/// <param name="payloadHandle">The payload handle.</param>
	/// <param name="payloadBuffer">[out] The payload buffer. The payload data is copied to this buffer. If
	/// 							the payload types of the payload and the buffer don't match,
	/// 							the function fails.</param>
	/// <param name="payloadSize">[out] Size of the payload data. If the payload size exceeds the buffer size
	/// 						  the function fails, i.e. no data is copied and the return status code
	/// 						  is payload buffer overflow. The payload size is in any case set
	/// 						  to the payload size.</param>
	/// <param name="bufferSize">Size of the payload buffer.</param>
	/// <returns>The status code. Indicates if the function was successful or if an error occurred.</returns>
	COMMAPI PTCCommunicationStatusCode PolyGetUInt32FromPayload(PTPayloadHandle payloadHandle,
		uint32_t* payloadBuffer, size_t* payloadSize, size_t bufferSize);

	/// <summary>Gets float data from a payload handle.</summary>
	/// <param name="payloadHandle">The payload handle.</param>
	/// <param name="payloadBuffer">[out] The payload buffer. The payload data is copied to this buffer. If
	/// 							the payload types of the payload and the buffer don't match,
	/// 							the function fails.</param>
	/// <param name="payloadSize">[out] Size of the payload data. If the payload size exceeds the buffer size
	/// 						  the function fails, i.e. no data is copied and the return status code
	/// 						  is payload buffer overflow. The payload size is in any case set
	/// 						  to the payload size.</param>
	/// <param name="bufferSize">Size of the payload buffer.</param>
	/// <returns>The status code. Indicates if the function was successful or if an error occurred.</returns>
	COMMAPI PTCCommunicationStatusCode PolyGetFloatFromPayload(PTPayloadHandle payloadHandle,
		float* payloadBuffer, size_t* payloadSize, size_t bufferSize);

	/// <summary>Gets double data from a payload handle.</summary>
	/// <param name="payloadHandle">The payload handle.</param>
	/// <param name="payloadBuffer">[out] The payload buffer. The payload data is copied to this buffer. If
	/// 							the payload types of the payload and the buffer don't match,
	/// 							the function fails.</param>
	/// <param name="payloadSize">[out] Size of the payload data. If the payload size exceeds the buffer size
	/// 						  the function fails, i.e. no data is copied and the return status code
	/// 						  is payload buffer overflow. The payload size is in any case set
	/// 						  to the payload size.</param>
	/// <param name="bufferSize">Size of the payload buffer.</param>
	/// <returns>The status code. Indicates if the function was successful or if an error occurred.</returns>
	COMMAPI PTCCommunicationStatusCode PolyGetDoubleFromPayload(PTPayloadHandle payloadHandle,
		double* payloadBuffer, size_t* payloadSize, size_t bufferSize);

	/// <summary>Evaluates the IP address of the device corresponding to the communication handle.
	/// 		 If the communication is a serial communication an empty string is returned.</summary>
	/// <param name="communicationHandle">The communication handle.</param>
	/// <param name="ipAddress">[out] The IP address of the device.</param>
	/// <param name="bufferSize">The size of the string buffer ipAddress.</param>
	COMMAPI void PolyDeviceIPAddress(PTCommunicationHandle communicationHandle, char* ipAddress, size_t bufferSize);

	#ifdef __cplusplus
}
#endif
