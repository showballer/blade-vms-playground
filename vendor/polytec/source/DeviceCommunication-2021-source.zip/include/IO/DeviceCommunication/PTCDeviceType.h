// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

/// \file
/// \brief	Definition of all device type available

#pragma once

/// <summary>
/// Device type used to communicate with a logical device
/// </summary>
/// <remarks>This enum values are specified by the device firmware.</remarks>
typedef enum PTCDeviceType
{
	/// <summary>
	/// Not used
	/// </summary>
	PTCDeviceType_Unknown = 0,

	/// <summary>
	/// Controller
	/// </summary>
	PTCDeviceType_Controller = 1,

	/// <summary>
	/// Sensor head
	/// </summary>
	PTCDeviceType_SensorHead = 2,

	/// <summary>
	/// Preamp
	/// </summary>
	PTCDeviceType_Preamp = 3,

	/// <summary>
	/// Input board
	/// </summary>
	PTCDeviceType_InputBoard = 4,

	/// <summary>
	/// Oscillator
	/// </summary>
	PTCDeviceType_Oscillator = 5,

	/// <summary>
	/// Velocity decoder analog
	/// </summary>
	PTCDeviceType_VelocityDecoderAnalog = 6,

	/// <summary>
	/// Velocity decoder digital
	/// </summary>
	PTCDeviceType_VelocityDecoderDigital = 7,

	/// <summary>
	/// Displacement decoder analog
	/// </summary>
	PTCDeviceType_DisplacementDecoderAnalog = 8,

	/// <summary>
	/// Displacement decoder digital
	/// </summary>
	PTCDeviceType_DisplacementDecoderDigital = 9,

	/// <summary>
	/// Output board analog
	/// </summary>
	PTCDeviceType_OutputBoardAnalog = 10,

	/// <summary>
	/// Output board digital
	/// </summary>
	PTCDeviceType_OutputBoardDigital = 11,

	/// <summary>
	/// Interface
	/// </summary>
	PTCDeviceType_Interface = 12,

	/// <summary>
	/// UserBoard
	/// </summary>
	PTCDeviceType_UserBoard = 13,

	/// <summary>
	/// Revolution decoder
	/// </summary>
	PTCDeviceType_RevolutionDecoder = 14,

	/// <summary>
	/// Ethernet switch
	/// </summary>
	PTCDeviceType_EthernetSwitch = 15,

	/// <summary>
	/// ADC board (used for reference channels)
	/// </summary>
	PTCDeviceType_AdcBoard = 16,

	/// <summary>
	/// DAC board (used for generator channels)
	/// </summary>
	PTCDeviceType_DacBoard = 17,

	/// <summary>
	/// Signal processing
	/// </summary>
	PTCDeviceType_SignalProcessing = 18,

	/// <summary>
	/// Currently not used
	/// </summary>
	PTCDeviceType_Decoder = 19,

	/// <summary>
	/// Sonde
	/// </summary>
	PTCDeviceType_Sonde = 20,

	/// <summary>
	/// Axis
	/// </summary>
	PTCDeviceType_Axis = 21,

	/// <summary>
	/// Acceleration decoder digital
	/// </summary>
	PTCDeviceType_AccelerationDecoderDigital = 22,

	/// <summary>
	/// ADC adjustment
	/// </summary>
	PTCDeviceType_AdcHardwareLayer = 23,

	/// <summary>
	/// DAC adjustment
	/// </summary>
	PTCDeviceType_DacHardwareLayer = 24,

	/// <summary>
	/// QTec module
	/// </summary>
	PTCDeviceType_QTecModule = 25,

	/// <summary>
	/// Camera Trigger
	/// </summary>
	PTCDeviceType_CameraTrigger = 26

} PTCDeviceType;

