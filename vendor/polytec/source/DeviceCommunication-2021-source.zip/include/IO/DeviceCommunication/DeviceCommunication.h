// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

/// \file
/// \brief	Declaration of a class defining the device communication type

#pragma once

#include "PTCMiscellaneousTag.h"
#include "PTCDeviceCommand.h"
#include "PTCDeviceType.h"


#include <chrono>
#include <memory>
#include <string>
#include <vector>

namespace Polytec
{
	namespace IO
	{
		class BinaryData;
		enum class CommandType;
		class CommunicationImplementation;
		class Device;
		class DeviceCommunication;
		class ICommunication;
		class MsgResponse;
		class MsgRequest;
		enum class PayloadType;

		/// <summary>
		/// Creates an UDP ethernet communication. This will also verify if there is a device which
		/// responds to incoming commands.
		/// </summary>
		/// <param name="ipAddress">The IP address of the device.</param>
		/// <param name="timeout">The timeout until an exception will be thrown if a device does not
		/// respond to a command.</param>
		/// <returns>A device communication instance.</returns>
		DeviceCommunication CreateUdpEthernetCommunication(const std::wstring& ipAddress,
			std::chrono::duration<float> timeout = std::chrono::seconds(2));

		/// <summary>
		/// Creates a TCP ethernet communication. This will also verify if there is a device which
		/// responds to incoming commands.
		/// </summary>
		/// <param name="ipAddress">The IP address of the device.</param>
		/// <param name="timeout">The timeout until an exception will be thrown if a device does not
		/// respond to a command.</param>
		/// <returns>A device communication instance.</returns>
		DeviceCommunication CreateTcpEthernetCommunication(const std::wstring& ipAddress,
			std::chrono::duration<float> timeout = std::chrono::seconds(2));

		/// <summary>
		/// Creates a serial communication. This will also verify if there is a device which responds to
		/// incoming commands.
		/// </summary>
		/// <param name="comPort">The COM port.</param>
		/// <param name="baudRate">The baud rate.</param>
		/// <param name="timeout">The timeout until an exception will be thrown if a device does not
		/// respond to a command.</param>
		/// <returns>A device communication instance.</returns>
		DeviceCommunication CreateSerialCommunication(const std::wstring& comPort, int baudRate,
			std::chrono::duration<float> timeout = std::chrono::seconds(2));

		/// <summary>High level device communication</summary>
		class DeviceCommunication
		{
		public:
			/// <summary>Default constructor. Creates an empty object.</summary>
			DeviceCommunication();

			/// <summary>
			/// A helper function for dependency injection of the device communication implementation. The
			/// conventional way to create a device communication instance is to use the factory functions,
			/// e.g. CreateSerialCommunication.
			/// </summary>
			/// <param name="timeout">The timeout for commands.</param>
			/// <param name="communication">The device communication implementation.</param>
			explicit DeviceCommunication(const std::chrono::duration<float>& timeout, std::unique_ptr<ICommunication> communication);

			DeviceCommunication(const DeviceCommunication&) = delete;
			DeviceCommunication& operator=(const DeviceCommunication&) = delete;

			/// <summary>
			/// Constructs an object by moving the ownership of the device communication implementation from
			/// the right hand side to this.
			/// </summary>
			/// <param name="rhs">[in,out] The right hand side.</param>
			DeviceCommunication(DeviceCommunication&& rhs) noexcept;

			/// <summary>
			/// Assigns the ownership of the device communication implementation from the right hand side to
			/// this.
			/// </summary>
			/// <param name="rhs">[in,out] The right hand side.</param>
			/// <returns>A shallow copy of this object.</returns>
			DeviceCommunication& operator=(DeviceCommunication&& rhs) noexcept;

			/// <summary>
			/// Destructor. It closes the device communication and releases the used resources.
			/// </summary>
			~DeviceCommunication();

			/// <summary>Evaluates if a communication is open, i.e. if it has been initialized and if the device is currently responding.</summary>
			/// <returns>True if open, false if not.</returns>
			bool IsOpen() const;

			/// <summary>It closes the device communication and releases the used resources.</summary>
			void Close();

			/// <summary>
			/// Sets the timeout. The timeout is the duration that will be waited until a device should
			/// respond to a command.
			/// </summary>
			/// <param name="timeout">The timeout in seconds.</param>
			void SetTimeout(std::chrono::duration<float> timeout);

			/// <summary>
			/// Gets the timeout. The timeout is the duration that will be waited until a device should
			/// respond to a command.
			/// </summary>
			/// <returns>The timeout.</returns>
			std::chrono::duration<float> GetTimeout() const;

			/// <summary>Gets the device IP address.</summary>
			/// <returns>
			/// Returns the device IP address in case of an ethernet communication. Returns an empty string
			/// in case of a serial communication.
			/// </returns>
			std::wstring DeviceIPAddress() const;

			/// <summary>
			/// Enables retries for commands. Requests may not receive an reply within the given
			/// timeout. If retries are enabled, timed out requests are retried.
			/// </summary>
			/// <param name="countOfRetries">The count of retries must be non-negative. E.g. 1 for one retry
			/// (resulting in overall 2 attempts until a timeout exception may happen).</param>
			void EnableRetries(int countOfRetries);

			/// <summary>
			/// Sends a Get-command to the device. A Get-command is used to get information about a current
			/// or static state of the device, e.g. the current focus position or the name of the device. See
			/// the documentation in PTCDeviceCommand.h for further information.
			/// </summary>
			/// <typeparam name="TResult">The expected payload type of the device response, e.g. int16_t
			/// for a single value or std::vector of type int16_t for multiple values.</typeparam>
			/// <param name="device">The device.</param>
			/// <param name="deviceCommand">The device command.</param>
			/// <param name="tag">The miscellaneous tag.</param>
			/// <returns>Returns the response from the device.</returns>
			template<typename TResult>
			TResult SendGet(const Device& device, PTCDeviceCommand deviceCommand,
				PTCMiscellaneousTag tag = PTCMiscellaneousTag_None) const;

			/// <summary>
			/// Sends a GetDevInfo-command to the device. A GetDevInfo-command is used to get certain
			/// additional information for a given device command e.g. the currently available velocity
			/// ranges. See the documentation in PTCDeviceCommand.h for further information.
			/// </summary>
			/// <typeparam name="TResult">The expected payload type of the device response, e.g. int16_t
			/// for a single value or std::vector of type int16_t for multiple values.</typeparam>
			/// <param name="device">The device.</param>
			/// <param name="deviceCommand">The device command.</param>
			/// <param name="tag">The miscellaneous tag.</param>
			/// <returns>Returns the response from the device.</returns>
			template<typename TResult>
			TResult SendGetDevInfo(const Device& device, PTCDeviceCommand deviceCommand,
				PTCMiscellaneousTag tag = PTCMiscellaneousTag_None) const;

			/// <summary>
			/// Sends a GetValueList-command to the device. A GetValueList-command is used to get certain
			/// additional information for a given device command e.g. all available velocity ranges as
			/// string. See the documentation in PTCDeviceCommand.h for further information.
			/// </summary>
			/// <typeparam name="TResult">The expected payload type of the device response, e.g.
			/// std::string for a string value or std::vector of type int16_t for multiple Int16 values.</typeparam>
			/// <param name="device">The device.</param>
			/// <param name="deviceCommand">The device command.</param>
			/// <param name="tag">The miscellaneous tag.</param>
			/// <returns>Returns the response from the device.</returns>
			template<typename TResult>
			TResult SendGetValueList(const Device& device, PTCDeviceCommand deviceCommand,
				PTCMiscellaneousTag tag = PTCMiscellaneousTag_None) const;

			/// <summary>
			/// Sends a Set-command to the device. A Set-command is used to control the state of a given
			/// device e.g. set the velocity range. See the documentation in PTCDeviceCommand.h for further
			/// information.
			/// </summary>
			/// <typeparam name="TPayload">The payload type of the device command, e.g. int16_t for a single
			/// value or std::vector of type int16_t for multiple Int16 values.</typeparam>
			/// <param name="device">The device.</param>
			/// <param name="deviceCommand">The device command.</param>
			/// <param name="payloadData">The payload data, e.g. the velocity range index.</param>
			/// <param name="tag">The miscellaneous tag.</param>
			template<typename TPayload>
			void SendSet(const Device& device, PTCDeviceCommand deviceCommand, const TPayload& payloadData,
				PTCMiscellaneousTag tag = PTCMiscellaneousTag_None);

			/// <summary>
			/// Overload to send a Set-command to the device without payload, e.g. PTCDeviceCommand_DisplacementClear.
			/// </summary>
			/// <param name="device">The device.</param>
			/// <param name="deviceCommand">The device command.</param>
			/// <param name="tag">The miscellaneous tag.</param>
			void SendSet(const Device& device, PTCDeviceCommand deviceCommand, PTCMiscellaneousTag tag = PTCMiscellaneousTag_None) const;

			/// <summary>
			/// Sends a parameterized Get-command to the device. See the documentation in PTCDeviceCommand.h
			/// for further information.
			/// </summary>
			/// <typeparam name="TResult">The expected payload type of the device response, e.g. int16_t for a
			/// single value or std::vector of type int16_t for multiple values.</typeparam>
			/// <typeparam name="TPayload">The payload type of the input parameters.</typeparam>
			/// <param name="device">The device.</param>
			/// <param name="deviceCommand">The device command.</param>
			/// <param name="parameters">The input parameters.</param>
			/// <param name="tag">(Optional) The miscellaneous tag.</param>
			/// <returns>Returns the response from the device.</returns>
			template<typename TResult, typename TPayload>
			TResult SendParamGet(const Device& device, PTCDeviceCommand deviceCommand,
				const TPayload& parameters, PTCMiscellaneousTag tag = PTCMiscellaneousTag_None) const;

			/// <summary>
			/// Sends a parameterized GetDevInfo-command to the device. See the documentation in PTCDeviceCommand.h
			/// for further information.
			/// </summary>
			/// <typeparam name="TResult">The expected payload type of the device response, e.g. int16_t for a
			/// single value or std::vector of type int16_t for multiple values.</typeparam>
			/// <typeparam name="TPayload">The payload type of the input parameters.</typeparam>
			/// <param name="device">The device.</param>
			/// <param name="deviceCommand">The device command.</param>
			/// <param name="parameters">The input parameters.</param>
			/// <param name="tag">(Optional) The miscellaneous tag.</param>
			/// <returns>Returns the response from the device.</returns>
			template<typename TResult, typename TPayload>
			TResult SendParamGetDevInfo(const Device& device, PTCDeviceCommand deviceCommand,
				const TPayload& parameters, PTCMiscellaneousTag tag = PTCMiscellaneousTag_None) const;

			/// <summary>
			/// Sends a parameterized GetValueList-command to the device. See the documentation in PTCDeviceCommand.h
			/// for further information.
			/// </summary>
			/// <typeparam name="TResult">The expected payload type of the device response, e.g. int16_t for a
			/// single value or std::vector of type int16_t for multiple values.</typeparam>
			/// <typeparam name="TPayload">The payload type of the input parameters.</typeparam>
			/// <param name="device">The device.</param>
			/// <param name="deviceCommand">The device command.</param>
			/// <param name="parameters">The input parameters.</param>
			/// <param name="tag">(Optional) The miscellaneous tag.</param>
			/// <returns>Returns the response from the device.</returns>
			template<typename TResult, typename TPayload>
			TResult SendParamGetValueList(const Device& device, PTCDeviceCommand deviceCommand,
				const TPayload& parameters, PTCMiscellaneousTag tag = PTCMiscellaneousTag_None) const;


			/// <summary>
			/// Sends a message data packet. This function is only needed for raw access to the data
			/// structure that will be sent.
			/// </summary>
			/// <param name="packet">[in,out] The packet to be sent.</param>
			/// <returns>The response package.</returns>
			MsgResponse SendMsgDataPacket(MsgRequest packet);

			/// <summary>Gets the communication implementation.</summary>
			/// <returns>The communication implementation.</returns>
			CommunicationImplementation& GetImpl() const;
		private:
			template<typename TPayload>
			TPayload DoSendGet(CommandType commandType, const Device& device, PTCDeviceCommand deviceCommand,
				PTCMiscellaneousTag tag, PayloadType requestType, const std::vector<std::byte>& requestData) const;

			void CheckImplementation() const;

		private:
			std::unique_ptr<CommunicationImplementation> m_implementation;
		};
	}
}
