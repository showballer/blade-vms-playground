// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

/// \file
/// \brief	Definition of a class defining a list of device available through a communication

#pragma once

#include <IO/DeviceCommunication/PTCDeviceType.h>

#include <cstdint>
#include <vector>

namespace Polytec
{
	namespace IO
	{
		class DeviceCommunication;
		class Device;

		/// <summary>
		/// A utility class to deal with the device list for a given device communication.
		/// </summary>
		class DeviceList
		{
		public:
			/// <summary>Constructor.</summary>
			/// <param name="communication">The device communication.</param>
			explicit DeviceList(const IO::DeviceCommunication& communication);

			/// <summary>Evaluates if a given device is supported by the device communication.</summary>
			/// <param name="device">The device.</param>
			/// <returns>True if the device is supported, false if not.</returns>
			bool HasDevice(const IO::Device& device) const;

			/// <summary>Counts the number of devices of given type.</summary>
			/// <param name="deviceType">The device type, e.g. PTCDeviceType_SensorHead.</param>
			/// <returns>The device count.</returns>
			int Count(PTCDeviceType deviceType) const;

			/// <summary>Get all supported devices.</summary>
			/// <returns>All devices.</returns>
			std::vector<Device> AllDevices() const;

		private:
			std::vector<int16_t> m_deviceList;
		};
	}
}
