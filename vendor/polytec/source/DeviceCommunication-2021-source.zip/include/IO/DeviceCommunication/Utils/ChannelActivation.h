// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

/// \file
/// \brief	Definition of a class wrapping the data acquisition active channels command and additional free functions

#pragma once

#include <IO/DataAcquisition/Channel.h>
#include <IO/DataAcquisition/PTCChannelType.h>
#include <IO/DeviceCommunication/PTCMiscellaneousTag.h>
#include <IO/DeviceCommunication/Device.h>
#include <IO/DeviceCommunication/PTCDeviceCommand.h>

#include <map>
#include <vector>

namespace Polytec::IO
{
	class DeviceCommunication;

	/// <summary>
	/// The channel activation class wraps the DaqActiveChannels command and handles channel activation and deactivation.
	/// </summary>
	/// <remarks>
	/// This class can only be used with devices that support the active channels command (e.g. VFX-F-110).
	/// To retrieve all active channels from any device use the free function /ref ActiveChannels below.
	/// </remarks>
	class ChannelActivation
	{
	public:
		/// <summary>Constructor.</summary>
		/// <param name="communication">The device communication instance.</param>
		explicit ChannelActivation(DeviceCommunication& communication);

		/// <summary>Gets all supported channel types.</summary>
		/// <returns>All supported channel types.</returns>
		std::vector<PTCChannelType> GetAllSupportedChannelTypes() const { return m_allChannelTypes; };

		/// <summary>Gets the maximum channel count.</summary>
		/// <param name="channelType">Type of the channel.</param>
		/// <returns>The maximum channel count.</returns>
		int	GetMaxChannelCount(PTCChannelType channelType) const;

		/// <summary>Gets the available channel count./</summary>
		/// <param name="channelType">Type of the channel.</param>
		/// <returns>The available channel count.</returns>
		int	GetAvailableChannelCount(PTCChannelType channelType) const;

		/// <summary>Gets all active channels of the specified type.</summary>
		/// <param name="channelType">Type of the channel.</param>
		/// <returns>The active channels.</returns>
		std::vector<int> GetActiveChannels(PTCChannelType channelType) const;

		/// <summary>Sets the active channels of the specified type.</summary>
		/// <param name="channelType">Type of the channel.</param>
		/// <param name="activeChannels">The active channels to be set.</param>
		void SetActiveChannels(PTCChannelType channelType, std::vector<int> activeChannels);

		/// <summary>Disables all channels.</summary>
		void DisableAllChannels();

	private:
		void CheckChannelType(PTCChannelType channelType) const;

		DeviceCommunication& m_communication;
		std::vector<PTCChannelType> m_allChannelTypes;
		mutable std::map<PTCChannelType, int> m_maxSupportedChannelCount;
	};

	/// <summary>Converts a channel type to the miscellaneous tag.</summary>
	/// <param name="channelType">Type of the channel.</param>
	/// <returns>ChannelType as a PTCMiscellaneousTag.</returns>
	PTCMiscellaneousTag ToMiscellaneousTag(PTCChannelType channelType);

	/// <summary>Converts a miscellaneous tag to a channel type.</summary>
	/// <param name="miscellaneousTag">The miscellaneous tag.</param>
	/// <returns>Miscellaneous tag as a PTCChannelType.</returns>
	PTCChannelType ToChannelType(PTCMiscellaneousTag miscellaneousTag);

	/// <summary>Retrieves all active channels even if it does not support the active channels command.</summary>
	/// <param name="communication">The device communication instance.</param>
	/// <returns>A list of all active channels<Channel></returns>
	std::vector<Channel> ActiveChannels(DeviceCommunication& communication);
}
