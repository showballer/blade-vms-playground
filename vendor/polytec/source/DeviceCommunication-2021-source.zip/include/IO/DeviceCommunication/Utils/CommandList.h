// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

/// \file
/// \brief	Definition of a class defining a list of commands that a device supports

#pragma once

#include <IO/DeviceCommunication/PTCDeviceCommand.h>


#include <cstdint>
#include <vector>

namespace Polytec::IO
{
	class DeviceCommunication;
	class Device;

	/// <summary>
	/// A utility class to deal with the command list for a given device communication and a device.
	/// </summary>
	class CommandList
	{
	public:
		/// <summary>Constructor.</summary>
		/// <param name="communication">The device communication.</param>
		/// <param name="device">The device.</param>
		explicit CommandList(const IO::DeviceCommunication& communication, const IO::Device& device);

		/// <summary>Evaluates if a given command is supported by the device communication.</summary>
		/// <param name="deviceCommand">The command.</param>
		/// <returns>True if the command is supported, false if not.</returns>
		bool HasCommand(PTCDeviceCommand deviceCommand) const;

		/// <summary>Get all supported commands of this device.</summary>
		/// <returns>All commands.</returns>
		std::vector<PTCDeviceCommand> AllCommands() const;

	private:
		std::vector<PTCDeviceCommand> m_commandList;
	};
}
