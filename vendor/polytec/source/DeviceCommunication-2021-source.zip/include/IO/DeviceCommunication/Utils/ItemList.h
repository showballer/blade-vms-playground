// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

/// \file
/// \brief	Declaration of a class that models an item list command
 
#pragma once

#include <IO/DeviceCommunication/Device.h>
#include <IO/DeviceCommunication/PTCDeviceCommand.h>

#include <string>
#include <vector>

namespace Polytec::IO
{
	class DeviceCommunication;

	/// <summary>
	/// The ItemList class models an item list command like Range
	/// </summary>
	/// <remarks>
	/// Item list commands return a comma separated list ("2 m/s,1 m/s,...") for GetValueList,
	/// all available indices for GetDevInfo and the current index for Get/Set.
	/// </remarks>
	class ItemList
	{
	public:
		/// <summary>Constructor.</summary>
		/// <param name="communication">The device communication instance.</param>
		/// <param name="device">The device.</param>
		/// <param name="command">The command.</param>
		explicit ItemList(DeviceCommunication& communication, const Device& device, PTCDeviceCommand command);

		/// <summary>Gets all items (including items that are currently not available).</summary>
		/// <returns>All items.</returns>
		std::vector<std::wstring> GetAllItems() const { return m_allItems; }

		/// <summary>Gets available indices.</summary>
		/// <returns>The available indices.</returns>
		std::vector<std::int16_t> GetAvailableIndices() const;

		/// <summary>Gets the currently available items as strings relating to GetAllItems.</summary>
		/// <returns>The available items.</returns>
		std::vector<std::wstring> GetAvailableItems() const;

		/// <summary>Gets the current item as string relating to GetAllItems.</summary>
		/// <returns>The current item.</returns>
		std::wstring GetCurrentItem() const;

		/// <summary>Gets the current index.</summary>
		/// <returns>The current index.</returns>
		std::int16_t GetCurrentIndex() const;

		/// <summary>Sets the current item as string relating to GetAllitems.</summary>
		/// <exception cref="std::logic_error">Raised when a logic error condition occurs.</exception>
		/// <param name="item">The item.</param>
		void SetCurrentItem(const std::wstring& item);

		/// <summary>Sets the current index.</summary>
		/// <param name="index">Zero-based index of the.</param>
		void SetCurrentIndex(std::int16_t index);

		/// <summary>Queries if an item exists.</summary>
		/// <param name="item">The item to test.</param>
		/// <returns>True if the item exists, false if not.</returns>
		bool HasItem(const std::wstring& item) const;

		/// <summary>Queries if an item is currently available.</summary>
		/// <param name="item">The item to test.</param>
		/// <returns>True if the item is available, false if not.</returns>
		bool IsItemAvailable(const std::wstring& item) const;

		/// <summary>Queries if an index is available./</summary>
		/// <param name="index">The index to test.</param>
		/// <returns>True if the index is available, false if not.</returns>
		bool IsIndexAvailable(std::int16_t index) const;

		/// <summary>
		/// Gets the start up item (only possible if the command supports
		/// PTCMiscellaneousTag_StartUpItem). This facilitates to determine the active state for commands
		/// that only have effect after a device reboot.
		/// </summary>
		/// <returns>The start up item.</returns>
		std::wstring GetStartUpItem() const;

	private:
		DeviceCommunication& m_communication;
		const Device m_device;
		const PTCDeviceCommand m_command;
		const std::vector<std::wstring> m_allItems;
	};
}
