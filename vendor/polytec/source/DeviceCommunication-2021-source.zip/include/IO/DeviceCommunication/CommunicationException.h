// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

/// \file
/// \brief	Declaration of an exception signaling a device communication error

#pragma once

#include "PTCCommunicationStatusCode.h"


#include <stdexcept>

namespace Polytec::IO
{
	/// <summary>Exception signalling a device communication error.</summary>
	class CommunicationException : public std::exception
	{
	public:
		/// <summary>
		/// Constructs a communication exception object based on a communication status code.
		/// </summary>
		/// <param name="statusCode">The communication status code.</param>
		/// <param name="additionalInformation">Additional information, i.e. a specific error description.</param>
		explicit CommunicationException(PTCCommunicationStatusCode statusCode,
			const std::wstring& additionalInformation = {});

		/// <summary>
		/// Constructs a communication exception object based on a communication status code.
		/// </summary>
		/// <param name="statusCode">The communication status code.</param>
		/// <param name="additionalInformation">Additional information, i.e. a specific error description.</param>
		explicit CommunicationException(PTCCommunicationStatusCode statusCode,
			const std::string& additionalInformation);

		/// <summary>Gets the communication status code.</summary>
		/// <returns>The communication status code.</returns>
		PTCCommunicationStatusCode GetStatusCode() const noexcept;

		/// <summary>Returns an explanatory string.</summary>
		/// <returns>Pointer to a null-terminated string with explanatory information.</returns>
		const char* what() const noexcept override;

		/// <summary>Returns additional information, i.e. a specific error description.</summary>
		/// <returns>A string with explanatory information.</returns>
		std::string AdditionalInformation() const;

		/// <summary>Returns an explanatory string.</summary>
		/// <returns>A string with explanatory information.</returns>
		std::string StatusMessage() const;

	private:
		const PTCCommunicationStatusCode m_statusCode;
		const std::wstring m_additionalInformation;
		mutable std::string m_message;
	};
}
