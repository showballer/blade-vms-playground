// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

/// \file
/// \brief	Definition of a class defining the type for a device

#pragma once

#include "PTCDeviceType.h"


#include <tuple>

namespace Polytec
{
	namespace IO
	{
		/// <summary>Defines the type for a device.</summary>
		class Device
		{
		public:
			/// <summary>Constructs a device object.</summary>
			/// <param name="type">The device type, e.g. PTCDeviceType_Controller.</param>
			/// <param name="number">The device number.</param>
			constexpr Device(PTCDeviceType type = PTCDeviceType_Unknown, int number = 0) noexcept
				: m_type(type)
				, m_number(number)
			{}

			/// <summary>Gets the device type.</summary>
			/// <returns>Returns the device type.</returns>
			constexpr PTCDeviceType Type() const noexcept
			{
				return m_type;
			}

			/// <summary>Gets the device number.</summary>
			/// <returns>Returns the device number.</returns>
			constexpr int Number() const noexcept
			{
				return m_number;
			}

		private:
			PTCDeviceType m_type;
			int m_number;
		};

		/// <summary>Equality operator.</summary>
		/// <param name="lhs">The first instance to compare.</param>
		/// <param name="rhs">The second instance to compare.</param>
		/// <returns>True if the parameters are considered equivalent.</returns>
		static constexpr bool operator==(const Device& lhs, const Device& rhs) noexcept
		{
			return lhs.Type() == rhs.Type() && lhs.Number() == rhs.Number();
		}

		/// <summary>Inequality operator.</summary>
		/// <param name="lhs">The first instance to compare.</param>
		/// <param name="rhs">The second instance to compare.</param>
		/// <returns>True if the parameters are not considered equivalent.</returns>
		static constexpr bool operator!=(const Device& lhs, const Device& rhs) noexcept
		{
			return !(lhs == rhs);
		}

		/// <summary>Less-than comparison operator.</summary>
		/// <param name="lhs">The first instance to compare.</param>
		/// <param name="rhs">The second instance to compare.</param>
		/// <returns>True if the first parameter is less than the second.</returns>
		static bool operator<(const Device& lhs, const Device& rhs) noexcept
		{
			return std::make_tuple(lhs.Type(), lhs.Number())
				< std::make_tuple(rhs.Type(), rhs.Number());
		}
	}
}
