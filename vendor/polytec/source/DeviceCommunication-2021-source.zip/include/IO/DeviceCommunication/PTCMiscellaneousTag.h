// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

/// \file
/// \brief	Defines additional information for some [commands](\ref PTCDeviceCommand)

#pragma once

/// <summary>
/// Additional information for some [commands](\ref PTCDeviceCommand).
/// </summary>
/// <remarks>
/// If the corresponding field in the msg-data is not used, that field need to be set to 'None'.
/// This enum values are specified by the device firmware.
/// \see PTCDeviceCommand
/// </remarks>
typedef enum PTCMiscellaneousTag
{
	/// <summary>
	/// Invalid default value.
	/// Use PTCMiscellaneousTag_None instead if the field is not used.
	/// </summary>
	PTCMiscellaneousTag_Unknown = 0,
	/// <summary>
	/// Indicates that the PTCMiscellaneousTag is not used.
	/// </summary>
	PTCMiscellaneousTag_None = 1,
	/// <summary>
	/// A channel with the index number 0.
	/// </summary>
	PTCMiscellaneousTag_Channel0 = 2,
	/// <summary>
	/// A channel with the index number 1.
	/// </summary>
	PTCMiscellaneousTag_Channel1 = 3,
	/// <summary>
	/// A channel with the index number 2.
	/// </summary>
	PTCMiscellaneousTag_Channel2 = 4,
	/// <summary>
	/// A channel with the index number 3.
	/// </summary>
	PTCMiscellaneousTag_Channel3 = 5,
	/// <summary>
	/// A channel with the index number 4.
	/// </summary>
	PTCMiscellaneousTag_Channel4 = 6,
	/// <summary>
	/// A channel with the index number 5.
	/// </summary>
	PTCMiscellaneousTag_Channel5 = 7,
	/// <summary>
	/// A channel with the index number 6.
	/// </summary>
	PTCMiscellaneousTag_Channel6 = 8,
	/// <summary>
	/// A channel with the index number 7.
	/// </summary>
	PTCMiscellaneousTag_Channel7 = 9,
	/// <summary>
	/// Channel X.
	/// </summary>
	PTCMiscellaneousTag_ChannelX = 10,
	/// <summary>
	/// Channel Y.
	/// </summary>
	PTCMiscellaneousTag_ChannelY = 11,
	/// <summary>
	/// Indicates that the command is applied to all devices of the given device type.
	/// The devices are treated as one device. The device number will be ignored.
	/// Typically used for decoder commands, e.g. to set all decoders to the same value at once.
	/// </summary>
	PTCMiscellaneousTag_Combined = 12,
	/// <summary>
	/// AllChannels.
	/// </summary>
	PTCMiscellaneousTag_AllChannels = 13,
	/// <summary>
	/// Port number 0.
	/// </summary>
	PTCMiscellaneousTag_Port0 = 14,
	/// <summary>
	/// Port number 1.
	/// </summary>
	PTCMiscellaneousTag_Port1 = 15,
	/// <summary>
	/// A parameter with the index number 0.
	/// </summary>
	PTCMiscellaneousTag_Param0 = 16,
	/// <summary>
	/// A parameter with the index number 1.
	/// </summary>
	PTCMiscellaneousTag_Param1 = 17,
	/// <summary>
	/// A parameter with the index number 2.
	/// </summary>
	PTCMiscellaneousTag_Param2 = 18,
	/// <summary>
	/// A parameter with the index number 3.
	/// </summary>
	PTCMiscellaneousTag_Param3 = 19,
	/// <summary>
	/// A parameter with the index number 4.
	/// </summary>
	PTCMiscellaneousTag_Param4 = 20,
	/// <summary>
	/// A parameter with the index number 5.
	/// </summary>
	PTCMiscellaneousTag_Param5 = 21,
	/// <summary>
	/// A parameter with the index number 6.
	/// </summary>
	PTCMiscellaneousTag_Param6 = 22,
	/// <summary>
	/// A parameter with the index number 7.
	/// </summary>
	PTCMiscellaneousTag_Param7 = 23,
	/// <summary>
	/// Trigger channel
	/// </summary>
	PTCMiscellaneousTag_ChannelTypeTrigger = 24,
	/// <summary>
	/// Velocity channel
	/// </summary>
	PTCMiscellaneousTag_ChannelTypeVelocity = 25,
	/// <summary>
	/// Displacement channel
	/// </summary>
	PTCMiscellaneousTag_ChannelTypeDisplacement = 26,
	/// <summary>
	/// Acceleration channel
	/// </summary>
	PTCMiscellaneousTag_ChannelTypeAcceleration = 27,
	/// <summary>
	/// RSSI channel
	/// </summary>
	PTCMiscellaneousTag_ChannelTypeRSSI = 28,
	/// <summary>
	/// Focus control board
	/// </summary>
	PTCMiscellaneousTag_FocusControlBoard = 29,
	/// <summary>
	/// Default value
	/// </summary>
	PTCMiscellaneousTag_DefaultValue = 30,
	/// <summary>
	/// Selected value
	/// </summary>
	PTCMiscellaneousTag_SelectedValue = 31,
	/// <summary>
	/// Start up value
	/// </summary>
	PTCMiscellaneousTag_StartUpValue = 32,
	/// <summary>
	/// Device index 0
	/// </summary>
	PTCMiscellaneousTag_DeviceIndex0 = 33,
	/// <summary>
	/// Device index 1
	/// </summary>
	PTCMiscellaneousTag_DeviceIndex1 = 34,
	/// <summary>
	/// Device index 2
	/// </summary>
	PTCMiscellaneousTag_DeviceIndex2 = 35,
	/// <summary>
	/// Device index 3
	/// </summary>
	PTCMiscellaneousTag_DeviceIndex3 = 36,
	/// <summary>
	/// Device index 4
	/// </summary>
	PTCMiscellaneousTag_DeviceIndex4 = 37,
	/// <summary>
	/// Device index 5
	/// </summary>
	PTCMiscellaneousTag_DeviceIndex5 = 38,
	/// <summary>
	/// Device index 6
	/// </summary>
	PTCMiscellaneousTag_DeviceIndex6 = 39,
	/// <summary>
	/// Device index 7
	/// </summary>
	PTCMiscellaneousTag_DeviceIndex7 = 40,
	/// <summary>
	/// Device index 8
	/// </summary>
	PTCMiscellaneousTag_DeviceIndex8 = 41,
	/// <summary>
	/// Device index 9
	/// </summary>
	PTCMiscellaneousTag_DeviceIndex9 = 42

} PTCMiscellaneousTag;

