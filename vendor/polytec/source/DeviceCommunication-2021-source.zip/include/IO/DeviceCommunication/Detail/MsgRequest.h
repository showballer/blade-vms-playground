// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#pragma once

#include <IO/DeviceCommunication/Detail/PayloadType.h>
#include <IO/DeviceCommunication/PTCDeviceCommand.h>
#include <IO/DeviceCommunication/PTCDeviceType.h>
#include <IO/DeviceCommunication/PTCMiscellaneousTag.h>

#include <cstddef>
#include <cstdint>
#include <vector>

namespace Polytec::IO
{
	enum class CommandType;
	class Device;
	class DataReader;
	class DataWriter;
	enum class MsgType;

	/// <summary>Message request sent to a device</summary>
	class MsgRequest
	{
	public:
		void Load(DataReader& reader, MsgType msgType);
		void Save(DataWriter& writer, MsgType msgType) const;

		void SetCommandNumber(int value);
		void SetResponsePort(int value);
		void SetCommandType(CommandType value);
		void SetDevice(const Device device);
		void SetDeviceType(PTCDeviceType value);
		void SetDeviceNumber(int value);
		void SetDeviceCommand(PTCDeviceCommand value);
		void SetMiscellaneousTag(PTCMiscellaneousTag value);
		void SetPayloadType(PayloadType value);
		void SetCommandData(const std::vector<std::byte>& value);

		int GetCommandNumber() const;
		int GetResponsePort() const;
		CommandType GetCommandType() const;
		Device GetDevice() const;
		PTCDeviceType GetDeviceType() const;
		int GetDeviceNumber() const;
		PTCDeviceCommand GetDeviceCommand() const;
		PTCMiscellaneousTag GetMiscellaneousTag() const;
		PayloadType GetPayloadType() const;
		const std::vector<std::byte>& GetCommandData() const;

	private:
		uint16_t m_commandNumber{};
		uint16_t m_responsePort{};
		uint8_t m_commandType{};
		uint8_t m_deviceType{};
		uint8_t m_deviceNumber{};
		uint16_t m_deviceCommand{};
		uint16_t m_miscellaneousTag{};
		uint8_t m_payloadType{};
		std::vector<std::byte> m_commandData{};
	};
}
