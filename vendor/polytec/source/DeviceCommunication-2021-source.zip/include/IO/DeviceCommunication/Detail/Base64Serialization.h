// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#pragma once


#include <string>
#include <vector>

namespace Polytec::IO
{
	template<typename TByte>
	std::string ToBase64String(const std::vector<TByte>& binary);

	template<typename TByte>
	std::vector<TByte> ParseBase64String(const std::string& string);
}
