// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#pragma once


#include <cstdlib>

#pragma warning(push)
#pragma warning(disable: 26409) // Avoid calling new and delete explicitly, use std::make_unique<T> instead (r.11).

namespace Polytec
{
	/// <summary>
	/// A phoenix singelton
	/// </summary>
	/// <remarks>
	/// A phoenix singleton is a singleton that is statically instantiated upon first use. If it is
	/// used after destruction, it is reconstructed. This makes it possible to use phoenix singleton
	/// in other statically instantiated objects.
	/// </remarks>
	/// <typeparam name="TImplementation">Type of the implementation.</typeparam>
	template<typename TImplementation>
	class PhoenixSingleton
	{
	public:
		/// <summary>Gets the singleton instance.</summary>
		/// <returns>The instance.</returns>
		static TImplementation& GetInstance()
		{
			if (!s_instance)
				s_instance = new PhoenixSingleton;
			return s_instance->m_implementation;
		}
	private:
		PhoenixSingleton()
		{
			std::atexit([]() noexcept
			{
				delete s_instance;
				s_instance = nullptr;
			});
		}
		PhoenixSingleton(const PhoenixSingleton&) = delete;
		PhoenixSingleton& operator=(const PhoenixSingleton&) = delete;
		PhoenixSingleton(PhoenixSingleton&&) = delete;
		PhoenixSingleton& operator=(PhoenixSingleton&&) = delete;
		~PhoenixSingleton() = default;

		static PhoenixSingleton* s_instance;
		TImplementation m_implementation;
	};

	template<typename TImplementation>
	PhoenixSingleton<TImplementation>* PhoenixSingleton<TImplementation>::s_instance = nullptr;
}

#pragma warning(pop)
