// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

/// \file
/// \brief	Definition of the device payload types

#pragma once

namespace Polytec::IO
{
	/// <summary>
	/// Device payload type
	/// </summary>
	/// <remarks>This enum values are specified by the device firmware.</remarks>
	enum class PayloadType
	{
		/// <summary>
		/// Not used
		/// </summary>
		Unknown = 0,
		/// <summary>
		/// No payload, e.g. used for set commands.
		/// </summary>
		None = 1,
		/// <summary>
		/// ISO8859-1 encoded string (char)
		/// </summary>
		Ascii = 2,
		/// <summary>
		/// int16_t
		/// </summary>
		Int16 = 3,
		/// <summary>
		/// uint16_t
		/// </summary>
		UInt16 = 4,
		/// <summary>
		/// int32_t
		/// </summary>
		Int32 = 5,
		/// <summary>
		/// uint32_t
		/// </summary>
		UInt32 = 6,
		/// <summary>
		/// float
		/// </summary>
		Float32 = 7,
		/// <summary>
		/// double
		/// </summary>
		Float64 = 8,
		/// <summary>
		/// byte / uint8_t
		/// </summary>
		Byte = 9,
		/// <summary>
		/// (not used)
		/// </summary>
		Hex = 10,
		/// <summary>
		/// (not used)
		/// </summary>
		UInt8 = 11,
		/// <summary>
		/// UTF8 encoded string (char)
		/// </summary>
		UTF8 = 12

	};
}
