// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#pragma once

namespace Polytec::IO
{
	/// <summary>
	/// Front-end command types
	/// </summary>
	/// <remarks>This enum values are specified by the front end firmware.</remarks>
	enum class CommandType
	{
		/// <summary>
		/// Not used
		/// </summary>
		Unknown = 0,
		/// <summary>
		/// Gets all possible values, regardless if they are currently available.
		/// </summary>
		GetValueList = 1,
		/// <summary>
		/// Gets all currently available values.
		/// </summary>
		GetDevInfo = 2,
		/// <summary>
		/// Gets the current state.
		/// </summary>
		Get = 3,
		/// <summary>
		/// Sets the current state.
		/// </summary>
		Set = 4,
	};
}
