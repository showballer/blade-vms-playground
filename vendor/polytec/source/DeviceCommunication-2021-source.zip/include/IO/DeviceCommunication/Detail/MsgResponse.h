// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#pragma once

#include <IO/DeviceCommunication/Detail/DataWriter.h>
#include <IO/DeviceCommunication/Detail/PayloadType.h>
#include <IO/DeviceCommunication/PTCCommunicationStatusCode.h>

namespace Polytec::IO
{
	class DataReader;
	enum class MsgType;

	/// <summary>Message response received from a device</summary>
	class MsgResponse
	{
	public:
		static MsgResponse Acknowledged();
		static MsgResponse Error(PTCCommunicationStatusCode errorCode);

		template<typename TPayload>
		static MsgResponse FromPayload(TPayload payload);

		void Load(DataReader& reader, MsgType msgType);
		void Save(DataWriter& data, MsgType msgType) const;

		void SetCommandNumber(int value);
		void SetPayloadType(PayloadType value);
		void SetCommandData(const std::vector<std::byte>& value);

		int GetCommandNumber() const;
		PayloadType GetPayloadType() const;
		const std::vector<std::byte>& GetCommandData() const;

		/// <summary>Get a data writer for the binary command data buffer held by this class</summary>
		/// <returns>The data writer.</returns>
		DataWriter CommandDataWriter() { return DataWriter(m_commandData); }

	private:
		uint16_t m_commandNumber{};
		uint8_t m_payloadType{};
		std::vector<std::byte> m_commandData{};
	};

	bool IsStringPayloadType(PayloadType type);
	bool IsError(const MsgResponse& response);
	PTCCommunicationStatusCode GetStatusCode(const MsgResponse& response);
}

#include "MsgResponse.inl"
