// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#include <IO/DeviceCommunication/Detail/PayloadTypeTraits.h>

namespace Polytec::IO
{
	/// <summary>Creates a message data packet from payload.</summary>
	/// <typeparam name="TPayload">Type of the payload.</typeparam>
	/// <param name="payload">The payload.</param>
	/// <returns>The payload message data packet.</returns>
	template<typename TPayload>
	MsgResponse MsgResponse::FromPayload(TPayload payload)
	{
		MsgResponse packet;
		packet.SetPayloadType(c_payloadType<TPayload>);
		packet.CommandDataWriter().Write(payload);
		return packet;
	}
}
