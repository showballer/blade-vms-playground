// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#pragma once

#include <IO/DeviceCommunication/Detail/PayloadType.h>

#include <set>
#include <string>
#include <utility>
#include <vector>

namespace Polytec::IO
{
	/// <summary>Data type for hex data</summary>
	struct HexData
	{
		/// <summary>Byte value</summary>
		std::byte Value;
	};

	namespace Detail
	{
		/// <summary>Default payload type trait</summary>
		template<typename TPayload>
		struct PayloadType
		{
			/// <summary>PayloadType corresponding to the given payload type</summary>
			static constexpr auto Value = IO::PayloadType::Unknown;
		};

		/// <summary>void payload type trait</summary>
		template<>
		struct PayloadType<void>
		{
			/// <summary>PayloadType corresponding to the given payload type</summary>
			static constexpr auto Value = IO::PayloadType::None;
		};

		/// <summary>char payload type trait</summary>
		template<>
		struct PayloadType<char>
		{
			/// <summary>PayloadType corresponding to the given payload type</summary>
			static constexpr auto Value = IO::PayloadType::UTF8;
		};

		/// <summary>std::byte payload type trait</summary>
		template<>
		struct PayloadType<std::byte>
		{
			/// <summary>PayloadType corresponding to the given payload type</summary>
			static constexpr auto Value = IO::PayloadType::Byte;
		};

		/// <summary>uint8_t payload type trait</summary>
		template<>
		struct PayloadType<uint8_t>
		{
			/// <summary>PayloadType corresponding to the given payload type</summary>
			static constexpr auto Value = IO::PayloadType::Byte;
		};

		/// <summary>int16_t payload type trait</summary>
		template<>
		struct PayloadType<int16_t>
		{
			/// <summary>PayloadType corresponding to the given payload type</summary>
			static constexpr auto Value = IO::PayloadType::Int16;
		};

		/// <summary>uint16_t payload type trait</summary>
		template<>
		struct PayloadType<uint16_t>
		{
			/// <summary>PayloadType corresponding to the given payload type</summary>
			static constexpr auto Value = IO::PayloadType::UInt16;
		};

		/// <summary>int32_t payload type trait</summary>
		template<>
		struct PayloadType<int32_t>
		{
			/// <summary>PayloadType corresponding to the given payload type</summary>
			static constexpr auto Value = IO::PayloadType::Int32;
		};

		/// <summary>uint32_t payload type trait</summary>
		template<>
		struct PayloadType<uint32_t>
		{
			/// <summary>PayloadType corresponding to the given payload type</summary>
			static constexpr auto Value = IO::PayloadType::UInt32;
		};

		/// <summary>float payload type trait</summary>
		template<>
		struct PayloadType<float>
		{
			/// <summary>PayloadType corresponding to the given payload type</summary>
			static constexpr auto Value = IO::PayloadType::Float32;
		};

		/// <summary>double payload type trait</summary>
		template<>
		struct PayloadType<double>
		{
			/// <summary>PayloadType corresponding to the given payload type</summary>
			static constexpr auto Value = IO::PayloadType::Float64;
		};

		/// <summary>std::string payload type trait</summary>
		template<>
		struct PayloadType<std::string>
		{
			/// <summary>PayloadType corresponding to the given payload type</summary>
			static constexpr auto Value = IO::PayloadType::UTF8;
		};

		/// <summary>const char* payload type trait</summary>
		template<>
		struct PayloadType<const char*>
		{
			/// <summary>PayloadType corresponding to the given payload type</summary>
			static constexpr auto Value = IO::PayloadType::UTF8;
		};

		/// <summary>std::wstring payload type trait</summary>
		template<>
		struct PayloadType<std::wstring>
		{
			/// <summary>PayloadType corresponding to the given payload type</summary>
			static constexpr auto Value = IO::PayloadType::UTF8;
		};

		/// <summary>HexData payload type trait</summary>
		template<>
		struct PayloadType<HexData>
		{
			/// <summary>PayloadType corresponding to the given payload type</summary>
			static constexpr auto Value = IO::PayloadType::Hex;
		};

		/// <summary>std::set<TPayload> payload type trait</summary>
		template<typename TPayload>
		struct PayloadType<std::set<TPayload>>
		{
			/// <summary>PayloadType corresponding to the given payload type</summary>
			static constexpr auto Value = PayloadType<TPayload>::Value;
		};

		/// <summary>std::pair<TPayload, TPayload> payload type trait</summary>
		template<typename TPayload>
		struct PayloadType<std::pair<TPayload, TPayload>>
		{
			/// <summary>PayloadType corresponding to the given payload type</summary>
			static constexpr auto Value = PayloadType<TPayload>::Value;
		};

		/// <summary>std::array payload type trait</summary>
		template<typename TPayload, std::size_t PSize>
		struct PayloadType<std::array<TPayload, PSize>>
		{
			/// <summary>PayloadType corresponding to the given payload type</summary>
			static constexpr auto Value = PayloadType<TPayload>::Value;
		};

		/// <summary>std::vector<TPayload> payload type trait</summary>
		template<typename TPayload>
		struct PayloadType<std::vector<TPayload>>
		{
			/// <summary>PayloadType corresponding to the given payload type</summary>
			static constexpr auto Value = PayloadType<TPayload>::Value;
		};
	}

	/// <summary>
	/// A type trait that stores the PayloadType corresponding to the given payload type.
	/// </summary>
	/// <typeparam name="TPayload">The payload type.</typeparam>
	template<typename TPayload>
	static constexpr auto c_payloadType = Detail::PayloadType<TPayload>::Value;
}
