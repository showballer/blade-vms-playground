// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#pragma once

#include <IO/DeviceCommunication/CommunicationException.h>
#include <IO/DeviceCommunication/Detail/PhoenixSingleton.h>

#include <map>

namespace Polytec::IO
{
	/// <summary>Manager for handles, e.g. PTCommunicationHandle.</summary>
	/// <typeparam name="TResource">Type of the resource, e.g. CommunicationResource.</typeparam>
	template <typename TResource>
	class HandleManager
	{
	public:
		HandleManager() = default;
		HandleManager(const HandleManager&) = delete;
		HandleManager& operator=(const HandleManager&) = delete;
		HandleManager(HandleManager&& rhs) = delete;
		HandleManager& operator=(HandleManager&& rhs) = delete;
		~HandleManager() = default;

		template <typename ...Args>
		int Create(Args&& ...objConstructionArgs)
		{
			int handle = 1;
			while (m_items.count(handle))
				handle++;

			m_items.try_emplace(handle, std::forward<Args>(objConstructionArgs)...);
			return handle;
		}

		void Delete(int handle)
		{
			m_items.erase(handle);
		}

		TResource& Get(int handle)
		{
			if (!IsValidHandle(handle))
				throw CommunicationException(PTCCommunicationStatusCode_InvalidArgument, "Invalid handle.");
			return m_items.at(handle);
		}

		bool IsValidHandle(int handle) const
		{
			return m_items.count(handle) > 0;
		}

	private:
		std::map<int, TResource> m_items;
	};

	/// <summary>Handle manager.</summary>
	/// <typeparam name="TResource">Type of the resource.</typeparam>
	/// <returns>A singleton instance of the manager.</returns>
	template <typename TResource>
	auto& GetHandleManager()
	{
		return PhoenixSingleton<HandleManager<TResource>>::GetInstance();
	}
}
