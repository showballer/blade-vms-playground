// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#pragma once


#include <functional>
#include <memory>
#include <mutex>
#include <thread>

namespace boost::asio
{
	class io_context;
}

namespace Polytec
{
	namespace IO
	{
		class IService;

		/// <summary>A service for asynchronous operations.</summary>
		class ServiceThread
		{
		public:
			using Callback = std::function<void()>;
			using ErrorHandler = std::function<void(const std::exception&)>;

			explicit ServiceThread(IService& service);
			ServiceThread(Callback run, Callback shutdown, ErrorHandler errorHandler);
			ServiceThread(const ServiceThread&) = delete;
			ServiceThread& operator=(const ServiceThread&) = delete;
			ServiceThread(ServiceThread&&) noexcept; // Moving m_implementation is noexcept
			ServiceThread& operator=(ServiceThread&&) = delete;
			~ServiceThread() noexcept;

			void Start();
			void Stop();

		private:
			void CheckValid() const;

			struct Implementation;
			std::unique_ptr<Implementation> m_implementation;
		};

		/// <summary>Create a service thread based on the provided context.</summary>
		/// <param name="ioContext">The context.</param>
		ServiceThread CreateContextThread(boost::asio::io_context& ioContext, ServiceThread::ErrorHandler errorHandler);
	}
}
