// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#pragma once


#include <cstddef>
#include <cstring>
#include <stdexcept>
#include <string>
#include <type_traits>
#include <vector>

#include <gsl/span_ext>

namespace Polytec::IO
{
	/// <summary>Data reader to read data of a given type from a binary buffer</summary>
	class DataReader
	{
	public:
		explicit DataReader(gsl::span<const std::byte> binaryData);

		DataReader(const DataReader&) = delete;
		DataReader& operator=(const DataReader&) = delete;
		DataReader(DataReader&&) = delete;
		DataReader& operator=(DataReader&&) = delete;

		template<typename T>
		void Read(T& value);

		template<typename T>
		T Read();

		template<typename T, std::size_t Extent = gsl::dynamic_extent>
		void ReadValues(gsl::span<T, Extent> values);

		template<typename Container>
		void ReadValues(Container& values);

		template <typename T, std::size_t N>
		void ReadValues(T(&values)[N]);

		template<typename T>
		void Read(std::vector<T>& values);

		template<typename T, typename U>
		void Read(std::pair<T, U>& values);

		void Read(std::string& string);
		void Read(std::wstring& string);

		std::vector<std::byte> ExtractData(std::size_t size);
		const std::byte* Data() const;
		std::size_t BytesAvailable() const;
		gsl::span<const std::byte> Span() const;
		bool EndOfBuffer() const;
		std::size_t Index() const;
		void Index(std::size_t index);

	private:
		void CheckBytesAvailable(std::size_t size) const;

		gsl::span<const std::byte> m_binaryData;
		std::size_t m_index{};
	};

	/// <summary>
	/// Reads data of the given type from the related binary data buffer and copies it to the given
	/// value.
	/// </summary>
	/// <exception cref="std::out_of_range">An exception is thrown if the data is not available.</exception>
	/// <typeparam name="T">Type of the value to be read.</typeparam>
	/// <param name="value">[out] The value that was read from the binary data buffer.</param>
	template<typename T>
	void DataReader::Read(T& value)
	{
		static_assert(std::is_trivially_copyable<T>::value, "This type is not implemented for DataReader.");
		CheckBytesAvailable(sizeof(T));

		#pragma warning(suppress: 26481) // Don't use pointer arithmetic. Use span instead (bounds.1).
		const void* source = m_binaryData.data() + m_index;
		void* destination = &value;

		std::memcpy(destination, source, sizeof(T));
		m_index += sizeof(T);
	}

	/// <summary>
	/// Reads data of the given type from the related binary data buffer and returns it.
	/// </summary>
	/// <exception cref="std::out_of_range">An exception is thrown if the data is not available.</exception>
	/// <typeparam name="T">Type of the value to be read.</typeparam>
	/// <returns>The read value of type T.</returns>
	template<typename T>
	T DataReader::Read()
	{
		T value;
		Read(value);
		return value;
	}

	/// <summary>
	/// Reads a sequence of values of the given type from the related binary data buffer into the specified span.
	/// </summary>
	/// <remarks>
	/// The size of the span determines how many values are read.
	/// </remarks>
	/// <exception cref="std::out_of_range">An exception is thrown if the data is not available.</exception>
	/// <typeparam name="T">Type of the values to be read.</typeparam>
	template<typename T, std::size_t Extent>
	void DataReader::ReadValues(gsl::span<T, Extent> values)
	{
		static_assert(std::is_trivially_copyable<T>::value, "This type is not implemented for DataReader.");
		auto dest = gsl::as_writable_bytes(values);
		CheckBytesAvailable(std::size(dest));
		auto source = m_binaryData.subspan(m_index, dest.size());
		std::memcpy(std::data(dest), std::data(source), std::size(dest));
		m_index += std::size(dest);
	}

	/// <summary>
	/// Reads a sequence of values from the related binary data buffer into the specified contiguous sequence container.
	/// </summary>
	/// <remarks>
	/// The size of the container determines how many values are read. The container must support size() and data() functions.
	/// </remarks>
	/// <exception cref="std::out_of_range">An exception is thrown if the data is not available.</exception>
	/// <typeparam name="Container">Type of the container.</typeparam>
	/// <param name="container">The container.</param>
	template<typename Container>
	void DataReader::ReadValues(Container& container)
	{
		ReadValues(gsl::make_span(container));
	}

	/// <summary>
	/// Reads a sequence of values from the related binary data buffer into the specified array.
	/// </summary>
	/// <remarks>
	/// The size of the array determines how many values are read.
	/// </remarks>
	/// <exception cref="std::out_of_range">An exception is thrown if the data is not available.</exception>
	/// <typeparam name="T">The type of the values to be read.</typeparam>
	/// <typeparam name="N">The extent of the array.</typeparam>
	/// <param name="values">The values.</param>
	template <typename T, std::size_t N>
	void DataReader::ReadValues(T(&values)[N])
	{
		ReadValues(gsl::make_span(values));
	}

	/// <summary>
	/// Reads data of the given type from the related binary data buffer. All available data of the
	/// binary data buffer is read out and copied to the given vector.
	/// </summary>
	/// <typeparam name="T">Type of the values to be read.</typeparam>
	/// <param name="values">[out] The vector of values that was read from the binary data buffer.</param>
	template<typename T>
	void DataReader::Read(std::vector<T>& values)
	{
		static_assert(std::is_trivially_copyable<T>::value, "This type is not implemented for DataReader.");

		values.resize(BytesAvailable() / sizeof(T));
		ReadValues(values);
	}

	/// <summary>
	/// Reads data pair of the given type from the related binary data buffer.
	/// </summary>
	/// <typeparam name="T">Type of the first value to be read.</typeparam>
	/// <typeparam name="U">Type of the second value to be read.</typeparam>
	/// <param name="values">[out] The pair of values that was read from the binary data buffer.</param>
	template<typename T, typename U>
	void DataReader::Read(std::pair<T, U>& values)
	{
		Read(values.first);
		Read(values.second);
	}
}
