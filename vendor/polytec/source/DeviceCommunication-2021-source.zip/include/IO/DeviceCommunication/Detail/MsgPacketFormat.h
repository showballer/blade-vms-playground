// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#pragma once

#include "INetworkPacketFormat.h"


#include <cstddef>
#include <vector>

namespace Polytec::IO
{
	/// <summary>
	/// A message packet format for the classes MsgHeader, MsgRequest and MsgResponse.
	/// </summary>
	class MsgPacketFormat : public INetworkPacketFormat
	{
	public:
		std::size_t GetBaseHeaderSize() const override { return 14; }
		std::size_t GetBodySize(const std::vector<std::byte>& header) const override;
	};
}
