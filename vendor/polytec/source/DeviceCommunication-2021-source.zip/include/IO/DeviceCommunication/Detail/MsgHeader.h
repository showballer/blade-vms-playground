// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#pragma once

#include "MsgType.h"


#include <cstdint>

namespace Polytec::IO
{
	class DataReader;
	class DataWriter;

	/// <summary>Message header used by MsgBuilder</summary>
	class MsgHeader
	{
	public:
		void Load(DataReader& reader);
		void Save(DataWriter& data) const;

		MsgType GetMsgType() const;
		std::size_t GetMsgSize() const;

		void SetMsgType(MsgType value);
		void SetSequenceNumber(int value);
		void SetMsgSize(std::size_t value);

	private:
		std::uint8_t m_msgType{};
		std::uint32_t m_sequenceNumber{};
		std::uint8_t m_multiCmd{};
		std::uint8_t m_multiPackageCmd{};
		std::uint16_t m_multiPackageCount{};
		std::uint32_t m_packetSize{};
	};

	/// <summary>Get header size in Bytes</summary>
	constexpr std::size_t Size(const MsgHeader&) { return 14; }
}
