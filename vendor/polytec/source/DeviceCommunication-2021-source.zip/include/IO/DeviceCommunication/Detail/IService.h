// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#pragma once


#include <exception>

namespace Polytec::IO
{
	/// <summary>A service interface</summary>
	/// <remarks>A service is an operation that is running until it is shut down.</remarks>
	class IService
	{
	public:
		IService() = default;
		IService(const IService&) = default;
		IService(IService&&) = default;
		IService& operator=(const IService&) = default;
		IService& operator=(IService&&) = default;
		virtual ~IService() = default;

		/// <summary>Runs this object. This may be blocking until Shutdown is called.</summary>
		virtual void Run() = 0;

		/// <summary>Shuts down a running instance. If Run is called, it will unblock.</summary>
		virtual void Shutdown() = 0;

		/// <summary>Handles the error, e.g. logs the error.</summary>
		/// <param name="e">The exception to handle.</param>
		virtual void HandleError(const std::exception& e) const = 0;
	};
}
