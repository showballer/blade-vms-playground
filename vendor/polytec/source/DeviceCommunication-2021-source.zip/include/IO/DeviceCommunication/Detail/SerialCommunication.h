// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#pragma once

#include <IO/DeviceCommunication/Detail/DeadlineTimer.h>
#include <IO/DeviceCommunication/Detail/ICommunication.h>

#include <boost/asio.hpp>

#include <mutex>
#include <string>
#include <vector>

namespace Polytec::IO
{
	/// <summary>A handler for serial communications</summary>
	class SerialCommunication : public ICommunication
	{
	public:
		explicit SerialCommunication(const std::wstring& serialPortName, int baudRate);

		SerialCommunication(const SerialCommunication&) = delete;
		SerialCommunication& operator=(const SerialCommunication&) = delete;
		SerialCommunication(SerialCommunication&&) = default;
		SerialCommunication& operator=(SerialCommunication&&) = default;

		void SendData(const std::vector<std::byte>& data) override;
		std::vector<std::byte> ReceiveData() override;
		int ResponsePort() const override;
		std::wstring DeviceIPAddress() const override;
		void SetTimeout(const std::chrono::duration<float>& timeout) override { m_timeout = timeout; }
		std::chrono::duration<float> GetTimeout() const override { return m_timeout; }

	private:
		void ClearInternalSerialPortBuffer();
		void ClearDeviceSerialPortBuffer();

		// The member variables m_ioService and m_deadline are also used by EthernetCommunication.
		// They are placed in the concrete classes because they are an implementation detail.
		boost::asio::io_service m_ioService;
		boost::asio::serial_port m_serialPort;
		DeadlineTimer m_deadlineTimer;
		std::chrono::duration<float> m_timeout = std::chrono::seconds(2);
		std::mutex m_writeMutex;
	};
}
