// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#pragma once

#include <IO/DeviceCommunication/Detail/DeadlineTimer.h>
#include <IO/DeviceCommunication/Detail/ICommunication.h>
#include <IO/DeviceCommunication/Detail/INetworkPacketFormat.h>

#include <boost/asio.hpp>

namespace Polytec::IO
{
	/// <summary>A handler for TCP communications</summary>
	class TcpEthernetCommunication : public ICommunication
	{
	public:
		explicit TcpEthernetCommunication(const std::wstring& hostname, std::unique_ptr<INetworkPacketFormat>&& packetFormat);

	private:
		std::vector<std::byte> ReceiveData() override;
		std::vector<std::byte> ReceiveDataBlocks(std::size_t headerSize, std::size_t packetSize, std::size_t blockSize);
		void SendData(const std::vector<std::byte>& data) override;
		int ResponsePort() const override;
		std::wstring DeviceIPAddress() const override;
		void SetTimeout(const std::chrono::duration<float>& timeout) override { m_timeout = timeout; }
		std::chrono::duration<float> GetTimeout() const override { return m_timeout; }

		boost::asio::io_service m_ioService;
		boost::asio::ip::tcp::socket m_socket;
		boost::asio::ip::tcp::endpoint m_deviceEndpoint;
		std::vector<std::byte> m_buffer;
		std::unique_ptr<INetworkPacketFormat> m_packetFormat;
		DeadlineTimer m_deadlineTimer;
		std::chrono::duration<float> m_timeout = std::chrono::seconds(2);
	};
}
