// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#pragma once


#include <vector>

namespace Polytec::IO
{
	class MsgResponse;

	/// <summary>
	/// A message response buffer
	/// </summary>
	/// <remarks>
	/// This class facilitates to store response packets from a communication. If responses are sent
	/// back in different order or are dropped because of a timeout, this buffer enables to access
	/// the required packet.
	/// </remarks>
	class MsgResponseBuffer
	{
	public:
		explicit MsgResponseBuffer(std::size_t bufferRange = 1'000);
		void Add(MsgResponse packet);
		bool Contains(int commandNumber) const;
		MsgResponse Extract(int commandNumber);

	private:
		std::vector<MsgResponse>::const_iterator Find(int commandNumber) const;
		void EraseOutdatedPackets(int commandNumber);

		std::vector<MsgResponse> m_responseBuffer;
		std::size_t m_bufferRange{};
	};
}
