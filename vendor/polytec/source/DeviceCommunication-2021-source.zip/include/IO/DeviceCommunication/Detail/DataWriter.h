// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#pragma once


#include <cstddef>
#include <cstring>
#include <set>
#include <string>
#include <type_traits>
#include <vector>

#include <gsl/span_ext>

namespace Polytec
{
	namespace IO
	{
		/// <summary>Data writer to write data of a given type to a binary buffer</summary>
		class DataWriter
		{
		public:
			template<typename T>
			static std::vector<std::byte> ToBinaryData(const T& value);

			explicit DataWriter(std::vector<std::byte>& binaryData);

			template<typename T>
			void Write(T value);

			template<typename T, std::ptrdiff_t Extent = gsl::dynamic_extent>
			void WriteValues(gsl::span<const T, Extent> values);

			template<typename Container>
			void WriteValues(const Container& container);

			template <typename T, std::size_t N>
			void WriteValues(const T(&values)[N]);

			template<typename T>
			void Write(const std::vector<T>& values);

			template<typename T>
			void Write(const std::set<T>& values);

			template<typename T, typename U>
			void Write(const std::pair<T, U>& values);

			void Write(const void* data, std::size_t size);
			void Write(const std::wstring& str);
			void Write(const std::string& str);
			void Write(const char* str);
			void Write(const std::vector<std::byte>& binaryData);

			void Clear();

		private:
			std::vector<std::byte>& m_data;
		};

		/// <summary>Converts a value to binary data.</summary>
		/// <typeparam name="T">Type of the value to be written.</typeparam>
		/// <param name="value">The value.</param>
		/// <returns>The binary data.</returns>
		template<typename T>
		std::vector<std::byte> DataWriter::ToBinaryData(const T& value)
		{
			std::vector<std::byte> result;
			DataWriter writer(result);
			writer.Write(value);
			return result;
		}

		/// <summary>
		/// Writes the given value of fundamental data type to the end of the binary data buffer.
		/// </summary>
		/// <typeparam name="T">Type of the value to be written.</typeparam>
		/// <param name="value">The value to be written.</param>
		template<typename T>
		void DataWriter::Write(T value)
		{
			static_assert(std::is_trivially_copyable<T>::value, "This type is not implemented for DataWriter.");
			Write(&value, sizeof(value));
		}

		/// <summary>
		/// Writes the given span of values of the fundamental data type to the end of the binary data buffer.
		/// </summary>
		/// <remarks>
		/// The size of the span determines how many values are written.
		/// </remarks>
		/// <typeparam name="T">The type of the the values.</typeparam>
		/// <typeparam name="Extent">Type of the extent.</typeparam>
		/// <param name="values">The values.</param>
		template<typename T, std::ptrdiff_t Extent>
		void DataWriter::WriteValues(gsl::span<const T, Extent> values)
		{
			static_assert(std::is_trivially_copyable<T>::value, "This type is not implemented for DataWriter.");
			auto bytes = gsl::as_bytes(values);
			Write(std::data(bytes), std::size(bytes));
		}

		/// <summary>
		/// Writes the values of fundamental data type in the given container to the end of the binary data
		/// buffer.
		/// </summary>
		/// <remarks>
		/// The size of the container determines how many values are written.
		/// </remarks>
		/// <typeparam name="Container">Type of the container.</typeparam>
		/// <param name="container">The container.</param>
		template<typename Container>
		void DataWriter::WriteValues(const Container& container)
		{
			WriteValues(gsl::make_span(container));
		}

		/// <summary>
		/// Writes the values of fundamental data type in the array to the end of the binary data buffer.
		/// </summary>
		/// <remarks>
		/// The size of the array determines how many values are written.
		/// </remarks>
		/// <typeparam name="T">The type of the the values.<</typeparam>
		/// <typeparam name="N">The extent of the array.</typeparam>
		/// <param name="values">The values.</param>
		template <typename T, std::size_t N>
		void DataWriter::WriteValues(const T(&values)[N])
		{
			WriteValues(gsl::make_span(values));
		}

		/// <summary>
		/// Writes the given vector of fundamental data type to the end of the binary data buffer.
		/// </summary>
		/// <typeparam name="T">Type of the values to be written.</typeparam>
		/// <param name="values">The vector to be written.</param>
		template<typename T>
		void DataWriter::Write(const std::vector<T>& values)
		{
			static_assert(std::is_trivially_copyable<T>::value, "This type is not implemented for DataWriter.");
			Write(std::data(values), std::size(values) * sizeof(T));
		}

		/// <summary>
		/// Writes the given set of fundamental data type to the end of the binary data buffer.
		/// </summary>
		/// <typeparam name="T">Type of the values to be written.</typeparam>
		/// <param name="values">The set to be written.</param>
		template<typename T>
		void DataWriter::Write(const std::set<T>& values)
		{
			m_data.reserve(m_data.size() + values.size() * sizeof(T));
			for (const auto& element : values)
				Write(element);
		}

		/// <summary>
		/// Writes the given pair of fundamental data type to the end of the binary data buffer.
		/// </summary>
		/// <typeparam name="T">Type of the first value to be written.</typeparam>
		/// <typeparam name="U">Type of the second value to be written.</typeparam>
		/// <param name="values">The pair to be written.</param>
		template<typename T, typename U>
		void DataWriter::Write(const std::pair<T, U>& values)
		{
			Write(values.first);
			Write(values.second);
		}
	}
}
