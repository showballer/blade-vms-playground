// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#pragma once

#include "StringConverter.h"

#include <Diagnostics/UnitTestHelpers.h>

#include <string>

namespace Polytec::IO::Test
{
	/// <summary>Unicode encoding helper</summary>
	struct Unicode
	{
		/// <summary>Unicode string</summary>
		std::wstring String;
		/// <summary>Equality operator overload</summary>
		bool operator==(const Unicode& rhs) const { return String == rhs.String; }
	};

	/// <summary>ISO8859-1 encoding helper</summary>
	struct ISO8859_1
	{
		/// <summary>ISO8859-1 string</summary>
		std::string String;
		/// <summary>Equality operator overload</summary>
		bool operator==(const ISO8859_1& rhs) const { return String == rhs.String; }
	};

	/// <summary>UTF-8 encoding helper</summary>
	struct UTF8
	{
		/// <summary>UTF-8 string</summary>
		std::string String;
		/// <summary>Equality operator overload</summary>
		bool operator==(const UTF8& rhs) const { return String == rhs.String; }
	};
}

namespace Microsoft::VisualStudio::CppUnitTestFramework
{
	/// <summary>UTF-8 string to CString conversion function</summary>
	/// <param name="utf8">A UTF-8 string</param>
	/// <returns>A CString</returns>
	template<>
	std::wstring ToString<Polytec::IO::Test::UTF8>(const Polytec::IO::Test::UTF8& utf8)
	{
		std::wstringstream stream;
		try
		{
			stream << Polytec::IO::ToWString(utf8.String);
		}
		catch (const std::exception&)
		{
			stream << L"<failed to convert>";
		}
		stream << L" (";
		for (const char c : utf8.String)
		{
			stream << std::hex << static_cast<uint8_t>(c) << L" ";
		}
		stream << L")";
		return stream.str();
	}

	/// <summary>ISO8859-1 string to CString conversion function</summary>
	/// <param name="iso88591">A ISO8859-1 string</param>
	/// <returns>A CString</returns>
	template<>
	std::wstring ToString<Polytec::IO::Test::ISO8859_1>(const Polytec::IO::Test::ISO8859_1& iso88591)
	{
		return ToString<Polytec::IO::Test::UTF8>({iso88591.String});
	}

	/// <summary>Unicode string to CString conversion function</summary>
	/// <param name="unicode">A Unicode string</param>
	/// <returns>A CString</returns>
	template<>
	std::wstring ToString<Polytec::IO::Test::Unicode>(const Polytec::IO::Test::Unicode& unicode)
	{
		std::wstringstream stream;
		stream << unicode.String << L" (";
		for (const wchar_t c : unicode.String)
		{
			stream << std::hex << static_cast<uint16_t>(c) << L" ";
		}
		stream << L")";
		return stream.str();
	}
}
