// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#pragma once

#include "MsgResponseBuffer.h"

#include <IO/DeviceCommunication/Detail/ICommunication.h>
#include <IO/DeviceCommunication/Detail/MsgBuilder.h>
#include <IO/DeviceCommunication/Detail/MsgResponse.h>
#include <IO/DeviceCommunication/PTCDeviceCommand.h>
#include <IO/DeviceCommunication/PTCMiscellaneousTag.h>

#include <memory>
#include <mutex>

namespace Polytec::IO
{
	enum class CommandType;
	class Device;
	class MsgRequest;
	class MsgResponse;
	struct DeviceEndpoint;
	
	std::wstring FormatBinaryData(const gsl::span<const std::byte>& commandData);

	/// <summary>Device communication implementation</summary>
	class CommunicationImplementation
	{
		using ResponsePayload = std::pair<PayloadType, std::vector<std::byte>>;

	public:
		explicit CommunicationImplementation(std::chrono::duration<float> timeout, std::unique_ptr<ICommunication>&& communication);
		CommunicationImplementation(const CommunicationImplementation&) = delete;
		CommunicationImplementation& operator=(const CommunicationImplementation&) = delete;
		CommunicationImplementation(CommunicationImplementation&&) = default;
		CommunicationImplementation& operator=(CommunicationImplementation&&) = default;

		void CheckCommunication();

		void SetTimeout(std::chrono::duration<float> timeout);
		std::chrono::duration<float> GetTimeout() const;
		void EnableRetries(int countOfRetries);

		ResponsePayload SendGet(CommandType commandType, const Device& device, PTCDeviceCommand deviceCommand,
			PTCMiscellaneousTag tag, PayloadType requestType, const std::vector<std::byte>& requestData);

		void SendSet(CommandType commandType, const Device& device, PTCDeviceCommand deviceCommand,
			PTCMiscellaneousTag tag, PayloadType payloadType, const std::vector<std::byte>& commandData);

		MsgResponse SendMsgDataPacket(MsgRequest&& data);

		std::wstring DeviceIPAddress() const { return m_communication->DeviceIPAddress(); }

	private:
		ResponsePayload DoSend(CommandType commandType,
			const Device& device,PTCDeviceCommand deviceCommand, PTCMiscellaneousTag tag,
			PayloadType requestType, const std::vector<std::byte>& requestData);

		int DoSendMsgDataPacket(MsgRequest&& data);
		MsgResponse DoReceiveMsgDataPacketWithErrorInfo(int commandNumber, PTCDeviceCommand deviceCommand);
		MsgResponse DoReceiveMsgDataPacket(int cmdNumber);
		void CollectDataPacket();
		void ConvertRequestStringEncoding(MsgRequest& request) const;
		void ConvertResponseStringEncoding(MsgResponse& response) const;

		std::unique_ptr<ICommunication> m_communication;
		MsgBuilder<MsgRequest> m_packetBuilder;
		uint16_t m_cmdNumber = 0;
		bool m_supportsUTF8{false};
		MsgResponseBuffer m_responseBuffer;
		int m_countOfRetries = 0;
		std::mutex m_mutex;
	};
}
