// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#pragma once

#include <IO/DeviceCommunication/Detail/PhoenixSingleton.h>
#include <IO/DeviceCommunication/Device.h>
#include <IO/DeviceCommunication/DeviceCommunication.h>
#include <IO/DeviceCommunication/PTCCommunicationStatusCode.h>
#include <IO/DeviceCommunication/Utils/ChannelActivation.h>
#include <IO/DeviceCommunication/Utils/CommandList.h>
#include <IO/DeviceCommunication/Utils/DeviceList.h>
#include <IO/DeviceCommunication/Utils/ItemList.h>

#include <functional>
#include <map>
#include <optional>

#pragma warning(push)
#pragma warning(disable: 26812) // The enum type '...' is unscoped. Prefer 'enum class' over 'enum' (Enum.3).

namespace Polytec::IO
{
	/// <summary>
	/// The communication resource is a helper class to implement the C interface of
	/// PolyDeviceCommunication and PolyDataAcquisition. It's singleton instance is accessed by the
	/// CommunicationHandleManager.
	/// </summary>
	class CommunicationResource
	{
	public:
		CommunicationResource(Polytec::IO::DeviceCommunication communication);
		CommunicationResource(const CommunicationResource&) = delete;
		CommunicationResource& operator=(const CommunicationResource&) = delete;
		CommunicationResource(CommunicationResource&& rhs) = delete;
		CommunicationResource& operator=(CommunicationResource&& rhs) = delete;
		~CommunicationResource() = default;

		Polytec::IO::DeviceCommunication& DeviceCommunication() { return m_deviceCommunication; }
		const Polytec::IO::DeviceList& DeviceList() const { return m_deviceList; }
		const Polytec::IO::CommandList& CommandList(PTCDeviceType deviceType, int deviceNumber);
		Polytec::IO::ItemList& ItemList(PTCDeviceType deviceType, int deviceNumber, PTCDeviceCommand deviceCommand);
		Polytec::IO::ChannelActivation& ChannelActivation();

	private:
		Polytec::IO::DeviceCommunication m_deviceCommunication;
		Polytec::IO::DeviceList m_deviceList;
		std::map<Device, Polytec::IO::CommandList> m_commandLists;
		std::map<std::pair<Device, PTCDeviceCommand>, Polytec::IO::ItemList> m_itemList;
		std::optional<Polytec::IO::ChannelActivation> m_channelActivation;
	};

	std::string GetLastCommunicationError();
	PTCCommunicationStatusCode Try(const std::function<void()>& f);
}

#pragma warning(pop)
