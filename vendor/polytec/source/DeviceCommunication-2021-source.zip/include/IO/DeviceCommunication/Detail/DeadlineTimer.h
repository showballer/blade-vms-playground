// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#pragma once


#include <boost/asio.hpp>

#include <chrono>
#include <functional>

namespace Polytec::IO
{
	/// <summary>
	/// A deadline timer class for IO operations
	/// </summary>
	/// <remarks>
	/// This facilitates to cancel IO operations if a given timeout expires.
	/// </remarks>
	class DeadlineTimer
	{
	public:
		/// <summary>Read handler function type</summary>
		using ReadHandler = std::function<void(const boost::system::error_code&, std::size_t)>;
		/// <summary>Asynchronous read function type</summary>
		using AsyncReadFunction = std::function<void(const ReadHandler&)>;

		explicit DeadlineTimer(boost::asio::io_service& ioService, std::function<void()> onDeadlineExpired);
		[[nodiscard]] std::size_t ReadUntilDeadLine(const std::chrono::duration<float>& timeout, const AsyncReadFunction& asyncRead);

	private:
		void CheckDeadline();

		boost::asio::io_service& m_ioService;
		boost::asio::deadline_timer m_deadlineTimer;
		std::function<void()> m_onDeadlineExpired;
	};
}
