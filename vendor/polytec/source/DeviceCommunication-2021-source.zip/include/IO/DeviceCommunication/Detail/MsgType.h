// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#pragma once

#include <cstddef>

namespace Polytec::IO
{
	/// <summary>The message type identifies the format of a message data packet.</summary>
	enum class MsgType
	{
		/// <summary>An unknown format. This is always an error.</summary>
		Unknown = 0,

		/// <summary>A format for message requests sent to the device. The payload length is limited to an uint16 value.</summary>
		Request = 1,

		/// <summary>A format for message responses sent from the device. The payload length is limited to an uint16 value.</summary>
		Response = 2,

		/// <summary>A service request format. This message type is currently not used.</summary>
		ServiceRequest = 3,

		/// <summary>A service response format. This message type is currently not used.</summary>
		ServiceResponse = 4,

		/// <summary>A format for message requests sent to the device. The payload length is limited to an uint32 value<./summary>
		LargeRequest = 5,

		/// <summary>A format for message responses sent from the device. The payload length is limited to an uint32 value.</summary>
		LargeResponse = 6
	};

	class DataReader;
	class DataWriter;
	class MsgRequest;
	class MsgResponse;

	std::size_t ReadPayloadSize(DataReader& reader, MsgType msgType);
	void WritePacketLength(DataWriter& dataWriter, MsgType msgType, std::size_t payloadSize);
	std::size_t Size(const MsgRequest &packet, MsgType msgType);
	std::size_t Size(const MsgResponse &packet, MsgType msgType);
	MsgType EvaluateMsgType(const MsgRequest &packet);
	MsgType EvaluateMsgType(const MsgResponse &packet);
}
