// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#pragma once


#include <cstddef>
#include <cstdint>
#include <vector>

namespace Polytec::IO
{
	/// <summary>
	/// A message builder for a given message data packet
	/// </summary>
	/// <typeparam name="TPacket">Type of the packet</typeparam>
	template<typename TPacket>
	class MsgBuilder
	{
	public:
		std::vector<std::byte> Build(const TPacket& packet);

	private:
		uint32_t m_sequenceNumber = 0;
	};
}
