// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#pragma once


#include <vector>

namespace Polytec::IO
{
	/// <summary>
	/// A network packet format interface
	/// </summary>
	/// <remarks>
	/// This class is needed to read network packets for streaming protocols
	/// like, e.g. TCP. Since the protocol doesn't offer the ability to send packets, the packet size
	/// has to be retrieved from the packet header. This means that first the header of fixed size
	/// has to be read. The variable length of the packet is retrieved from the header.
	/// </remarks>
	class INetworkPacketFormat
	{
	public:
		#pragma warning(suppress: 26432) // If you define or delete any default operation in the type 'class Polytec::IO::INetworkPacketFormat', define or delete them all (c.21).
		virtual ~INetworkPacketFormat() = default;

		/// <summary>
		/// Gets the base packet header size, which is a constant size. This is the minimum size of a
		/// header containing the information how much data will follow in this packet.
		/// </summary>
		/// <returns>The packet header size.</returns>
		virtual std::size_t GetBaseHeaderSize() const = 0;

		/// <summary>
		/// Gets packet body size. This size is variable and is retrieved from the header. Packet size
		/// equals body size plus base header size.
		/// </summary>
		/// <param name="header">The header.</param>
		/// <returns>The packet body size.</returns>
		virtual std::size_t GetBodySize(const std::vector<std::byte>& header) const = 0;
	};
}
