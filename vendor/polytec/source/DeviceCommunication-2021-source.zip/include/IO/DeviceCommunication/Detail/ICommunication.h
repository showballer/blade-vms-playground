// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#pragma once


#include <chrono>
#include <string>
#include <vector>

namespace Polytec::IO
{
	/// <summary>Generic communication handler interface</summary>
	class ICommunication
	{
	public:
		ICommunication() = default;
		ICommunication(const ICommunication&) = default;
		ICommunication(ICommunication&&) = default;
		ICommunication& operator=(const ICommunication&) = default;
		ICommunication& operator=(ICommunication&&) = default;
		virtual ~ICommunication() = default;

		/// <summary>Sends data to the device.</summary>
		/// <param name="data">The binary data to be sent.</param>
		virtual void SendData(const std::vector<std::byte>& data) = 0;

		/// <summary>Receives data from the device within the defined timeout.</summary>
		/// <returns>Returns the received data. Returns empty data if the timeout has expired.</returns>
		virtual std::vector<std::byte> ReceiveData() = 0;

		/// <summary>Sets a timeout for IO operations. If this timeout expires, the operation is canceled.</summary>
		/// <param name="timeout">The timeout.</param>
		virtual void SetTimeout(const std::chrono::duration<float>& timeout) = 0;

		/// <summary>Get the timeout for IO operations. If this timeout expires, the operation is canceled.</summary>
		/// <returns>The timeout.</returns>
		virtual std::chrono::duration<float> GetTimeout() const = 0;

		/// <summary>
		/// Gets the device IP address. If the device has no IP address as e.g. for a serial
		/// communication, an empty string is returned.
		/// </summary>
		/// <returns>The device IP address as string.</returns>
		virtual std::wstring DeviceIPAddress() const = 0;

		/// <summary>
		/// Gets the response port to which the device should send its response. In case of a serial
		/// communication this is not needed and zero is returned.
		/// </summary>
		/// <returns>The response port.</returns>
		virtual int ResponsePort() const = 0;
	};
}
