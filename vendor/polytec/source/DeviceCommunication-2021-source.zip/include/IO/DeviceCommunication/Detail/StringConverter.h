// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#pragma once


#include <string>
#include <vector>

namespace Polytec::IO
{
	std::string ToString(const std::wstring& wstr);
	std::wstring ToWString(const std::string& str);

	std::vector<std::byte> Latin1FromUTF8(const std::vector<std::byte>& data);
	std::vector<std::byte> UTF8FromLatin1(const std::vector<std::byte>& data);

	std::wstring UnicodeFromLatin1(const std::string& latin);
	std::string Latin1FromUnicode(const std::wstring& unicode);
}
