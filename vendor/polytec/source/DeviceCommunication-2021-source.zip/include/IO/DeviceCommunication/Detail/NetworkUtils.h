// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#pragma once

#include <IO/DeviceCommunication/CommunicationException.h>

#include <boost/system/system_error.hpp>

namespace boost::asio
{
	class io_context;
}

namespace Polytec::IO
{
	bool IsReservedPort(int port);
	int NumberOfReservedPorts();

	/// <summary>Creates and binds a socket to a free port outside the reserved range of ports for Polytec devices.</summary>
	/// <exception cref="std::logic_error">Raised when no port could be found.</exception>
	/// <typeparam name="TProtocol">The network protocol, e.g. UDP, TCP.</typeparam>
	/// <param name="ioContext">[in,out] Context for the i/o.</param>
	/// <returns>The socket.</returns>
	template <typename TProtocol>
	typename TProtocol::socket CreateSocket(boost::asio::io_context& ioContext)
	{
		for (int attempt = 0; attempt <= NumberOfReservedPorts(); attempt++)
		{
			auto socket = typename TProtocol::socket(ioContext, typename TProtocol::endpoint(TProtocol::v4(), 0));
			if (!IsReservedPort(socket.local_endpoint().port()))
			{
				return socket;
			}
		}
		throw std::logic_error("No port could be found."); // here it is assumed, that the OS iterates through the ports and thus will find a port outside the reserved range
	}

	/// <summary>
	/// Resolves the hostname and returns the device endpoint.
	/// </summary>
	/// <exception cref="CommunicationException">A communication exception is thrown when the hostname
	/// can't be resolved.</exception>
	/// <typeparam name="TProtocol">The network protocol, e.g. UDP, TCP.</typeparam>
	/// <param name="ioContext">[in,out] The i/o context.</param>
	/// <param name="hostname">The hostname or IP address.</param>
	/// <param name="port">The port.</param>
	/// <returns>The endpoint.</returns>
	template <typename TProtocol>
	typename TProtocol::endpoint ResolveHostname(boost::asio::io_context& ioContext, const std::string& hostname, int port)
	{
		try
		{
			typename TProtocol::resolver resolver(ioContext);
			return *resolver.resolve({TProtocol::v4(), hostname, std::to_string(port)});
		}
		catch (const boost::system::system_error& e)
		{
			throw CommunicationException(PTCCommunicationStatusCode_SystemError,
				"Failed to resolve hostname: " + std::string(e.what()));
		}
	}
}
