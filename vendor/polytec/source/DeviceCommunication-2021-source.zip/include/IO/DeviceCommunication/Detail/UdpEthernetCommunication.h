// Copyright (c) 2016-2021 Polytec GmbH, Waldbronn
// Released under the terms of the GNU Lesser General Public License version 3.

#pragma once

#include <IO/DeviceCommunication/Detail/DeadlineTimer.h>
#include <IO/DeviceCommunication/Detail/ICommunication.h>

#include <boost/asio.hpp>

namespace Polytec::IO
{
	/// <summary>A handler for UDP communications</summary>
	class UdpEthernetCommunication : public ICommunication
	{
	public:
		explicit UdpEthernetCommunication(const std::wstring& hostname);

		UdpEthernetCommunication(const UdpEthernetCommunication&) = delete;
		UdpEthernetCommunication& operator=(const UdpEthernetCommunication&) = delete;
		UdpEthernetCommunication(UdpEthernetCommunication&&) = default;
		UdpEthernetCommunication& operator=(UdpEthernetCommunication&&) = default;

		std::vector<std::byte> ReceiveData() override;
		void SendData(const std::vector<std::byte>& data) override;
		int ResponsePort() const override;
		std::wstring DeviceIPAddress() const override;
		void SetTimeout(const std::chrono::duration<float>& timeout) override { m_timeout = timeout; }
		std::chrono::duration<float> GetTimeout() const override { return m_timeout; }

	private:
		std::vector<std::byte> TryReceiveData();

		// The member variables m_ioService and m_deadline are also used by SerialCommunication.
		// They are placed in the concrete classes because they are an implementation detail.
		boost::asio::io_service m_ioService;
		std::vector<std::byte> m_buffer;
		boost::asio::ip::udp::socket m_socket;
		boost::asio::ip::udp::endpoint m_deviceEndpoint;
		boost::asio::ip::udp::endpoint m_senderEndpoint;
		DeadlineTimer m_deadlineTimer;
		std::chrono::duration<float> m_timeout = std::chrono::seconds(2);
	};
}
